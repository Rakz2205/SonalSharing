
package com.utilities.javaUtils;

import com.github.javafaker.Faker;
import io.codearte.jfairy.Fairy;

import java.util.Locale;
import java.util.Random;

public class DataGeneratorUtility {


    //  generate 10 digit random unique number
    //  the implementation will not generate purely unique number
    //  In about 32 years this ID could be repeated
    public static long generateTenDigitNumber() {
        try {
            final long LIMIT = 10000000000L;
            long last = 0;

            long id = (System.currentTimeMillis() / 100) % LIMIT;
            if (id <= last) {
                id = (last + 1) % LIMIT;
            }
            return id;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateMobileNumber() {
        try {
            Random random = new Random();
            String num2 = "";

            int num = random.nextInt(900000000) + 100000000;
            String str = String.valueOf(num);

            boolean loop = true;
            while (loop) {
                int num1 = random.nextInt(9);
                if (num1 == 9 || num1 == 8 || num1 == 7) {
                    loop = false;
                    num2 = String.valueOf(num1);
                }
            }
            return num2 + str;
        } catch (Exception e) {
            throw new RuntimeException("Error while generating Mobile Number " + e.getMessage());
        }
    }

    public static String generatePan() {
        try {
            Random random = new Random();
            return ("AJWPQ" + (random.nextInt(9999) + 1) + "P");
        } catch (Exception e) {
            throw new RuntimeException("Error while generating pan number " + e.getMessage());
        }
    }

    public static String getAlphaNumericString(int stringLength) {
        try {
            // chose a Character random from this String
            String alphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    + "0123456789"
                    + "abcdefghijklmnopqrstuvxyz";

            StringBuilder stringBuilder = new StringBuilder(stringLength);
            for (int i = 0; i < stringLength; i++) {
                int index
                        = (int) (alphaNumericString.length()
                        * Math.random());

                stringBuilder.append(alphaNumericString
                        .charAt(index));
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            throw new RuntimeException("error while generating the Alpha-Numeric string.", e);
        }
    }

    public static String getNumericString(int stringLength) {
        try {
            String alphaNumericString = "0123456789";
            StringBuilder stringBuilder = new StringBuilder(stringLength);
            for (int i = 0; i < stringLength; i++) {
                int index
                        = (int) (alphaNumericString.length()
                        * Math.random());

                stringBuilder.append(alphaNumericString
                        .charAt(index));
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            throw new RuntimeException("error while generating the Alpha-Numeric string.", e);
        }
    }

    public static Faker getFakeTestData(){
        Faker faker=new Faker(new Locale("en-IND"));
        return faker;
    }

    public static Fairy getDataFromJFairy(){
        Fairy fairy = Fairy.create();
        return fairy;
    }
}
