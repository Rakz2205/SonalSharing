package com.utilities.webUtils;

public class AssertUtility {
}
