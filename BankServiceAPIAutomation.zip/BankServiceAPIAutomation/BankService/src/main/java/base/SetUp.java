package base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utilities.fileUtils.PropertiesUtility;
import com.utilities.reportUtils.ExtentUtility;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.sql.Connection;
import java.util.Properties;

public class SetUp implements Constants {

    public static Properties properties;
    public static Properties apiProperties;
    public static String testDataSheetPath;
    public static ExtentReports extentReports;
    public static ExtentTest extentTest;
    public static ExtentTest extentTestChildNode;
    public static String testName = "";
    public static Connection dbBankService = null;
    public static Connection dbCBS1 = null;
    public static Connection dbCBS2 = null;
    public static Connection dbCBS3 = null;
    public static Connection dbCBS4 = null;
    public static Connection dbTransactionService = null;
    public static Connection dbAuthenticationPSP = null;
    public static Connection dbVAM = null;
    public static Connection dbNodalAccount = null;

    @BeforeSuite(groups = {"UPI", "AEPS", "eNach", "All", "sanity"})
    public void beforeSetUp() {
        try {

            properties = PropertiesUtility.getApplicationProperties("ApiProperties//config.properties");
            testDataSheetPath = System.getProperty("user.dir") + "//TestData//" + properties.getProperty("TestDataFileName");

            extentReports = ExtentUtility.createReport("//TestReport//" + properties.getProperty("ExtentTestName"));
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                //  api PP properties

            } else {
                //  api SIT properties
                apiProperties = PropertiesUtility.getApplicationProperties("ApiProperties//endPointsSIT.properties");
            }

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @AfterSuite(groups = {"UPI", "AEPS", "eNach", "All", "sanity"})
    public void cleanUp() {
        try {
            extentReports.flush();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}
