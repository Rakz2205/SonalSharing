package base;

import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.connectionUtils.UnixUtility;

import java.sql.Connection;
import java.sql.SQLException;

public class ConnectionSetup extends SetUp {

    public static void createTestConnections() {
        try {
            //  Create database connection
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                dbBankService = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty(""), properties.getProperty(""), properties.getProperty(""));
            } else {
                if (dbBankService == null)
                    dbBankService = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_BankService_UserHost"),
                            properties.getProperty("DB_BankService_Username"), properties.getProperty("DB_BankService_Password"));

                if (dbCBS2 == null) {
                    dbCBS2 = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_CBS_2_UserHost"),
                            properties.getProperty("DB_CBS_Username"), properties.getProperty("DB_CBS_Password"));
                }

                if (dbTransactionService == null) {
                    Thread.sleep(2000);
                    dbTransactionService = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_TransactionService_UserHost"),
                            properties.getProperty("DB_TransactionService_Username"), properties.getProperty("DB_TransactionService_Password"));
                }

                if (dbAuthenticationPSP == null)
                    dbAuthenticationPSP = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_PSP_AUTH_UserHost_New"),
                            properties.getProperty("DB_PSP_AUTH_Username_New"), properties.getProperty("DB_PSP_AUTH_Password_New"));
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void createVAMConnection() {
        try {
            //  Create database connection
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                dbVAM = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty(""), properties.getProperty(""), properties.getProperty(""));
            } else {
                if (dbVAM == null) {
                    Thread.sleep(2000);
                    dbVAM = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_VAM_UserHost"),
                            properties.getProperty("DB_VAM_Username"), properties.getProperty("DB_VAM_Password"));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void createCBSConnection() {
        try {
            //  Create database connection
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                dbVAM = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty(""), properties.getProperty(""), properties.getProperty(""));
            } else {
                if (dbCBS1 == null) {
                    dbCBS1 = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_CBS_1_UserHost"),
                            properties.getProperty("DB_CBS_Username"), properties.getProperty("DB_CBS_Password"));
                }

                if (dbCBS3 == null) {
                    dbCBS3 = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_CBS_3_UserHost"),
                            properties.getProperty("DB_CBS_Username"), properties.getProperty("DB_CBS_Password"));
                }

                if (dbCBS4 == null) {
                    dbCBS4 = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_CBS_4_UserHost"),
                            properties.getProperty("DB_CBS_Username"), properties.getProperty("DB_CBS_Password"));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void createNodalAccountConnection() {
        try {
            //  Create database connection
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                dbNodalAccount = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty(""), properties.getProperty(""), properties.getProperty(""));
            } else {
                if (dbNodalAccount == null) {
                    Thread.sleep(500);
                    dbNodalAccount = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_Nodal_UserHost"),
                            properties.getProperty("DB_Nodal_Username"), properties.getProperty("DB_Nodal_Password"));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the nodal account database connections.", e);
        }
    }

    public static void createSSHConnections() {
        try {
            //  Create unix session
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                UnixUtility.createUnixConnection(properties.getProperty("PP_UnixHostname"),
                        properties.getProperty("PP_UnixUsername"), properties.getProperty("PP_UnixPassword"), Integer.parseInt(properties.getProperty("UnixPort")));
            } else {
                UnixUtility.createUnixConnection(properties.getProperty("SIT_UnixHostname"),
                        properties.getProperty("SIT_UnixUsername"), properties.getProperty("SIT_UnixPassword"), Integer.parseInt(properties.getProperty("UnixPort")));
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the SSH connections.", e);
        }
    }

    public static void closeSSHConnections() {
       /* try {
            if (UnixUtility.session != null) {
                UnixUtility.session.disconnect();
            }

        } catch (Exception e) {
            throw new RuntimeException("error while closing the SSH connection.", e);
        }*/
    }

    public static void closeVAMConnection() {
        try {
            dbVAM.close();
        } catch (Exception e) {
            throw new RuntimeException("error while closing the test connections.", e);
        }
    }

    public static void closeTestConnections() {

        closeConnection(dbBankService);
        dbBankService = null;

        closeConnection(dbCBS1);
        dbCBS1 = null;

        closeConnection(dbCBS2);
        dbCBS2 = null;

        closeConnection(dbCBS3);
        dbCBS3 = null;

        closeConnection(dbCBS4);
        dbCBS4 = null;

        closeConnection(dbTransactionService);
        dbTransactionService = null;

        closeConnection(dbAuthenticationPSP);
        dbAuthenticationPSP = null;

        closeConnection(dbNodalAccount);
        dbNodalAccount = null;
    }

    private static void closeConnection(Connection c) {
        try {
            if (c != null) {
                c.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
