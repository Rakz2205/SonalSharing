package base;

public interface Constants {

    String TYPE_TRANSACTION = "Transaction";
    String TYPE_NON_TRANSACTION = "NonTransaction";
    String TYPE_AUTHENTICATION = "Authentication";

    String log_Type_Pass = "Pass";
    String log_Type_Fail = "Fail";
    String log_Type_Log = "Log";

    String Type_Permanent_Address = "PER_ADDR";
    String Type_Correspondence_Address = "CURR_ADDR";

    // Transaction Service related data
    Integer CURRENCY_CODE = 356;
    Integer TYPE_DEBIT = 111;
    Integer TYPE_CREDIT = 213;
    Integer TYPE_AUTH = 301;
    Integer TYPE_CANCEL = 215;
    Integer TYPE_CAPTURE = 113;
    Integer TYPE_REVERSAL = 302;
    Integer TYPE_FUND_TRANSFER = 423;
    Integer SUB_TYPE_DEBIT_REVERSAL = 527;
    Integer SUB_TYPE_CREDIT_REVERSAL = 526;

    //  Default SIT Payer
    String DEFAULT_SIT_PAYER_ACCOUNT = "30000000036468";
    String DEFAULT_SIT_PAYER_NAME = "Omkar Vilas Shinde";
    String DEFAULT_SIT_PAYER_BANK_IFSC = "JIOP0000001";
    Integer DEFAULT_SIT_PAYER_TYPE = 1;

    //  Default Payer
    String DEFAULT_PP_PAYER_ACCOUNT = "30000000036468";
    String DEFAULT_PP_PAYER_NAME = "Omkar Vilas Shinde";
    String DEFAULT_PP_PAYER_BANK_IFSC = "JIOP0000001";
    Integer DEFAULT_PP_PAYER_TYPE = 1;

    //  Default GL account
    String DEFAULT_SIT_GL_ACCOUNT = "4000003563503000";
    String DEFAULT_SIT_GL_ACCOUNT_1 = "30000000033817";
    String DEFAULT_SIT_GL_ACCOUNT_2 = "30000000040872";

    //Default SIT Payee
    String DEFAULT_SIT_PAYEE_ACCOUNT = "30000000041364";
    String DEFAULT_SIT_PAYEE_NAME = "Vasil Grudev";
    String DEFAULT_SIT_PAYEE_BANK_IFSC = "JIOP0000001";
    Integer DEFAULT_SIT_PAYEE_TYPE = 1;

    //Default PP Payee
    String DEFAULT_PP_PAYEE_ACCOUNT = "30000000031911";
    String DEFAULT_PP_PAYEE_NAME = "Vasil Grudev";
    String DEFAULT_PP_PAYEE_BANK_IFSC = "JIOP0000001";
    Integer DEFAULT_PP_PAYEE_TYPE = 1;

    //DEBIT FREEZE SIT ACCOUNT DETAILS
    String DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT = "30000000040031";
    String DEFAULT_SIT_DEBIT_FREEZE_BANK_IFSC = "JIOP0000001";

    //CREDIT FREEZE SIT ACCOUNT DETAILS
    String DEFAULT_SIT_CREDIT_FREEZE_ACCOUNT = "30000000040244";
    String DEFAULT_SIT_CREDIT_FREEZE_BANK_IFSC = "JIOP0000001";

    //CREDIT FREEZE PP ACCOUNT DETAILS
    String DEFAULT_PP_CREDIT_FREEZE_ACCOUNT = "30000000040244";
    String DEFAULT_PP_CREDIT_FREEZE_BANK_IFSC = "JIOP0000001";

    //TOTAL FREEZE SIT ACCOUNT DETAILS
    String DEFAULT_SIT_TOTAL_FREEZE_ACCOUNT = "30000000033752";
    //String DEFAULT_SIT_TOTAL_FREEZE_ACCOUNT = "30000000042050";
    String DEFAULT_SIT_TOTAL_FREEZE_BANK_IFSC = "JIOP0000001";

    //TOTAL FREEZE PP ACCOUNT DETAILS
    String DEFAULT_PP_TOTAL_FREEZE_ACCOUNT = "30000000042050";
    String DEFAULT_PP_TOTAL_FREEZE_BANK_IFSC = "JIOP0000001";

    //TOTAL FREEZE SIT ACCOUNT DETAILS
    String DEFAULT_SIT_CLOSED_ACCOUNT = "30000000040970";
    String DEFAULT_SIT_CLOSED_BANK_IFSC = "JIOP0000001";

    //TOTAL FREEZE PP ACCOUNT DETAILS
    String DEFAULT_PP_CLOSED_ACCOUNT = "30000000040970";
    String DEFAULT_PP_CLOSED_BANK_IFSC = "JIOP0000001";

    //Current ACCOUNT SIT
    String SIT_CURRENT_ACCOUNT = "30000000042298";
    String SIT_CURRENT_ACCOUNT_BANK_IFSC = "JIOP0000001";

    String SIT_CURRENT_CLOSED_ACCOUNT = "30000000040945";
    String SIT_CURRENT_CLOSED_ACCOUNT_BANK_IFSC = "JIOP0000001";

    String SIT_CURRENT_TOTAL_FREEZE_ACCOUNT = "30000000041933";
    String SIT_CURRENT_TOTAL_FREEZE_ACCOUNT_BANK_IFSC = "JIOP0000001";

    String SIT_CURRENT_DEBIT_FREEZE_ACCOUNT = "30000000039530";
    String SIT_CURRENT_DEBIT_FREEZE_ACCOUNT_BANK_IFSC = "JIOP0000001";

    String SIT_CURRENT_CREDIT_FREEZE_ACCOUNT = "30000000039548";
    String SIT_CURRENT_CREDIT_FREEZE_ACCOUNT_BANK_IFSC = "JIOP0000001";

    //INACTIVE OR DORMANT_ACCOUNT
    String SIT_DORMANT_ACCOUNT = "30000000033922";
    String SIT_DORMANT_ACCOUNT_BANK_IFSC = "JIOP0000001";

    String SIT_CURRENT_DORMANT_ACCOUNT = "30000000037804";
    String SIT_CURRENT_DORMANT_ACCOUNT_BANK_IFSC = "JIOP0000001";

    //Transaction SubType
    Integer SUB_TYPE_576 = 576;
    Integer SUB_TYPE_525 = 525;
    Integer SUB_TYPE_524 = 524;
    Integer SUB_TYPE_523 = 523;
    Integer SUB_TYPE_580 = 580;
    Integer SUB_TYPE_550 = 550;

    //Application Type
    Integer APPLICATION_ID_3132 = 3132;
    Integer APPLICATION_ID_9000 = 9000;
    Integer APPLICATION_ID_8012 = 8012;

    Integer APPLICATION_ID_8011 = 8011;
    Integer APPLICATION_ID_3133 = 3133;
    Integer APPLICATION_ID_8013 = 8013;
    Integer INVALID_APP_ID_1111 = 1111;

    //Entity IDs
    Integer ENTITY_ID_8001 = 8001;
    Integer INVALID_ENTITY_ID_9999 = 9999;
    Integer ENTITY_ID_8011 = 8011;
    Integer ENTITY_ID_8012 = 8012;
    Integer ENTITY_ID_8013 = 8013;
    Integer ENTITY_ID_9000 = 9000;

    //ERROR CODES
    String ERROR_CODE_30503 = "30503";
    String ERROR_CODE_30509 = "30509";
    String ERROR_CODE_6011 = "6011";
    String ERROR_CODE_30508 = "30508";
    String ERROR_CODE_30000 = "30000";
    String ERROR_CODE_30504 = "30504";
    String ERROR_CODE_30505 = "30505";
    String ERROR_CODE_21021 = "21021";
    String ERROR_CODE_30506 = "30506";
    String ERROR_CODE_30514 = "30514";
    String ERROR_CODE_21024 = "21024";
    String ERROR_CODE_21004 = "21004";
    String ERROR_CODE_21005 = "21005";
    String ERROR_CODE_30515 = "30515";
    String ERROR_CODE_30507 = "30507";
    String ERROR_CODE_30518 = "30518";
    String ERROR_CODE_21002 = "21002";
    String ERROR_CODE_50011 = "50011";
    String ERROR_CODE_30520 = "30520";
    String ERROR_CODE_30526 = "30526";
    String ERROR_CODE_30524 = "30524";
    String ERROR_CODE_30523 = "30523";
    String ERROR_CODE_5904 = "5904";
    String ERROR_CODE_5906 = "5906";
    String ERROR_CODE_5909 = "5909";
    String ERROR_CODE_50100 = "50100";
    String ERROR_CODE_30529 = "30529";


    //ERROR MESSAGES
    String INVALID_VALUE_TRAN_MSG = "Invalid value :transaction";
    String INVALID_SOME_TECHNICAL_ERROR_MSG = "Some technical error occurred. Please try after some time!";
    String INVALID_MESSAGE_FORMAT_ERROR_MSG = "Message Format Error";
    String INVALID_SYSTEM_MALFUNCTION = "System Malfunction";
    String INVALID_TRANSACTION_NOT_FOUND_MSG = "Transaction not found";
    String INVALID_CURRENCY_ERROR_MSG = "Currency provided is invalid";
    String INVALID_TRANSACTION_ERROR_MSG = "transaction must not be null";
    String INVALID_IDEMPOTENT_KEY_ERROR_MSG = "idempotentKey must not be null";
    String INVALID_INVOICE_ERROR_MSG = "invoice must not be null";
    String INVALID_CURRENCY_ERROR_MSG_1 = "currency must not be null";
    String INVALID_CURRENCY_ERROR_MSG_3 = "Currency provided is invalid";
    String INVALID_SUBTYPE_ERROR_MSG = "Method SubType provided is invalid";
    String INVALID_MODE_ERROR_MSG = "Payment Mode provided is invalid";
    String INVALID_METHOD_ERROR_MSG = "method must not be null";
    String INVALID_CAPTURE_METHOD_ERROR_MSG = "Capture Method provided is invalid";
    String INVALID_LIVE_MODE_ERROR_MSG = "livemode must not be null";
    String INVALID_APPLICATION_ID_ERROR_MSG = "application must not be null";
    String INVALID_TIMESTAMP_ERROR_MSG = "initiatingEntityTimestamp must not be null";
    String INVALID_METHOD_TYPE_MSG_1 = "Method Type provided is invalid";
    String INVALID_METHOD_TYPE_MSG_2 = "type must not be null";
    String MESSAGE_FORMAT_ERROR = "Message Format Error";
    String INVALID_VALUE_AMOUNT_ERROR_MSG = "Invalid value :amount";
    String INVALID_PAYER_TYPE_ERROR_MSG = "Payer Type provided is invalid";
    String PAYER_DETAILS_REQUIRED_ERROR_MSG = "Payer details are required.";
    String SYSTEM_MALFUNCTION_ERROR_MESSAGE = "System Malfunction";
    String INSUFFICIENT_FUNDS_ERROR_MSG = "Insufficient Funds";
    String INVALID_VALUE_PAYER_ERROR_MSG = "Invalid value :payer";
    String TRANSACTION_NOT_PERMITTED_ERROR_MSG = "Transaction Not Permitted to Card Holder";
    String INVALID_INITIATING_ENTITY_ERROR_MSG = "initiatingEntity must not be null";
    String INVALID_ENTITY_ERROR_MSG = "entityId must not be null";
    String INVALID_AMOUNT_ERROR_MSG = "Invalid value :amount";
    String INVALID_PAYEE_ERROR_MSG = "Payee details are required.";
    String INVALID_PAYEE_TYPE_ERROR_MSG = "Payee Type provided is invalid";
    String INVALID_VALUE_PAYEE = "Invalid value :payee";
    String INVALID_NON_JBP_ACCOUNT_MSG = "Non JPB Account";
    String INVALID_ACCOUNT_NUMBER = "Invalid Account Number";
    String INVALID_TRANSACTION_NOT_PERMITTED = "Transaction Not Permitted to Card Holder";
    String INVALID_AMOUNT = "Invalid amount";
    String INVALID_PAYEE_ACCOUNT = "Payee account number is invalid";
    String INVALID_ACCOUNT_DETAILS = "Invalid account details";
    String INVALID_FREEZE_MSG = "Invalid account details";
    String ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG = "Account either freezed or invalid account details";
    String VIRTUAL_ACCOUNT_NOT_EXIST = "Virtual Account does not exist";
    String ACCOUNT_IS_INACTIVE = "Account is Inactive ";
    String VIRTUAL_ACCOUNT_NOT_ACTIVE = "Not able to update virtual account Virtual Account number is already ACTIVE";
    String VIRTUAL_ACCOUNT_NOT_DEACTIVATED = "Not able to update virtual account Virtual Account number is already DEACTIVATED";
    String INTERNAL_TECHNICAL_ERROR = "Internal technical error.";

    String ACTION_SET = "set";
    String ACTION_DELETE = "delete";

    //paramsName
    String TRANSACTION = "transaction";
    String IDEMPOTENT_KEY = "idempotentKey";
    String CURRENCY = "currency";
    String INVOICE = "invoice";
    String METHOD = "method";
    String METHOD_TYPE = "methodType";
    String METHOD_SUBTYPE = "methodSubType";
    String MODE = "mode";
    String LIVE_MODE = "livemode";
    String APPLICATION_ID = "application";
    String INITIATING_ENTITY_TIMESTAMP = "timestamp";
    String INITIATING_ENTITY = "initiatingEntity";
    String ENTITY_ID = "entityId";
    String CALLBACK_URL = "callbackUrl";
    String CAPTURE_METHOD = "captureMethod";
    String ORIGINAL_ID = "originalId";
    String AUTHORIZATION_CODE = "authorizationCode";
    String AMOUNT = "amount";
    String AMOUNT_NET_AMOUNT = "netAmount";
    String AMOUNT_GROSS_AMOUNT = "grossAmount";
    String PAYER = "payer";
    String PAYEE = "payee";
    String TYPE = "type";
    String ACCOUNT_NUMBER = "accountNumber";
    String BANK_IFSC = "bankIfsc";
    String BANK_CUSTOMER_ID = "bankCustomerID";
    String CUSTOMER_ACCOUNT_NUMBER = "bankAccountNumber";
    String AUTH_CODE = "authorizationCode";
    String VIRTUAL_ACCOUNT_ID = "id";
    String VIRTUAL_ACCOUNT_CLIENT_CODE = "clientCode";
    String VIRTUAL_ACCOUNT_ACCOUNT_STATUS = "accountStatus";
    String VIRTUAL_ACCOUNT_NUMBER = "virtualAccountNumber";
    String VIRTUAL_ACCOUNT_CUSTOMER_CODE = "customerCode";
    String VIRTUAL_ACCOUNT_CUSTOMER_NAME = "customerName";
    String VIRTUAL_ACCOUNT_CUSTOMER_EMAIL = "emailId";
    String VIRTUAL_ACCOUNT_CREATED_BY = "createdBy";


    String PATH_TRANSACTION = "transaction";
    String PATH_IDEMPOTENT_KEY = "transaction.idempotentKey";
    String PATH_CURRENCY = "transaction.currency";
    String PATH_INVOICE = "transaction.invoice";
    String PATH_METHOD = "transaction.method";
    String PATH_METHOD_TYPE = "transaction.method.type";
    String PATH_METHOD_SUBTYPE = "transaction.method.subType";
    String PATH_MODE = "transaction.mode";
    String PATH_LIVE_MODE = "transaction.livemode";
    String PATH_APPLICATION_ID = "transaction.application";
    String PATH_INITIATING_ENTITY_TIMESTAMP = "transaction.initiatingEntityTimestamp";
    String PATH_INITIATING_ENTITY = "transaction.initiatingEntity";
    String PATH_ENTITY_ID = "transaction.initiatingEntity.entityId";
    String PATH_CALLBACK_URL = "transaction.initiatingEntity.callbackUrl";
    String PATH_CAPTURE_METHOD = "transaction.captureMethod";
    String PATH_ORIGINAL_ID = "transaction.originalId";
    String PATH_AUTHORIZATION_CODE = "transaction.authorizationCode";
    String PATH_AMOUNT = "amount";
    String PATH_AMOUNT_NET_AMOUNT = "amount.netAmount";
    String PATH_AMOUNT_GROSS_AMOUNT = "amount.grossAmount";
    String PATH_PAYER = "payer";
    String PATH_PAYER_TYPE = "payer.type";
    String PATH_PAYER_ACCOUNT_NUMBER = "payer.accountNumber";
    String PATH_PAYER_BANK_IFSC = "payer.bankIfsc";
    String PATH_PAYEE = "payee";
    String PATH_PAYEE_TYPE = "payee.type";
    String PATH_PAYEE_ACCOUNT_NUMBER = "payee.accountNumber";
    String PATH_PAYEE_BANK_IFSC = "payee.bankIfsc";
    String PATH_BANK_CUSTOMER_ID = "bankCustomerID";
    String PATH_AUTH_AUTHORIZATION_CODE = "authorizationCode[0].code";
    String PATH_BANK_ACCOUNT_NUMBER = "bankAccountNumber";
    String PATH_ID = "id";
    String PATH_CLIENT_CODE = "clientCode";
    String PATH_ACCOUNT_STATUS = "accountStatus";
    String PATH_ACCOUNT_NUMBER = "virtualAccountNumber";
    String PATH_CUSTOMER_CODE = "customerCode";
    String PATH_CUSTOMER_NAME = "customerName";
    String PATH_CUSTOMER_EMAIL_1 = "emailId1";
    String PATH_CREATED_BY = "createdBy";

    //ACCOUNT TYPES
    String DEBIT_FREEZE = "DEBIT FREEZE";
    String TOTAL_FREEZE = "TOTAL FREEZE";
    String CLOSED_ACCOUNT = "CLOSED ACCOUNT";
    String DORMANT_ACCOUNT = "DORMANT ACCOUNT";

    String AUTH_MPIN_TYPE = "7";
    String VALIDATION_DOB_TYPE = "1";

    int VALIDATION_SET_DOB_AUTH_CODE = 5;
    int VALIDATION_RESET_DOB_AUTH_CODE = 6;
    int VALIDATION_DIGITAL_SIGNATURE_DOB = 7;

    String MPIN_MOBILE_NUMBER = "mobile";
    String MPIN_BANK_CUSTOMER_ID = "bankCustomerId";

    int AUTH_MODE_OTP = 1;
    int AUTH_MODE_MPIN = 7;
    int AUTH_MODE_FACE = 9;
    int AUTH_MODE_FINGERPRINT = 10;
    int AUTH_MODE_UPI_PIN = 11;
    int AUTH_MODE_DEBIT_PIN = 12;
    int AUTH_MODE_EXTEND_SESSION = 14;
    int AUTH_MODE_VALIDATE_SESSION = 15;

    //  Transaction Modes
    Integer MODE_1 = 1;
    Integer MODE_2 = 2;
    Integer MODE_3 = 3;
    Integer MODE_4 = 4;
    Integer MODE_5 = 5;

    //  Nodal constant
    String REMOTE_FILE_PRIVATE_KEY_PASS = "payoutpgp";

    String SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH = "/app/payout/transaction/rpsl/input/";
    String SIT_NODAL_ACCOUNT_SFTP_IN_PROCESS_PATH = "/app/payout/transaction/rpsl/inputprocessed/";
    String SIT_NODAL_ACCOUNT_SFTP_IN_ERROR_PATH = "/app/payout/transaction/rpsl/inputerror/";

    String SIT_NODAL_ACCOUNT_SFTP_OUT_DIR_PATH = "/app/payout/transaction/rpsl/output/";
    String SIT_NODAL_ACCOUNT_SFTP_OUT_PROCESS_PATH = "/app/payout/transaction/rpsl/outputprocessed/";
    String SIT_NODAL_ACCOUNT_SFTP_OUT_ERROR_PATH = "/app/payout/transaction/rpsl/outputerror/";

    String Type_Authentication = "Authentication";
}

