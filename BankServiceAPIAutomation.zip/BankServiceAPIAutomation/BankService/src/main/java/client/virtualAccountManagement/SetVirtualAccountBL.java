package client.virtualAccountManagement;

import base.Constants;
import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DataGeneratorUtility;
import entity.Header;
import entity.virtualAccountManagement.SetVirtualAccountEntity;
import io.restassured.response.Response;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.errorEntity.ErrorResponse;
import responseEntity.virtualAccountManagement.SetVirtualAccountResponseEntity;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.util.Map;

public class SetVirtualAccountBL extends SetUp {

    Gson request = new Gson();
    public SetVirtualAccountEntity setVirtualAccountEntity;

    public String createSetVirtualAccountPayload(Map<Object, Object> testData, boolean isActive) {
        try {

            setVirtualAccountEntity = new SetVirtualAccountEntity();
            String code = DataGeneratorUtility.getNumericString(5);

            setVirtualAccountEntity.setId(code);
            setVirtualAccountEntity.setClientCode((String) testData.get("CORPORATE_CLIENT_CODE"));

            if (isActive)
                setVirtualAccountEntity.setAccountStatus(1);
            else
                setVirtualAccountEntity.setAccountStatus(0);

            setVirtualAccountEntity.setVirtualAccountNumber((String) testData.get("VIRTUAL_ACCOUNT_NUMBER"));
            setVirtualAccountEntity.setCustomerCode((String) testData.get("CORPORATE_CUSTOMER_CODE"));
            setVirtualAccountEntity.setCustomerName((String) testData.get("CUSTOMER_NAME"));

            setEmailForVirtualAccount((String) testData.get("CUSTOMER_EMAIL"), setVirtualAccountEntity);
            setVirtualAccountEntity.setCreatedBy(System.getProperty("user.name"));

            String payload = request.toJson(setVirtualAccountEntity);
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while creating the set virtual account payload.", e);

            throw new RuntimeException("error while creating the set virtual account payload.", e);
        }
    }

    public String createSetVirtualAccountPayload(String corporateCode, String emails, Boolean isActive) {
        try {

            setVirtualAccountEntity = new SetVirtualAccountEntity();
            String code = DataGeneratorUtility.getNumericString(5);

            setVirtualAccountEntity.setId(code);
            setVirtualAccountEntity.setClientCode(code);

            if (isActive)
                setVirtualAccountEntity.setAccountStatus(1);
            else
                setVirtualAccountEntity.setAccountStatus(0);

            setVirtualAccountEntity.setVirtualAccountNumber(corporateCode + DataGeneratorUtility.generateTenDigitNumber());
            setVirtualAccountEntity.setCustomerCode(code);
            setVirtualAccountEntity.setCustomerName(DataGeneratorUtility.getFakeTestData().name().fullName());
            setVirtualAccountEntity.setCreatedBy(System.getProperty("user.name"));

            setEmailForVirtualAccount(emails, setVirtualAccountEntity);

            String payload = request.toJson(setVirtualAccountEntity);
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while creating the set virtual account payload.", e);

            throw new RuntimeException("error while creating the set virtual account payload.", e);
        }
    }

    public String createSetVirtualAccountPayload(String accountNumber) {
        try {

            String query = "Select * from VIRTUAL_ACCOUNT  where VIRTUAL_ACCOUNT_NUMBER = '" + accountNumber + "'";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);

            int recordCount = DataBaseUtility.getRowCount(resultSet);
            if (recordCount != 1)
                throw new Exception("Account number not found.");

            resultSet.next();
            setVirtualAccountEntity = new SetVirtualAccountEntity();

            setVirtualAccountEntity.setId(resultSet.getString("CORPORATE_CLIENT_CODE"));
            setVirtualAccountEntity.setClientCode(resultSet.getString("CORPORATE_CLIENT_CODE"));

            String accountStatus = resultSet.getString("STATUS");

            if (accountStatus.equalsIgnoreCase("ACTIVE"))
                setVirtualAccountEntity.setAccountStatus(0);
            else
                setVirtualAccountEntity.setAccountStatus(1);

            setVirtualAccountEntity.setVirtualAccountNumber(resultSet.getString("VIRTUAL_ACCOUNT_NUMBER"));
            setVirtualAccountEntity.setCustomerCode(resultSet.getString("CORPORATE_CUSTOMER_CODE"));
            setVirtualAccountEntity.setCustomerName(resultSet.getString("CUSTOMER_NAME"));

            setEmailForVirtualAccount(properties.getProperty("VIRTUAL_ACCOUNT_EMAIL"), setVirtualAccountEntity);
            setVirtualAccountEntity.setCreatedBy(System.getProperty("user.name"));

            String payload = request.toJson(setVirtualAccountEntity);
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while creating the set virtual account payload.", e);

            throw new RuntimeException("error while creating the set virtual account payload.", e);
        }
    }

    public String modifySetVirtualAccountPayload(String invalidCase, String action, Object invalidValue) {
        try {
            String payload = request.toJson(setVirtualAccountEntity);
            switch (invalidCase) {
                case VIRTUAL_ACCOUNT_ID:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_ID, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_CLIENT_CODE:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_CLIENT_CODE, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_ACCOUNT_STATUS:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_ACCOUNT_STATUS, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_NUMBER:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_ACCOUNT_NUMBER, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_CUSTOMER_CODE:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_CUSTOMER_CODE, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_CUSTOMER_NAME:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_CUSTOMER_NAME, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_CUSTOMER_EMAIL:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_CUSTOMER_EMAIL_1, invalidValue);
                    break;
                case VIRTUAL_ACCOUNT_CREATED_BY:
                    payload = CommonMethods.ChangeJsonPayload(payload, action, Constants.PATH_CREATED_BY, invalidValue);
                    break;
            }

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "modify set virtual account payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while modifying the set virtual account payload.", e);

            throw new RuntimeException("error while modifying the set virtual account payload.", e);
        }
    }

    private void setEmailForVirtualAccount(String emails, SetVirtualAccountEntity setVirtualAccountEntity) {
        try {
            String[] emailCollection = (emails).split(",");
            switch (emailCollection.length) {
                case 1:
                    setVirtualAccountEntity.setEmailId1(emailCollection[0]);
                    break;
                case 2:
                    setVirtualAccountEntity.setEmailId1(emailCollection[0]);
                    setVirtualAccountEntity.setEmailId2(emailCollection[1]);
                    break;
                case 3:
                    setVirtualAccountEntity.setEmailId1(emailCollection[0]);
                    setVirtualAccountEntity.setEmailId2(emailCollection[1]);
                    setVirtualAccountEntity.setEmailId3(emailCollection[2]);
                    break;
                case 4:
                    setVirtualAccountEntity.setEmailId1(emailCollection[0]);
                    setVirtualAccountEntity.setEmailId2(emailCollection[1]);
                    setVirtualAccountEntity.setEmailId3(emailCollection[2]);
                    setVirtualAccountEntity.setEmailId4(emailCollection[3]);
                    break;
                case 5:
                    setVirtualAccountEntity.setEmailId1(emailCollection[0]);
                    setVirtualAccountEntity.setEmailId2(emailCollection[1]);
                    setVirtualAccountEntity.setEmailId3(emailCollection[2]);
                    setVirtualAccountEntity.setEmailId4(emailCollection[3]);
                    setVirtualAccountEntity.setEmailId5(emailCollection[4]);
                    break;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> setSetVirtualAccountHeader(int channelId) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);
            String query = "Select * from CHANNEL where CHANNEL_ID = " + channelId;

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);
            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("channel id is not present in database.");

            resultSet.next();
            header.put("X-CHANNEL-ID", resultSet.getString("CHANNEL_ID"));
            header.put("X-API-TOKEN", resultSet.getString("API_TOKEN"));

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while setting the set virtual account header.", e);

            throw new RuntimeException("error while setting the set virtual account header.", e);
        }
    }

    public Response postSetVirtualAccount(String requestBody, Map<String, String> header) {
        try {
            Response setVirtualAccountResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Set_VirtualAccount"), header);

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account api response : " + setVirtualAccountResponse.prettyPrint(), null);

            return setVirtualAccountResponse;

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while posting the set virtual account api.", e);

            throw new RuntimeException("error while posting the set virtual account api.", e);
        }
    }

    public void validateSetVirtualAccountResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {
            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account  api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while validating the set virtual account api response status.", e);

            throw new RuntimeException("error while validating the set virtual account api response status.", e);
        }
    }

    public void validateSetVirtualAccountResponse(Response apiResponse) {
        try {
            SoftAssert softAssert = new SoftAssert();
            SetVirtualAccountResponseEntity setVirtualAccountResponseEntity = apiResponse.as(SetVirtualAccountResponseEntity.class);

            softAssert.assertEquals(setVirtualAccountResponseEntity.getStatus(), "SUCCESS");

            String query = "Select REQUEST, RESPONSE, STATUS from VAM_LOGGING order by CREATED_AT desc fetch first 1 rows only";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);
            resultSet.next();

            String requestDB = resultSet.getString("REQUEST");
            String responseDB = resultSet.getString("RESPONSE");

            SetVirtualAccountEntity requestEntity = request.fromJson(requestDB, SetVirtualAccountEntity.class);
            SetVirtualAccountResponseEntity responseEntity = request.fromJson(responseDB, SetVirtualAccountResponseEntity.class);

            softAssert.assertTrue(EqualsBuilder.reflectionEquals(setVirtualAccountEntity, requestEntity));
            softAssert.assertTrue(EqualsBuilder.reflectionEquals(setVirtualAccountResponseEntity, responseEntity));

            softAssert.assertAll();

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account  api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while validating the set virtual account api response.", e);

            throw new RuntimeException("error while validating the set virtual account api response.", e);
        }
    }

    public void validateSetVirtualAccountFailedResponse(Response apiResponse, String errorMessage, String errorCode) {
        try {
            SoftAssert softAssert = new SoftAssert();

            ErrorResponse error = apiResponse.as(ErrorResponse.class);
            softAssert.assertEquals(error.getError().getMessage(), errorMessage);
            softAssert.assertEquals(error.getError().getCode(), errorCode);

            String query = "Select REQUEST, RESPONSE, STATUS from VAM_LOGGING order by CREATED_AT desc fetch first 1 rows only";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);
            resultSet.next();

            String requestDB = resultSet.getString("REQUEST");
            String responseDB = resultSet.getString("RESPONSE");

            SetVirtualAccountEntity requestEntity = request.fromJson(requestDB, SetVirtualAccountEntity.class);
            SetVirtualAccountResponseEntity responseEntity = request.fromJson(responseDB, SetVirtualAccountResponseEntity.class);

            softAssert.assertTrue(EqualsBuilder.reflectionEquals(setVirtualAccountEntity, requestEntity));
            if (!(responseEntity.getStatus().contains("FAILURE") && responseEntity.getReason().contains(errorMessage)
                    && responseEntity.getReason().contains(errorCode))) {
                softAssert.assertTrue(false);
            }


            softAssert.assertAll();

            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Pass,
                    "set virtual account  api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(SetVirtualAccountBL.class, log_Type_Fail,
                    "error while validating the set virtual account api response.", e);

            throw new RuntimeException("error while validating the set virtual account api response.", e);
        }
    }
}
