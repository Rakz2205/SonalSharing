package client.virtualAccountManagement;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.Header;
import entity.virtualAccountManagement.GetCurrentAccountEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.errorEntity.ErrorResponse;
import responseEntity.virtualAccountManagement.GetCurrentAccountResponseEntity;
import utils.Reporter;

import java.sql.ResultSet;
import java.util.Map;

public class GetCurrentAccountBL extends SetUp {

    Gson request = new Gson();

    public String createGetCurrentAccountPayload(String virtualAccountNumber) {
        try {

            GetCurrentAccountEntity getCurrentAccountEntity = new GetCurrentAccountEntity();
            getCurrentAccountEntity.setVirtualAccountNumber(virtualAccountNumber);

            String payload = request.toJson(getCurrentAccountEntity);

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while creating the get current account payload.", e);

            throw new RuntimeException("error while creating the get current account payload.", e);
        }
    }

    public Map<String, String> setGetBalanceHeader(int channelId) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);
            String query = "Select * from CHANNEL where CHANNEL_ID = " + channelId;

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);
            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("channel id is not present in database.");

            resultSet.next();
            header.put("X-CHANNEL-ID", resultSet.getString("CHANNEL_ID"));
            header.put("X-API-TOKEN", resultSet.getString("API_TOKEN"));

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while setting the get current account header.", e);

            throw new RuntimeException("error while setting the get current account header.", e);
        }
    }

    public Response postGetCurrentAccount(String requestBody, Map<String, String> header) {
        try {

            Response getCurrentAccountResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Get_CurrentAccount"), header);

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account api response : " + getCurrentAccountResponse.prettyPrint(), null);

            return getCurrentAccountResponse;

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while posting the get current account api.", e);

            throw new RuntimeException("error while posting the get current account api.", e);
        }
    }

    public void validateGetCurrentAccountResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account  api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while validating the get current account api response status.", e);

            throw new RuntimeException("error while validating the get current account api response status.", e);
        }
    }

    public void validateGetCurrentAccountResponse(Response apiResponse, String virtualAccountNumber) {
        try {
            SoftAssert softAssert = new SoftAssert();

            GetCurrentAccountResponseEntity getCurrentAccountResponseEntity = apiResponse.as(GetCurrentAccountResponseEntity.class);

            String query = "Select a.ACCOUNT_NUMBER as ACCOUNT_NUMBER, a.IFSC_CODE as IFSC_CODE, b.CORPORATE_CLIENT_CODE as CLIENT_CODE from \n" +
                    "CURRENT_ACCOUNT a, VIRTUAL_ACCOUNT b where a.CURRENT_ACCOUNT_ID = b.CURRENT_ACCOUNT_ID " +
                    "and b.VIRTUAL_ACCOUNT_NUMBER = '" + virtualAccountNumber + "'";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbVAM, query);
            resultSet.next();

            softAssert.assertEquals(resultSet.getString("ACCOUNT_NUMBER"), getCurrentAccountResponseEntity.getAccountNumber());
            softAssert.assertEquals(resultSet.getString("IFSC_CODE"), getCurrentAccountResponseEntity.getIfscCode());
            softAssert.assertEquals(resultSet.getString("CLIENT_CODE"), getCurrentAccountResponseEntity.getClientCode());

            softAssert.assertAll();

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account  api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while validating the get current account api response.", e);

            throw new RuntimeException("error while validating the get current account api response.", e);
        }
    }

    public void validateGetCurrentAccountFailedResponse(Response apiResponse, String errorMessage, String errorCode) {
        try {
            SoftAssert softAssert = new SoftAssert();

            ErrorResponse error = apiResponse.as(ErrorResponse.class);
            softAssert.assertEquals(error.getError().getMessage(), errorMessage);
            softAssert.assertEquals(error.getError().getCode(), errorCode);

            softAssert.assertAll();

            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Pass,
                    "get current account  api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetCurrentAccountBL.class, log_Type_Fail,
                    "error while validating the get current account api response.", e);

            throw new RuntimeException("error while validating the get current account api response.", e);
        }
    }
}
