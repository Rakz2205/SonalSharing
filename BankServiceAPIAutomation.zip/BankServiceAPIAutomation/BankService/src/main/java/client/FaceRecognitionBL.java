package client;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import entity.AuthenticateList;
import entity.Header;
import entity.MobileEntity;
import entity.User;
import entity.bankCustomerServiceEntity.FaceRecognitionEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.faceRecognition.FaceRecognitionResponse;
import com.utilities.apiUtils.RestUtil;
import utils.CommonMethods;
import utils.Reporter;

import java.util.List;
import java.util.Map;

public class FaceRecognitionBL extends SetUp {


    public Map<String, String> setFaceRecognitionHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(Type_Authentication);

          //  header.put("x-channel-id", "1234");
          //  header.put("x-api-key", "12f312uy3tvu791623bx");
          //  header.put("x-trace-id", "123123");
          //  header.put("x-device-info", "ad");
            header.put("x-channel-id", (String)testData.get("ChannelId"));
            header.put("x-api-key", testData.get("ApiKey").toString());
            header.put("x-trace-id", testData.get("TraceId").toString());
            header.put("x-device-info", testData.get("DeviceInfo").toString());

            //header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                    "FaceRecognition header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(FaceRecognitionBL.class, log_Type_Fail,
                    "error while setting the FaceRecognitionBL header.", e);

            throw new RuntimeException("error while setting the FaceRecognitionBL header.", e);
        }
    }


    public String createFaceRecognitionPayload(Map<Object, Object> testData) {
        try {

            FaceRecognitionEntity faceRecoginationEntity = new FaceRecognitionEntity();
            Gson request = new Gson();

            MobileEntity mobile = CommonMethods.getMobileEntities(testData.get("MobileNo").toString(), testData.get("CountryCode").toString());
            AuthenticateList authenticateListData = CommonMethods.getAuthenticationListEntities((Integer.parseInt(testData.get("Mode").toString())) , (String)testData.get("Value"), (String)testData.get("Action"), (String) testData.get("TransactionRefNumber"));
            User user = CommonMethods.getUserEntities((String) testData.get("CustomerId"), mobile , (String)testData.get("EmailID") , (String)testData.get("CustomerImage1")+(String)testData.get("CustomerImage2")+(String)testData.get("CustomerImage3"));

            List<AuthenticateList> listOfAuthenticateList = CommonMethods.getAuthenticateList(authenticateListData);



            faceRecoginationEntity.setUser(user);
            faceRecoginationEntity.setScope((String)testData.get("Scope"));
            faceRecoginationEntity.setAuthenticateList(listOfAuthenticateList);



            String payload = request.toJson(faceRecoginationEntity);

            Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                    "FaceRecognition payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(FaceRecognitionBL.class, log_Type_Fail,
                    "error while creating the FaceRecognition payload.", e);

            throw new RuntimeException("error while creating the FaceRecognition payload.", e);
        }
    }


        public Response postFaceRecognition (String requestBody, Map<String, String> header){
            try {

                Response faceRecognitionResponse = RestUtil.postByJson(requestBody,
                        apiProperties.getProperty("FaceRecoginition"), header);

                Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                        "FaceRecognition API response : " + faceRecognitionResponse.prettyPrint(), null);

                return faceRecognitionResponse;

            } catch (Exception e) {
                Reporter.logReport(FaceRecognitionBL.class, log_Type_Fail,
                        "error while posting the faceRecognition API.", e);

                throw new RuntimeException("error while posting the faceRecognition API.", e);
            }
        }


        public void validateFaceRecognitionResponseStatus (Response apiResponse, int apiExpectedStatus){
            try {

                Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

                Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                        "FaceRecognition API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

            } catch (Exception e) {
                Reporter.logReport(FaceRecognitionBL.class, log_Type_Fail,
                        "error while validating the FaceRecognition API response status.", e);

                throw new RuntimeException("error while validating the FaceRecognition API response status.", e);
            }
        }


        public void validateFaceRecognitionResponse (Response apiResponse, Map<Object, Object> testData){

            try {
                SoftAssert softAssert = new SoftAssert();
                FaceRecognitionResponse faceRecognitionResponseObj = apiResponse.as(FaceRecognitionResponse.class);

                int statusCode = apiResponse.getStatusCode();
                String status = faceRecognitionResponseObj.getStatus();
                String bankCustomerId = faceRecognitionResponseObj.getBankCustomerId();
                boolean authenticated = faceRecognitionResponseObj.isAuthenticated();
                String authMatchScore = faceRecognitionResponseObj.getFrAuthResponse().getMatch_score();
                String errorCode = faceRecognitionResponseObj.getError().getCode();
                String errorMessage = faceRecognitionResponseObj.getError().getMessage();

                if(statusCode==200) {
                    switch (status) {
                        case ("SUCCESS"):
                            if (authMatchScore == "99") {
                                softAssert.assertEquals(status, "SUCCESS");
                                softAssert.assertEquals(bankCustomerId, testData.get("CustomerId"));
                                softAssert.assertEquals(authenticated, true);
                                softAssert.assertEquals(authMatchScore, "99");
                                softAssert.assertAll();

                                /*Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                                        "faceRecognition api customer match validation with bank customer id. Customer mach-score is: " + authMatchScore + " and authenticated: " + authenticated + " and Bank Customer id: " + bankCustomerId, null );
*/
                            } else if (authMatchScore == "0") {
                                Assert.assertFalse(false);
                                Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                                        "faceRecognition api customer match validation. Customer mach-score is: " + authMatchScore + " and authenticated: " + authenticated , null );
                            }
                            break;
                        case ("FAILED"):
                            softAssert.assertFalse(authenticated, "Test result: isAuthenticated: false");
                            softAssert.assertEquals(errorCode, testData.get("ErrorCode"));
                            softAssert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                            softAssert.assertAll();


                           /* Assert.assertFalse(authenticated);
                            Assert.assertEquals(errorCode, testData.get("ErrorCode"));
                            Assert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                            Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                                    "faceRecognition api error code and message validated. " +"\"" +errorCode+": " + errorMessage +"\"" + " and customer is authenticated: " + authenticated, null );

                            */
                            break;
                        default:
                            org.testng.Reporter.log("validating fr api status code 200 scenarios. ");
                    }
                }
                else{
                        softAssert.assertEquals(errorCode, testData.get("ErrorCode"));
                        softAssert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                        softAssert.assertAll();
                   /* Assert.assertEquals(errorCode, testData.get("ErrorCode"));
                    Assert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                     Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                            "faceRecognition api error code and message validated. " + "\"" +errorCode+": " + errorMessage +"\"", null );

                    */



                }

                Reporter.logReport(FaceRecognitionBL.class, log_Type_Pass,
                        "faceRecognition api response validated. Status code is  : " + apiResponse.getStatusCode(), null);

            } catch (Exception e) {
                Reporter.logReport(FaceRecognitionBL.class, log_Type_Fail,
                        "error while validating the faceRecognition api response status.", e);

                throw new RuntimeException("error while validating the faceRecognition api response status.", e);
            }

        }


    }


