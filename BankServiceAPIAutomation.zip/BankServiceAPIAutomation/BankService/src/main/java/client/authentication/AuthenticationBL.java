package client.authentication;

import base.SetUp;
import client.customer.GetCustomerBL;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.*;
import entity.authenticationEntity.AuthenticateCredentialEntity;
import entity.authenticationEntity.AuthorizationCodeEntity;
import entity.authenticationEntity.DigitalSignatureAuthenticationEntity;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import utils.CommonMethods;
import utils.CryptoUtil;
import utils.DigitalSignature;
import utils.Reporter;

import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AuthenticationBL extends SetUp {

    public static String createMPinAuthenticateCredentialPayload(String type, String typeValue, String newPin, int purpose, String extraInfo) {
        String payload;
        try {
            Gson request = new Gson();

            AuthenticateCredentialEntity authenticateCredentialEntity = new AuthenticateCredentialEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);
                    break;
            }
            authenticateCredentialEntity.setUser(user);

            authenticateCredentialEntity.setScope("REQUEST");
            String aesKey = CryptoUtil.generateAesKey();

            String publicKey = CryptoUtil.getPublicKey();
            Secure secure = new Secure();
            secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));
            authenticateCredentialEntity.setSecure(secure);

            AuthenticateList authenticateList = new AuthenticateList();
            authenticateList.setMode(AUTH_MODE_MPIN);
            authenticateList.setValue(CryptoUtil.encryptAES(newPin, aesKey, "AES/ECB/PKCS5PADDING"));

            List<AuthenticateList> listAuthenticateList = new ArrayList<>();
            listAuthenticateList.add(authenticateList);
            authenticateCredentialEntity.setAuthenticateList(listAuthenticateList);

            authenticateCredentialEntity.setPurpose(purpose);
            authenticateCredentialEntity.setExtraInfo(extraInfo);

            payload = request.toJson(authenticateCredentialEntity);
            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "authenticate credentials payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while creating the authenticate credentials payload.", e);

            throw new RuntimeException("error while creating the authenticate credentials payload.", e);
        }
    }

    public static String createOTPPayload(String type, String typeValue, String action, String value) {
        String payload;
        try {
            Gson request = new Gson();

            AuthenticateCredentialEntity authenticateCredentialEntity = new AuthenticateCredentialEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);
                    break;
            }

            authenticateCredentialEntity.setUser(user);
            authenticateCredentialEntity.setScope("REQUEST");

            AuthenticateList authenticateList = new AuthenticateList();
            authenticateList.setMode(AUTH_MODE_OTP);
            authenticateList.setAction(action.toLowerCase());

            if (action.toLowerCase().equalsIgnoreCase("verify")) {

                String aesKey = CryptoUtil.generateAesKey();
                String publicKey = CryptoUtil.getPublicKey();

                authenticateList.setValue(CryptoUtil.encryptAES(value, aesKey, "AES/ECB/PKCS5PADDING"));

                Secure secure = new Secure();
                secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));
                authenticateCredentialEntity.setSecure(secure);
            } else {
                authenticateList.setValue(value);
            }

            List<AuthenticateList> listAuthenticateList = new ArrayList<>();
            listAuthenticateList.add(authenticateList);
            authenticateCredentialEntity.setAuthenticateList(listAuthenticateList);

            //  New implementation
            authenticateCredentialEntity.setPurpose(AUTH_MODE_OTP);
            authenticateCredentialEntity.setExtraInfo("20000033535");

            payload = request.toJson(authenticateCredentialEntity);
            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "OTP payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while creating the OTP payload.", e);

            throw new RuntimeException("error while creating the OTP payload.", e);
        }
    }

    public static String createAuthenticateMPinPayload(String type, String typeValue, String pin) {
        String payload;
        try {
            Gson request = new Gson();

            AuthenticateCredentialEntity authenticateCredentialEntity = new AuthenticateCredentialEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);
                    break;
            }

            authenticateCredentialEntity.setUser(user);
            authenticateCredentialEntity.setScope("REQUEST");

            AuthenticateList authenticateList = new AuthenticateList();
            authenticateList.setMode(AUTH_MODE_MPIN);

            String aesKey = CryptoUtil.generateAesKey();
            String publicKey = CryptoUtil.getPublicKey();

            authenticateList.setValue(CryptoUtil.encryptAES(pin, aesKey, "AES/ECB/PKCS5PADDING"));

            Secure secure = new Secure();
            secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));
            authenticateCredentialEntity.setSecure(secure);

            List<AuthenticateList> listAuthenticateList = new ArrayList<>();
            listAuthenticateList.add(authenticateList);
            authenticateCredentialEntity.setAuthenticateList(listAuthenticateList);

            //  New implementation
            authenticateCredentialEntity.setPurpose(1);
            authenticateCredentialEntity.setExtraInfo("20000033535");

            payload = request.toJson(authenticateCredentialEntity);
            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "authenticate mpin payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while creating the authenticate mpin payload.", e);

            throw new RuntimeException("error while creating the authenticate mpin payload.", e);
        }
    }

    public static String addDigitalSignature(String payload, Type entityType) {
        Gson request = new Gson();
        try {
            String digitalSignature = DigitalSignature.generateSignature(payload);

            Secure secure = new Secure();
            //secure.setSignature(digitalSignature);

            DigitalSignatureAuthenticationEntity authenticateCredential = new DigitalSignatureAuthenticationEntity();
            authenticateCredential.setPayload(request.fromJson(payload, entityType));
            authenticateCredential.setSecure(secure);

            payload = request.toJson(authenticateCredential);

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "digital signature added. Updated payload :" + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while generating the digital signature.", e);

            throw new RuntimeException("error while generating the digital signature.", e);
        }
    }

    public static String createMPinAuthorizationCodePayload(Response authenticationCredentialsResponse, String authMode) {
        String payload;

        try {
            Gson request = new Gson();
            AuthorizationCodeEntity authorizationCodeEntity = new AuthorizationCodeEntity();

            String bankCustomerId = authenticationCredentialsResponse.jsonPath().getString("bankCustomerId");
            String authorization = authenticationCredentialsResponse.jsonPath().getString("authorizationCode");

            authorizationCodeEntity.setBankCustomerID(bankCustomerId);
            authorizationCodeEntity.setAuthenticationMode(authMode);
            authorizationCodeEntity.setAuthorizationCode(authorization);
            authorizationCodeEntity.setAuthenticationScope("AUTH");
            authorizationCodeEntity.setAuthenticationPurpose(1);
            authorizationCodeEntity.setExtraInfo("Authentication Info");


            payload = request.toJson(authorizationCodeEntity);
            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "authorization code payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while creating the authorization code payload.", e);

            throw new RuntimeException("error while creating the authorization code payload.", e);
        }
    }

    public static Response postAuthenticateCredentials(String requestBody, Map<String, String> header) {
        try {

            Response changeMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Authenticate_Credentials"), header);

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "post authenticate credentials pin api response : " + changeMPinResponse.prettyPrint(), null);

            return changeMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while posting the authenticate credentials api.", e);

            throw new RuntimeException("error while posting the authenticate credentials api.", e);
        }
    }

    public static Response postAuthorizationCode(String requestBody, Map<String, String> header) {
        try {

            Response changeMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Authorization_Code"), header);

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "post authorization code api response : " + changeMPinResponse.prettyPrint(), null);

            return changeMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while posting the authorization codes api.", e);

            throw new RuntimeException("error while posting the authorization code api.", e);
        }
    }

    public static Response postOTP(String requestBody, Map<String, String> header) {
        try {

            Response changeMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("OTP_Auth"), header);

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "post otp api response : " + changeMPinResponse.prettyPrint(), null);

            return changeMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while posting the otp api.", e);

            throw new RuntimeException("error while posting the otp api.", e);
        }
    }

    public static void validateAuthenticationResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "authenticate api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while validating the authenticate api response status.", e);

            throw new RuntimeException("error while validating the authenticate api response status.", e);
        }
    }

    public static String getOTPFromDatabase(String type, String typeValue) {
        try {
            String mobileNumber;
            if (type.equalsIgnoreCase(MPIN_BANK_CUSTOMER_ID)) {
                mobileNumber = GetCustomerBL.getCustomerData(2, typeValue, "mobile.number");
            } else {
                mobileNumber = typeValue;
            }

            String query = "Select OTP from JPB_OTP where MOBILE_NUMBER = '" + mobileNumber + "' order by CREATED_AT " +
                    "desc fetch first 1 row only";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbAuthenticationPSP, query);
            resultSet.next();

            return resultSet.getString("OTP");

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while getting the otp from the database.", e);

            throw new RuntimeException("error while getting the otp from the database.", e);
        }
    }

    public static void validateOTPResponse(Response apiResponse, String type, String typeValue) {
        try {

            SoftAssert softAssert = new SoftAssert();
            String expectedBankCustomerId;

            if (type.equalsIgnoreCase(MPIN_MOBILE_NUMBER)) {
                expectedBankCustomerId = GetCustomerBL.getCustomerData(1, typeValue, "bankCustomerId");
            } else {
                expectedBankCustomerId = typeValue;
            }
            String actualBankCustomerId = apiResponse.jsonPath().getString("bankCustomerId");

            softAssert.assertEquals(actualBankCustomerId, expectedBankCustomerId, "error while validating the bank customer id.");
            softAssert.assertEquals(apiResponse.jsonPath().getString("status"), "SUCCESS");


            Reporter.logReport(AuthenticationBL.class, log_Type_Pass, "OTP is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail, "error while validating the OTP.", e);

            throw new RuntimeException("error while validating the OTP.", e);
        }
    }

    public static void validateResponseForInvalidAuthCase(Response apiResponse, String invalidCase, String action) {
        try {
            SoftAssert softAssert = new SoftAssert();
            switch (invalidCase) {
                case CUSTOMER_ACCOUNT_NUMBER:
                    if (action.equalsIgnoreCase(ACTION_SET)) {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "123", "Verification Failed - Account Mismatch");
                    } else {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "005", "[Account Number is missing]");
                    }

                    break;
                case BANK_CUSTOMER_ID:
                    if (action.equalsIgnoreCase(ACTION_SET)) {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "100", "Internal Error - Please try again later");
                    } else {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "005", "[Bank Customer ID is missing]");
                    }
                    break;
                case AUTH_CODE:
                    if (action.equalsIgnoreCase(ACTION_SET)) {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "118", "Invalid authorization code");
                    } else {
                        softAssert.assertEquals(apiResponse.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
                        CommonMethods.validateFailedTransactionResponse(apiResponse, "6011", "Some technical error occurred. Please try after some time!");
                    }
                    break;
            }

            Reporter.logReport(AuthenticationBL.class, log_Type_Pass,
                    "successfully validated the response for invalid auth code.", null);

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while validating the response.", e);

            throw new RuntimeException("error while validating the response.", e);
        }
    }

    public static String getOTPAuthCode(String type, String typeValue, int channelId, int traceId) {
        try {

            //  set header
            Map<String, String> header = Header.getHeader(TYPE_AUTHENTICATION);
            header.put("X-CHANNEL-ID", String.valueOf(channelId));
            header.put("X-TRACE-ID", String.valueOf(traceId));

            //  generate otp payload
            String otpPayload = AuthenticationBL.createOTPPayload(type, typeValue, "generate", "");

            //  post generate otp
            Response responseGenerateOTP = AuthenticationBL.postOTP(otpPayload, header);

            if (responseGenerateOTP.jsonPath().getString("status").equalsIgnoreCase("SUCCESS")) {

                //   get otp from the db
                String otp = AuthenticationBL.getOTPFromDatabase(type, typeValue);

                //  verify otp payload
                String verifyOTPPayload = AuthenticationBL.createOTPPayload(type, typeValue, "verify", otp);

                //  post verify otp
                Response responseVerifyOtp = AuthenticationBL.postOTP(verifyOTPPayload, header);

                return responseVerifyOtp.jsonPath().getString("authorizationCode");
            } else {
                throw new Exception("error while getting the otp auth code.");
            }

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while getting the otp auth code.", e);

            throw new RuntimeException("error while getting the otp auth code.", e);
        }
    }

    public static String getOTP(String type, String typeValue, int channelId, int traceId) {
        try {

            //  set header
            Map<String, String> header = Header.getHeader(TYPE_AUTHENTICATION);
            header.put("X-CHANNEL-ID", String.valueOf(channelId));
            header.put("X-TRACE-ID", String.valueOf(traceId));

            //  generate otp payload
            String otpPayload = AuthenticationBL.createOTPPayload(type, typeValue, "generate", "");

            //  post generate otp
            Response responseGenerateOTP = AuthenticationBL.postOTP(otpPayload, header);

            if (responseGenerateOTP.jsonPath().getString("status").equalsIgnoreCase("SUCCESS")) {

                //   get otp from the db
                String otp = AuthenticationBL.getOTPFromDatabase(type, typeValue);

                return otp;
            } else {
                throw new Exception("error while getting the otp");
            }

        } catch (Exception e) {
            Reporter.logReport(AuthenticationBL.class, log_Type_Fail,
                    "error while getting the otp auth code.", e);

            throw new RuntimeException("error while getting the otp auth code.", e);
        }
    }
}
