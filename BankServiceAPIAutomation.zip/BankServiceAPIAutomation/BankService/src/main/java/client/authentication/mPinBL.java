package client.authentication;

import base.SetUp;
import client.customer.GetCustomerBL;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import entity.*;
import entity.authenticationEntity.MPinEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.errorEntity.ErrorResponse;
import utils.CryptoUtil;
import utils.DigitalSignature;
import utils.Reporter;

import java.util.Map;

public class mPinBL extends SetUp {

    Gson request = new Gson();

    public String createChangeMPinPayload(String type, String typeValue, String oldPin, String newPin) {
        try {

            MPinEntity mPinEntity = new MPinEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);
                    break;
            }

            mPinEntity.setUser(user);

            mPinEntity.setCredentialType(AUTH_MPIN_TYPE);
            String aesKey = CryptoUtil.generateAesKey();

            mPinEntity.setCredentialValue(CryptoUtil.encryptAES(newPin, aesKey, "AES/ECB/PKCS5PADDING"));
            mPinEntity.setOldCredentialValue(CryptoUtil.encryptAES(oldPin, aesKey, "AES/ECB/PKCS5PADDING"));

            String publicKey = CryptoUtil.getPublicKey();
            Secure secure = new Secure();
            secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));

            mPinEntity.setSecure(secure);
            String payload = request.toJson(mPinEntity);

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "Change m-pin payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while creating the change m-pin payload.", e);

            throw new RuntimeException("error while creating the change m-pin payload.", e);
        }
    }

    public String createSetResetMPinPayload(String type, String typeValue, int validationType, String pin, String otpAuthCode, String otp) {
        try {
            String dob = null;
            MPinEntity mPinEntity = new MPinEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    dob = GetCustomerBL.getCustomerData(1, typeValue, "dob");
                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);

                    dob = GetCustomerBL.getCustomerData(2, typeValue, "dob");
                    break;
            }

            mPinEntity.setUser(user);
            mPinEntity.setCredentialType(AUTH_MPIN_TYPE);

            Validations validations = new Validations();
            validations.setType(validationType);
            validations.setDateOfBirth(dob);

            if (otpAuthCode != null)
                validations.setOtpAuthCode(otpAuthCode);

            String aesKey = CryptoUtil.generateAesKey();
            if (otp != null)
                validations.setOtp(CryptoUtil.encryptAES(otp, aesKey, "AES/ECB/PKCS5PADDING"));

            mPinEntity.setValidations(validations);


            mPinEntity.setCredentialValue(CryptoUtil.encryptAES(pin, aesKey, "AES/ECB/PKCS5PADDING"));
            String publicKey = CryptoUtil.getPublicKey();

            Secure secure = new Secure();
            secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));

            mPinEntity.setSecure(secure);
            String payload = request.toJson(mPinEntity);
            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "reset m-pin payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while creating the reset m-pin payload.", e);

            throw new RuntimeException("error while creating the reset m-pin payload.", e);
        }
    }

    public String createSetResetMPinPayloadWithIncorrectDOB(String type, String typeValue, String pin, String dob) {
        try {
            MPinEntity mPinEntity = new MPinEntity();
            User user = new User();

            switch (type) {
                case MPIN_MOBILE_NUMBER:
                    MobileEntity mobileEntity = new MobileEntity();
                    mobileEntity.setMobileNumber(typeValue);

                    user.setMobile(mobileEntity);
                    break;
                case MPIN_BANK_CUSTOMER_ID:
                    user.setBankCustomerId(typeValue);

                    break;
            }

            mPinEntity.setUser(user);
            mPinEntity.setCredentialType(AUTH_MPIN_TYPE);

            Validations validations = new Validations();
            validations.setType(VALIDATION_SET_DOB_AUTH_CODE);
            validations.setDateOfBirth(dob);

            mPinEntity.setValidations(validations);

            String aesKey = CryptoUtil.generateAesKey();
            mPinEntity.setCredentialValue(CryptoUtil.encryptAES(pin, aesKey, "AES/ECB/PKCS5PADDING"));

            String publicKey = CryptoUtil.getPublicKey();

            Secure secure = new Secure();
            secure.setEncryptionKey(CryptoUtil.encryptRSA(aesKey, publicKey, "RSA/ECB/PKCS1PADDING"));

            String payload = request.toJson(mPinEntity);
            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "reset m-pin payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while creating the reset m-pin payload.", e);

            throw new RuntimeException("error while creating the reset m-pin payload.", e);
        }
    }

    public Map<String, String> setMPinHeader(int channelId, int traceId, String payload) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_AUTHENTICATION);
            header.put("X-CHANNEL-ID", String.valueOf(channelId));
            header.put("X-TRACE-ID", String.valueOf(traceId));

            if (payload != null)
                header.put("X-SIGNATURE", DigitalSignature.generateAuthSignature(payload));

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "m pin header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while setting the m pin header.", e);

            throw new RuntimeException("error while setting the m pin header.", e);
        }
    }

    public Map<String, String> setOTPHeader(int channelId, int traceId) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_AUTHENTICATION);
            header.put("X-CHANNEL-ID", String.valueOf(channelId));
            header.put("X-TRACE-ID", String.valueOf(traceId));

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "m pin header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while setting the m pin header.", e);

            throw new RuntimeException("error while setting the m pin header.", e);
        }
    }

    public Response postChangeMPin(String requestBody, Map<String, String> header) {
        try {

            Response changeMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Change_Credentials"), header);

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "post change m pin api response : " + changeMPinResponse.prettyPrint(), null);

            return changeMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while posting the change m pin api.", e);

            throw new RuntimeException("error while posting the change m pin api.", e);
        }
    }

    public Response postResetMPin(String requestBody, Map<String, String> header) {
        try {

            Response resetMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Reset_Credentials"), header);

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "post reset m pin api response : " + resetMPinResponse.prettyPrint(), null);

            return resetMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while posting the reset m pin api.", e);

            throw new RuntimeException("error while posting the reset m pin api.", e);
        }
    }

    public Response postSetMPin(String requestBody, Map<String, String> header) {
        try {

            Response setMPinResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Set_Credentials"), header);

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "post set m pin api response : " + setMPinResponse.prettyPrint(), null);

            return setMPinResponse;

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while posting the set m pin api.", e);

            throw new RuntimeException("error while posting the set m pin api.", e);
        }
    }

    public void validateMPinResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "m pin api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while validating the m pin api response status.", e);

            throw new RuntimeException("error while validating the m pin api response status.", e);
        }
    }

    public static void validateErrorMessages(Response apiResponse, String failureMessage, String failureCode) {
        try {

            SoftAssert softAssert = new SoftAssert();

            ErrorResponse error = apiResponse.as(ErrorResponse.class);
            softAssert.assertEquals(error.getError().getCode(), failureCode);
            softAssert.assertEquals(error.getError().getMessage().trim(), failureMessage.trim());

            Reporter.logReport(mPinBL.class, log_Type_Pass,
                    "error message validation is successful.", null);

        } catch (Exception e) {
            Reporter.logReport(mPinBL.class, log_Type_Fail,
                    "error while validating the error messages.", e);

            throw new RuntimeException("error while validating the error messages.", e);
        }
    }
}
