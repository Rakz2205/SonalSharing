package client.nodalAccount;

import base.Constants;
import base.SetUp;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.connectionUtils.UnixUtility;
import com.utilities.fileUtils.ExcelUtility;
import com.utilities.fileUtils.FileUtility;
import com.utilities.javaUtils.DateUtility;
import entity.nodalAccount.MerchantSettlementDetails;
import entity.nodalAccount.ResponseFileDetails;
import org.testng.Assert;
import utils.CommonMethods;
import utils.FileSecurity;
import utils.Reporter;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NodalAccountBL extends SetUp {

    private static List<String> collectionMerchantId = new ArrayList<>();
    private static Map<String, MerchantSettlementDetails> collectionMerchantSettlementDetails = new HashMap<>();

    private static Map<String, MerchantSettlementDetails> successTransactions = new HashMap<>();
    private static Map<String, MerchantSettlementDetails> failedTransactions = new HashMap<>();
    private static Map<String, MerchantSettlementDetails> failedTransactionsWithNoResponse = new HashMap<>();

    private static Map<String, ResponseFileDetails> collectionSuccessResponseRecords = new HashMap<>();
    private static Map<String, ResponseFileDetails> collectionFailResponseRecords = new HashMap<>();

    public String createMerchantMasterFile(int numberOfRecords) {
        String filePath;
        Map<Object, Object> tesData;
        List<String> merchantData = new ArrayList<>();

        //  clear directory
        FileUtility.cleanDirectory(System.getProperty("user.dir") + "//src//main//resources//NodalAccount//MerchantMaster//");

        try {
            String sampleFilePath = System.getProperty("user.dir") +
                    "//src//main//resources//NodalAccount//NodalAccount.xlsx";

            Object[][] testDataMerchantMaster = ExcelUtility.getDataFromExcel(sampleFilePath, "MerchantMaster");

            if (testDataMerchantMaster.length >= numberOfRecords && numberOfRecords > 0) {
                for (int i = 0; i < numberOfRecords; i++) {
                    tesData = (Map<Object, Object>) testDataMerchantMaster[i][0];

                    String status = (String) tesData.get("Status");
                    String merchantId = (String) tesData.get("MerchantId");
                    String merchantName = (String) tesData.get("MerchantName");
                    String accountNumber = (String) tesData.get("AccountNumber");
                    String bankIFSC = (String) tesData.get("BankIFSC");
                    String identifier = (String) tesData.get("Identifier");

                    String record = status + "|" + merchantId + "|" + merchantName + "|" + accountNumber + "|" + bankIFSC + "|" + identifier;
                    merchantData.add(record);
                    collectionMerchantId.add(merchantId);

                    tesData.clear();
                }

                String fileContent = String.join("\n", merchantData);

                String timeStamp = DateUtility.getCurrentDateTime("yyyyMMdd_hhmmss");
                filePath = System.getProperty("user.dir") +
                        "//src//main//resources//NodalAccount//MerchantMaster//RPSLM_RPSLMBUYERUPLD_" + timeStamp + ".txt";

                FileUtility.createFile(filePath, fileContent);
            } else {
                throw new Exception("number of records are to high or invalid. Test data record count is : " + testDataMerchantMaster.length);
            }

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "merchant master file is created.", null);

            return filePath;
        } catch (Exception e) {
            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while creating the merchant master file.", e);
            throw new RuntimeException("error while creating the merchant master file.", e);
        }
    }

    public String createSettlementFile(int numberOfRecords) {
        String filePath;
        Map<Object, Object> tesData;

        int counter = 0;
        List<String> settlementData = new ArrayList<>();

        //  clear directory
        FileUtility.cleanDirectory(System.getProperty("user.dir") + "//src//main//resources//NodalAccount//JPBSettlement//");

        try {
            String sampleFilePath = System.getProperty("user.dir") +
                    "//src//main//resources//NodalAccount//NodalAccount.xlsx";

            Object[][] testDataSettlement = ExcelUtility.getDataFromExcel(sampleFilePath, "JPBSettlement");
            if (numberOfRecords > 0) {
                for (int i = 0; i <= testDataSettlement.length; i++) {

                    if (i == testDataSettlement.length) {
                        i = 0;
                        testDataSettlement = ExcelUtility.getDataFromExcel(sampleFilePath, "JPBSettlement");
                    }
                    if (counter == numberOfRecords)
                        break;

                    tesData = (Map<Object, Object>) testDataSettlement[i][0];

                    //  created Merchant settlement details
                    MerchantSettlementDetails merchantSettlementDetails = new MerchantSettlementDetails();

                    String merchantName = (String) tesData.get("MerchantName");
                    merchantSettlementDetails.setMerchantName(merchantName);

                    String merchantSettlementAccountNumber = (String) tesData.get("MerchantSettlementAccountNumber");
                    merchantSettlementDetails.setMerchantSettlementAccountNumber(merchantSettlementAccountNumber);

                    String merchantSettlementIFSCNumber = (String) tesData.get("MerchantSettlementIFSCNumber");
                    merchantSettlementDetails.setMerchantSettlementIFSCNumber(merchantSettlementIFSCNumber);

                    String settlementAmount = (String) tesData.get("SettlementAmount");
                    merchantSettlementDetails.setSettlementAmount(settlementAmount);

                    String dateOfSettlement = DateUtility.getCurrentDateTime("yyyyMMddhhmmss");
                    merchantSettlementDetails.setDateOfSettlement(dateOfSettlement);

                    String nodalAccountNumber = (String) tesData.get("NodalAccountNumber");
                    merchantSettlementDetails.setNodalAccountNumber(nodalAccountNumber);

                    String settlementBatchId = (String) tesData.get("SettlementBatchId");
                    merchantSettlementDetails.setSettlementBatchId(settlementBatchId);

                    String settlementIdentifier = "JPB_" + System.currentTimeMillis() + "_" + counter++;
                    merchantSettlementDetails.setSettlementIdentifier(settlementIdentifier);

                    String merchantId = (String) tesData.get("MerchantId");
                    merchantSettlementDetails.setMerchantId(merchantId);

                    String record = merchantName + "," + merchantSettlementAccountNumber + "," + merchantSettlementIFSCNumber + "," + settlementAmount + "," + dateOfSettlement
                            + "," + nodalAccountNumber + "," + settlementIdentifier + "," + settlementBatchId + "," + merchantId;

                    settlementData.add(record);
                    collectionMerchantSettlementDetails.put(settlementIdentifier, merchantSettlementDetails);

                    tesData.clear();
                }

                String fileContent = String.join("\n", settlementData);
                String timeStamp = DateUtility.getCurrentDateTime("yyyyMMdd_hhmmss");

                filePath = System.getProperty("user.dir") +
                        "//src//main//resources//NodalAccount//JPBSettlement//JPB_RPSLEPAY_" + timeStamp + ".csv";

                FileUtility.createFile(filePath, fileContent);

            } else {
                throw new Exception("number of records are to high or invalid. Test data record count is : " + testDataSettlement.length);
            }

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "merchant settlement file is created.", null);

            return filePath;
        } catch (Exception e) {
            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while creating the Settlement file.", e);
            throw new RuntimeException("error while creating the Settlement file.", e);
        }
    }

    public static void uploadFileOverSftp(String remoteDirectory, String localDirectory, String fileName) {
        try {

            UnixUtility.uploadFileOverSftp(remoteDirectory, localDirectory, fileName);

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "file successfully place at : " + remoteDirectory, null);

        } catch (Exception e) {

            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while placing the file on sftp server.", e);

            throw new RuntimeException("error while placing the file on sftp server.", e);
        }
    }

    public static void checkFileExist(String filePath) {
        try {
            boolean isPresent;
            int counter = 0;

            int waitTime = Integer.parseInt(properties.getProperty("Nodal_Default_Timeout"));
            do {
                try {
                    isPresent = UnixUtility.checkFileExist(filePath);
                } catch (Exception e) {
                    isPresent = false;
                }
                if (waitTime == counter++)
                    break;
                else
                    Thread.sleep(1000);
            } while (!isPresent);

            if (isPresent == false)
                throw new Exception("file not present.");

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "file successfully processed.", null);

        } catch (Exception e) {

            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while processing the file.", e);

            throw new RuntimeException("error while processing the file.", e);
        }
    }

    public static void checkRecordExistInDatabase(String fileName) {
        try {
            boolean isPresent = false;
            int counter = 0;

            ResultSet resultSet;
            int recordCount = 0;

            int waitTime = Integer.parseInt(properties.getProperty("Record_Process_Time"));
            String query = "Select * from input_file where FILE_NAME = '" + fileName + "'";

            do {
                try {
                    //  query db to look for record
                    resultSet = DataBaseUtility.executeSelectStatement(dbNodalAccount, query);
                    recordCount = DataBaseUtility.getRowCount(resultSet);

                    if (recordCount > 0)
                        break;

                } catch (Exception e) {
                    isPresent = false;
                }

                if (waitTime == counter++)
                    break;

                Thread.sleep(1000);
            } while (!isPresent);

            if (recordCount == 0)
                throw new Exception(fileName + " not present in database.");

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "file record is exist in database.", null);

        } catch (Exception e) {

            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while checking the record in database.", e);

            throw new RuntimeException("error while checking the record in database.", e);
        }
    }

    public void validateNodalTransaction() {
        try {
            int counter = 0;
            int transactionWaitTime = Integer.parseInt(properties.getProperty("Transaction_Process_Time"));

            //  iterate by each payment sequence number
            for (String paymentSequenceNumber : collectionMerchantSettlementDetails.keySet()) {

                //  search for record in DB
                String queryTransactionDetails = "Select * from TRANSACTION_DETAILS where PAYMENT_SEQUENCE_NUMBER = '" + paymentSequenceNumber + "'";
                ResultSet resultSetTransactionDetails = DataBaseUtility.executeSelectStatement(dbNodalAccount, queryTransactionDetails);

                resultSetTransactionDetails.next();
                String transactionStatus = resultSetTransactionDetails.getString("STATUS");

                //  if the transaction status is initiated
                //  then we are waiting till transactionWaitTime to complete the transaction
                while (transactionStatus.equalsIgnoreCase("INITIATED")) {

                    Thread.sleep(1000);
                    resultSetTransactionDetails = DataBaseUtility.executeSelectStatement(dbNodalAccount, queryTransactionDetails);

                    transactionStatus = resultSetTransactionDetails.getString("STATUS");
                    if (transactionWaitTime == counter++) {
                        break;
                    }
                }

                //  get data from merchant settlement collection
                MerchantSettlementDetails merchantSettlementDetails = collectionMerchantSettlementDetails.get(paymentSequenceNumber);

                //  set transaction id, idempotent key and status
                merchantSettlementDetails.setBankTransactionId(resultSetTransactionDetails.getString("BANK_TRANSACTION_ID"));
                merchantSettlementDetails.setPayoutTransactionId(resultSetTransactionDetails.getString("PAYOUT_TRANSACTION_ID"));
                merchantSettlementDetails.setTransactionStatus(resultSetTransactionDetails.getString("STATUS"));
                merchantSettlementDetails.setTransactionStatus(resultSetTransactionDetails.getString("STATUS_REASON_CODE"));

                if (transactionStatus.equalsIgnoreCase("SUCCESS") || transactionStatus.equalsIgnoreCase("PENDING")) {

                    //  query core transaction table to get transaction data
                    String queryCoreTransaction = "Select * from JPB_CORE_TRANSACTION where TRANSACTION_ID = '" + merchantSettlementDetails.getBankTransactionId() + "'";
                    ResultSet resultSetCoreTransaction = DataBaseUtility.executeSelectStatement(dbNodalAccount, queryCoreTransaction);
                    resultSetCoreTransaction.next();

                    //  set type and subtype
                    merchantSettlementDetails.setType(resultSetCoreTransaction.getString("METHOD_TYPE"));
                    merchantSettlementDetails.setSubType(resultSetCoreTransaction.getString("METHOD_SUB_TYPE"));

                    // query transaction service data base to get PROCESSOR_TRANSACTION_ID
                    String queryTransaction = "Select * from JPB_TRANSACTION where TRANSACTION_ID = '" + resultSetCoreTransaction.getString("IDEMPOTENT_KEY") + "' and INVOICE = '" + resultSetCoreTransaction.getString("INVOICE") + "'";
                    ResultSet resultSetTransaction = DataBaseUtility.executeSelectStatement(dbTransactionService, queryTransaction);

                    Connection connectionCBS;

                    //  423 : fund transfer
                    //  421 : NEFT
                    if (resultSetCoreTransaction.getString("METHOD_TYPE") == "421") {
                        while (resultSetTransaction.next()) {
                            if (resultSetTransaction.getString("METHOD_TYPE") == "231") {

                                //  get CBS instance on the basis of account number
                                connectionCBS = CommonMethods.getCBSInstanceByAccountNumber(resultSetTransaction.getString("PAYEE_ACCOUNT_NUMBER"));

                            } else {
                                connectionCBS = CommonMethods.getCBSInstanceByAccountNumber(resultSetTransaction.getString("PAYER_ACCOUNT_NUMBER"));
                            }

                            //  validate result in CBS
                            validateRecordInCBSDatabase(connectionCBS, resultSetTransaction.getString("PROCESSOR_TRANSACTION_ID"), paymentSequenceNumber);
                        }
                    } else if (resultSetCoreTransaction.getString("METHOD_TYPE") == "421") {
                        resultSetTransaction.next();

                        //  get CBS instance and validate result in CBS
                        connectionCBS = CommonMethods.getCBSInstanceByAccountNumber(resultSetTransaction.getString("PAYER_ACCOUNT_NUMBER"));
                        validateRecordInCBSDatabase(connectionCBS, resultSetTransaction.getString("PROCESSOR_TRANSACTION_ID"), paymentSequenceNumber);

                        //  for NEFT transaction, storing UTR number
                        merchantSettlementDetails.setUtrNumber(resultSetTransactionDetails.getString("UTR_NUMBER"));
                    } else {
                        throw new Exception("invalid transaction performed. Transaction method type is :" + resultSetTransaction.getString("METHOD_TYPE"));
                    }
                    successTransactions.put(paymentSequenceNumber, merchantSettlementDetails);
                } else if (resultSetTransactionDetails.getString("RESPONSE_FILE_ID").equalsIgnoreCase("null")) {

                    //  records that are not present in reponse file
                    failedTransactionsWithNoResponse.put(paymentSequenceNumber, merchantSettlementDetails);
                } else {
                    failedTransactions.put(paymentSequenceNumber, merchantSettlementDetails);
                }
            }

            if (successTransactions.size() != 0)
                Reporter.logReport(NodalAccountBL.class, log_Type_Log,
                        "Nodal account success transactions count : " + successTransactions.size() + "<br /> transactions are :" + String.join(" | ", successTransactions.keySet()), null);

            if (failedTransactions.size() != 0)
                Reporter.logReport(NodalAccountBL.class, log_Type_Log,
                        "Nodal account failed transactions count : " + failedTransactions.size() + "<br /> transactions are :" + String.join(" | ", failedTransactions.keySet()), null);

            if (failedTransactionsWithNoResponse.size() != 0)
                Reporter.logReport(NodalAccountBL.class, log_Type_Log,
                        "Nodal account failed transactions with no response count : " + failedTransactionsWithNoResponse.size() + "<br /> transactions are :" + String.join(" | ", successTransactions.keySet()), null);

            int totalNumberofRecords = successTransactions.size() + failedTransactions.size() + failedTransactionsWithNoResponse.size();

            if (collectionMerchantSettlementDetails.size() == totalNumberofRecords)
                Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                        "Nodal account transaction successfully validated.", null);
            else
                throw new Exception("DB and actual record mismatched.");
        } catch (Exception e) {

            Reporter.logReport(NodalAccountBL.class, log_Type_Fail, "nodal account validation failed.", e);

            throw new RuntimeException("nodal account validation failed.", e);
        }
    }

    private void validateRecordInCBSDatabase(Connection connectionCBS, String referenceNumber, String paymentSequenceNumber) {
        try {

            String queryCBS = "Select * from TBAADM.DTD where REF_NUM = '" + referenceNumber + "'";
            ArrayList<String> tranList = DataBaseUtility.getDatabaseRecords(connectionCBS, queryCBS).get("PART_TRAN_TYPE");

            if (tranList.size() == 0) {
                throw new Exception("no records are presnet in CBS DB. query db to validate result." + queryCBS);
            } else {
                String[] tranType = {"C", "D"};

                for (String str : tranType) {
                    if (!tranList.contains(str))
                        Assert.assertTrue(false, String.format("Type %s is not present in DB", str));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("error while validating the transaction. Payment sequence number is : " + paymentSequenceNumber, e);
        }
    }

    public void validateSettlementRecordsInResponseFile(Path path) {
        try {

            String query = "Select * from TRANSACTION_DETAILS where INPUT_FILE_NAME = '" + path.getFileName().toString() + "' and RESPONSE_FILE_ID is not null";
            ArrayList<String> collectionResponseFile = DataBaseUtility.getDatabaseRecords(dbNodalAccount, query).get("RESPONSE_FILE_ID");

            for (String responseFileName : collectionResponseFile) {
                //  get the source directory
                String sourceDir = path.getParent().toString();

                //  get encrypted file name
                //  once the issue resolved change the file name .pgp to .gpg
                String encryptedResponseFileName = responseFileName.substring(0, responseFileName.lastIndexOf(".")).concat(".pgp");

                // get file from SFTP server to local
                UnixUtility.getFileUsingSftp(SIT_NODAL_ACCOUNT_SFTP_OUT_DIR_PATH, sourceDir, encryptedResponseFileName);

                //  decrypt response file
                FileSecurity.decryptFile(sourceDir, encryptedResponseFileName);

                // store response records in collection for verification
                getDataFromResponseFile(sourceDir + "//" + responseFileName);

            }

            //  check success DB records in response file
            validateTransactionInResponseFile(successTransactions, collectionSuccessResponseRecords, "Success Transaction");

            //  check failed DB records in response file
            validateTransactionInResponseFile(failedTransactions, collectionFailResponseRecords, "Failed Transaction");

            Reporter.logReport(NodalAccountBL.class, log_Type_Log,
                    "response : number of success records : " + collectionSuccessResponseRecords.size() + "<br /> records are : " + String.join(" | ", collectionSuccessResponseRecords.keySet()), null);

            Reporter.logReport(NodalAccountBL.class, Constants.log_Type_Log,
                    "response : number of failed records : " + collectionFailResponseRecords.size() + "<br /> records are : " + String.join(" | ", collectionFailResponseRecords.keySet()), null);

            Reporter.logReport(NodalAccountBL.class, log_Type_Pass,
                    "successfully verified the records in response file.", null);

        } catch (Exception e) {

            Reporter.logReport(NodalAccountBL.class, log_Type_Fail,
                    "error while validating the records in response file.", e);

            throw new RuntimeException("error while checking the record in database.", e);
        }
    }

    private void getDataFromResponseFile(String fullFilePath) throws IOException {
        String line;
        int count = 0;

        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(fullFilePath));
            while ((line = bufferedReader.readLine()) != null) {
                if (count != 0) {
                    String[] responseDetails = line.split(",");    // use comma as separator

                    ResponseFileDetails responseFileDetails = new ResponseFileDetails();

                    responseFileDetails.setMerchantId(responseDetails[0]);
                    responseFileDetails.setBankTransactionId(responseDetails[0]);
                    responseFileDetails.setDateOfSettlement(responseDetails[0]);
                    responseFileDetails.setTransactionStatus(responseDetails[0]);
                    responseFileDetails.setNodalAccountNumber(responseDetails[0]);
                    responseFileDetails.setMerchantSettlementAccountNumber(responseDetails[0]);
                    responseFileDetails.setMerchantSettlementIFSCNumber(responseDetails[0]);
                    responseFileDetails.setSettlementIdentifier(responseDetails[0]);
                    responseFileDetails.setUtrNumber(responseDetails[0]);

                    if (responseFileDetails.getTransactionStatus().equalsIgnoreCase("SUCCESS") ||
                            responseFileDetails.getTransactionStatus().equalsIgnoreCase("PENDING")) {

                        //  get response for success transaction
                        collectionSuccessResponseRecords.put(responseFileDetails.getSettlementIdentifier(), responseFileDetails);
                    } else {
                        //  get response for failed transaction
                        collectionFailResponseRecords.put(responseFileDetails.getSettlementIdentifier(), responseFileDetails);
                    }
                }
            }
        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
    }

    private void validateTransactionInResponseFile(Map<String, MerchantSettlementDetails> collectionDB, Map<String, ResponseFileDetails> collectionResponse, String message) {
        try {
            if (collectionDB.size() == collectionResponse.size()) {

                List<String> mismatchedRecords = new ArrayList<>();
                for (String paymentSequenceNumber : collectionDB.keySet()) {

                    boolean flag;
                    MerchantSettlementDetails merchantSettlementDetails = collectionMerchantSettlementDetails.get(paymentSequenceNumber);
                    ResponseFileDetails responseFileDetails = collectionResponse.get(paymentSequenceNumber);

                    if ((merchantSettlementDetails.getBankTransactionId() == responseFileDetails.getBankTransactionId()) &&
                            (merchantSettlementDetails.getBankTransactionId() == responseFileDetails.getBankTransactionId()) &&
                            (merchantSettlementDetails.getBankTransactionId() == responseFileDetails.getBankTransactionId()) &&
                            (merchantSettlementDetails.getBankTransactionId() == responseFileDetails.getBankTransactionId()) &&
                            (merchantSettlementDetails.getBankTransactionId() == responseFileDetails.getBankTransactionId())) {
                        flag = true;
                    } else {
                        flag = false;
                    }

                    //  add seq number if found mismatch
                    if (!flag)
                        mismatchedRecords.add(paymentSequenceNumber);
                }

                if (mismatchedRecords.size() != 0) {
                    throw new Exception(message + " : mismatched DB records and response records.<br />records are : " + String.join(" | ", mismatchedRecords));
                }

            } else {
                throw new Exception(message + " : mismatch in DB transaction and records in response file.");
            }
        } catch (Exception e) {
            throw new RuntimeException("error while comparing the records.", e);
        }
    }
}
