package client.nodalAccount;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.Header;
import entity.accountEntity.GetBalanceEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Map;

public class BalanceInquiryBL extends SetUp {

    public String createBalanceInquiryPayload(String accountNumber) {
        try {

            GetBalanceEntity getBalanceEntity = new GetBalanceEntity();
            Gson request = new Gson();

            getBalanceEntity.setAccountNumber(accountNumber);
            String payload = request.toJson(getBalanceEntity);

            Reporter.logReport(BalanceInquiryBL.class, log_Type_Pass,
                    "balance inquiry payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(BalanceInquiryBL.class, log_Type_Fail,
                    "error while creating the get balance payload.", e);

            throw new RuntimeException("error while creating the get balance payload.", e);
        }
    }

    public Map<String, String> setBalanceInquiryHeader() {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            Reporter.logReport(BalanceInquiryBL.class, log_Type_Pass,
                    "balance inquiry header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(BalanceInquiryBL.class, log_Type_Fail,
                    "error while setting the balance inquiry header.", e);

            throw new RuntimeException("error while setting the balance inquiry header.", e);
        }
    }

    public Response postBalanceInquiry(String requestBody, Map<String, String> header) {
        try {

            Response balanceInquiryResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("NodalAccount_BalanceInquiry"), header);

            Reporter.logReport(BalanceInquiryBL.class, log_Type_Pass,
                    "Get address api response : " + balanceInquiryResponse.prettyPrint(), null);

            return balanceInquiryResponse;

        } catch (Exception e) {
            Reporter.logReport(BalanceInquiryBL.class, log_Type_Fail,
                    "error while posting the balance inquiry api.", e);

            throw new RuntimeException("error while posting the balance inquiry api.", e);
        }
    }

    public void validateBalanceInquiryResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(BalanceInquiryBL.class, log_Type_Pass,
                    "balance inquiry api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(BalanceInquiryBL.class, log_Type_Fail,
                    "error while validating the balance inquiry api response status.", e);

            throw new RuntimeException("error while validating the balance inquiry api response status.", e);
        }
    }

    public void validateBalanceInquiryResponse(Response apiResponse, String accountNumber) {
        try {

            SoftAssert softAssert = new SoftAssert();
            DecimalFormat decimalFormat = new DecimalFormat("0.00");

            String query = "select * from TBAADM.GAM where FORACID = '" + accountNumber + "'";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbCBS2, query);

            resultSet.next();
            String balanceExpected = decimalFormat.format(Double.parseDouble(resultSet.getString("CLR_BAL_AMT")));
            String balanceActual = decimalFormat.format(Double.parseDouble(apiResponse.jsonPath().getString("effectiveBalance")));


            softAssert.assertEquals(balanceActual, balanceExpected);
            softAssert.assertAll();

            Reporter.logReport(BalanceInquiryBL.class, log_Type_Pass,
                    "balance inquiry api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(BalanceInquiryBL.class, log_Type_Fail,
                    "error while validating the balance inquiry api response.", e);

            throw new RuntimeException("error while validating the balance inquiry api response.", e);
        }
    }
}
