package client.transaction;

import base.SetUp;
import com.google.gson.Gson;
import com.jayway.jsonpath.JsonPath;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.Header;
import entity.InitiatingEntity;
import entity.Transaction;
import entity.TransactionEntity.TransactionEntity;
import entity.TransactionMethod;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.Error;
import responseEntity.TransactionResponseEntity.TransactionResponseEntity;
import responseEntity.errorEntity.ErrorResponse;
import utils.CommonMethods;
import utils.DigitalSignature;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DebitTransactionBL extends SetUp {

    enum transactionTableValues {
        id("TRANSACTION_ID"), idempotentKey("IDEMPOTENT_KEY"), arrivalDate("ARRIVAL_DATE"), created("CREATED"),
        currency("CURRENCY"), mode("TRANSACTION_MODE"), type("METHOD_TYPE"), subType("METHOD_SUB_TYPE"),
        captureMethod("CAPTURE_METHOD"), status("STATUS"), application("APPLICATION_ID"), entityId("INITIATING_ENTITY_ID"),
        callbackUrl("CALLBACK_URL"), invoice("INVOICE"), responseTime("RESPONSE_TIME"), netAmount("NET_AMOUNT"),
        grossAmount("GROSS_AMOUNT"), payeeType("PAYEE_CUSTOMER_TYPE"), payeeName("PAYEE_NAME"), payeeMmid("PAYEE_MMID"),
        payeeAccountNumber("PAYEE_ACCOUNT_NUMBER"), payeeBankIFSC("PAYEE_BANK_IFSC"), payeeBankName("PAYEE_BANK_NAME"),
        payeeMerchantId("PAYEE_MERCHANT_ID"), payeeTerminalId("PAYEE_TERMINAL_ID"), payeeMobile("PAYEE_MOBILE_NUMBER"),
        payerType("PAYER_CUSTOMER_TYPE"), payerName("PAYER_NAME"), payerMmid("PAYER_MMID"), payerAccountNumber("PAYER_ACCOUNT_NUMBER"),
        payerBankIFSC("PAYER_BANK_IFSC"), payerBankName("PAYER_BANK_NAME"), payerMerchantId("PAYER_MERCHANT_ID"),
        payerTerminalId("PAYER_TERMINAL_ID"), payerMobile("PAYER_MOBILE_NUMBER"), originalId("ORIGINAL_TRANSACTION_ID");

        private String eqValue;

        transactionTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    Gson request = new Gson();
    public TransactionEntity transactionEntity;
    public String originalTransactionId;
    public boolean isStoreOriginalTransactionId = false;


    public Map<String, String> setDebitTransactionHeader() {
        try {
            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);

            String query = "Select * from jpb_channel where CHANNEL_ID = "
                    + transactionEntity.getTransaction().getInitiatingEntity().getEntityId();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("channel id is not present in database.");

            resultSet.next();
            header.put("X-CHANNEL-ID", resultSet.getString("CHANNEL_ID"));
            header.put("X-API-KEY", resultSet.getString("API_TOKEN"));

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while setting the Debit transaction header.", e);

            throw new RuntimeException("error while setting the debit transaction header.", e);
        }
    }

    public Map<String, String> setInvalidDebitTransactionHeader(String param, String val) {
        try {
            Map<String, String> header = setDebitTransactionHeader();

            switch (param.toUpperCase()){
                case("X-CHANNEL-ID"):
                    header.replace("X-CHANNEL-ID", val);
                    break;
                case("X-API-KEY"):
                    header.replace("X-API-KEY", val);
                    break;
            }

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction invalid header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while setting the Debit transaction invalid header.", e);

            throw new RuntimeException("error while setting the debit transaction invalid header.", e);
        }
    }

    public String createDebitTransactionPayload(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {
        String payload;
        try {

            transactionEntity = new TransactionEntity();
            Gson request = new Gson();

            //  create new idempotent key
            String idempotentKey = CommonMethods.generateNewIdempotentKey();

            InitiatingEntity initiatingEntity = CommonMethods.getDefaultInitiatingEntity(entityId);
            TransactionMethod transactionMethod = CommonMethods.getTransactionMethod(TYPE_DEBIT, subType);

            Transaction transaction = CommonMethods.createTransaction(idempotentKey, initiatingEntity, transactionMethod, applicationId, mode);
            //transaction.setMode(mode);

            transactionEntity.setTransaction(transaction);
            transactionEntity.setAmount(CommonMethods.generateAmount());
            transactionEntity.setPayer(CommonMethods.getGenericPayer(accountNumber, bankIFSC));

            payload = request.toJson(transactionEntity);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while creating the get Debit transaction payload.", e);

            throw new RuntimeException("error while creating the Debit transaction.", e);
        }
    }

    public String addNarrationInTransaction(String statementDescriptor) {
        String payload;
        try {

            transactionEntity.getTransaction().setStatementDescriptor(statementDescriptor);
            payload = request.toJson(transactionEntity);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "added statement descriptor.", null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while adding the statement descriptor.", e);

            throw new RuntimeException("error while adding the statement descriptor.", e);
        }
    }

    protected TransactionEntity createDebitTransactionPayload(int subType, int applicationId, int initiatingEntityID, int mode) {

        transactionEntity = new TransactionEntity();
        String idempotentKey = CommonMethods.generateNewIdempotentKey();

        InitiatingEntity initiatingEntity = CommonMethods.getDefaultInitiatingEntity(initiatingEntityID);

        TransactionMethod transactionMethod = CommonMethods.getTransactionMethod(TYPE_DEBIT, subType);
        Transaction transaction = CommonMethods.createTransaction(idempotentKey, initiatingEntity, transactionMethod, applicationId, mode);

        transactionEntity.setTransaction(transaction);
        transactionEntity.setAmount(CommonMethods.generateAmount());
        transactionEntity.setPayer(CommonMethods.getGenericPayer());

        return transactionEntity;
    }

    public String createJsonPayload(TransactionEntity transactionEntity) {
        String payload = request.toJson(transactionEntity);
        Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                "Debit transaction payload has been created. Payload : " + payload, null);
        return payload;
    }

    public Response postDebitTransaction(String requestBody, Map<String, String> header) {
        try {

            Response getDebitResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Transactions_Payments"), header);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction api response : " + getDebitResponse.prettyPrint(), null);

            return getDebitResponse;

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while posting the Debit transaction api.", e);

            throw new RuntimeException("error while posting the Debit transaction api.", e);
        }
    }

    public void validateDebitTransactionResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while validating the Debit transaction API response status.", e);

            throw new RuntimeException("error while validating the Debit transaction API response status.", e);
        }
    }

    public void validateDebitTransactionResponse(Response apiResponse, String amountBeforeDebit, String amountAfterDebit) {
        try {

            double balance;

            TransactionResponseEntity transactionResponse = apiResponse.as(TransactionResponseEntity.class);
            Map<String, Object> mappedData = getMappedData(transactionResponse);

            Assert.assertTrue(mappedData.get("status").toString().equalsIgnoreCase("SUCCESS"),
                    " is transaction successful?");

            validateTransactionRecords(mappedData);

            if (transactionEntity.getTransaction().getMethod().getSubType() == SUB_TYPE_DEBIT_REVERSAL)
                balance = Double.parseDouble(amountBeforeDebit) + transactionEntity.getAmount().getNetAmount();
            else
                balance = Double.parseDouble(amountBeforeDebit) - transactionEntity.getAmount().getNetAmount();

            //  verify balance
            Assert.assertEquals(amountAfterDebit, String.valueOf(balance), "Amount mismatch after debit transaction");
            validateTransactionInCBS(transactionResponse);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction API validated.", null);

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while validating the Debit transaction API.", e);

            throw new RuntimeException("error while validating the Debit transaction API.", e);
        }
    }

    public void validateDebitTransactionSuccess(Response apiResponse) {
        try {
            TransactionResponseEntity transactionResponse = apiResponse.as(TransactionResponseEntity.class);
            Map<String, Object> mappedData = getMappedData(transactionResponse);
            Assert.assertTrue(mappedData.get("status").toString().equalsIgnoreCase("SUCCESS"),
                    "Is Debit transaction successful?");
            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction is successful", null);
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "Debit transaction not successful", e);

            throw new RuntimeException("Debit transaction not successful", e);
        }

    }

    private Map<String, Object> getMappedData(TransactionResponseEntity transactionEntity) {
        Map<String, Object> mapTransactionEntity = new HashMap<>();

        mapTransactionEntity.put("id", transactionEntity.getTransaction().getId());
        mapTransactionEntity.put("originalId", transactionEntity.getTransaction().getOriginalId());
        mapTransactionEntity.put("idempotentKey", transactionEntity.getTransaction().getIdempotentKey());
        mapTransactionEntity.put("arrivalDate", transactionEntity.getTransaction().getArrivalDate());
        mapTransactionEntity.put("created", transactionEntity.getTransaction().getCreated());
        mapTransactionEntity.put("currency", transactionEntity.getTransaction().getCurrency());
        mapTransactionEntity.put("failureCode", transactionEntity.getTransaction().getFailureCode());
        mapTransactionEntity.put("failureMessage", transactionEntity.getTransaction().getFailureMessage());
        mapTransactionEntity.put("mode", transactionEntity.getTransaction().getMode());
        mapTransactionEntity.put("type", transactionEntity.getTransaction().getMethod().getType());
        mapTransactionEntity.put("subType", transactionEntity.getTransaction().getMethod().getSubType());
        mapTransactionEntity.put("captureMethod", transactionEntity.getTransaction().getCaptureMethod());
        mapTransactionEntity.put("status", transactionEntity.getTransaction().getStatus());
        mapTransactionEntity.put("application", transactionEntity.getTransaction().getApplication());
        mapTransactionEntity.put("entityId", transactionEntity.getTransaction().getInitiatingEntity().getEntityId());
        mapTransactionEntity.put("callbackUrl", transactionEntity.getTransaction().getInitiatingEntity().getCallbackUrl());
        mapTransactionEntity.put("invoice", transactionEntity.getTransaction().getInvoice());
        mapTransactionEntity.put("responseTime", transactionEntity.getTransaction().getResponseTime());

        mapTransactionEntity.put("netAmount", transactionEntity.getAmount().getNetAmount());
        mapTransactionEntity.put("grossAmount", transactionEntity.getAmount().getGrossAmount());

        mapTransactionEntity.put("payeeType", transactionEntity.getPayee().getType());
        mapTransactionEntity.put("payeeName", transactionEntity.getPayee().getName());
        mapTransactionEntity.put("payeeMmid", transactionEntity.getPayee().getMmid());
        mapTransactionEntity.put("payeeAccountNumber", transactionEntity.getPayee().getAccountNumber());
        mapTransactionEntity.put("payeeBankIFSC", transactionEntity.getPayee().getBankIfsc());
        mapTransactionEntity.put("payeeBankName", transactionEntity.getPayee().getBankName());
        mapTransactionEntity.put("payeeMerchantId", transactionEntity.getPayee().getMerchantId());
        mapTransactionEntity.put("payeeTerminalId", transactionEntity.getPayee().getTerminalId());
        mapTransactionEntity.put("payeeMobile", transactionEntity.getPayee().getMobile().getNumber());

        mapTransactionEntity.put("payerType", transactionEntity.getPayer().getType());
        mapTransactionEntity.put("payerName", transactionEntity.getPayer().getName());
        mapTransactionEntity.put("payerMmid", transactionEntity.getPayer().getMmid());
        mapTransactionEntity.put("payerAccountNumber", transactionEntity.getPayer().getAccountNumber());
        mapTransactionEntity.put("payerBankIFSC", transactionEntity.getPayer().getBankIfsc());
        mapTransactionEntity.put("payerBankName", transactionEntity.getPayer().getBankName());
        mapTransactionEntity.put("payerMerchantId", transactionEntity.getPayer().getMerchantId());
        mapTransactionEntity.put("payerTerminalId", transactionEntity.getPayer().getTerminalId());
        mapTransactionEntity.put("payerMobile", transactionEntity.getPayer().getMobile().getNumber());

        return mapTransactionEntity;
    }

    private void validateTransactionRecords(Map<String, Object> mappedData) {
        try {
            SoftAssert softAssert = new SoftAssert();
            DecimalFormat decimalFormat = new DecimalFormat("0.0");

            String query = "Select * from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + mappedData.get("idempotentKey") + "' and INVOICE = '" + mappedData.get("invoice") + "' and APPLICATION_ID = " +
                    mappedData.get("application");
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);

            resultSet.next();
            for (String key : mappedData.keySet()) {

                Object response = mappedData.get(key);
                if (response != null) {
                    if (response instanceof String) {
                        String columnValue = DebitTransactionBL.transactionTableValues.valueOf(key).eqValue;

                        switch (key) {
                            case "arrivalDate":
                            case "created":
                            case "responseTime":
                                String dateActual = DateUtility.convertDateToNewFormat(
                                        //TODO: need to change the new format
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(resultSet.getString(columnValue)),
                                        "yyyy-MM-dd HH:mm:ss");

                                String dateExpected = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse((String) mappedData.get(key)),
                                        "yyyy-MM-dd HH:mm:ss");

                                softAssert.assertEquals(dateActual, dateExpected);
                                break;
                            default:
                                softAssert.assertEquals((String) mappedData.get(key), resultSet.getString(columnValue));
                        }
                    }

                    if (response instanceof Double) {
                        String actual = decimalFormat.format(mappedData.get(key));
                        String expected = decimalFormat.format(resultSet.getObject(DebitTransactionBL.transactionTableValues.valueOf(key).eqValue));
                        softAssert.assertEquals(actual, expected);
                    }

                    if (response instanceof Integer) {
                        int actual = (int) mappedData.get(key);
                        if (actual != 0) {
                            int expected = resultSet.getInt(DebitTransactionBL.transactionTableValues.valueOf(key).eqValue);
                            softAssert.assertEquals(actual, expected);
                        }
                    }
                }
            }
            if (!isStoreOriginalTransactionId) {
                originalTransactionId = resultSet.getString("ORIGINAL_TRANSACTION_ID");
                isStoreOriginalTransactionId = true;
            }
            softAssert.assertAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void validateFailedTransactionResponse(Response apiResponse, String failureCode, String failureMessage) {
        CommonMethods.validateFailedTransactionResponse(apiResponse, failureCode, failureMessage);
    }

    public void validateDebitTransactionFailure(Response apiResponse, String failureCode, String failureMessage) {

        try {
            CommonMethods.validateFailedTransactionResponse(apiResponse, failureCode, failureMessage);
            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Error message, status & code are correct.", null);
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "Error message, status & code are incorrect.", e);
        }
    }

    public String createDebitReversalPayload() {
        try {
            transactionEntity = CommonMethods.createTransactionReversalPayload(transactionEntity, originalTransactionId);

            String payload = request.toJson(transactionEntity);
            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit Reversal payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while creating the Debit reversal Txn payload.", e);

            throw new RuntimeException("error while creating the debit reversal payload.", e);
        }

    }

    public String createDebitReversalPayload(String paramType, Object paramVal) {
        try {
            transactionEntity = CommonMethods.createTransactionReversalPayload(transactionEntity, originalTransactionId);
            modifyDebitTxnPayload(paramType, paramVal, false, null);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit Reversal payload has been created. Payload : ", null);
            return request.toJson(transactionEntity);
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while creating the Debit reversal Txn payload.", e);

            throw new RuntimeException("error while creating the debit reversal payload.", e);
        }
    }

    /*
     * Method to modify transaction Entity parameters after creating a transaction entity
     * */
    public String modifyDebitTxnPayload(String paramType, Object paramVal, boolean modifySerialization, String action) {

        try {
            String modifiedPayload = CommonMethods.modifyTxnPayload(transactionEntity, paramType, paramVal, modifySerialization, action);
            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit Txn payload has been modified. New Payload : " + modifiedPayload, null);
            return modifiedPayload;
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while modifying the Debit payload.", e);

            throw new RuntimeException("error while modifying the debit payload.", e);
        }
    }

    public String createDebitReversalPayload(Map<Object, Object> testData) {
        String payload;
        try {
            transactionEntity = CommonMethods.createTransactionReversalPayload(testData);
            payload = request.toJson(transactionEntity);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit Reversal payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while creating the Debit reversal payload.", e);

            throw new RuntimeException("error while creating the debit reversal payload.", e);
        }
    }

    public void verifyAccountBalanceUnchanged(String beforeBalance, String afterBalance) {
        Assert.assertEquals(beforeBalance, afterBalance, "previous & new Balance mismatch");
    }

    /*
     * Add digital signature when entity ID is provided
     * */
    public Map<String, String> addDigitalSignature(Map<String, String> header, String payload, int entityId) {

        String certificatePath = CommonMethods.getCertificatePath(entityId);
        String signature = DigitalSignature.generateSignature(payload, certificatePath);
        header.put("x-signature", signature);
        return header;
    }

    /*
     * extract entityId from payload and generate digitalSignature
     * */
    public Map<String, String> addDigitalSignature(Map<String, String> header, String payload) {

        JSONObject jsonObject = new JSONObject(payload);
        int entityID = jsonObject.getInt(PATH_ENTITY_ID);
        return addDigitalSignature(header, payload, entityID);
    }


    public Response postDebitTransactionPayouts(String requestBody, Map<String, String> header) {
        try {

            Response getDebitResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Transactions_Payouts"), header);

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "transaction payout api response : " + getDebitResponse.prettyPrint(), null);

            return getDebitResponse;

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while posting the transaction payout api.", e);

            throw new RuntimeException("error while posting the transaction payout api response api.", e);
        }
    }

    /*
     * Transaction validation in CBS
     * */
    public void validateTransactionInCBS(TransactionResponseEntity transactionResponse) {
        try {
            String query = "Select PROCESSOR_TRANSACTION_ID from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + transactionResponse.getTransaction().getIdempotentKey() + "' and INVOICE = '" +
                    transactionResponse.getTransaction().getInvoice() + "' and APPLICATION_ID = " +
                    transactionResponse.getTransaction().getApplication();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            resultSet.next();

            String referenceNumber = resultSet.getString("PROCESSOR_TRANSACTION_ID");
            String queryCBS = "Select * from TBAADM.DTD where REF_NUM = '" + referenceNumber + "'";

            ArrayList<String> tranList = DataBaseUtility.getDatabaseRecords(dbCBS2, queryCBS).get("PART_TRAN_TYPE");
            String[] tranType = {"C", "D"};

            for (String str : tranType) {
                if (!tranList.contains(str))
                    Assert.fail("Type " + str + " is not present in DB");
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyPermissionDeniedMessage(Response apiResponse){
        SoftAssert softAssert = new SoftAssert();
        try{

            Error error = apiResponse.as(Error.class);
            softAssert.assertEquals(error.getCode(), "50302", "is error code correct?");
            softAssert.assertEquals(error.getMessage().trim(), "Permission Denied", "is error message correct?");
            softAssert.assertAll();

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "error code & error message are correct.", null);
        }
        catch (Exception e){
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while validating error code & message.", e);

            throw new RuntimeException("error while validating error code & message.", e);
        }
    }

}
