package client.transaction;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.*;
import entity.TransactionEntity.TransactionEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.TransactionResponseEntity.TransactionResponseEntity;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AuthCaptureCancelBL extends SetUp {

    enum transactionTableValues {
        id("TRANSACTION_ID"), idempotentKey("IDEMPOTENT_KEY"), arrivalDate("ARRIVAL_DATE"), created("CREATED"),
        currency("CURRENCY"), mode("TRANSACTION_MODE"), type("METHOD_TYPE"), subType("METHOD_SUB_TYPE"),
        captureMethod("CAPTURE_METHOD"), status("STATUS"), application("APPLICATION_ID"), entityId("INITIATING_ENTITY_ID"),
        callbackUrl("CALLBACK_URL"), invoice("INVOICE"), responseTime("RESPONSE_TIME"), netAmount("NET_AMOUNT"),
        grossAmount("GROSS_AMOUNT"), payeeType("PAYEE_CUSTOMER_TYPE"), payeeName("PAYEE_NAME"), payeeMmid("PAYEE_MMID"),
        payeeAccountNumber("PAYEE_ACCOUNT_NUMBER"), payeeBankIFSC("PAYEE_BANK_IFSC"), payeeBankName("PAYEE_BANK_NAME"),
        payeeMerchantId("PAYEE_MERCHANT_ID"), payeeTerminalId("PAYEE_TERMINAL_ID"), payeeMobile("PAYEE_MOBILE_NUMBER"),
        payerType("PAYER_CUSTOMER_TYPE"), payerName("PAYER_NAME"), payerMmid("PAYER_MMID"), payerAccountNumber("PAYER_ACCOUNT_NUMBER"),
        payerBankIFSC("PAYER_BANK_IFSC"), payerBankName("PAYER_BANK_NAME"), payerMerchantId("PAYER_MERCHANT_ID"),
        payerTerminalId("PAYER_TERMINAL_ID"), payerMobile("PAYER_MOBILE_NUMBER"), authorizationCode("AUTHORIZATION_CODE"), originalId("ORIGINAL_TRANSACTION_ID");

        private String eqValue;

        transactionTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    Gson request = new Gson();
    public TransactionEntity transactionEntity;
    public String authenticationCode;
    public String originalTransactionId;
    public boolean isStore = false;

    public String createAuthTransactionPayload(String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {
        String payload;
        try {
            transactionEntity = new TransactionEntity();

            //  create new idempotent key
            String idempotentKey = CommonMethods.generateNewIdempotentKey();

            InitiatingEntity initiatingEntity = CommonMethods.getDefaultInitiatingEntity(entityId);
            TransactionMethod transactionMethod = CommonMethods.getTransactionMethod(TYPE_AUTH);

            Transaction transaction = CommonMethods.createTransaction(idempotentKey, initiatingEntity, transactionMethod, applicationId, mode);
            transaction.setDescription("auth transaction : paid to third party");

            transactionEntity.setTransaction(transaction);
            transactionEntity.setAmount(CommonMethods.generateAmount());

            transactionEntity.setPayer(CommonMethods.getGenericPayer(accountNumber, bankIFSC));
            payload = CommonMethods.removeSubType(transactionEntity);

            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Pass,
                    "Auth transaction payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Fail,
                    "error while creating the get auth transaction payload.", e);

            throw new RuntimeException("error while creating the auth transaction payload.", e);
        }
    }

    public String createCaptureCancelTransactionPayload(int type) {
        String payload;
        try {
            transactionEntity = CommonMethods.createTransactionCaptureCancelPayload(transactionEntity, originalTransactionId, authenticationCode, type);
            payload = CommonMethods.removeSubType(transactionEntity);

            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Pass,
                    "capture/cancel transaction payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Fail,
                    "error while creating the get capture/cancel transaction payload.", e);

            throw new RuntimeException("error while creating the capture/cancel transaction payload.", e);
        }
    }

    public Map<String, String> setAuthCaptureCancelTransactionHeader() {
        try {
            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);

            String query = "Select * from jpb_channel where CHANNEL_ID = "
                    + transactionEntity.getTransaction().getInitiatingEntity().getEntityId();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("channel id is not present in database.");

            resultSet.next();
            header.put("X-CHANNEL-ID", resultSet.getString("CHANNEL_ID"));
            header.put("X-API-KEY", resultSet.getString("API_TOKEN"));

            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Pass,
                    "transaction header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Fail,
                    "error while setting the auth/capture/cancel transaction header.", e);

            throw new RuntimeException("error while setting the auth/capture/cancel transaction header.", e);
        }
    }

    public Response postAuthCaptureCancelTransaction(String requestBody, Map<String, String> header) {
        try {

            Response getBalanceResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Transactions_Payments"), header);

            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Pass,
                    "auth/capture/cancel transaction api response : " + getBalanceResponse.prettyPrint(), null);

            return getBalanceResponse;

        } catch (Exception e) {
            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Fail,
                    "error while posting the auth/capture/cancel transaction api.", e);

            throw new RuntimeException("error while posting the auth/capture/cancel transaction api.", e);
        }
    }

    public void validateAuthCaptureCancelTransactionResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Pass,
                    "auth/capture/cancel transaction API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(AuthCaptureCancelBL.class, log_Type_Fail,
                    "error while validating the auth/capture/cancel transaction API response status.", e);

            throw new RuntimeException("error while validating the auth/capture/cancel transaction API response status.", e);
        }
    }

    public void validateAuthCaptureCancelTransactionResponse(Response apiResponse, Map<String, Double> beforeBalance, Map<String, Double> afterBalance) {
        try {
            SoftAssert softAssert = new SoftAssert();
            double beforeOnHoldBalance;
            double afterOnHoldBalance;

            TransactionResponseEntity transactionResponse = apiResponse.as(TransactionResponseEntity.class);

            Map<String, Object> mappedData = getMappedData(transactionResponse);
            Assert.assertTrue(mappedData.get("status").toString().equalsIgnoreCase("SUCCESS"),
                    "transaction is not successful");

            beforeOnHoldBalance = beforeBalance.get("onHoldBalance");
            afterOnHoldBalance = afterBalance.get("onHoldBalance");

            double beforeTotalBalance = beforeBalance.get("totalBalance");
            double afterTotalBalance = afterBalance.get("totalBalance");
            double netAmount = transactionResponse.getAmount().getNetAmount();

            switch (transactionResponse.getTransaction().getMethod().getType()) {
                case 301:

                    softAssert.assertEquals(afterOnHoldBalance, (beforeOnHoldBalance + netAmount));
                    double finalBalance = beforeOnHoldBalance - netAmount;

                    softAssert.assertEquals(afterTotalBalance, finalBalance);
                    break;
                case 113:

                    if (netAmount > beforeOnHoldBalance) {
                        double remainingAmount = netAmount - beforeOnHoldBalance;
                        softAssert.assertEquals(afterTotalBalance, (beforeTotalBalance - remainingAmount));

                    } else {
                        softAssert.assertEquals(afterOnHoldBalance, (beforeOnHoldBalance - netAmount));
                        softAssert.assertEquals(afterTotalBalance, (beforeTotalBalance + netAmount));
                    }
                    break;
                case 215:

                    softAssert.assertEquals(beforeBalance, afterBalance);
                    softAssert.assertEquals(beforeTotalBalance, afterTotalBalance);

                    break;
            }

            validateTransactionRecords(mappedData);
            Reporter.logReport(CreditTransactionBL.class, log_Type_Pass,
                    "auth capture cancel transaction API validated.", null);

        } catch (Exception e) {
            Reporter.logReport(CreditTransactionBL.class, log_Type_Fail,
                    "error while validating the auth capture cancel transaction API.", e);

            throw new RuntimeException("error while validating the auth capture cancel transaction API.", e);
        }
    }

    public void validateTransactionInCBS(TransactionResponseEntity transactionResponse) {
        try {
            String query = "Select PROCESSOR_TRANSACTION_ID from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + transactionResponse.getTransaction().getIdempotentKey() + "' and INVOICE = '" +
                    transactionResponse.getTransaction().getInvoice() + "' and APPLICATION_ID = " +
                    transactionResponse.getTransaction().getApplication();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            resultSet.next();

            String referenceNumber = resultSet.getString("PROCESSOR_TRANSACTION_ID");
            String queryCBS = "Select * from TBAADM.DTD where REF_NUM = '" + referenceNumber + "'";

            ArrayList<String> tranList = DataBaseUtility.getDatabaseRecords(dbCBS2, queryCBS).get("PART_TRAN_TYPE");
            String[] tranType = {"C", "D"};

            for (String str : tranType) {
                if (!tranList.contains(str))
                    Assert.assertTrue(false, String.format("Type %s is not present in DB", str));
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Map<String, Object> getMappedData(TransactionResponseEntity transactionEntity) {
        Map<String, Object> mapTransactionEntity = new HashMap<>();

        mapTransactionEntity.put("id", transactionEntity.getTransaction().getId());
        mapTransactionEntity.put("idempotentKey", transactionEntity.getTransaction().getIdempotentKey());
        mapTransactionEntity.put("originalId", transactionEntity.getTransaction().getOriginalId());
        mapTransactionEntity.put("arrivalDate", transactionEntity.getTransaction().getArrivalDate());
        mapTransactionEntity.put("created", transactionEntity.getTransaction().getCreated());
        mapTransactionEntity.put("currency", transactionEntity.getTransaction().getCurrency());
        mapTransactionEntity.put("failureCode", transactionEntity.getTransaction().getFailureCode());
        mapTransactionEntity.put("failureMessage", transactionEntity.getTransaction().getFailureMessage());
        mapTransactionEntity.put("mode", transactionEntity.getTransaction().getMode());
        mapTransactionEntity.put("type", transactionEntity.getTransaction().getMethod().getType());
        mapTransactionEntity.put("subType", transactionEntity.getTransaction().getMethod().getSubType());
        mapTransactionEntity.put("captureMethod", transactionEntity.getTransaction().getCaptureMethod());
        mapTransactionEntity.put("status", transactionEntity.getTransaction().getStatus());
        mapTransactionEntity.put("application", transactionEntity.getTransaction().getApplication());
        mapTransactionEntity.put("entityId", transactionEntity.getTransaction().getInitiatingEntity().getEntityId());
        mapTransactionEntity.put("callbackUrl", transactionEntity.getTransaction().getInitiatingEntity().getCallbackUrl());
        mapTransactionEntity.put("invoice", transactionEntity.getTransaction().getInvoice());
        mapTransactionEntity.put("responseTime", transactionEntity.getTransaction().getResponseTime());
        mapTransactionEntity.put("authorizationCode", transactionEntity.getTransaction().getAuthorizationCode());

        mapTransactionEntity.put("netAmount", transactionEntity.getAmount().getNetAmount());
        mapTransactionEntity.put("grossAmount", transactionEntity.getAmount().getGrossAmount());

        mapTransactionEntity.put("payeeType", transactionEntity.getPayee().getType());
        mapTransactionEntity.put("payeeName", transactionEntity.getPayee().getName());
        mapTransactionEntity.put("payeeMmid", transactionEntity.getPayee().getMmid());
        mapTransactionEntity.put("payeeAccountNumber", transactionEntity.getPayee().getAccountNumber());
        mapTransactionEntity.put("payeeBankIFSC", transactionEntity.getPayee().getBankIfsc());
        mapTransactionEntity.put("payeeBankName", transactionEntity.getPayee().getBankName());
        mapTransactionEntity.put("payeeMerchantId", transactionEntity.getPayee().getMerchantId());
        mapTransactionEntity.put("payeeTerminalId", transactionEntity.getPayee().getTerminalId());
        mapTransactionEntity.put("payeeMobile", transactionEntity.getPayee().getMobile().getNumber());

        mapTransactionEntity.put("payerType", transactionEntity.getPayer().getType());
        mapTransactionEntity.put("payerName", transactionEntity.getPayer().getName());
        mapTransactionEntity.put("payerMmid", transactionEntity.getPayer().getMmid());
        mapTransactionEntity.put("payerAccountNumber", transactionEntity.getPayer().getAccountNumber());
        mapTransactionEntity.put("payerBankIFSC", transactionEntity.getPayer().getBankIfsc());
        mapTransactionEntity.put("payerBankName", transactionEntity.getPayer().getBankName());
        mapTransactionEntity.put("payerMerchantId", transactionEntity.getPayer().getMerchantId());
        mapTransactionEntity.put("payerTerminalId", transactionEntity.getPayer().getTerminalId());
        mapTransactionEntity.put("payerMobile", transactionEntity.getPayer().getMobile().getNumber());

        return mapTransactionEntity;
    }

    private void validateTransactionRecords(Map<String, Object> mappedData) {
        try {
            SoftAssert softAssert = new SoftAssert();
            DecimalFormat decimalFormat = new DecimalFormat("0.0");

            String query = "Select * from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + mappedData.get("idempotentKey") + "' and ORIGINAL_TRANSACTION_ID = '" + mappedData.get("originalId") + "' and APPLICATION_ID = " +
                    mappedData.get("application");

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);

            resultSet.next();
            for (String key : mappedData.keySet()) {

                Object response = mappedData.get(key);
                if (response != null) {
                    if (response instanceof String) {
                        String columnValue = AuthCaptureCancelBL.transactionTableValues.valueOf(key).eqValue;

                        switch (key) {
                            case "arrivalDate":
                            case "created":
                            case "responseTime":
                                String dateActual = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(resultSet.getString(columnValue)),
                                        "yyyy-MM-dd HH:mm:ss");

                                String dateExpected = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse((String) mappedData.get(key)),
                                        "yyyy-MM-dd HH:mm:ss");

                                softAssert.assertEquals(dateActual, dateExpected);
                                break;
                            default:
                                softAssert.assertEquals((String) mappedData.get(key), resultSet.getString(columnValue));
                        }
                    }

                    if (response instanceof Double) {
                        String actual = decimalFormat.format(mappedData.get(key));
                        String expected = decimalFormat.format(resultSet.getObject(AuthCaptureCancelBL.transactionTableValues.valueOf(key).eqValue));
                        softAssert.assertEquals(actual, expected);
                    }

                    if (response instanceof Integer) {
                        int actual = (int) mappedData.get(key);
                        if (actual != 0) {
                            int expected = resultSet.getInt(AuthCaptureCancelBL.transactionTableValues.valueOf(key).eqValue);
                            softAssert.assertEquals(actual, expected);
                        }
                    }
                }
            }

            if (!isStore) {
                originalTransactionId = resultSet.getString("ORIGINAL_TRANSACTION_ID");
                authenticationCode = resultSet.getString("AUTHORIZATION_CODE");
                isStore = true;
            }
            softAssert.assertAll();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
