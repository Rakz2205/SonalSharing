package client.transaction;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import entity.Header;
import entity.channelEntity.RegisterChannel;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import utils.DigitalSignature;
import utils.Reporter;

import java.util.Map;

public class RegisterChannelBL extends SetUp {

    public static void RegisterChannel(int channelId) {
        try {
            String encodedPublicKey = DigitalSignature.encodePublicKey();

            RegisterChannel channel = new RegisterChannel();
            channel.setChannelId(String.valueOf(channelId));
            channel.setPublicKey(encodedPublicKey);

            String requestBody = new Gson().toJson(channel);

            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);
            Response response = RestUtil.postByJson(requestBody, apiProperties.getProperty("Channel_Register"), header);

            if (response.getStatusCode() != HttpStatus.SC_OK)
                throw new Exception("not able to register the channel.");

            Reporter.logReport(RegisterChannelBL.class, log_Type_Pass, "channel registered. Channel id : " + channelId, null);
        } catch (Exception e) {
            Reporter.logReport(RegisterChannelBL.class, log_Type_Fail, "channel registration failed.", e);
            throw new RuntimeException("channel registration failed.", e);
        }
    }

    public static void RegisterAuthenticationChannel(int channelId) {
        try {
            String encodedPublicKey = DigitalSignature.encodePublicKey();

            RegisterChannel channel = new RegisterChannel();
            channel.setChannelId(String.valueOf(channelId));
            channel.setPublicKey(encodedPublicKey);

            String requestBody = new Gson().toJson(channel);

            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);
            Response response = RestUtil.putByUrl(apiProperties.getProperty("Channel_Auth_Register"), header, requestBody);

            if (response.getStatusCode() != HttpStatus.SC_OK)
                throw new Exception("not able to register the channel.");

            Reporter.logReport(RegisterChannelBL.class, log_Type_Pass, "channel registered. Channel id : " + channelId, null);
        } catch (Exception e) {
            Reporter.logReport(RegisterChannelBL.class, log_Type_Fail, "channel registration failed.", e);
            throw new RuntimeException("channel registration failed.", e);
        }
    }

    public static String getPublicKeyUsingChannel(int channelId) {
        try {

            //  set header for old bank service
            Map<String, String> header = Header.getHeader(TYPE_AUTHENTICATION);

            Response getPublicKey = RestUtil.getByUrl(apiProperties.getProperty("Channel_Get") +
                    channelId, header);

            if (getPublicKey.getStatusCode() != HttpStatus.SC_OK) {
                throw new Exception("error while fetching the public key.");
            } else {
                Reporter.logReport(RegisterChannelBL.class, log_Type_Pass,
                        "Get public key api response : " + getPublicKey.prettyPrint(), null);

                return getPublicKey.jsonPath().getString("publicKey");
            }

        } catch (Exception e) {
            Reporter.logReport(RegisterChannelBL.class, log_Type_Fail,
                    "error while getting the public key.", e);

            throw new RuntimeException("error while getting the public key.", e);
        }
    }
}
