package client.transaction;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.Header;
import entity.InitiatingEntity;
import entity.Transaction;
import entity.TransactionEntity.TransactionEntity;
import entity.TransactionMethod;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.Error;
import responseEntity.TransactionResponseEntity.TransactionResponseEntity;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;

public class FundTransferBL extends SetUp {

    enum transactionTableValues {
        id("TRANSACTION_ID"), idempotentKey("IDEMPOTENT_KEY"), arrivalDate("ARRIVAL_DATE"), created("CREATED"),
        currency("CURRENCY"), mode("TRANSACTION_MODE"), type("METHOD_TYPE"), subType("METHOD_SUB_TYPE"),
        captureMethod("CAPTURE_METHOD"), status("STATUS"), application("APPLICATION_ID"), entityId("INITIATING_ENTITY_ID"),
        callbackUrl("CALLBACK_URL"), invoice("INVOICE"), responseTime("RESPONSE_TIME"), netAmount("NET_AMOUNT"),
        grossAmount("GROSS_AMOUNT"), payeeType("PAYEE_CUSTOMER_TYPE"), payeeName("PAYEE_NAME"), payeeMmid("PAYEE_MMID"),
        payeeAccountNumber("PAYEE_ACCOUNT_NUMBER"), payeeBankIFSC("PAYEE_BANK_IFSC"), payeeBankName("PAYEE_BANK_NAME"),
        payeeMerchantId("PAYEE_MERCHANT_ID"), payeeTerminalId("PAYEE_TERMINAL_ID"), payeeMobile("PAYEE_MOBILE_NUMBER"),
        payerType("PAYER_CUSTOMER_TYPE"), payerName("PAYER_NAME"), payerMmid("PAYER_MMID"), payerAccountNumber("PAYER_ACCOUNT_NUMBER"),
        payerBankIFSC("PAYER_BANK_IFSC"), payerBankName("PAYER_BANK_NAME"), payerMerchantId("PAYER_MERCHANT_ID"),
        payerTerminalId("PAYER_TERMINAL_ID"), payerMobile("PAYER_MOBILE_NUMBER"), authorizationCode("AUTHORIZATION_CODE"),
        originalId("ORIGINAL_TRANSACTION_ID");

        private String eqValue;

        transactionTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    public TransactionEntity transactionEntity;
    Gson request = new Gson();

    public String createFundTransferPayload(int subType, String payerAccountNumber, String payeeAccountNumber, String bankIFSC, int entityId, int applicationId, int mode) {
        String payload;
        try {
            transactionEntity = new TransactionEntity();

            //  create new idempotent key
            String idempotentKey = CommonMethods.generateNewIdempotentKey();

            InitiatingEntity initiatingEntity = CommonMethods.getDefaultInitiatingEntity(entityId);
            TransactionMethod transactionMethod = CommonMethods.getTransactionMethod(TYPE_FUND_TRANSFER, subType);

            Transaction transaction = CommonMethods.createTransaction(idempotentKey, initiatingEntity, transactionMethod, applicationId, mode);

            transactionEntity.setTransaction(transaction);
            transactionEntity.setAmount(CommonMethods.generateAmount());
            transactionEntity.setPayer(CommonMethods.getGenericPayer(payerAccountNumber, bankIFSC));
            transactionEntity.setPayee(CommonMethods.getGenericPayee(payeeAccountNumber, bankIFSC));

            payload = request.toJson(transactionEntity);

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "fund transfer payload has been created. Payload : " + payload, null);

            return payload;
        } catch (Exception e) {
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while creating the fund transfer payload.", e);

            throw new RuntimeException("error while creating the fund transfer payload.", e);
        }
    }

    public Map<String, String> setFundTransferHeader() {
        try {
            Map<String, String> header = Header.getHeader(TYPE_TRANSACTION);

            String query = "Select * from jpb_channel where CHANNEL_ID = "
                    + transactionEntity.getTransaction().getInitiatingEntity().getEntityId();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("channel id is not present in database.");

            resultSet.next();
            header.put("X-CHANNEL-ID", resultSet.getString("CHANNEL_ID"));
            header.put("X-API-KEY", resultSet.getString("API_TOKEN"));

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "fund transfer header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while setting the fund transfer header.", e);

            throw new RuntimeException("error while setting the fund transfer header.", e);
        }
    }

    public Map<String, String> setInvalidFundTransferHeader(String param, String val) {
        try {
            Map<String, String> header = setFundTransferHeader();

            switch (param.toUpperCase()){
                case("X-CHANNEL-ID"):
                    header.replace("X-CHANNEL-ID", val);
                    break;
                case("X-API-KEY"):
                    header.replace("X-API-KEY", val);
                    break;
            }

            Reporter.logReport(DebitTransactionBL.class, log_Type_Pass,
                    "Debit transaction invalid header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(DebitTransactionBL.class, log_Type_Fail,
                    "error while setting the Debit transaction invalid header.", e);

            throw new RuntimeException("error while setting the debit transaction invalid header.", e);
        }
    }

    public Response postFundTransfer(String requestBody, Map<String, String> header) {
        try {

            Response getBalanceResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Transactions_Payouts"), header);

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "fund transfer api response : " + getBalanceResponse.prettyPrint(), null);

            return getBalanceResponse;

        } catch (Exception e) {
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while posting the fund transfer api.", e);

            throw new RuntimeException("error while posting the fund transfer api.", e);
        }
    }

    public void validateFundTransferResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "fund transfer API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while validating the fund transfer API response status.", e);

            throw new RuntimeException("error while validating the fund transfer API response status.", e);
        }
    }

    public void validateFundTransferResponse(Response apiResponse, String amountBeforeCreditTransaction, String amountAfterCreditTransaction) {
        try {
            double balance;
            TransactionResponseEntity transactionResponse = apiResponse.as(TransactionResponseEntity.class);

            Map<String, Object> mappedData = CommonMethods.getMappedData(transactionResponse);
            Assert.assertTrue(mappedData.get("status").toString().equalsIgnoreCase("SUCCESS"),
                    "Fund transfer not successful");

            validateTransactionRecords(mappedData);

            if (transactionEntity.getTransaction().getMethod().getSubType() == SUB_TYPE_CREDIT_REVERSAL)
                balance = Double.parseDouble(amountBeforeCreditTransaction) - transactionEntity.getAmount().getNetAmount();
            else
                balance = Double.parseDouble(amountBeforeCreditTransaction) + transactionEntity.getAmount().getNetAmount();

            Assert.assertEquals(amountAfterCreditTransaction, String.valueOf(balance));
            validateTransactionInCBS(transactionResponse);

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "Fund transfer API validated.", null);

        } catch (Exception e) {
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while validating the fund transfer API.", e);

            throw new RuntimeException("error while validating the fund transfer API.", e);
        }
    }

    public void validateTransactionInCBS(TransactionResponseEntity transactionResponse) {
        try {
            String query = "Select PROCESSOR_TRANSACTION_ID from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + transactionResponse.getTransaction().getIdempotentKey() + "' and INVOICE = '" +
                    transactionResponse.getTransaction().getInvoice() + "' and APPLICATION_ID = " +
                    transactionResponse.getTransaction().getApplication();

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);
            while (resultSet.next()) {
                String referenceNumber = resultSet.getString("PROCESSOR_TRANSACTION_ID");
                String queryCBS = "Select * from TBAADM.DTD where REF_NUM = '" + referenceNumber + "'";

                ArrayList<String> tranList = DataBaseUtility.getDatabaseRecords(dbCBS2, queryCBS).get("PART_TRAN_TYPE");
                String[] tranType = {"C", "D"};

                for (String str : tranType) {
                    if (!tranList.contains(str))
                        Assert.assertTrue(false, String.format("Type %s is not present in DB", str));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void validateTransactionRecords(Map<String, Object> mappedData) {
        try {
            SoftAssert softAssert = new SoftAssert();
            DecimalFormat decimalFormat = new DecimalFormat("0.0");

            String query = "Select * from jpb_transaction where IDEMPOTENT_KEY = " +
                    "'" + mappedData.get("idempotentKey") + "' and ORIGINAL_TRANSACTION_ID = '" + mappedData.get("originalId") + "' and APPLICATION_ID = " +
                    mappedData.get("application") + " ORDER BY CREATED desc fetch first 1 rows only";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);

            resultSet.next();
            for (String key : mappedData.keySet()) {

                Object response = mappedData.get(key);
                if (response != null) {
                    if (response instanceof String) {
                        String columnValue = FundTransferBL.transactionTableValues.valueOf(key).eqValue;

                        switch (key) {
                            case "arrivalDate":
                            case "created":
                            case "responseTime":
                                String dateActual = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(resultSet.getString(columnValue)),
                                        "yyyy-MM-dd HH:mm:ss");

                                String dateExpected = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse((String) mappedData.get(key)),
                                        "yyyy-MM-dd HH:mm:ss");

                                softAssert.assertEquals(dateActual, dateExpected);
                                break;
                            default:
                                softAssert.assertEquals((String) mappedData.get(key), resultSet.getString(columnValue));
                        }
                    }

                    if (response instanceof Double) {
                        String actual = decimalFormat.format(mappedData.get(key));
                        String expected = decimalFormat.format(resultSet.getObject(FundTransferBL.transactionTableValues.valueOf(key).eqValue));
                        softAssert.assertEquals(actual, expected);
                    }

                    if (response instanceof Integer) {
                        int actual = (int) mappedData.get(key);
                        if (actual != 0) {
                            int expected = resultSet.getInt(FundTransferBL.transactionTableValues.valueOf(key).eqValue);
                            softAssert.assertEquals(actual, expected);
                        }
                    }
                }
            }

            softAssert.assertAll();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyPermissionDeniedMessage(Response apiResponse){
        SoftAssert softAssert = new SoftAssert();
        try{

            Error error = apiResponse.as(Error.class);
            softAssert.assertEquals(error.getCode(), "50302", "is error code correct?");
            softAssert.assertEquals(error.getMessage().trim(), "Permission Denied", "is error message correct?");
            softAssert.assertAll();

            Reporter.logReport(FundTransferBL.class, log_Type_Pass,
                    "error code & error message are correct.", null);
        }
        catch (Exception e){
            Reporter.logReport(FundTransferBL.class, log_Type_Fail,
                    "error while validating error code & message.", e);

            throw new RuntimeException("error while validating error code & message.", e);
        }
    }

}
