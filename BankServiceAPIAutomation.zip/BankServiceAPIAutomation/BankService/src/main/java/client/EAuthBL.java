package client;

import base.SetUp;
import com.google.gson.Gson;
import entity.*;
import entity.bankCustomerServiceEntity.EAuthEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.eAuth.EAuthResponse;
import com.utilities.apiUtils.RestUtil;
import utils.CommonMethods;
import utils.Reporter;

import java.util.List;
import java.util.Map;

public class EAuthBL extends SetUp {

    public Map<String, String> setEAuthHeader(Map<String, String> testData){
        try{
           Map<String, String> header = Header.getHeader(Type_Authentication);

           header.put("x-channel-id", testData.get("ChannelId").toString());
           header.put("x-api-key", testData.get("ApiKey").toString());
           header.put("x-trace-id", testData.get("TraceId").toString());
           header.put("x-device-info", testData.get("DeviceInfo").toString());

           return header;
        }
        catch (Exception e){


            throw new RuntimeException("Error while setting up eAuth header");
        }
    }

    public String createEAuthPayload(Map<String, String> testData){
        try{
            EAuthEntity eAuthEntity = new EAuthEntity();
            Gson request = new Gson();

            // DeviceInfo deviceInfo = new DeviceInfo();
            DeviceInfo deviceInfo = CommonMethods.getDeviceInfoEntities(
                    testData.get("DI_dpId"),
                    testData.get("DI_rdsId"),
                    testData.get("DI_rdsVer"),
                    testData.get("DI_dc"),
                    testData.get("DI_mi"),
                    testData.get("DI_mc")
            );


            //CaptureResponse captureResponse = new CaptureResponse();
            CaptureResponse captureResponse =
                    CommonMethods.getCaptureResponseEntities(
                            testData.get("CR_iCount"),
                            testData.get("CR_PidDatatype"),
                            testData.get("CR_rdsID"),
                            testData.get("CR_nmPoin"),
                            testData.get("CR_errInfo"),
                            testData.get("CR_iType"),
                            testData.get("CR_ver"),
                            testData.get("CR_rc"),
                            testData.get("CR_dpID"),
                            testData.get("CR_mc"),
                            testData.get("CR_sessionKey"),
                            testData.get("CR_tid"),
                            testData.get("RC_mi"),
                            testData.get("RC_dc"),
                            testData.get("CR_consent"),
                            testData.get("CR_errCode"),
                            testData.get("CR_qScore"),
                            testData.get("CR_saTxn"),
                            testData.get("CR_pCount"),
                            testData.get("CR_fCount"),
                            testData.get("CR_hmac"),
                            testData.get("CR_sa"),
                            testData.get("CR_ci"),
                            testData.get("CR_appCode"),
                            testData.get("CR_rdsVer"),
                            testData.get("CR_pType"),
                            testData.get("CR_Piddata"),
                            testData.get("CR_fType")
                    );


            EAuthRequest eAuthRequest =
                    CommonMethods.getEAuthRequest(
                            testData.get("ER_AadhaarToken").toString(),
                            testData.get("ER_Consent").toString(),
                            testData.get("ER_AppCode").toString(),
                            testData.get("ER_transactionRefNumber"),
                            captureResponse,
                            deviceInfo);
            AuthenticateList authenticateListData =
                    CommonMethods.getAuthenticationListOfEAuthEntities(
                            Integer.parseInt((String)testData.get("Mode")),
                            testData.get("Value").toString(),
                            testData.get("Action").toString(),
                            testData.get("Authenticate_TransactionRefNumber").toString(),
                            eAuthRequest);

            MobileEntity mobile = CommonMethods.getMobileEntities(
                    testData.get("MobileNo").toString(),
                    testData.get("CountryCode").toString());

            User user = CommonMethods.getUserEntitiesOfEAuth(
                    testData.get("CustomerId").toString(),
                    mobile, testData.get("EmailID").toString());

            List<AuthenticateList> listOfAuthenticateList =
                    CommonMethods.getAuthenticateList(authenticateListData);

            eAuthEntity.setUser(user);
            eAuthEntity.setScope(testData.get("Scope"));
            eAuthEntity.setAuthenticateList(listOfAuthenticateList);

           String payload = request.toJson(eAuthEntity);

            return payload;
        }
        catch (Exception e){
            throw new RuntimeException("Error while setting up eAuth payload");
        }

    }

    public Response postEAuth(String requestBody, Map<String, String> header){
        try{
           Response eAuthApiResponse = RestUtil.postByJson(requestBody, apiProperties.getProperty("EAuth"), header);

            Reporter.logReport(EAuthBL.class, log_Type_Pass,
                    "eAuth API response: " + eAuthApiResponse.prettyPrint(), null);
            return eAuthApiResponse;

        }catch (Exception e){

            Reporter.logReport(EAuthBL.class, log_Type_Fail,"error while posting the eAuth api", e);

            throw new RuntimeException("Error while posting the eAuth api", e);
        }


    }

    public void validateEAuthResponseStatus(Response apiResponse, int apiExpectedStatus){
        try{
            Assert.assertEquals(apiResponse.statusCode(), apiExpectedStatus);

            Reporter.logReport(EAuthBL.class, log_Type_Pass,
                    "eAuth api status code validation. Status code is: " + apiResponse.getStatusCode(), null);

        }catch(Exception e){

            Reporter.logReport(EAuthBL.class, log_Type_Fail,
                    "error while validating eAuth api status code", e);

            throw new RuntimeException("error while validating the eAuth api status code", e);
        }
    }

    public void validateEAuthResponse(Response apiResponse, Map<String, String> testData){
        try{
            SoftAssert softAssert = new SoftAssert();
            EAuthResponse eAuthResponseObj = apiResponse.as(EAuthResponse.class);

            int statusCode = apiResponse.getStatusCode();
            String status = eAuthResponseObj.getStatus();
            String errorCode = eAuthResponseObj.getError().getCode();
            String errorMessage = eAuthResponseObj.getError().getMessage();
            boolean isAuthenticated = eAuthResponseObj.isAuthenticated();

            if(statusCode == 200) {
                switch (status) {
                    case ("Success"):
                        softAssert.assertEquals(status, "SUCCESS");
                        //add required parameters
                        softAssert.assertAll();
                        break;
                    case ("FAILURE"):
                        softAssert.assertEquals(status, "FAILURE");
                        softAssert.assertFalse(isAuthenticated, "validating customer's isAuthenticated in failure case");
                        softAssert.assertEquals(errorCode, testData.get("ErrorCode"));
                        softAssert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                        softAssert.assertAll();
                        break;
                    default:
                        org.testng.Reporter.log("validating eAuth api scenarios. ");

                }
            }
                else{
                    softAssert.assertEquals(errorCode, testData.get("ErrorCode"));
                    softAssert.assertEquals(errorMessage, testData.get("ErrorMessage"));
                    softAssert.assertAll();
                }

          Reporter.logReport(EAuthBL.class, log_Type_Pass,
                  "eAuth api response validation. Status code is: " + apiResponse.getStatusCode(), null);

        }catch(Exception e){

            Reporter.logReport(EAuthBL.class, log_Type_Fail,
                    "error while validating eAuth api response. Status code is: " + apiResponse.getStatusCode(),e);

            throw new RuntimeException("error while validating eAuth api response. Status code is: " + apiResponse.getStatusCode(), null);
        }


    }




}
