package client.account;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.Header;
import entity.accountEntity.GetBalanceEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.getMiniStatement.GetMiniStatementResponse;
import responseEntity.Statement;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetMiniStatementBL extends SetUp {

    public String createGetMiniStatementPayload(Map<Object, Object> testData) {
        try {

            GetBalanceEntity getMiniStatementEntity = new GetBalanceEntity();
            Gson request = new Gson();

            getMiniStatementEntity.setAccountNumber((String) testData.get("AccountNumber"));
            String payload = request.toJson(getMiniStatementEntity);

            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while creating the get Mini-Statement payload.", e);

            throw new RuntimeException("error while creating the get MiniStatement payload.", e);
        }
    }

    public Map<String, String> setGetMiniStatementHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while setting the get MiniStatement header.", e);

            throw new RuntimeException("error while setting the get MiniStatement header.", e);
        }
    }

    public Response postGetMiniStatement(String requestBody, Map<String, String> header) {
        try {

            Response getMiniStatementResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Account_MiniStatement"), header);

            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement api response : " + getMiniStatementResponse.prettyPrint(), null);

            return getMiniStatementResponse;

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while posting the get MiniStatement api.", e);

            throw new RuntimeException("error while posting the get MiniStatement api.", e);
        }
    }

    public Response getMiniStatementOld(Map<Object, Object> testData) {
        try {

            //  set header for old bank service
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("Content-Type", "application/json");
            header.put("X-CHANNEL-ID", "3141");
            header.put("X-API-TOKEN", "AE431FBD11844DBF7646CBF65E4368B1");

            //  set params for get
            Map<String, String> params = Header.getHeader(TYPE_NON_TRANSACTION);
            params.put("bankCustomerId", (String) testData.get("BankCustomerID"));

            String currentDate = DateUtility.getCurrentDateTime("dd-MM-yyyy");

            params.put("toDate", currentDate);
            params.put("pageSize", (String) testData.get("PageSize"));
            params.put("fromDate", (String) testData.get("FromDate"));

            Response getBalanceResponse = RestUtil.get(params, header, apiProperties.getProperty("Account_MiniStatementOld"));

            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement old api response : " + getBalanceResponse.prettyPrint(), null);

            return getBalanceResponse;

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while getting the get MiniStatement old api.", e);

            throw new RuntimeException("error while getting the get MiniStatement old api.", e);
        }
    }

    public void validateGetMiniStatementResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while validating the get MiniStatement api response status.", e);

            throw new RuntimeException("error while validating the get MiniStatement api response status.", e);
        }
    }

    public void validateGetMiniStatementResponse(Response apiResponse, String accountNumber) {
        try {

            List<Map<String, String>> statementDbMap = new ArrayList<>();
            List<Map<String, String>> statementApiMap = new ArrayList<>();

            SoftAssert softAssert = new SoftAssert();

            GetMiniStatementResponse getMiniStatementResponse = apiResponse.as(GetMiniStatementResponse.class);
            softAssert.assertEquals(getMiniStatementResponse.getAccountNumber(), accountNumber);

            String queryDTD = "Select * from (Select * from TBAADM.DTD where acid in (Select acid from TBAADM.GAM where " +
                    "FORACID = '" + accountNumber + "') and PSTD_FLG = 'Y') where ROWNUM <= 10 order by RCRE_TIME desc";

            ResultSet resultSetDaily = DataBaseUtility.executeSelectStatement(dbCBS2, queryDTD);
            while (resultSetDaily.next()) {
                statementDbMap.add(getStatementDBData(resultSetDaily));
            }

            int recordCount = DataBaseUtility.getRowCount(resultSetDaily);
            ResultSet resultSetHistory;

            if (recordCount < 10) {
                int historyRecordCount = 10 - recordCount;
                String queryHTD = "Select * from (Select * from TBAADM.HTD where acid in (Select acid from TBAADM.GAM where " +
                        "FORACID = '" + accountNumber + "') and PSTD_FLG = 'Y') where ROWNUM <= " + historyRecordCount + " order by RCRE_TIME desc";

                resultSetHistory = DataBaseUtility.executeSelectStatement(dbCBS2, queryHTD);
                while (resultSetHistory.next()) {
                    statementDbMap.add(getStatementDBData(resultSetHistory));
                }
            }

            for (Statement statement : getMiniStatementResponse.getStatement()) {
                statementApiMap.add(getStatementMappedData(statement));
            }

            softAssert.assertEquals(statementApiMap, statementDbMap);
            softAssert.assertAll();
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement api is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while validating the get MiniStatement api response.", e);

            throw new RuntimeException("error while validating the get MiniStatement api response.", e);
        }
    }

    private Map<String, String> getStatementMappedData(Statement statement) {
        Map<String, String> statementMap = new HashMap<>();

        statementMap.put("date", statement.getDate());
        statementMap.put("tranParticulars", statement.getTranParticulars());
        statementMap.put("type", statement.getType());
        statementMap.put("amount", statement.getAmount());

        return statementMap;
    }

    private Map<String, String> getStatementDBData(ResultSet resultSet) {

        Map<String, String> statementMap = new HashMap<>();
        DecimalFormat decimalFormat = new DecimalFormat("0.00");

        try {
            statementMap.put("date", DateUtility.convertDateToNewFormat(resultSet.getString("TRAN_DATE"), "dd-MM-yy", "yyyyMMdd"));

            String message = resultSet.getString("TRAN_PARTICULAR");
            if (message.length() > 40)
                statementMap.put("tranParticulars", message.substring(0, 40));
            else
                statementMap.put("tranParticulars", message);

            statementMap.put("type", resultSet.getString("PART_TRAN_TYPE") == "D" ? "Debit" : "Credit");
            statementMap.put("amount", decimalFormat.format(Double.parseDouble(resultSet.getString("TRAN_AMT"))));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return statementMap;
    }


    public void validateGetMiniStatementResponse(Response apiResponse, Response oldApiResponse, String accountNumber) {
        try {

            DecimalFormat decimalFormat = new DecimalFormat("0.0");
            SoftAssert softAssert = new SoftAssert();

            //  verify account number
            Assert.assertEquals(apiResponse.jsonPath().getString("accountNumber"), accountNumber);

            //  get amount from old and new apis
            List<String> apiStatementAmount = apiResponse.jsonPath().getList("statement.amount");
            List<String> apiOldStatementAmount = oldApiResponse.jsonPath().getList("amount.netAmount");

            for (String amount : apiStatementAmount) {
                float newAmount = Float.parseFloat(decimalFormat.format(Double.parseDouble(amount)));
                if (!apiOldStatementAmount.contains(newAmount))
                    softAssert.fail("Amount doesn't present in old api statement. Amount : " + amount);
            }

            softAssert.assertAll();
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Pass,
                    "Get MiniStatement api is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetMiniStatementBL.class, log_Type_Fail,
                    "error while validating the get MiniStatement api response.", e);

            throw new RuntimeException("error while validating the get MiniStatement api response.", e);
        }
    }
}
