package client.account;

import base.SetUp;
import client.customer.GetAddressBL;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.Header;
import entity.accountEntity.GetBalanceEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.AccountsBalance;
import responseEntity.getBalance.GetBalanceResponse;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class GetBalanceBL extends SetUp {

    public String createGetBalancePayload(Map<Object, Object> testData) {
        try {

            GetBalanceEntity getBalanceEntity = new GetBalanceEntity();
            Gson request = new Gson();

            getBalanceEntity.setAccountNumber((String) testData.get("AccountNumber"));
            String payload = request.toJson(getBalanceEntity);

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass,
                    "Get balance payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while creating the get balance payload.", e);

            throw new RuntimeException("error while creating the get balance payload.", e);
        }
    }

    public Map<String, String> setGetBalanceHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass,
                    "Get balance header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while setting the get balance header.", e);

            throw new RuntimeException("error while setting the get balance header.", e);
        }
    }

    public Response postGetBalance(String requestBody, Map<String, String> header) {
        try {

            Response getBalanceResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Account_GetBalance"), header);

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass,
                    "Get address api response : " + getBalanceResponse.prettyPrint(), null);

            return getBalanceResponse;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while posting the get balance api.", e);

            throw new RuntimeException("error while posting the get balance api.", e);
        }
    }

    public Response getBalanceOld(Map<Object, Object> testData) {
        try {

            //  set header for old bank service
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("Content-Type", "application/json");
            header.put("X-CHANNEL-ID", "3141");
            header.put("X-API-TOKEN", "AE431FBD11844DBF7646CBF65E4368B1");

            Response getBalanceResponse = RestUtil.getByUrl(apiProperties.getProperty("Account_GetBalanceOld") +
                    testData.get("BankCustomerID"), header);

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass,
                    "Get balance old api response : " + getBalanceResponse.prettyPrint(), null);

            return getBalanceResponse;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while getting the get balance old api.", e);

            throw new RuntimeException("error while getting the get balance old api.", e);
        }
    }

    public void validateGetBalanceResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass,
                    "Get balance api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while validating the get balance api response status.", e);

            throw new RuntimeException("error while validating the get balance api response status.", e);
        }
    }

    public void validateGetBalanceResponse(Response apiResponse, String accountNumber) {
        try {
            SoftAssert softAssert = new SoftAssert();
            double investedBalanceExpected = 0;

            DecimalFormat decimalFormat = new DecimalFormat("0.0");
            GetBalanceResponse getBalanceResponse = apiResponse.as(GetBalanceResponse.class);

            String query = "select * from TBAADM.GAM where FORACID = '" + accountNumber + "'";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbCBS2, query);

            resultSet.next();
            double currentBalanceExpected = Double.parseDouble(resultSet.getString("CLR_BAL_AMT"));
            double onHoldBalanceExpected = Double.parseDouble(resultSet.getString("LIEN_AMT"));

            String idCIF = resultSet.getString("CIF_ID");
            if (!idCIF.equalsIgnoreCase("null")) {
                query = "Select INVSTD_BAL from TBAADM.CIDT where CIF_ID = '" + resultSet.getString("CIF_ID") + "' order by RCRE_TIME desc";
                resultSet = DataBaseUtility.executeSelectStatement(dbCBS2, query);

                if (!(DataBaseUtility.getRowCount(resultSet) == 0)) {
                    resultSet.next();
                    investedBalanceExpected = Double.parseDouble(resultSet.getString("INVSTD_BAL"));
                }
            }


            double currentBalanceActual = 0;
            double onHoldBalanceActual = 0;

            for (AccountsBalance accountsBalance : getBalanceResponse.getAccountsBalance()) {

                if (accountsBalance.getAccountCategory().equalsIgnoreCase("PRIMARY"))
                    softAssert.assertEquals(accountsBalance.getBankAccountNumber(), accountNumber);

                currentBalanceActual = currentBalanceActual + accountsBalance.getCurrentBalance();
                onHoldBalanceActual = onHoldBalanceActual + accountsBalance.getOnHoldBalance();

            }

            String totalBalanceActual = decimalFormat.format(currentBalanceActual - onHoldBalanceActual);
            String totalBalanceExpected = decimalFormat.format((currentBalanceExpected - onHoldBalanceExpected) + investedBalanceExpected);

            softAssert.assertEquals(totalBalanceActual, totalBalanceExpected);
            softAssert.assertAll();

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get balance api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while validating the get balance api response.", e);

            throw new RuntimeException("error while validating the get balance api response.", e);
        }
    }

    public void validateGetBalanceResponse(Response apiResponse, Response oldApiResponse) {
        try {

            GetBalanceResponse getBalanceResponse = apiResponse.as(GetBalanceResponse.class);
            GetBalanceResponse getBalanceResponseOld = oldApiResponse.as(GetBalanceResponse.class);

            Assert.assertEquals(getBalanceResponse.getTotalBalance(), getBalanceResponseOld.getTotalBalance());

            if (getBalanceResponse.getAccountsBalance().length == getBalanceResponseOld.getAccountsBalance().length) {
                for (int i = 0; i < getBalanceResponse.getAccountsBalance().length; i++) {
                    verifyAccountBalance(getMappedData(getBalanceResponse.getAccountsBalance()[i]),
                            getMappedData(getBalanceResponseOld.getAccountsBalance()[i]));
                }
            }

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get balance api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while validating the get balance api response.", e);

            throw new RuntimeException("error while validating the get balance api response.", e);
        }
    }

    private Map<String, Object> getMappedData(AccountsBalance accountsBalance) {
        Map<String, Object> customerAccountsBalance = new HashMap<>();

        customerAccountsBalance.put("accountCategory", accountsBalance.getAccountCategory());
        customerAccountsBalance.put("bankAccountNumber", accountsBalance.getBankAccountNumber());
        customerAccountsBalance.put("availableBalance", accountsBalance.getAvailableBalance());
        customerAccountsBalance.put("onHoldBalance", accountsBalance.getOnHoldBalance());
        customerAccountsBalance.put("currentBalance", accountsBalance.getCurrentBalance());

        return customerAccountsBalance;
    }

    private void verifyAccountBalance(Map<String, Object> accountsBalance, Map<String, Object> accountsBalanceOld) {
        try {

            SoftAssert softAssert = new SoftAssert();

            for (String key : accountsBalance.keySet()) {
                if (accountsBalance.get(key) instanceof String) {
                    if (accountsBalance.get(key) != null)
                        softAssert.assertEquals(accountsBalance.get(key), accountsBalanceOld.get(key));
                }

                if (accountsBalance.get(key) instanceof Double) {
                    if (!accountsBalance.get(key).equals(0))
                        softAssert.assertEquals(accountsBalance.get(key), accountsBalanceOld.get(key));
                }
            }

            softAssert.assertAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String postGetBalance(String accountNumber) {
        try {

            GetBalanceEntity getBalanceEntity = new GetBalanceEntity();
            Gson request = new Gson();

            getBalanceEntity.setAccountNumber(accountNumber);
            String requestBody = request.toJson(getBalanceEntity);

            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);
            Response response = RestUtil.postByJson(requestBody, apiProperties.getProperty("Account_GetBalance"), header);

            String totalBalance = response.jsonPath().getString("totalBalance");
            Reporter.logReport(GetBalanceBL.class, log_Type_Pass, "Post get balance. " +
                    "\nAccount Number : " + accountNumber + "\nTotal balance is: " + totalBalance, null);

            return totalBalance;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while posting the get balance.", e);

            throw new RuntimeException("error while posting the get balance.", e);
        }
    }

    public Map<String, Double> postGetBalanceWithOnHoldBalance(String accountNumber) {
        try {

            Map<String, Double> mapGetBalance = new HashMap<>();
            GetBalanceEntity getBalanceEntity = new GetBalanceEntity();
            Gson request = new Gson();

            getBalanceEntity.setAccountNumber(accountNumber);
            String requestBody = request.toJson(getBalanceEntity);

            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);
            Response response = RestUtil.postByJson(requestBody, apiProperties.getProperty("Account_GetBalance"), header);

            GetBalanceResponse getBalanceResponse = response.as(GetBalanceResponse.class);

            mapGetBalance.put("totalBalance", getBalanceResponse.getTotalBalance());
            for (AccountsBalance accountsBalance : getBalanceResponse.getAccountsBalance()) {
                if (accountsBalance.getBankAccountNumber().equalsIgnoreCase(accountNumber)) {
                    mapGetBalance.put("onHoldBalance", accountsBalance.getOnHoldBalance());
                    break;
                }
            }

            Reporter.logReport(GetBalanceBL.class, log_Type_Pass, "Post get balance. " +
                    "\nAccount Number : " + accountNumber + "\nTotal balance details is: " + mapGetBalance, null);

            return mapGetBalance;

        } catch (Exception e) {
            Reporter.logReport(GetBalanceBL.class, log_Type_Fail,
                    "error while posting the get balance.", e);

            throw new RuntimeException("error while posting the get balance.", e);
        }
    }
}
