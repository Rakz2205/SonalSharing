package client.account;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.Header;
import entity.accountEntity.GetAccountEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.getAccount.AccountDetails;
import responseEntity.getAccount.GetAccountResponse;
import responseEntity.getAccount.LinkedCards;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class GetAccountBL extends SetUp {

    enum accountTableValues {
        firstName("FIRST_NAME"), middleName("MIDDLE_NAME"), lastName("LAST_NAME"),
        accountType("ACCOUNT_TYPE"), accountNumber("DECRYPTED_ACCOUNT_NUMBER"),
        cardName("OWNER_NAME"), cardNumber("MASKED_CARD_NUMBER"), mmid("MMID"),
        bankName("BANK_NAME"), bankIfsc("IFS_CODE"), accountStatus("accountStatus"),
        freezeStatus("freeze_Status"), limit("limit"), type("CARD_TYPE");

        private String eqValue;

        private accountTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    public String createGetAccountPayload(Map<Object, Object> testData) {
        try {

            GetAccountEntity getAccountEntity = new GetAccountEntity();
            Gson request = new Gson();

            getAccountEntity.setType(Integer.parseInt((String) testData.get("CustomerType")));
            getAccountEntity.setValue((String) testData.get("Value"));
            getAccountEntity.setResponseType((String) testData.get("ResponseType"));

            String[] accountMetadataArr = ((String) testData.get("Metadata")).split(",");

            for (String type : accountMetadataArr) {
                getAccountEntity.getMetaData().add(type);
            }

            String payload = request.toJson(getAccountEntity);

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while creating the get Account payload.", e);

            throw new RuntimeException("error while creating the get Account payload.", e);
        }
    }
    public String createAccountPayloadUsingProfileID(String profileID) {
        try {

            GetAccountEntity getAccountEntity = new GetAccountEntity();
            Gson request = new Gson();

            getAccountEntity.setType(2);
            getAccountEntity.setValue(profileID);
            getAccountEntity.setResponseType("ALL");

            String[] accountMetadataArr = {""};
            String payload = request.toJson(getAccountEntity);
            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount payload has been created. Payload : " + payload, null);
            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while creating the get Account payload.", e);

            throw new RuntimeException("error while creating the get Account payload.", e);
        }
    }

    public Map<String, String> setGetAccountHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while setting the getAccount header.", e);

            throw new RuntimeException("error while setting the getAccount header.", e);
        }
    }

    public Map<String, String> getDefaultHeader() {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", "false");

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount header : " + header, null);

            return header;
        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while setting the getAccount header.", e);

            throw new RuntimeException("error while setting the getAccount header.", e);
        }
    }

    public Response postGetAccount(String requestBody, Map<String, String> header) {
        try {

            Response getAccountResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Account_GetAccount"), header);

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount API response : " + getAccountResponse.prettyPrint(), null);

            return getAccountResponse;

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while posting the getAccount API.", e);

            throw new RuntimeException("error while posting the getAccount API.", e);
        }
    }

    public void validateGetAccountResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "GetAccount API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the GetAccount API response status.", e);

            throw new RuntimeException("error while validating the GetAccount API response status.", e);
        }
    }

    public void validateGetAccountResponse(Response apiResponse, Map<Object, Object> testData) {
        try {
            GetAccountResponse getAccountResponseObj = apiResponse.as(GetAccountResponse.class);
            String profileID = CommonMethods.getProfileID(testData);
            validateGetAccount(profileID, getAccountResponseObj);

            Reporter.logReport(GetAccountBL.class, log_Type_Pass,
                    "getAccount api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the getAccount api response status.", e);

            throw new RuntimeException("error while validating the getAccount api response status.", e);
        }

    }

    public void validateGetAccount(String profileId, GetAccountResponse getAccountResponseObj) {
        try {
            AccountDetails[] accountsArr = getAccountResponseObj.getAccountDetails();
            ResultSet resultSet = null;
            String query = null;

            for (AccountDetails account : accountsArr) {
                Map<String, String> accountData = getMappedData(account);
                String accountType = account.getAccountType();

                switch (accountType) {
                    case ("PPI"):
                        query = "select AC.PREPAID_ACCOUNT_ID AS DECRYPTED_ACCOUNT_NUMBER, PR.FIRST_NAME," +
                                " PR.Middle_Name,PR.LAST_NAME, AC.STATE AS BANK_NAME from PROFILE PR, ACCOUNT AC " +
                                "where PR.Account_ID = AC.Account_ID and PR.profile_id=" + profileId;
                        resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);
                        verifyResult(resultSet, accountData);
                        break;
                    case ("SAVINGS"):
                    case ("CURRENT"):
                        query = "select BK.ACCOUNT_TYPE, BK.DECRYPTED_ACCOUNT_NUMBER, PR.FIRST_NAME," +
                                " PR.Middle_Name,PR.LAST_NAME, BK.Bank_name, Bk.IFS_CODE, BK.mmid from PROFILE PR," +
                                " BANK_DETAILS BK where PR.Account_ID = BK.Account_ID and PR.profile_id=" + profileId;
                        resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);
                        verifyResult(resultSet, accountData);

                        LinkedCards[] linkedCardsArr = account.getLinkedCards();

                        if(linkedCardsArr != null){
                            for (LinkedCards linkedCard : linkedCardsArr) {
                                Map<String, String> cardData = getLinkedCardData(linkedCard);
                                String cardNumber = cardData.get("cardNumber");
                                String cardNumberLast4Digits = cardNumber.substring(cardNumber.length() - 4);

                                query = "Select * from Card_vault where MASKED_CARD_NUMBER like '%" + cardNumberLast4Digits + "%'";
                                resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);
                                verifyResult(resultSet, cardData);
                            }
                        }
                        break;
                    default:
                        Assert.fail("UnKnown Account Type");
                }
            }
        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the getAccount api response status.", e);
            throw new RuntimeException(e);
        }
    }

    private void verifyResult(ResultSet resultSet, Map<String, String> accountData) {

        String columnValue = null;
        try {
            resultSet.next();
            SoftAssert softAssert = new SoftAssert();

            Set<String> allParams = accountData.keySet();
            for (String param : allParams) {
                String val = accountData.get(param);
                if (val != null) {
                    if (!param.equalsIgnoreCase("accountStatus") & !param.equalsIgnoreCase("freezeStatus")) {
                        columnValue = accountTableValues.valueOf(param).eqValue;

                        switch (param) {
                            case "limit":
                                //TODO: verify when limit response is valid in response
                                break;
                            case "bankName":
                                String bankName = resultSet.getString(columnValue);
                                if (!bankName.equalsIgnoreCase("JIO Payments Bank")) {
                                    bankName = "Wallet";
                                }
                                softAssert.assertEquals(bankName, accountData.get(param));
                                break;
                            case "cardNumber":
                                String cardLastDigits = "X" + accountData.get(param).substring(accountData.get(param).length() - 4);
                                softAssert.assertEquals(resultSet.getString(columnValue), cardLastDigits);
                                break;
                            default:

                                softAssert.assertEquals(resultSet.getString(columnValue), accountData.get(param));
                        }
                    }
                }
            }
            softAssert.assertAll();
        } catch (java.sql.SQLException e1) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the getAccount api response parameter" + columnValue, e1);
            throw new RuntimeException("error while validating the getKyc api response parameters", e1);
        } catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the getAccount api response", e);

            throw new RuntimeException(e);
        }
    }

    //get Account mapped data except card details
    private Map<String, String> getMappedData(AccountDetails accountDetails) {
        Map<String, String> accountMap = new HashMap<>();
        accountMap.put("accountNumber", accountDetails.getAccountNumber());
        accountMap.put("firstName", accountDetails.getAccountHolderName().getFirstName());
        accountMap.put("middleName", accountDetails.getAccountHolderName().getMiddleName());
        accountMap.put("lastName", accountDetails.getAccountHolderName().getLastName());
        accountMap.put("bankName", accountDetails.getBankName());
        accountMap.put("bankIfsc", accountDetails.getBankIfsc());
        accountMap.put("mmid", accountDetails.getMmid());
        accountMap.put("accountStatus", accountDetails.getAccountStatus());
        accountMap.put("freezeStatus", accountDetails.getAccountRestrictions().getFreezeStatus());
        return accountMap;
    }

    //get mapped data for linked card details
    private Map<String, String> getLinkedCardData(LinkedCards linkedCard) {
        Map<String, String> cardMap = new HashMap<>();
        cardMap.put("cardName", linkedCard.getCardName());
        cardMap.put("cardNumber", linkedCard.getCardNumber());
        cardMap.put("limit", linkedCard.getLimit());
        cardMap.put("type", linkedCard.getType());
        return cardMap;
    }

    public static String getAccountNumber(int type, String value) {
        String accountNumber = null;
        try {
            GetAccountEntity getAccountEntity = new GetAccountEntity();
            Gson request = new Gson();

            getAccountEntity.setType(type);
            getAccountEntity.setValue(value);
            getAccountEntity.setResponseType("ALL");

            Response getCustomerResponse = RestUtil.postByJson(request.toJson(getAccountEntity),
                    apiProperties.getProperty("Account_GetAccount"), Header.getHeader(TYPE_NON_TRANSACTION));

            GetAccountResponse getAccountResponseObj = getCustomerResponse.as(GetAccountResponse.class);
            for (AccountDetails accountDetails : getAccountResponseObj.getAccountDetails()) {
                if (accountDetails.getAccountNumber() != "" && accountDetails.getAccountNumber() != null) {
                    accountNumber = accountDetails.getAccountNumber();
                    break;
                }
            }

            return accountNumber;

        } catch (Exception e) {
            throw new RuntimeException("error while fetching the bank account number.", e);
        }
    }

    public void validateBlockedAccountResponse(Response apiResponse, String profileId){
        try{
            SoftAssert softAssert = new SoftAssert();
            String closedStatus = apiResponse.jsonPath().getString("accountDetails.accountClosedDetails.closedStatus[0]");
            String closedDate = apiResponse.jsonPath().getString("accountDetails.accountClosedDetails.closedDate[0]");

            softAssert.assertTrue(closedStatus.equalsIgnoreCase("true"), "Closed status is not true");
            softAssert.assertNotNull(closedDate, "closed date is null");
            softAssert.assertTrue(!closedDate.equals(""), "closed date is empty");
            softAssert.assertAll();
        }
        catch (Exception e) {
            Reporter.logReport(GetAccountBL.class, log_Type_Fail,
                    "error while validating the getAccount response for blocked account", e);

            throw new RuntimeException(e);
        }


    }
}
