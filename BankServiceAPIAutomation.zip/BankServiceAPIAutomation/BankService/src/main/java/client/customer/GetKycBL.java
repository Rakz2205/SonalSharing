package client.customer;


import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.customerEntity.GetKycEntity;
import entity.Header;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.KYC.GetKycResponse;
import responseEntity.KYC.KycDetails;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;

public class GetKycBL extends SetUp {

    enum kycTableValues {
        firstName("NAME"), proofType("IDENTITY_TYPE"), proofValue("IDENTITY_NUMBER"),
        identityStatus("IDENTITY_STATUS"), number("MOBILE_NUMBER"),
        verifiedBy("VERIFIED_BY"), dob("dob"), createdAt("CREATED_AT"),
        updatedAt("UPDATED_AT");

        private String eqValue;
        kycTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    public String createGetKycPayload(Map<Object, Object> testData) {
        try {

            GetKycEntity getKycEntity = new GetKycEntity();
            Gson request = new Gson();

            getKycEntity.setType(Integer.parseInt((String) testData.get("CustomerType")));
            getKycEntity.setValue((String) testData.get("Value"));
            getKycEntity.setResponseType((String) testData.get("ResponseType"));

            String[] kycMetadataArr = ((String) testData.get("Metadata")).split(",");

            for (String type : kycMetadataArr) {
                getKycEntity.getMetaData().add(type);
            }

            String payload = request.toJson(getKycEntity);

            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "Get KYC payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while creating the get KYC payload.", e);

            throw new RuntimeException("error while creating the get KYC payload.", e);
        }
    }

    public Map<String, String> setGetKycHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "Get KYC header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while setting the get KYC header.", e);

            throw new RuntimeException("error while setting the get KYC header.", e);
        }
    }

    public Response postGetKyc(String requestBody, Map<String, String> header) {
        try {

            Response getKycResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Customer_GetKyc"), header);

            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "Get KYC API response : " + getKycResponse.prettyPrint(), null);

            return getKycResponse;

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while posting the get KYC API.", e);

            throw new RuntimeException("error while posting the get KYC API.", e);
        }
    }

    public void validateGetKycResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "Get KYC API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while validating the get KYC API response status.", e);

            throw new RuntimeException("error while validating the get KYC API response status.", e);
        }
    }

    public void validateGetKycResponse(Response apiResponse, Map<Object, Object> testData) {

        try {

            GetKycResponse getKycResponseObj = apiResponse.as(GetKycResponse.class);
            String profileID= CommonMethods.getProfileID(testData);
            validateGetKyc(profileID, getKycResponseObj);

            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "getKyc API response is valid.", null);

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while validating the getKyc API response.", e);

            throw new RuntimeException("error while validating the getKyc API response.", e);
        }
    }

    private void validateGetKyc(String profileID, GetKycResponse getKycResponseObj) {

        try {
            Assert.assertTrue(getKycResponseObj.getBankCustomerId().equalsIgnoreCase(profileID));
            int responseArr = getKycResponseObj.getKycDetails().length;

            for (int i = 0; i < responseArr; i++) {
                String proofType = getKycResponseObj.getKycDetails()[i].getProofType();

                //TODO: check cases for multiple proof types
                proofType = proofType.equalsIgnoreCase("1") ? "AADHAAR" : "PAN";
                String query = "select * from  IDENTITY where ACCOUNT_ID= (Select Account_id from Profile " +
                        "where profile_id = " + profileID + ")AND IDENTITY_TYPE='" + proofType + "'";

                ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

                Map<String, String> kycData = getMappedData(getKycResponseObj.getKycDetails()[i]);
                verifyResult(resultSet, kycData);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void verifyResult(ResultSet resultSet, Map<String, String> kycData) {

        String columnValue = null;
        try {
            resultSet.next();
            SoftAssert softAssert = new SoftAssert();

            Set<String> allParams = kycData.keySet();
            for (String param : allParams) {
                String val = kycData.get(param);
                if (val != null) {
                    if (!param.equalsIgnoreCase("countryCode")) {
                        columnValue = kycTableValues.valueOf(param).eqValue;

                        switch (param) {
                            case "createdAt":
                            case "updatedAt":
                                String date = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                                                .parse(resultSet.getString(columnValue)), "dd-MMM-yyyy");
                                softAssert.assertEquals(date, kycData.get(param));
                                break;
                            default:
                                softAssert.assertEquals(resultSet.getString(columnValue), kycData.get(param));
                        }
                    }
                }
            }
            softAssert.assertAll();
        } catch (java.sql.SQLException e1) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while validating the getKyc api response parameter" + columnValue, e1);
            throw new RuntimeException("error while validating the getKyc api response parameters", e1);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Map<String, String> getMappedData(KycDetails getKycDetailsObj) {
        Map<String, String> customerKycMap = new HashMap<>();
        customerKycMap.put("proofValue", getKycDetailsObj.getProofValue());
        customerKycMap.put("identityStatus", getKycDetailsObj.getIdentityStatus());
        customerKycMap.put("verifiedBy", getKycDetailsObj.getVerifiedBy());
        customerKycMap.put("firstName", getKycDetailsObj.getName().getFirstName());
        customerKycMap.put("dob", getKycDetailsObj.getDob());
        customerKycMap.put("countryCode", getKycDetailsObj.getMobile().getCountryCode());
        customerKycMap.put("number", getKycDetailsObj.getMobile().getNumber());
        customerKycMap.put("createdAt", getKycDetailsObj.getCreatedAt());
        customerKycMap.put("updatedAt", getKycDetailsObj.getUpdatedAt());
        return customerKycMap;
    }

    /*
    * Validates if a PAN card number (if present in response) matches the given pattern.
    * */
    public void validateGetKycPanNumber(Response apiResponse, Map<Object, Object> testData){

        String v = (String) testData.get("Value");
        String t = (String) testData.get("CustomerType");

        try {
            GetKycResponse getKycResponseObj = apiResponse.as(GetKycResponse.class);
            KycDetails[] kycDetailsArr = getKycResponseObj.getKycDetails();

            for (KycDetails details:kycDetailsArr) {
                String proofType = details.getProofType().trim();
                if(proofType !=null && !proofType.isEmpty() & proofType.equals("2")){
                    String value = details.getProofValue().trim();
                    Assert.assertTrue(value.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}"));
                }
            }
            Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "getKyc API PAN card number is valid for Customer type:value: " + t+":" +v, null);

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while validating PAN card number for Customer type-value: " + t+"-" +v, e);

            throw new RuntimeException("error while validating PAN card number of Customer.", e);
        }
    }

    //TODO: to be implemented based on OVD types, make date consistent so that it can be compared
    public void validateGetKycDob(Response apiResponse, Map<Object, Object> testData){

    }

    public void validateKycDetailsIsNull(Response apiResponse){
        GetKycResponse getKycResponseObj = apiResponse.as(GetKycResponse.class);
        KycDetails[] kycDetailsArr = getKycResponseObj.getKycDetails();

        try{
            if(kycDetailsArr != null){
                for (KycDetails kycDetail:kycDetailsArr) {
                    SoftAssert softAssert = new SoftAssert();
                    softAssert.assertNull(kycDetail.getMobile());
                    softAssert.assertNull(kycDetail.getProofType());
                    softAssert.assertNull(kycDetail.getProofValue());
                    softAssert.assertNull(kycDetail.getCreatedAt());
                    softAssert.assertNull(kycDetail.getDob());
                    softAssert.assertNull(kycDetail.getIdentityStatus());
                    softAssert.assertNull(kycDetail.getName());
                    softAssert.assertNull(kycDetail.getUpdatedAt());
                    softAssert.assertNull(kycDetail.getVerifiedBy());
                    softAssert.assertAll();
            }
        }
        Reporter.logReport(GetKycBL.class, log_Type_Pass,
                    "Get KYC API response is Null.", null);

        } catch (Exception e) {
            Reporter.logReport(GetKycBL.class, log_Type_Fail,
                    "error while validating the getKYC API response.", e);

            throw new RuntimeException("error while validating the getKYC api response.", e);
        }
    }
}
