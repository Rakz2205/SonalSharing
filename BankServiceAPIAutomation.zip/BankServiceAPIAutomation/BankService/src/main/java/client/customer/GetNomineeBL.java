package client.customer;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.customerEntity.GetNomineeEntity;
import entity.Header;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.Address;
import responseEntity.getNominee.GetNomineeResponse;
import responseEntity.getNominee.NomineeDetails;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;

public class GetNomineeBL extends SetUp {

    enum nomineeTableValues {
        nomineeId("ID"),
        mobile("PHONE_NUMBER"),
        relationship("RELATION"),
        dob("DOB"),
        firstName("FIRST_NAME"),
        middleName("MIDDLE_NAME"),
        lastName("LAST_NAME"),
        emailId("EMAIL");

        private String eqValue;

        nomineeTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    public String createGetNomineePayload(Map<Object, Object> testData) {
        try {

            GetNomineeEntity getNomineeEntity = new GetNomineeEntity();
            Gson request = new Gson();

            getNomineeEntity.setType(Integer.parseInt((String) testData.get("CustomerType")));
            getNomineeEntity.setValue((String) testData.get("Value"));
            getNomineeEntity.setResponseType((String) testData.get("ResponseType"));

            String[] nomineeMetadataArr = ((String) testData.get("Metadata")).split(",");

            for (String type : nomineeMetadataArr) {
                getNomineeEntity.getMetaData().add(type);
            }

            String payload = request.toJson(getNomineeEntity);

            Reporter.logReport(GetNomineeBL.class, log_Type_Pass,
                    "Get Nominee payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetNomineeBL.class, log_Type_Fail,
                    "error while creating the get Nominee payload.", e);

            throw new RuntimeException("error while creating the get Nominee payload.", e);
        }
    }

    public Map<String, String> setGetNomineeHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetNomineeBL.class, log_Type_Pass,
                    "Get Nominee header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetNomineeBL.class, log_Type_Fail,
                    "error while setting the get Nominee header.", e);

            throw new RuntimeException("error while setting the get Nominee header.", e);
        }
    }

    public Response postGetNominee(String requestBody, Map<String, String> header) {
        try {

            Response getNomineeResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Customer_GetNominee"), header);

            Reporter.logReport(GetNomineeBL.class, log_Type_Pass,
                    "Get Nominee API response : " + getNomineeResponse.prettyPrint(), null);

            return getNomineeResponse;

        } catch (Exception e) {
            Reporter.logReport(GetNomineeBL.class, log_Type_Fail,
                    "error while posting the get Nominee API.", e);

            throw new RuntimeException("error while posting the get Nominee API.", e);
        }
    }

    public void validateGetNomineeResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetNomineeBL.class, log_Type_Pass,
                    "Get Nominee API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetNomineeBL.class, log_Type_Fail,
                    "error while validating the get Nominee API response status.", e);

            throw new RuntimeException("error while validating the get Nominee API response status.", e);
        }
    }

    public void validateGetNomineeResponse(Response apiResponse, Map<Object, Object> testData) {
        try {
            GetNomineeResponse getNomineeResponse = apiResponse.as(GetNomineeResponse.class);

            String profileID = CommonMethods.getProfileID(testData);
            String query = "Select ID from INDIVIDUAL_DETAIL where ACCOUNT_ID = (Select ACCOUNT_ID from PROFILE " +
                    "where profile_id = " + profileID + ") and Relation = 'NOMINEE'";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);
            List<String> nomineeIdCollection = new ArrayList<>();

            while (resultSet.next()) {
                nomineeIdCollection.add(resultSet.getString("ID"));
            }

            int i = 0;
            for (NomineeDetails nomineeDetails : getNomineeResponse.getNominees()) {
                validateNomineeDetails(nomineeDetails, nomineeIdCollection.get(i++));
            }

            Reporter.logReport(GetNomineeBL.class, log_Type_Pass,
                    "Get Nominee API response validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetNomineeBL.class, log_Type_Fail,
                    "error while validating the get Nominee API response.", e);

            throw new RuntimeException("error while validating the get Nominee API response.", e);
        }
    }

    private void validateNomineeDetails(NomineeDetails nomineeDetails, String NomineeId) {
        try {

            Map<String, Object> nomineeData = getMappedData(nomineeDetails, NomineeId);
            validateNomineeRecords(nomineeData);

            //  validate nominee Guardian
            if (nomineeDetails.isMinor()) {
                if (nomineeDetails.getGuardian() != null) {

                    Map<String, Object> nomineeGuardianData = getMappedData(nomineeDetails.getGuardian(), nomineeDetails.getGuardian().getNomineeId());
                    validateNomineeRecords(nomineeGuardianData);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Map<String, Object> getMappedData(NomineeDetails nomineeDetails, String nomineeId) {
        Map<String, Object> nomineeDetailsMap = new HashMap<>();

        nomineeDetailsMap.put("nomineeId", nomineeId);
        nomineeDetailsMap.put("mobile", nomineeDetails.getMobile().getNumber());
        nomineeDetailsMap.put("relationship", nomineeDetails.getRelationship());
        nomineeDetailsMap.put("dob", nomineeDetails.getDob());
        nomineeDetailsMap.put("firstName", nomineeDetails.getName().getFirstName());
        nomineeDetailsMap.put("middleName", nomineeDetails.getName().getMiddleName());
        nomineeDetailsMap.put("lastName", nomineeDetails.getName().getLastName());
        nomineeDetailsMap.put("emailId", nomineeDetails.getEmailId());
        nomineeDetailsMap.put("address", nomineeDetails.getAddress());
        nomineeDetailsMap.put("guardian", nomineeDetails.getGuardian());
        nomineeDetailsMap.put("minor", nomineeDetails.isMinor());

        return nomineeDetailsMap;
    }

    private Map<String, String> getAddressMappedData(Address address) {
        Map<String, String> addressMap = new HashMap<>();

        addressMap.put("state", address.getState() == null ? "null" : address.getState());
        addressMap.put("pincode", address.getPincode() == null ? "null" : address.getPincode());
        addressMap.put("country", address.getCountry() == null ? "null" : address.getCountry());
        addressMap.put("addressData", address.getAddressData() == null ? "null" : address.getAddressData());

        return addressMap;
    }

    private void validateNomineeRecords(Map<String, Object> mappedData) {
        try {
            SoftAssert softAssert = new SoftAssert();

            String query = "Select * from INDIVIDUAL_DETAIL where ID = " + mappedData.get("nomineeId");
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

            resultSet.next();
            for (String key : mappedData.keySet()) {

                Object response = mappedData.get(key);

                if (response != null) {
                    if (response instanceof String) {
                        String columnValue = nomineeTableValues.valueOf(key).eqValue;

                        switch (key) {
                            case "dob":
                                String date = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(resultSet.getString(columnValue)),
                                        "dd-MMM-yyyy");

                                softAssert.assertEquals(date, (String) mappedData.get(key));
                                break;
                            default:
                                softAssert.assertEquals((String) mappedData.get(key), resultSet.getString(columnValue));
                        }
                    }

                    if (response instanceof Address[]) {

                        String addressQuery = "Select * from INDIVIDUAL_Address where INDIVIDUAL_ID = " + mappedData.get("nomineeId");
                        ResultSet resultSetAddress = DataBaseUtility.executeSelectStatement(dbBankService, addressQuery);

                        List<Map<String, String>> listAddress = new ArrayList<>();
                        while (resultSetAddress.next()) {
                            Map<String, String> mapAddress = new HashMap<>();

                            mapAddress.put("state", resultSetAddress.getString("STATE"));
                            mapAddress.put("pincode", resultSetAddress.getString("POST_CODE"));
                            mapAddress.put("country", resultSetAddress.getString("COUNTRY"));
                            mapAddress.put("addressData", resultSetAddress.getString("ADDRESS_LINE1") + " " + resultSetAddress.getString("ADDRESS_LINE2")
                                    + " " + resultSetAddress.getString("ADDRESS_LINE3"));

                            listAddress.add(mapAddress);
                        }

                        for (Address address : (Address[]) mappedData.get(key)) {
                            if (!listAddress.contains(getAddressMappedData(address))) {
                                softAssert.assertTrue(false, "Error while verifying the address. Address : " + getAddressMappedData(address));
                            }
                        }
                    }
                }
            }
            softAssert.assertAll();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
