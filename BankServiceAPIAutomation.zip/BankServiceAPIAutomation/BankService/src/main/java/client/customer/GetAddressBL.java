package client.customer;

import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.Header;
import entity.customerEntity.GetAddressEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GetAddressBL extends SetUp {

    public String createGetAddressPayload(Map<Object, Object> testData) {
        try {

            GetAddressEntity getAddressEntity = new GetAddressEntity();
            Gson request = new Gson();

            getAddressEntity.setType(Integer.parseInt((String) testData.get("CustomerType")));
            getAddressEntity.setValue((String) testData.get("Value"));

            String[] addressTypeArr = ((String) testData.get("AddressType")).split(",");
            List<Integer> addressType = new ArrayList<>();

            for (String type : addressTypeArr) {
                addressType.add(Integer.parseInt(type));
            }

            getAddressEntity.setAddressType(addressType);
            String payload = request.toJson(getAddressEntity);

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get address payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while creating the get address payload.", e);

            throw new RuntimeException("error while creating the get address payload.", e);
        }
    }

    public Map<String, String> setGetAddressHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get address header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while setting the get address header.", e);

            throw new RuntimeException("error while setting the get address header.", e);
        }
    }

    public Response postGetAddress(String requestBody, Map<String, String> header) {
        try {

            Response getAddressResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Customer_GetAddress"), header);

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get address api response : " + getAddressResponse.prettyPrint(), null);

            return getAddressResponse;

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while posting the get address api.", e);

            throw new RuntimeException("error while posting the get address api.", e);
        }
    }

    public void validateGetAddressResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get address api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while validating the get address api response status.", e);

            throw new RuntimeException("error while validating the get address api response status.", e);
        }
    }

    public void validateGetAddressResponse(Response apiResponse, Map<Object, Object> testData) {
        try {
            List<Map<String, String>> addressCollection = apiResponse.jsonPath().getList("addressDetails");

            if (addressCollection != null) {
                for (Map<String, String> address : addressCollection) {

                    // todo : create a utility to get the profile id from different types

                    String profileID = CommonMethods.getProfileID(testData);
                    validateGetAddress(profileID, address);

                }
            } else {
                throw new Exception("address records are not present.");
            }

            Reporter.logReport(GetAddressBL.class, log_Type_Pass,
                    "Get address api response is validated.", null);

        } catch (Exception e) {
            Reporter.logReport(GetAddressBL.class, log_Type_Fail,
                    "error while validating the get address api response.", e);

            throw new RuntimeException("error while validating the get address api response.", e);
        }
    }

    private void validateGetAddress(String profileID, Map<String, String> address) {
        try {
            String addressType = null;

            switch (address.get("addressType")) {

                case "Permanent Address":
                    addressType = Type_Permanent_Address;
                    break;

                case "Correspondence Address":
                    addressType = Type_Correspondence_Address;
                    break;

                case "3":

                    break;
                case "4":

                    break;
                case "5":

                    break;
                default:

            }

            // todo : need to check , On the basis of customer , we need to change our query

            String query = "Select * from Address where ACCOUNT_ID = (Select Account_id from Profile " +
                    "where profile_id = " + profileID + ") and ADDRESS_TYPE = '" + addressType + "'";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);
            verifyAddress(resultSet, address);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void verifyAddress(ResultSet resultSet, Map<String, String> address) {
        try {

            resultSet.next();
            SoftAssert softAssert = new SoftAssert();

            softAssert.assertEquals(resultSet.getString("CITY"), address.get("city"));
            softAssert.assertEquals(resultSet.getString("STATE"), address.get("state"));
            softAssert.assertEquals(resultSet.getString("POST_CODE"), address.get("pincode"));
            softAssert.assertEquals(resultSet.getString("COUNTRY"), address.get("country"));
            softAssert.assertEquals(resultSet.getString("ADDRESS_LINE1") + resultSet.getString("ADDRESS_LINE2")
                    + resultSet.getString("ADDRESS_LINE3"), address.get("addressData"));

            softAssert.assertAll();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
