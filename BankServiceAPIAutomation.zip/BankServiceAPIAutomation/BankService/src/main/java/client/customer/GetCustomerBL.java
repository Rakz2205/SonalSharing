package client.customer;


import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.Header;
import entity.customerEntity.GetCustomerEntity;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.getCustomer.GetCustomerResponse;
import utils.CommonMethods;
import utils.Reporter;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class GetCustomerBL extends SetUp {

    enum customerTableValues {
        firstName("first_name"), emailId("email"), maritalStatus("MARITAL_STATUS"),
        lastName("last_name"), countryCode("countryCode"), number("mobile"), gender("GENDER"),
        bankCustomerId("PROFILE_ID"), dob("dob"), createdAt("CREATED_AT"),
        updatedAt("UPDATED_AT"), kycStatus("KYC_STATUS"), emailVerified("EMAIL_VERIFIED"),
        merchant("IS_MERCHANT");

        private String eqValue;

        private customerTableValues(String eqValue) {
            this.eqValue = eqValue;
        }
    }

    public String createGetCustomerPayload(Map<Object, Object> testData) {
        try {

            GetCustomerEntity getCustomerEntity = new GetCustomerEntity();
            Gson request = new Gson();

            getCustomerEntity.setType(Integer.parseInt((String) testData.get("CustomerType")));
            getCustomerEntity.setValue((String) testData.get("Value"));
            getCustomerEntity.setResponseType((String) testData.get("ResponseType"));

            String[] customerMetadataArr = ((String) testData.get("Metadata")).split(",");

            for (String type : customerMetadataArr) {
                getCustomerEntity.getMetaData().add(type);
            }

            String payload = request.toJson(getCustomerEntity);

            Reporter.logReport(GetCustomerBL.class, log_Type_Pass,
                    "Get customer payload has been created. Payload : " + payload, null);

            return payload;

        } catch (Exception e) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while creating the get customer payload.", e);

            throw new RuntimeException("error while creating the get customer payload.", e);
        }
    }

    public Map<String, String> setGetCustomerHeader(Map<Object, Object> testData) {
        try {
            Map<String, String> header = Header.getHeader(TYPE_NON_TRANSACTION);

            header.put("x-loginid", "7892215058");
            header.put("x-uuid", "123456789");
            header.put("sessionId", "02449ed5-d878-40f5-aa05-33aa5ce8e61d");
            header.put("encryption", (String) testData.get("HeaderEncryption"));

            Reporter.logReport(GetCustomerBL.class, log_Type_Pass,
                    "Get customer header : " + header, null);

            return header;

        } catch (Exception e) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while setting the get customer header.", e);

            throw new RuntimeException("error while setting the get customer header.", e);
        }
    }

    public Response postGetCustomer(String requestBody, Map<String, String> header) {
        try {

            Response getCustomerResponse = RestUtil.postByJson(requestBody,
                    apiProperties.getProperty("Customer_GetCustomer"), header);

            Reporter.logReport(GetCustomerBL.class, log_Type_Pass,
                    "Get customer API response : " + getCustomerResponse.prettyPrint(), null);

            return getCustomerResponse;

        } catch (Exception e) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while posting the get customer API.", e);

            throw new RuntimeException("error while posting the get customer API.", e);
        }
    }

    public void validateGetCustomerResponseStatus(Response apiResponse, int apiExpectedStatus) {
        try {

            Assert.assertEquals(apiResponse.getStatusCode(), apiExpectedStatus);

            Reporter.logReport(GetCustomerBL.class, log_Type_Pass,
                    "Get customer API status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while validating the get customer API response status.", e);

            throw new RuntimeException("error while validating the get customer API response status.", e);
        }
    }

    public void validateGetCustomerResponse(Response apiResponse, Map<Object, Object> testData) {
        try {

            GetCustomerResponse getCustomerResponseObj = apiResponse.as(GetCustomerResponse.class);
            String profileId = CommonMethods.getProfileID(testData);
            validateGetCustomer(profileId, getCustomerResponseObj);

            Reporter.logReport(GetCustomerBL.class, log_Type_Pass,
                    "getCustomer api status code validated. Status code is  : " + apiResponse.getStatusCode(), null);

        } catch (Exception e) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while validating the getCustomer api response status.", e);

            throw new RuntimeException("error while validating the getCustomer api response status.", e);
        }
    }

    private void validateGetCustomer(String profileID, GetCustomerResponse getCustomerResponseObj) {

        try {
            String query = "Select * from Profile where profile_id=" + profileID;
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

//            ObjectMapper oMapper = new ObjectMapper();
//            Map<String, String> customerData = oMapper.convertValue(getCustomerResponseObj, Map.class);

            Map<String, String> customerData = getMappedData(getCustomerResponseObj);
            System.out.println(customerData);
            verifyResult(resultSet, customerData);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void verifyResult(ResultSet resultSet, Map<String, String> customerData) {

        String columnValue = null;
        try {
            resultSet.next();
            SoftAssert softAssert = new SoftAssert();

            Set<String> allParams = customerData.keySet();
            for (String param : allParams) {
                String val = customerData.get(param);
                if (val != null) {
                    if (!param.equalsIgnoreCase("merchant") & !param.equalsIgnoreCase("countryCode")) {
                        columnValue = customerTableValues.valueOf(param).eqValue;

                        switch (param) {
                            case "gender":
                                String gender = resultSet.getString(columnValue);
                                gender = gender.equalsIgnoreCase("m") ? "MALE" : "FEMALE";
                                softAssert.assertEquals(gender, customerData.get(param));
                                break;
                            case "createdAt":
                            case "updatedAt":
                            case "dob":
                                String date = DateUtility.convertDateToNewFormat(
                                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(resultSet.getString(columnValue)),
                                        "dd-MM-yyyy");
                                softAssert.assertEquals(date, customerData.get(param));
                                break;
                            case "emailVerified":
                                boolean verified = resultSet.getString(columnValue).equalsIgnoreCase("Y");
                                softAssert.assertEquals(String.valueOf(verified), customerData.get(param));
                                break;
                            default:
                                softAssert.assertEquals(resultSet.getString(columnValue), customerData.get(param));
                        }
                    }
                }
            }
            softAssert.assertAll();

        } catch (java.sql.SQLException e1) {
            Reporter.logReport(GetCustomerBL.class, log_Type_Fail,
                    "error while validating the getCustomer api response parameter" + columnValue, e1);
            throw new RuntimeException("error while validating the getCustomer api response parameters", e1);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> getMappedData(GetCustomerResponse customerData) {
        Map<String, String> customerDataMap = new HashMap<String, String>();

        customerDataMap.put("firstName", customerData.getName().getFirstName());
        customerDataMap.put("middleName", customerData.getName().getMiddleName());
        customerDataMap.put("lastName", customerData.getName().getLastName());
        customerDataMap.put("countryCode", customerData.getMobile().getCountryCode());
        customerDataMap.put("number", customerData.getMobile().getNumber());
        customerDataMap.put("gender", customerData.getGender());
        customerDataMap.put("bankCustomerId", customerData.getBankCustomerId());
        customerDataMap.put("emailId", customerData.getEmailId());
        customerDataMap.put("maritalStatus", customerData.getMaritalStatus());
        customerDataMap.put("dob", customerData.getDob());
        customerDataMap.put("createdAt", customerData.getCreatedAt());
        customerDataMap.put("updatedAt", customerData.getUpdatedAt());
        customerDataMap.put("kycStatus", customerData.getKycStatus());
        customerDataMap.put("emailVerified", customerData.getEmailVerified());
        customerDataMap.put("merchant", customerData.getMerchant());

        return customerDataMap;
    }

    public static String getCustomerData(int type, String value, String jsonPath) {
        try {
            GetCustomerEntity getCustomerEntity = new GetCustomerEntity();
            Gson request = new Gson();

            getCustomerEntity.setType(type);
            getCustomerEntity.setValue(value);
            getCustomerEntity.setResponseType("ALL");

            Response getCustomerResponse = RestUtil.postByJson(request.toJson(getCustomerEntity),
                    apiProperties.getProperty("Customer_GetCustomer"), Header.getHeader(TYPE_NON_TRANSACTION));


            return getCustomerResponse.jsonPath().getString(jsonPath);

        } catch (Exception e) {
            throw new RuntimeException("error while fetching the customer details.", e);
        }
    }
}

