package utils;

import base.Constants;
import com.didisoft.pgp.PGPLib;
import lw.bouncycastle.openpgp.PGPException;

public class FileSecurity implements Constants {


    //  used for file encryption
    // csv and text file encryption
    public static String encryptFile(String path, String fileName) {
        try {
            String destinationFileName = fileName.substring(0, fileName.lastIndexOf(".")).concat(".gpg");
            boolean fileEncrypted = FileSecurity.encrypt(path, path, fileName, destinationFileName);
            if (fileEncrypted) {
                try {
                    //Files.delete(Paths.get(path + "\\" + fileName));
                    return destinationFileName;
                } catch (Exception e) {
                    throw new Exception("Error while deleting file");
                }
            }
            Reporter.logReport(FileSecurity.class, log_Type_Pass,
                    "file encryption successful. file name is :" + fileName, null);
            return fileName;
        } catch (Exception e) {
            Reporter.logReport(FileSecurity.class, log_Type_Fail,
                    "error while encrypting the file.", e);
            throw new RuntimeException("error while encrypting the file.", e);
        }
    }

    public static String decryptFile(String sourcePath, String sourceFileName) {
        try {
            String destinationFileName = sourceFileName.substring(0, sourceFileName.lastIndexOf(".")).concat(".csv");
            boolean fileDecrypted = FileSecurity.decrypt(sourcePath, sourcePath, sourceFileName, destinationFileName);
            if (fileDecrypted) {
                try {
                    //Files.delete(Paths.get(sourcePath + "//" + sourceFileName));
                    return destinationFileName;
                } catch (Exception e) {
                    throw new Exception("Error while deleting file");
                }
            } else {
                throw new Exception("File decryption fail.");
            }
        } catch (Exception e) {
            throw new RuntimeException("error while decrypting the file.", e);
        }
    }

    public static boolean encrypt(String sourcePath, String destinationPath, String sourceFileName, String destinationFileName) {

        String publicKeyPath = System.getProperty("user.dir") +
                "//src//main//resources//NodalAccount//Keys//publickey.asc";

        PGPLib pgp = new PGPLib();
        try {
            String fullyQualifiedSourceFileName = sourcePath + "\\" + sourceFileName;
            String fullyQualifiedDestinationFileName = destinationPath + "\\" + destinationFileName;
            pgp.encryptFile(fullyQualifiedSourceFileName, publicKeyPath, fullyQualifiedDestinationFileName, true, false);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("error while decrypting the file.", e);
        }
    }

    public static boolean decrypt(String sourcePath, String destinationPath, String sourceFileName, String destinationFileName) {

        String privateKeyPath = System.getProperty("user.dir") +
                "//src//main//resources//NodalAccount//Keys//privatekey.asc";
        PGPLib pgp = new PGPLib();
        try {
            String fullyQualifiedSourceFileName = sourcePath + "//" + sourceFileName;
            String fullyQualifiedDestinationFileName = destinationPath + "//" + destinationFileName;
            String fileName = pgp.decryptFile(fullyQualifiedSourceFileName, privateKeyPath,
                    Constants.REMOTE_FILE_PRIVATE_KEY_PASS, fullyQualifiedDestinationFileName);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("error while decrypting the content.", e);
        }
    }

    public static String decryptString(String encryptedMessage) {

        String privateKeyPath = System.getProperty("user.dir") +
                "//src//main//resources//NodalAccount//Keys//privatekey.asc";

        PGPLib pgp = new PGPLib();
        try {
            String decryptedData = pgp.decryptString(encryptedMessage, privateKeyPath, Constants.REMOTE_FILE_PRIVATE_KEY_PASS);
            return decryptedData;
        } catch (Exception e) {
            throw new RuntimeException("error while decrypting the string.", e);
        }
    }

    public static String encryptString(String plainMessage) throws PGPException {

        String publicKeyPath = System.getProperty("user.dir") +
                "//src//main//resources//NodalAccount//Keys//publickey.asc";
        PGPLib pgp = new PGPLib();
        try {
            String encryptedString = pgp.encryptString(plainMessage, publicKeyPath);
            return encryptedString;
        } catch (Exception e) {
            throw new RuntimeException("error while encrypting the string.", e);
        }
    }
}


