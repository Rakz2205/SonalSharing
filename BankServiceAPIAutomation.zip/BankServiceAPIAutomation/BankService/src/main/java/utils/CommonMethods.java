package utils;

import base.Constants;
import base.SetUp;
import com.google.gson.Gson;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.javaUtils.DateUtility;
import entity.*;
import entity.TransactionEntity.TransactionEntity;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import responseEntity.TransactionResponseEntity.TransactionResponseEntity;
import responseEntity.errorEntity.ErrorResponse;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class CommonMethods extends SetUp {

    /*
     * Method to fetch Profile ID from given Customer Type:
     * 1 - MOBILE_NUMBER
     * 2 - BANK_CUSTOMER_ID i.e. Profile_ID
     * 3 - JFS_USER_ID
     * 4 - AADHAAR TOKEN
     * 5 - VPA
     * 6 - Account Number
     * */
    public static String getProfileID(Map<Object, Object> testData) {

        String customerType = (String) testData.get("CustomerType");
        String value = (String) testData.get("Value");
        String profileID = null;

        try {

            switch (customerType.trim()) {
                case "1":
                    String query = "Select Profile_ID from Profile where mobile='" + value.trim() + "'";
                    ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

                    resultSet.next();
                    profileID = resultSet.getString("Profile_ID");
                    break;
                case "2":
                    profileID = value.trim();
                    break;
                case "3":
                    //TODO: JFS_USER_ID currently not implemented in the APIs
                    break;
                case "4":
                    query = "SELECT Profile_ID from Profile where Account_id in (Select ACCOUNT_ID from IDENTITY" +
                            " where IDENTITY_NUMBER='" + value.trim() + "')";
                    resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

                    resultSet.next();
                    profileID = resultSet.getString("Profile_ID");
                    break;
                case "5":
                    //TODO: VPA currently not implemented in the APIs
                    break;
                case "6":
                    //  TODO:   Check for 30000000006119

                    query = "Select PROFILE_ID from PROFILE where ACCOUNT_ID in " +
                            "((select ACCOUNT_ID from bank_details where DECRYPTED_ACCOUNT_NUMBER = '" + value.trim() + "'))";
                    resultSet = DataBaseUtility.executeSelectStatement(dbBankService, query);

                    resultSet.next();
                    profileID = resultSet.getString("Profile_ID");
                    break;
                default:
                    profileID = (String) testData.get("Value");
            }

        } catch (SQLException e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail,
                    "error while fetching Profile_ID for given customerType", e);

        }
        return profileID;
    }

    /*
     * Method to validate API response time
     * Fails a test case if time limit exceeds a certain threshold.
     * */
    public static void validateAPIsTimeout(Response response, long timeInMilliSeconds) {
        try {

            long responseTime = response.getTimeIn(TimeUnit.MILLISECONDS);
            if (responseTime > timeInMilliSeconds)
                Assert.assertTrue(false, "Response time is more than time out value. " +
                        "\n Response Time : " + responseTime + "\n Timeout : " + timeInMilliSeconds);
            else
                Reporter.logReport(CommonMethods.class, log_Type_Log,
                        "API response time is : " + responseTime, null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail,
                    "error while validating the APIs response time.", null);
        }
    }

    /*
     * Method to generate a unique Idempotent Key.
     * Idempotent key generated are of format: auto-mation-x, where x is a number.
     * last used Idempotent Key is fetched from database & the 'x' part is incremented to get a unique ID.
     * */
    public static String generateNewIdempotentKey() {
        String newKey = null;
        try {
            /*String query = "select IDEMPOTENT_KEY from jpb_transaction where IDEMPOTENT_KEY LIKE '%auto-mation-%' " +
                    "ORDER BY CREATED desc fetch first 1 rows only";
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);

            if (resultSet.next()) {
                String currentKey = resultSet.getString("IDEMPOTENT_KEY");
                String counter = currentKey.split("auto-mation-")[1];
                int v = Integer.parseInt(counter);
                ++v;
                newKey = "auto-mation-" + v;
            }*/

            newKey = "auto_" + getTimeStamp();
        } catch (Exception e) {
            throw new RuntimeException("Error while creating unique idempotent key");
        }
        return newKey;
    }

    public static Connection getCBSInstanceByAccountNumber(String accountNumber) {
        try {
            if (accountNumber.startsWith("7") || accountNumber.startsWith("8")) {
                return dbCBS1;
            } else if (accountNumber.startsWith("3") || accountNumber.startsWith("4")) {
                return dbCBS2;
            } else if (accountNumber.startsWith("1") || accountNumber.startsWith("2")) {
                return dbCBS3;
            } else if (accountNumber.startsWith("5") || accountNumber.startsWith("6")) {
                return dbCBS4;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("error while fetching the CBS instance.", e);
        }
    }

    public static String getTimeStamp() {
        try {
            return DateUtility.getCurrentDateTime("ddMMyyyyHHmmss_") + System.currentTimeMillis();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateNewInvoice() {
        String invoice;
        try {

            /*DecimalFormat decimalFormat = new DecimalFormat("00000");

            String query = "select INVOICE from jpb_transaction where INVOICE LIKE '%auto_%' " +
                    "ORDER BY CREATED desc fetch first 1 rows only";

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbTransactionService, query);

            if (resultSet.next()) {
                String currentKey = resultSet.getString("INVOICE");
                String counter = currentKey.split("auto_")[1];

                invoice = "auto_" + decimalFormat.parse(String.valueOf(Integer.parseInt(counter) + 1));
            }*/

            invoice = "invoice_" + getTimeStamp();
        } catch (Exception e) {
            throw new RuntimeException("error while creating the invoice.");
        }
        return invoice;
    }

    //TODO: Initialise all params
    public static UserAccountDetails getGenericPayer() {
        UserAccountDetails payer = new UserAccountDetails();

        if (properties.getProperty("Environment").equalsIgnoreCase("SIT")) {
            payer.setAccountNumber(Constants.DEFAULT_SIT_PAYER_ACCOUNT);

            payer.setName(Constants.DEFAULT_SIT_PAYER_NAME);
            payer.setBankIfsc(Constants.DEFAULT_SIT_PAYER_BANK_IFSC);

            payer.setType(DEFAULT_SIT_PAYER_TYPE);
        } else {
            payer.setAccountNumber(Constants.DEFAULT_PP_PAYER_ACCOUNT);

            payer.setName(Constants.DEFAULT_PP_PAYER_NAME);
            payer.setBankIfsc(Constants.DEFAULT_PP_PAYER_BANK_IFSC);

            payer.setType(DEFAULT_PP_PAYER_TYPE);
        }
        return payer;
    }

    //TODO: Initialise all params
    public static UserAccountDetails getGenericPayee() {
        UserAccountDetails payee = new UserAccountDetails();

        if (properties.getProperty("Environment").equalsIgnoreCase("SIT")) {

            payee.setAccountNumber(Constants.DEFAULT_SIT_PAYEE_ACCOUNT);
            payee.setName(Constants.DEFAULT_SIT_PAYEE_NAME);

            payee.setBankIfsc(Constants.DEFAULT_SIT_PAYEE_BANK_IFSC);
            payee.setType(DEFAULT_SIT_PAYEE_TYPE);
        } else {

            payee.setAccountNumber(Constants.DEFAULT_PP_PAYEE_ACCOUNT);
            payee.setName(Constants.DEFAULT_PP_PAYEE_NAME);

            payee.setBankIfsc(Constants.DEFAULT_PP_PAYEE_BANK_IFSC);
            payee.setType(DEFAULT_PP_PAYEE_TYPE);
        }

        return payee;
    }

    public static UserAccountDetails getGenericPayee(String accountNumber, String bankIFSC) {
        UserAccountDetails payee = new UserAccountDetails();

        payee.setAccountNumber(accountNumber);
        payee.setBankIfsc(bankIFSC);

        //TODO: Need to change the type
        payee.setType(1);

        return payee;
    }

    public static UserAccountDetails getGenericPayer(String accountNumber, String bankIFSC) {
        UserAccountDetails payer = new UserAccountDetails();

        payer.setAccountNumber(accountNumber);
        payer.setBankIfsc(bankIFSC);

        //TODO: Need to change the type
        payer.setType(1);

        return payer;
    }

    //TODO: Write a method to generate a number to 2 decimal places
    public static Amount generateAmount() {
        Amount amount = new Amount();

        amount.setNetAmount(1);
        amount.setGrossAmount(1);

        return amount;
    }

    public static Amount generateAmount(Double netAmount, Double grossAmount) {
        Amount amount = new Amount();

        amount.setNetAmount(netAmount);
        amount.setGrossAmount(grossAmount);

        return amount;
    }

    public static InitiatingEntity getDefaultInitiatingEntity() {
        InitiatingEntity initiatingEntity = new InitiatingEntity();

        initiatingEntity.setCallbackUrl("http://localhost:9002/jfs/v1/plan");
        initiatingEntity.setEntityId(ENTITY_ID_8001);

        return initiatingEntity;
    }

    public static InitiatingEntity getDefaultInitiatingEntity(int entityId) {
        InitiatingEntity initiatingEntity = new InitiatingEntity();

        initiatingEntity.setCallbackUrl("http://localhost:9002/jfs/v1/plan");
        initiatingEntity.setEntityId(entityId);

        return initiatingEntity;
    }

    public static InitiatingEntity getDefaultInitiatingEntity(int entityId, String callBackURL) {
        InitiatingEntity initiatingEntity = new InitiatingEntity();

        initiatingEntity.setCallbackUrl(callBackURL);
        initiatingEntity.setEntityId(entityId);

        return initiatingEntity;
    }

    public static TransactionMethod getDefaultTransactionMethod() {
        TransactionMethod transactionMethod = new TransactionMethod();

        transactionMethod.setType(Constants.TYPE_DEBIT);
        transactionMethod.setSubType(SUB_TYPE_576);

        return transactionMethod;
    }

    public static TransactionMethod getTransactionMethod(int type, int subType) {
        TransactionMethod transactionMethod = new TransactionMethod();

        transactionMethod.setType(type);
        transactionMethod.setSubType(subType);

        return transactionMethod;
    }

    public static TransactionMethod getTransactionMethod(int type) {
        TransactionMethod transactionMethod = new TransactionMethod();

        transactionMethod.setType(type);
        return transactionMethod;
    }

    public static Transaction createTransaction(String idempotentKey, String invoice, TransactionMethod transactionMethod, int applicationId) {

        Transaction transaction = new Transaction();
        transaction.setIdempotentKey(idempotentKey);

        transaction.setCurrency(Constants.CURRENCY_CODE);
        transaction.setInvoice(invoice);

        transaction.setMode(1);
        transaction.setCaptureMethod(1);

        transaction.setLivemode("false");
        transaction.setApplication(applicationId);

        transaction.setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

        transaction.setInitiatingEntity(getDefaultInitiatingEntity());
        transaction.setMethod(transactionMethod);

        return transaction;
    }

    public static Transaction createTransaction(String idempotentKey, InitiatingEntity initiatingEntity, TransactionMethod transactionMethod, int applicationId) {

        Transaction transaction = new Transaction();
        transaction.setIdempotentKey(idempotentKey);

        transaction.setCurrency(Constants.CURRENCY_CODE);
        transaction.setInvoice(generateNewInvoice());

        transaction.setMode(1);
        transaction.setCaptureMethod(1);

        transaction.setLivemode("false");
        transaction.setApplication(applicationId);

        transaction.setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

        transaction.setInitiatingEntity(initiatingEntity);
        transaction.setMethod(transactionMethod);

        return transaction;
    }

    public static Transaction createTransaction(String idempotentKey, InitiatingEntity initiatingEntity, TransactionMethod transactionMethod, int applicationId, int mode) {

        Transaction transaction = new Transaction();
        transaction.setIdempotentKey(idempotentKey);

        transaction.setCurrency(Constants.CURRENCY_CODE);
        transaction.setInvoice(generateNewInvoice());

        transaction.setMode(mode);
        transaction.setCaptureMethod(1);

        transaction.setLivemode("false");
        transaction.setApplication(applicationId);

        transaction.setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

        transaction.setInitiatingEntity(initiatingEntity);
        transaction.setMethod(transactionMethod);

        return transaction;
    }

    public static TransactionEntity createTransactionReversalPayload(TransactionEntity transactionEntity, String originalTransactionId) {
        try {

            transactionEntity.getTransaction().setIdempotentKey(generateNewIdempotentKey());
            transactionEntity.getTransaction().setOriginalId(originalTransactionId);

            transactionEntity.getTransaction().setMethod(setTransactionMethodForReversal
                    (transactionEntity.getTransaction().getMethod().getType(), transactionEntity.getTransaction().getMethod().getSubType()));

            transactionEntity.getTransaction().setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

            return transactionEntity;
        } catch (Exception e) {
            throw new RuntimeException("error while creating the reversal payload.", e);
        }
    }

    public static TransactionEntity createTransactionCaptureCancelPayload(TransactionEntity transactionEntity, String originalTransactionId, String authorizationCode, int type) {
        try {

            transactionEntity.getTransaction().setIdempotentKey(generateNewIdempotentKey());
            transactionEntity.getTransaction().setOriginalId(originalTransactionId);
            transactionEntity.getTransaction().setAuthorizationCode(authorizationCode);

            switch (type) {
                case 215:
                    transactionEntity.getTransaction().getMethod().setType(TYPE_CANCEL);
                    break;
                case 113:
                    transactionEntity.getTransaction().getMethod().setType(TYPE_CAPTURE);
                    break;
            }

            transactionEntity.getTransaction().setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
            return transactionEntity;
        } catch (Exception e) {
            throw new RuntimeException("error while creating the reversal payload.", e);
        }
    }

    public static Transaction createTransactionUsingDatabase(Map<Object, Object> testData, TransactionMethod transactionMethod) {

        Transaction transaction = new Transaction();
        transaction.setIdempotentKey(generateNewIdempotentKey());
        transaction.setOriginalId((String) testData.get("ORIGINAL_TRANSACTION_ID"));

        transaction.setCurrency(Constants.CURRENCY_CODE);
        transaction.setInvoice(generateNewInvoice());

        transaction.setMode(1);
        transaction.setCaptureMethod(1);

        transaction.setLivemode("false");
        transaction.setApplication(Integer.parseInt((String) testData.get("APPLICATION_ID")));

        transaction.setInitiatingEntityTimestamp(DateUtility.getCurrentDateTime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

        InitiatingEntity initiatingEntity = getDefaultInitiatingEntity(Integer.parseInt((String) testData.get("INITIATING_ENTITY_ID")),
                (String) testData.get("CALLBACK_URL"));

        transaction.setInitiatingEntity(initiatingEntity);
        transaction.setMethod(transactionMethod);

        return transaction;
    }

    public static TransactionEntity createTransactionReversalPayload(Map<Object, Object> testData) {
        try {
            TransactionEntity transactionEntity = new TransactionEntity();
            int transactionType = Integer.parseInt((String) testData.get("METHOD_TYPE"));
            int transactionSubType = Integer.parseInt((String) testData.get("METHOD_SUB_TYPE"));

            TransactionMethod transactionMethod = setTransactionMethodForReversal(transactionType, transactionSubType);
            Transaction transaction = createTransactionUsingDatabase(testData, transactionMethod);

            transactionEntity.setTransaction(transaction);
            transactionEntity.setAmount(generateAmount(Double.parseDouble(testData.get("NET_AMOUNT").toString()),
                    Double.parseDouble(testData.get("GROSS_AMOUNT").toString())));

            switch (transactionType) {
                case (213):
                    transactionEntity.setPayee(getGenericPayee((String) testData.get("PAYEE_ACCOUNT_NUMBER"), (String) testData.get("PAYEE_BANK_IFSC")));
                    break;
                case (111):
                    transactionEntity.setPayer(getGenericPayer((String) testData.get("PAYER_ACCOUNT_NUMBER"), (String) testData.get("PAYER_BANK_IFSC")));
                    break;
            }
            return transactionEntity;
        } catch (Exception e) {

            throw new RuntimeException("error while creating the reversal payload.", e);
        }
    }

    public static String getDefaultPayeeAccountNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_PAYEE_ACCOUNT;
        else
            return DEFAULT_PP_PAYEE_ACCOUNT;
    }

    public static String getDefaultCreditFreezeAccountNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_CREDIT_FREEZE_ACCOUNT;
        else
            return DEFAULT_PP_CREDIT_FREEZE_ACCOUNT;
    }

    public static String getDefaultTotalFreezeAccountNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_TOTAL_FREEZE_ACCOUNT;
        else
            return DEFAULT_PP_TOTAL_FREEZE_ACCOUNT;
    }

    public static String getDefaultCloseAccountNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_CLOSED_ACCOUNT;
        else
            return DEFAULT_PP_CLOSED_ACCOUNT;
    }

    public static String getDefaultPayeeBankIFSCNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_PAYEE_BANK_IFSC;
        else
            return DEFAULT_PP_PAYEE_BANK_IFSC;
    }

    public static String getDefaultPayerAccountNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_PAYER_ACCOUNT;
        else
            return DEFAULT_PP_PAYER_ACCOUNT;
    }

    public static String getDefaultPayerBankIFSCNumber() {
        if (properties.getProperty("Environment").equalsIgnoreCase("SIT"))
            return DEFAULT_SIT_PAYER_BANK_IFSC;
        else
            return DEFAULT_PP_PAYER_BANK_IFSC;
    }

    public static String removeSubType(TransactionEntity transactionEntity) {
        try {
            Gson request = new Gson();

            DocumentContext documentContext = JsonPath.parse(request.toJson(transactionEntity));
            documentContext.delete("transaction.method.subType");

            return documentContext.jsonString();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String performActionOnTransaction(TransactionEntity transactionEntity, String action, String jsonPath, Object object) {
        try {
            Gson request = new Gson();
            return ChangeJsonPayload(request.toJson(transactionEntity), action, jsonPath, object);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String ChangeJsonPayload(String jsonPayLoad, String action, String jsonPath, Object object) {
        DocumentContext documentContext = JsonPath.parse(jsonPayLoad);
        switch (action) {
            case (ACTION_SET):
                documentContext.set(jsonPath, object);
                break;
            case (ACTION_DELETE):
                documentContext.delete(jsonPath);
                break;
        }
        return documentContext.jsonString();
    }

    public static TransactionMethod setTransactionMethodForReversal(int type, int subType) {
        TransactionMethod transactionMethod = new TransactionMethod();
        try {
            switch (type) {
                case (213):
                    transactionMethod = getTransactionMethod(TYPE_REVERSAL, SUB_TYPE_CREDIT_REVERSAL);
                    break;
                case (111):
                    transactionMethod = getTransactionMethod(TYPE_REVERSAL, SUB_TYPE_DEBIT_REVERSAL);
                    break;
                case (302):
                    transactionMethod = getTransactionMethod(TYPE_REVERSAL, subType);
                    break;
                default:
                    throw new Exception("Transaction type is invalid for reversal.");
            }
            transactionMethod.setType(TYPE_REVERSAL);
            return transactionMethod;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String modifyTxnPayload(TransactionEntity transactionEntity, String paramType, Object paramVal, boolean modifySerialization, String action) {
        String payload = null;
        Gson request = new Gson();

        try {
            switch (paramType) {
                case (APPLICATION_ID):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_APPLICATION_ID, paramVal);
                    else
                        transactionEntity.getTransaction().setApplication((Integer) paramVal);
                    break;

                case (ENTITY_ID):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_ENTITY_ID, paramVal);
                    else
                        transactionEntity.getTransaction().getInitiatingEntity().setEntityId((Integer) paramVal);
                    break;

                case (ORIGINAL_ID):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_ORIGINAL_ID, paramVal);
                    else
                        transactionEntity.getTransaction().setOriginalId(paramVal.toString());
                    break;

                case (IDEMPOTENT_KEY):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_IDEMPOTENT_KEY, paramVal);
                    else
                        transactionEntity.getTransaction().setIdempotentKey(paramVal.toString());
                    break;

                case (CURRENCY):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_CURRENCY, paramVal);
                    else
                        transactionEntity.getTransaction().setCurrency((Integer) paramVal);
                    break;

                case (INITIATING_ENTITY_TIMESTAMP):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_INITIATING_ENTITY_TIMESTAMP, paramVal);
                    else
                        transactionEntity.getTransaction().setInitiatingEntityTimestamp(paramVal.toString());
                    break;

                case (MODE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_MODE, paramVal);
                    else
                        transactionEntity.getTransaction().setMode((Integer) paramVal);
                    break;

                case (CAPTURE_METHOD):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_CAPTURE_METHOD, paramVal);
                    else
                        transactionEntity.getTransaction().setCaptureMethod((Integer) paramVal);
                    break;

                case (INVOICE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_INVOICE, paramVal);
                    else
                        transactionEntity.getTransaction().setInvoice((String) paramVal);
                    break;

                case (TRANSACTION):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_TRANSACTION, paramVal);
                    break;

                case (METHOD):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_METHOD, paramVal);
                    break;

                case (METHOD_TYPE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_METHOD_TYPE, paramVal);
                    else
                        transactionEntity.getTransaction().getMethod().setType((Integer) paramVal);
                    break;

                case (METHOD_SUBTYPE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_METHOD_SUBTYPE, paramVal);
                    else
                        transactionEntity.getTransaction().getMethod().setSubType((Integer) paramVal);
                    break;

                case (LIVE_MODE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_LIVE_MODE, paramVal);
                    else
                        transactionEntity.getTransaction().setLivemode((String) paramVal);
                    break;

                case (INITIATING_ENTITY):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_INITIATING_ENTITY, paramVal);
                    break;

                case (CALLBACK_URL):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_CALLBACK_URL, paramVal);
                    else
                        transactionEntity.getTransaction().getInitiatingEntity().setCallbackUrl((String) paramVal);
                    break;

                case (AUTHORIZATION_CODE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_AUTHORIZATION_CODE, paramVal);
                    else
                        transactionEntity.getTransaction().setAuthorizationCode((String) paramVal);
                    break;

                case (AMOUNT):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_AMOUNT, paramVal);

                    break;
                case (AMOUNT_NET_AMOUNT):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_AMOUNT_NET_AMOUNT, paramVal);
                    else
                        transactionEntity.getAmount().setNetAmount((Double) paramVal);
                    break;

                case (AMOUNT_GROSS_AMOUNT):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_AMOUNT_GROSS_AMOUNT, paramVal);
                    else
                        transactionEntity.getAmount().setGrossAmount((Double) paramVal);
                    break;

                case (Constants.PAYER):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYER, paramVal);

                    break;

                case (PAYEE):
                    if (modifySerialization)
                        payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYEE, paramVal);

                    break;
                case (ACCOUNT_NUMBER):
                    if (transactionEntity.getPayer() == null) {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYEE_ACCOUNT_NUMBER, paramVal);
                        else
                            transactionEntity.getPayee().setAccountNumber((String) paramVal);
                    } else {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYER_ACCOUNT_NUMBER, paramVal);
                        else
                            transactionEntity.getPayer().setAccountNumber((String) paramVal);
                    }
                    break;
                case (BANK_IFSC):
                    if (transactionEntity.getPayer() == null) {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYEE_BANK_IFSC, paramVal);
                        else
                            transactionEntity.getPayee().setBankIfsc((String) paramVal);
                    } else {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYER_BANK_IFSC, paramVal);
                        else
                            transactionEntity.getPayer().setBankIfsc((String) paramVal);
                    }
                    break;
                case (TYPE):
                    if (transactionEntity.getPayer() == null) {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYEE_TYPE, paramVal);
                        else
                            transactionEntity.getPayee().setType((Integer) paramVal);
                    } else {
                        if (modifySerialization)
                            payload = CommonMethods.performActionOnTransaction(transactionEntity, action, PATH_PAYER_TYPE, paramVal);
                        else
                            transactionEntity.getPayer().setType((Integer) paramVal);
                    }
                    break;
            }

            if (payload == null)
                payload = request.toJson(transactionEntity);

            return payload;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void validateFailedTransactionResponse(Response apiResponse, String failureCode, String failureMessage) {
        try {

            SoftAssert softAssert = new SoftAssert();

            if (apiResponse.getStatusCode() == HttpStatus.SC_OK) {
                TransactionResponseEntity transactionResponse = apiResponse.as(TransactionResponseEntity.class);
                Map<String, Object> mappedData = getMappedData(transactionResponse);

                softAssert.assertTrue(mappedData.get("status").toString().equalsIgnoreCase("FAILED"), "Transaction status Failed?");

                //check if failure code is not null
                softAssert.assertTrue(mappedData.get("failureCode") != null, "Failure Code present?");

                if (mappedData.get("failureCode") != null)
                    softAssert.assertEquals(mappedData.get("failureCode").toString(), failureCode, "is Failure Code Correct?");

                //check if failure message is not null
                softAssert.assertTrue(failureMessage != null, "Failure Message present?");

                if (mappedData.get("failureMessage") != null)
                    softAssert.assertTrue(mappedData.get("failureMessage").toString().equalsIgnoreCase(failureMessage), "is Failure Message Correct?");

            } else {
                ErrorResponse error = apiResponse.as(ErrorResponse.class);
                softAssert.assertEquals(error.getError().getCode(), failureCode);
                softAssert.assertEquals(error.getError().getMessage().trim(), failureMessage.trim());
            }


            softAssert.assertAll();

            Reporter.logReport(CommonMethods.class, log_Type_Pass,
                    "Error message, status & code are correct.", null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail,
                    "Error message, status & code are incorrect.", e);

            throw new RuntimeException("Error message, status & code are incorrect.", e);
        }

    }

    public static Map<String, Object> getMappedData(TransactionResponseEntity transactionEntity) {
        Map<String, Object> mapTransactionEntity = new HashMap<>();

        mapTransactionEntity.put("id", transactionEntity.getTransaction().getId());
        mapTransactionEntity.put("originalId", transactionEntity.getTransaction().getOriginalId());
        mapTransactionEntity.put("idempotentKey", transactionEntity.getTransaction().getIdempotentKey());
        mapTransactionEntity.put("arrivalDate", transactionEntity.getTransaction().getArrivalDate());
        mapTransactionEntity.put("created", transactionEntity.getTransaction().getCreated());
        mapTransactionEntity.put("currency", transactionEntity.getTransaction().getCurrency());
        mapTransactionEntity.put("failureCode", transactionEntity.getTransaction().getFailureCode());
        mapTransactionEntity.put("failureMessage", transactionEntity.getTransaction().getFailureMessage());
        mapTransactionEntity.put("mode", transactionEntity.getTransaction().getMode());
        mapTransactionEntity.put("type", transactionEntity.getTransaction().getMethod().getType());
        mapTransactionEntity.put("subType", transactionEntity.getTransaction().getMethod().getSubType());
        mapTransactionEntity.put("captureMethod", transactionEntity.getTransaction().getCaptureMethod());
        mapTransactionEntity.put("status", transactionEntity.getTransaction().getStatus());
        mapTransactionEntity.put("application", transactionEntity.getTransaction().getApplication());
        mapTransactionEntity.put("entityId", transactionEntity.getTransaction().getInitiatingEntity().getEntityId());
        mapTransactionEntity.put("callbackUrl", transactionEntity.getTransaction().getInitiatingEntity().getCallbackUrl());
        mapTransactionEntity.put("invoice", transactionEntity.getTransaction().getInvoice());
        mapTransactionEntity.put("responseTime", transactionEntity.getTransaction().getResponseTime());
        mapTransactionEntity.put("authorizationCode", transactionEntity.getTransaction().getAuthorizationCode());


        mapTransactionEntity.put("netAmount", transactionEntity.getAmount().getNetAmount());
        mapTransactionEntity.put("grossAmount", transactionEntity.getAmount().getGrossAmount());

        mapTransactionEntity.put("payeeType", transactionEntity.getPayee().getType());
        mapTransactionEntity.put("payeeName", transactionEntity.getPayee().getName());
        mapTransactionEntity.put("payeeMmid", transactionEntity.getPayee().getMmid());
        mapTransactionEntity.put("payeeAccountNumber", transactionEntity.getPayee().getAccountNumber());
        mapTransactionEntity.put("payeeBankIFSC", transactionEntity.getPayee().getBankIfsc());
        mapTransactionEntity.put("payeeBankName", transactionEntity.getPayee().getBankName());
        mapTransactionEntity.put("payeeMerchantId", transactionEntity.getPayee().getMerchantId());
        mapTransactionEntity.put("payeeTerminalId", transactionEntity.getPayee().getTerminalId());
        mapTransactionEntity.put("payeeMobile", transactionEntity.getPayee().getMobile().getNumber());

        mapTransactionEntity.put("payerType", transactionEntity.getPayer().getType());
        mapTransactionEntity.put("payerName", transactionEntity.getPayer().getName());
        mapTransactionEntity.put("payerMmid", transactionEntity.getPayer().getMmid());
        mapTransactionEntity.put("payerAccountNumber", transactionEntity.getPayer().getAccountNumber());
        mapTransactionEntity.put("payerBankIFSC", transactionEntity.getPayer().getBankIfsc());
        mapTransactionEntity.put("payerBankName", transactionEntity.getPayer().getBankName());
        mapTransactionEntity.put("payerMerchantId", transactionEntity.getPayer().getMerchantId());
        mapTransactionEntity.put("payerTerminalId", transactionEntity.getPayer().getTerminalId());
        mapTransactionEntity.put("payerMobile", transactionEntity.getPayer().getMobile().getNumber());

        return mapTransactionEntity;
    }

    /*
     * method to get certificate path based on entity ID
     * */
    public static String getCertificatePath(int entityId) {

        String path;
        switch (entityId) {

            case (8011):
            case (8012):
            case (8013):
                path = System.getProperty("user.dir") +
                        "//src//main//resources//Certificate//eNach//nach_keystore_sit.p12";
                break;
            default:
                path = "";
        }
        return path;
    }

    public static DeviceInfo getDeviceInfoEntities(String dpId, String rdsId, String rdsVer, String dc, String mi, String mc){
        DeviceInfo deviceInfoEntities = new DeviceInfo();

        deviceInfoEntities.setDpId(dpId);
        deviceInfoEntities.setRdsId(rdsId);
        deviceInfoEntities.setRdsVer(rdsVer);
        deviceInfoEntities.setDc(dc);
        deviceInfoEntities.setMi(mi);
        deviceInfoEntities.setMc(mc);

        return deviceInfoEntities;
    }

    public static CaptureResponse getCaptureResponseEntities(String iCount,
                                                             String pidDatatype,
                                                             String rdsID,
                                                             String nmPoin,
                                                             String errInfo,
                                                             String iType,
                                                             String ver,
                                                             String rc,
                                                             String dpID,
                                                             String mc,
                                                             String sessionKey,
                                                             String tid,
                                                             String mi,
                                                             String dc,
                                                             String consent,
                                                             String errCode,
                                                             String qScore,
                                                             String saTxn,
                                                             String pCount,
                                                             String fCount,
                                                             String hmac,
                                                             String sa,
                                                             String ci,
                                                             String appCode,
                                                             String rdsVer,
                                                             String pType,
                                                             String piddata,
                                                             String fType){
        CaptureResponse captureResponseEntities = new CaptureResponse();

        captureResponseEntities.setiCount(iCount);
        captureResponseEntities.setPidDatatype(pidDatatype);
        captureResponseEntities.setRdsID(rdsID);
        captureResponseEntities.setNmPoin(nmPoin);
        captureResponseEntities.setErrInfo(errInfo);
        captureResponseEntities.setiType(iType);
        captureResponseEntities.setVer(ver);
        captureResponseEntities.setRc(rc);
        captureResponseEntities.setDpID(dpID);
        captureResponseEntities.setMc(mc);
        captureResponseEntities.setSessionKey(sessionKey);
        captureResponseEntities.setTid(tid);
        captureResponseEntities.setMi(mi);
        captureResponseEntities.setDc(dc);
        captureResponseEntities.setConsent(consent);
        captureResponseEntities.setErrCode(errCode);
        captureResponseEntities.setqScore(qScore);
        captureResponseEntities.setSaTxn(saTxn);
        captureResponseEntities.setpCount(pCount);
        captureResponseEntities.setfCount(fCount);
        captureResponseEntities.setHmac(hmac);
        captureResponseEntities.setSa(sa);
        captureResponseEntities.setCi(ci);
        captureResponseEntities.setAppCode(appCode);
        captureResponseEntities.setRdsVer(rdsVer);
        captureResponseEntities.setpType(pType);
        captureResponseEntities.setPiddata(piddata);
        captureResponseEntities.setfType(fType);

        return captureResponseEntities;
    }

    public static EAuthRequest getEAuthRequest(String aadhaarToken, String consent, String appCode, String transactionRefNumber, CaptureResponse captureResponse, DeviceInfo deviceInfo){
        EAuthRequest eAuthRequest = new EAuthRequest();

        eAuthRequest.setAadhaarToken(aadhaarToken);
        eAuthRequest.setConsent(consent);
        eAuthRequest.setAppCode(appCode);
        eAuthRequest.setTransactionRefNumber(transactionRefNumber);
        eAuthRequest.setCaptureResponse(captureResponse);
        eAuthRequest.setDeviceInfo(deviceInfo);

        return eAuthRequest;
    }

    public static AuthenticateList getAuthenticationListOfEAuthEntities(int mode, String value, String action, String transactionRefNumber, EAuthRequest eAuthRequest){
        AuthenticateList authenticateList = new AuthenticateList();

        authenticateList.setMode(mode);
        authenticateList.setValue(value);
        authenticateList.setAction(action);
        authenticateList.setTransactionRefNumber(transactionRefNumber);
        authenticateList.seteAuthRequest(eAuthRequest);

        return authenticateList;
    }

    public static MobileEntity getMobileEntities(String mobileNumber, String countryCode){
        MobileEntity mobile = new MobileEntity();

        mobile.setMobileNumber(mobileNumber);
        mobile.setCountryCode(countryCode);

        return mobile;
    }

    public static User getUserEntitiesOfEAuth(String bankCustomerId, MobileEntity mobile, String emailAddress){
        User user = new User();

        user.setBankCustomerId(bankCustomerId);
        user.setMobile(mobile);
        user.setEmailAddress(emailAddress);

        return user;
    }

    public static List<AuthenticateList> getAuthenticateList(AuthenticateList authenticateListData){

        List<AuthenticateList> listOfAuthenticateList = new ArrayList<>();
        listOfAuthenticateList.add(0, authenticateListData);

        return listOfAuthenticateList;
    }

    public static AuthenticateList getAuthenticationListEntities(int mode, String value, String action, String transactionRefNumber){
        AuthenticateList authenticateList = new AuthenticateList();

        authenticateList.setMode(mode);
        authenticateList.setValue(value);
        authenticateList.setAction(action);
        authenticateList.setTransactionRefNumber(transactionRefNumber);

        return authenticateList;
    }


    public static User getUserEntities(String bankCustomerId, MobileEntity mobile, String emailID, String customerImage){
        User user = new User();

        user.setBankCustomerId(bankCustomerId);
        user.setMobile(mobile);
        user.setEmailAddress(emailID);
        user.setCustomerImage(customerImage);

        return user;
    }


}
