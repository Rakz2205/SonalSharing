package utils;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Enumeration;

public class DigitalSignature {


    public static String encodePublicKey() {
        try {
            String publicCertificatePath = System.getProperty("user.dir") +
                    "//src//main//resources//Certificate//public_certificate.cer";

            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate
                    (new FileInputStream(publicCertificatePath));

            PublicKey publicKey = certificate.getPublicKey();
            String encodePublicKey = Base64.getEncoder().encodeToString(publicKey.getEncoded());

            return encodePublicKey;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static KeyStore loadKeystore(String filePath) throws Exception {
        try {
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream(filePath), "changeit".toCharArray());

            return keyStore;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String encodePrivateKey() {
        try {
            String filePath = System.getProperty("user.dir") +
                    "//src//main//resources//Certificate//sender_keystore.p12";

            KeyStore keyStore = loadKeystore(filePath);

            PrivateKey privateKey = (PrivateKey) keyStore.getKey("senderKeyPair", "changeit".toCharArray());
            String encodePrivateKey = Base64.getEncoder().encodeToString(privateKey.getEncoded());

            return encodePrivateKey;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateSignature(String alias, KeyStore keyStore, String message) {
        try {
            PrivateKey privateKey = (PrivateKey) keyStore.getKey(alias, "changeit".toCharArray());

            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);

            signature.update(message.getBytes());
            byte[] digitalSignature = signature.sign();

            return Base64.getEncoder().encodeToString(digitalSignature);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateSignature(String message) {
        try {
            String filePath = System.getProperty("user.dir") +
                    "//src//main//resources//Certificate//sender_keystore.p12";

            KeyStore keyStore = loadKeystore(filePath);
            return generateSignature( "senderKeyPair", keyStore, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateAuthSignature(String message) {
        try {
            String filePath = System.getProperty("user.dir") +
                    "//src//main//resources//Certificate//Authentication//sender_keystore.p12";

            KeyStore keyStore = loadKeystore(filePath);
            return generateSignature( "senderKeyPair", keyStore, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateAuthenticationSignature(String message) {
        try {
            String filePath = System.getProperty("user.dir") +
                    "//src//main//resources//Certificate//jpb_rsa_public_sit.pem";

            KeyStore keyStore = loadKeystore(filePath);
            return generateSignature( "senderKeyPair", keyStore, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String generateSignature(String payload, String certificatePath ) {
        try {
            KeyStore keyStore = loadKeystore(certificatePath);

            Enumeration<String> aliases = keyStore.aliases();
            String alias = "";
            while(aliases.hasMoreElements()){
                alias = aliases.nextElement();
                System.out.println(alias);
            }
            return generateSignature(alias, keyStore, payload);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}