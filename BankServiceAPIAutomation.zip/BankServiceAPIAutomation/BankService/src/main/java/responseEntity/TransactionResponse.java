package responseEntity;

public class TransactionResponse {

    private String id = null;
    private String idempotentKey = null;
    private String originalId = null;
    private int currency;
    private String invoice = null;
    private TransactionMethodReponse method = new TransactionMethodReponse();
    private int mode;
    private int captureMethod;
    private String livemode = null;
    private int application;
    private String initiatingEntityTimestamp = null;
    private InitiatingEntityResponse initiatingEntity = new InitiatingEntityResponse();
    private String arrivalDate = null;
    private String created = null;
    private String responseTime = null;
    private String authorizationCode = null;
    private String status = null;
    private String failureCode = null;
    private String failureMessage = null;
    private String statementDescriptor = null;

    public String getFailureCode() {
        return failureCode;
    }

    public void setFailureCode(String failureCode) {
        this.failureCode = failureCode;
    }

    public String getFailureMessage() {
        return failureMessage;
    }

    public void setFailureMessage(String failureMessage) {
        this.failureMessage = failureMessage;
    }

    public String getIdempotentKey() {
        return idempotentKey;
    }

    public void setIdempotentKey(String idempotentKey) {
        this.idempotentKey = idempotentKey;
    }

    public int getCurrency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public TransactionMethodReponse getMethod() {
        return method;
    }

    public void setMethod(TransactionMethodReponse method) {
        this.method = method;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public int getCaptureMethod() {
        return captureMethod;
    }

    public void setCaptureMethod(int captureMethod) {
        this.captureMethod = captureMethod;
    }

    public String getLivemode() {
        return livemode;
    }

    public void setLivemode(String livemode) {
        this.livemode = livemode;
    }

    public int getApplication() {
        return application;
    }

    public void setApplication(int application) {
        this.application = application;
    }

    public String getInitiatingEntityTimestamp() {
        return initiatingEntityTimestamp;
    }

    public void setInitiatingEntityTimestamp(String initiatingEntityTimestamp) {
        this.initiatingEntityTimestamp = initiatingEntityTimestamp;
    }

    public InitiatingEntityResponse getInitiatingEntity() {
        return initiatingEntity;
    }

    public void setInitiatingEntity(InitiatingEntityResponse initiatingEntity) {
        this.initiatingEntity = initiatingEntity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(String responseTime) {
        this.responseTime = responseTime;
    }

    public String getAuthorizationCode() {
        return authorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOriginalId() {
        return originalId;
    }

    public void setOriginalId(String originalId) {
        this.originalId = originalId;
    }

    public String getStatementDescriptor() {
        return statementDescriptor;
    }

    public void setStatementDescriptor(String statementDescriptor) {
        this.statementDescriptor = statementDescriptor;
    }

}
