package responseEntity.getMiniStatement;

import responseEntity.Statement;

public class GetMiniStatementResponse {

    public Statement[] getStatement() {
        return statement;
    }

    public void setStatement(Statement[] statement) {
        this.statement = statement;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    private Statement[] statement;
    private String accountNumber;
}
