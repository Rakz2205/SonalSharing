package responseEntity.TransactionResponseEntity;

import entity.Amount;
import responseEntity.TransactionResponse;
import responseEntity.UserAccountDetailsResponse;

public class TransactionResponseEntity {

    private TransactionResponse transaction = new TransactionResponse();
    private Amount amount = new Amount();
    private UserAccountDetailsResponse payer = new UserAccountDetailsResponse();
    private UserAccountDetailsResponse payee = new UserAccountDetailsResponse();

    public TransactionResponse getTransaction() {
        return transaction;
    }

    public void setTransaction(TransactionResponse transaction) {
        this.transaction = transaction;
    }

    public Amount getAmount() {
        return amount;
    }

    public void setAmount(Amount amount) {
        this.amount = amount;
    }

    public UserAccountDetailsResponse getPayer() {
        return payer;
    }

    public void setPayer(UserAccountDetailsResponse payer) {
        this.payer = payer;
    }

    public UserAccountDetailsResponse getPayee() {
        return payee;
    }

    public void setPayee(UserAccountDetailsResponse payee) {
        this.payee = payee;
    }
}
