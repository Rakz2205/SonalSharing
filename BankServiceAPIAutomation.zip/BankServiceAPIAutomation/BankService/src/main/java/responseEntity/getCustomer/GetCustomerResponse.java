package responseEntity.getCustomer;

import responseEntity.Mobile;
import responseEntity.Name;

public class GetCustomerResponse {

    private String createdAt = null;
    private String emailVerified = null;
    private String kycStatus = null;
    private String gender = null;
    private String dob = null;
    private Name name;
    private Mobile mobile;
    private String merchant = null;
    private String emailId = null;
    private String bankCustomerId = null;
    private String maritalStatus = null;
    private String updatedAt = null;

    public String getCreatedAt ()
    {
        return createdAt;
    }

    public void setCreatedAt (String createdAt)
    {
        this.createdAt = createdAt;
    }

    public String getEmailVerified ()
    {
        return emailVerified;
    }

    public void setEmailVerified (String emailVerified)
    {
        this.emailVerified = emailVerified;
    }

    public String getKycStatus ()
    {
        return kycStatus;
    }

    public void setKycStatus (String kycStatus)
    {
        this.kycStatus = kycStatus;
    }

    public String getGender ()
    {
        return gender;
    }

    public void setGender (String gender)
    {
        this.gender = gender;
    }

    public String getDob ()
    {
        return dob;
    }

    public void setDob (String dob)
    {
        this.dob = dob;
    }

    public Name getName ()
    {
        return name;
    }

    public void setName (Name name)
    {
        this.name = name;
    }

    public Mobile getMobile ()
    {
        return mobile;
    }

    public void setMobile (Mobile mobile)
    {
        this.mobile = mobile;
    }

    public String getMerchant ()
    {
        return merchant;
    }

    public void setMerchant (String merchant)
    {
        this.merchant = merchant;
    }

    public String getEmailId ()
    {
        return emailId;
    }

    public void setEmailId (String emailId)
    {
        this.emailId = emailId;
    }

    public String getBankCustomerId ()
    {
        return bankCustomerId;
    }

    public void setBankCustomerId (String bankCustomerId)
    {
        this.bankCustomerId = bankCustomerId;
    }

    public String getMaritalStatus ()
    {
        return maritalStatus;
    }

    public void setMaritalStatus (String maritalStatus)
    {
        this.maritalStatus = maritalStatus;
    }

    public String getUpdatedAt ()
    {
        return updatedAt;
    }

    public void setUpdatedAt (String updatedAt)
    {
        this.updatedAt = updatedAt;
    }
}
