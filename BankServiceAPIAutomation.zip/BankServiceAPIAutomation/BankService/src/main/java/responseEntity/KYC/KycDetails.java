package responseEntity.KYC;

import responseEntity.Mobile;
import responseEntity.Name;

public class KycDetails {
    private String createdAt = null;

    private String proofValue = null;

    private String dob = null;

    private String proofType = null;

    private String identityStatus = null;

    private Name name;

    private Mobile mobile;

    private String verifiedBy = null;

    private String updatedAt = null;

    public String getCreatedAt ()
    {
        return createdAt;
    }

    public void setCreatedAt (String createdAt)
    {
        this.createdAt = createdAt;
    }

    public String getProofValue ()
    {
        return proofValue;
    }

    public void setProofValue (String proofValue)
    {
        this.proofValue = proofValue;
    }

    public String getDob ()
    {
        return dob;
    }

    public void setDob (String dob)
    {
        this.dob = dob;
    }

    public String getProofType ()
    {
        return proofType;
    }

    public void setProofType (String proofType)
    {
        this.proofType = proofType;
    }

    public String getIdentityStatus ()
    {
        return identityStatus;
    }

    public void setIdentityStatus (String identityStatus)
    {
        this.identityStatus = identityStatus;
    }

    public Name getName ()
    {
        return name;
    }

    public void setName (Name name)
    {
        this.name = name;
    }

    public Mobile getMobile ()
    {
        return mobile;
    }

    public void setMobile (Mobile mobile)
    {
        this.mobile = mobile;
    }

    public String getVerifiedBy ()
    {
        return verifiedBy;
    }

    public void setVerifiedBy (String verifiedBy)
    {
        this.verifiedBy = verifiedBy;
    }

    public String getUpdatedAt ()
    {
        return updatedAt;
    }

    public void setUpdatedAt (String updatedAt)
    {
        this.updatedAt = updatedAt;
    }
}
