package responseEntity.KYC;

public class GetKycResponse {

    private KycDetails[] kycDetails;

    private String bankCustomerId = null;

    public KycDetails[] getKycDetails ()
    {
        return kycDetails;
    }

    public void setKycDetails (KycDetails[] kycDetails)
    {
        this.kycDetails = kycDetails;
    }

    public String getBankCustomerId ()
    {
        return bankCustomerId;
    }

    public void setBankCustomerId (String bankCustomerId)
    {
        this.bankCustomerId = bankCustomerId;
    }

}
