package responseEntity;

public class Statement {

    private String date = null;
    private String instrumentId = null;
    private String tranReportCode = null;
    private String tranParticulars = null;
    private String type = null;
    private String amount = null;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(String instrumentId) {
        this.instrumentId = instrumentId;
    }

    public String getTranReportCode() {
        return tranReportCode;
    }

    public void setTranReportCode(String tranReportCode) {
        this.tranReportCode = tranReportCode;
    }

    public String getTranParticulars() {
        return tranParticulars;
    }

    public void setTranParticulars(String tranParticulars) {
        this.tranParticulars = tranParticulars;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
