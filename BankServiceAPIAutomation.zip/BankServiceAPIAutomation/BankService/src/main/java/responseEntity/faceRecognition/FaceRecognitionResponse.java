package responseEntity.faceRecognition;

import com.fasterxml.jackson.annotation.JsonProperty;
import responseEntity.Error;
import responseEntity.FrAuthResponse;

public class FaceRecognitionResponse {

    private String status = null;
    private String bankCustomerId = null;
    private String authorizationCode = null;
    private FrAuthResponse frAuthResponse = new FrAuthResponse();
    @JsonProperty
    private boolean isAuthenticated = false;

    private Error error = new Error();

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBankCustomerId() {
        return bankCustomerId;
    }

    public void setBankCustomerId(String bankCustomerId) {
        this.bankCustomerId = bankCustomerId;
    }

    public String getAuthorizationCode() {
        return authorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }

    public FrAuthResponse getFrAuthResponse() {
        return frAuthResponse;
    }

    public void setFrAuthResponse(FrAuthResponse frAuthResponse) {
        this.frAuthResponse = frAuthResponse;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }
}
