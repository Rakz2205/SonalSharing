package responseEntity;

public class AccountsBalance {

    private String accountCategory = null;
    private String accountSubCategory = null;
    private String bankAccountNumber = null;
    private double availableBalance = 0;
    private double onHoldBalance = 0;
    private double currentBalance = 0;
    private String bankAccountId = null;

    public String getAccountCategory() {
        return accountCategory;
    }

    public void setAccountCategory(String accountCategory) {
        this.accountCategory = accountCategory;
    }

    public String getAccountSubCategory() {
        return accountSubCategory;
    }

    public void setAccountSubCategory(String accountSubCategory) {
        this.accountSubCategory = accountSubCategory;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public double getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(double availableBalance) {
        this.availableBalance = availableBalance;
    }

    public double getOnHoldBalance() {
        return onHoldBalance;
    }

    public void setOnHoldBalance(double onHoldBalance) {
        this.onHoldBalance = onHoldBalance;
    }

    public double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public String getBankAccountId() {
        return bankAccountId;
    }

    public void setBankAccountId(String bankAccountId) {
        this.bankAccountId = bankAccountId;
    }
}
