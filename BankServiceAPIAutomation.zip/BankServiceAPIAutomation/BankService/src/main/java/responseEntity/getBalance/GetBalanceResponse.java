package responseEntity.getBalance;

import responseEntity.AccountsBalance;

public class GetBalanceResponse {

    private AccountsBalance[] accountsBalance = null;
    private double totalBalance = 0;

    public AccountsBalance[] getAccountsBalance() {
        return accountsBalance;
    }

    public void setAccountsBalance(AccountsBalance[] accountsBalance) {
        this.accountsBalance = accountsBalance;
    }

    public double getTotalBalance() {
        return totalBalance;
    }

    public void setTotalBalance(double totalBalance) {
        this.totalBalance = totalBalance;
    }
}
