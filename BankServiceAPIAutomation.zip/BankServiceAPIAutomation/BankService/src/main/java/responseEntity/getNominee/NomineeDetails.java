package responseEntity.getNominee;

import com.fasterxml.jackson.annotation.JsonProperty;
import responseEntity.Address;
import responseEntity.Mobile;
import responseEntity.Name;

import java.util.List;

public class NomineeDetails {

    private String nomineeId = null;
    private Mobile mobile = new Mobile();
    private String relationship = null;
    private Name name = null;
    private String emailId = null;
    private String dob = null;
    private List<Address> address = null;
    private NomineeDetails guardian = null;
    @JsonProperty
    private boolean isMinor = false;

    public String getNomineeId() {
        return nomineeId;
    }

    public void setNomineeId(String nomineeId) {
        this.nomineeId = nomineeId;
    }

    public Mobile getMobile() {
        return mobile;
    }

    public void setMobile(Mobile mobile) {
        this.mobile = mobile;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public NomineeDetails getGuardian() {
        return guardian;
    }

    public void setGuardian(NomineeDetails guardian) {
        this.guardian = guardian;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public boolean isMinor() {
        return isMinor;
    }

    public void setMinor(boolean minor) {
        isMinor = minor;
    }
}
