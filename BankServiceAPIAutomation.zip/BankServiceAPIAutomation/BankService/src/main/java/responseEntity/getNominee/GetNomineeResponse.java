package responseEntity.getNominee;

import java.util.List;

public class GetNomineeResponse {
    private List<NomineeDetails> nominees;

    public List<NomineeDetails> getNominees() {
        return nominees;
    }
    public void setNominees(List<NomineeDetails> nominees) {
        this.nominees = nominees;
    }
}
