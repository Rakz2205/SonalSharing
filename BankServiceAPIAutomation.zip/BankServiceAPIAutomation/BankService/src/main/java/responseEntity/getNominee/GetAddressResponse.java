package responseEntity.getNominee;

import responseEntity.AddressDetails;

public class GetAddressResponse {

    private AddressDetails[] addressDetails = null;

    public AddressDetails[] getAddressDetails() {
        return addressDetails;
    }

    public void setAddressDetails(AddressDetails[] addressDetails) {
        this.addressDetails = addressDetails;
    }

    @Override
    public String toString() {
        return " [addressDetails = " + addressDetails + "]";
    }
}
