package responseEntity.getAccount;

public class AccountRestrictions {

    private String freezeStatus =null;

    public String getFreezeStatus ()
    {
        return freezeStatus;
    }

    public void setFreezeStatus (String freezeStatus)
    {
        this.freezeStatus = freezeStatus;
    }
}
