package responseEntity.getAccount;

public class LinkedCards {
    private String cardName = null;

    private String limit = null;

    private String type = null;

    private String cardNumber = null;

    private Status status;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getCardName ()
    {
        return cardName;
    }

    public void setCardName (String cardName)
    {
        this.cardName = cardName;
    }

    public String getLimit ()
    {
        return limit;
    }

    public void setLimit (String limit)
    {
        this.limit = limit;
    }

    public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

    public String getCardNumber ()
    {
        return cardNumber;
    }

    public void setCardNumber (String cardNumber)
    {
        this.cardNumber = cardNumber;
    }

}
