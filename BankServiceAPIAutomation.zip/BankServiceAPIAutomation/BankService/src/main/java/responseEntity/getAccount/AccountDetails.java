package responseEntity.getAccount;

import responseEntity.Name;

public class AccountDetails {

    private String accountStatus = null;

    private String bankIfsc = null;

    private AccountRestrictions accountRestrictions = new AccountRestrictions();

    private LinkedCards[] linkedCards = null;

    private String accountType = null;

    private String mmid = null;

    private Name accountHolderName = new Name();

    public Name getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(Name accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    private String bankName = null;

    private String accountNumber = null;

    //private AccountHolderName accountHolderName;

    public String getAccountStatus ()
    {
        return accountStatus;
    }

    public void setAccountStatus (String accountStatus)
    {
        this.accountStatus = accountStatus;
    }

    public String getBankIfsc ()
    {
        return bankIfsc;
    }

    public void setBankIfsc (String bankIfsc)
    {
        this.bankIfsc = bankIfsc;
    }

    public AccountRestrictions getAccountRestrictions ()
    {
        return accountRestrictions;
    }

    public void setAccountRestrictions (AccountRestrictions accountRestrictions)
    {
        this.accountRestrictions = accountRestrictions;
    }

    public LinkedCards[] getLinkedCards ()
    {
        return linkedCards;
    }

    public void setLinkedCards (LinkedCards[] linkedCards)
    {
        this.linkedCards = linkedCards;
    }

    public String getAccountType ()
    {
        return accountType;
    }

    public void setAccountType (String accountType)
    {
        this.accountType = accountType;
    }

    public String getMmid ()
    {
        return mmid;
    }

    public void setMmid (String mmid)
    {
        this.mmid = mmid;
    }

    public String getBankName ()
    {
        return bankName;
    }

    public void setBankName (String bankName)
    {
        this.bankName = bankName;
    }

    public String getAccountNumber ()
    {
        return accountNumber;
    }

    public void setAccountNumber (String accountNumber)
    {
        this.accountNumber = accountNumber;
    }

//    public AccountHolderName getAccountHolderName ()
//    {
//        return accountHolderName;
//    }
//
//    public void setAccountHolderName (AccountHolderName accountHolderName)
//    {
//        this.accountHolderName = accountHolderName;
//    }
}
