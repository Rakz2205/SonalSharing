package responseEntity.getAccount;

public class GetAccountResponse {

    private AccountDetails[] accountDetails = null;

    public AccountDetails[] getAccountDetails ()
    {
        return accountDetails;
    }

    public void setAccountDetails (AccountDetails[] accountDetails)
    {
        this.accountDetails = accountDetails;
    }
}
