package responseEntity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FrAuthResponse {

    @JsonProperty("match-score")
    private String match_score;

    public String getMatch_score() {
        return match_score;
    }

    public void setMatch_score(String match_score) {
        this.match_score = match_score;
    }
}
