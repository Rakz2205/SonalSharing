package responseEntity.errorEntity;

import responseEntity.Error;

public class ErrorResponse {

    Error error = new Error();
    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
