package responseEntity.eAuth;

import com.fasterxml.jackson.annotation.JsonProperty;
import responseEntity.Error;

public class EAuthResponse {

    private String status;
    @JsonProperty
    private boolean isAuthenticated;
    private Error error = new Error();

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
