package entity.virtualAccountManagement;

public class GetCurrentAccountEntity {

    private String virtualAccountNumber;

    public String getVirtualAccountNumber() {
        return virtualAccountNumber;
    }

    public void setVirtualAccountNumber(String virtualAccountNumber) {
        this.virtualAccountNumber = virtualAccountNumber;
    }
}
