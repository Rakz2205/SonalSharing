package entity.virtualAccountManagement;

public class SetVirtualAccountEntity {

    private String id;
    private int accountStatus;
    private String clientCode;
    private String virtualAccountNumber;
    private String customerCode;
    private String customerName;
    private String emailId1;
    private String emailId2;
    private String emailId3;
    private String emailId4;
    private String emailId5;
    private String productCode;
    private String productName;
    private String roCode;
    private String roName;
    private String customerMobileNumber1;
    private String customerMobileNumber2;
    private String customerMobileNumber3;
    private String customerMobileNumber4;
    private String customerMobileNumber5;

    private String createdBy;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(int accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getVirtualAccountNumber() {
        return virtualAccountNumber;
    }

    public void setVirtualAccountNumber(String virtualAccountNumber) {
        this.virtualAccountNumber = virtualAccountNumber;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmailId1() {
        return emailId1;
    }

    public void setEmailId1(String emailId1) {
        this.emailId1 = emailId1;
    }

    public String getEmailId2() {
        return emailId2;
    }

    public void setEmailId2(String emailId2) {
        this.emailId2 = emailId2;
    }

    public String getEmailId3() {
        return emailId3;
    }

    public void setEmailId3(String emailId3) {
        this.emailId3 = emailId3;
    }

    public String getEmailId4() {
        return emailId4;
    }

    public void setEmailId4(String emailId4) {
        this.emailId4 = emailId4;
    }

    public String getEmailId5() {
        return emailId5;
    }

    public void setEmailId5(String emailId5) {
        this.emailId5 = emailId5;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getRoCode() {
        return roCode;
    }

    public void setRoCode(String roCode) {
        this.roCode = roCode;
    }

    public String getRoName() {
        return roName;
    }

    public void setRoName(String roName) {
        this.roName = roName;
    }

    public String getCustomerMobileNumber1() {
        return customerMobileNumber1;
    }

    public void setCustomerMobileNumber1(String customerMobileNumber1) {
        this.customerMobileNumber1 = customerMobileNumber1;
    }

    public String getCustomerMobileNumber2() {
        return customerMobileNumber2;
    }

    public void setCustomerMobileNumber2(String customerMobileNumber2) {
        this.customerMobileNumber2 = customerMobileNumber2;
    }

    public String getCustomerMobileNumber3() {
        return customerMobileNumber3;
    }

    public void setCustomerMobileNumber3(String customerMobileNumber3) {
        this.customerMobileNumber3 = customerMobileNumber3;
    }

    public String getCustomerMobileNumber4() {
        return customerMobileNumber4;
    }

    public void setCustomerMobileNumber4(String customerMobileNumber4) {
        this.customerMobileNumber4 = customerMobileNumber4;
    }

    public String getCustomerMobileNumber5() {
        return customerMobileNumber5;
    }

    public void setCustomerMobileNumber5(String customerMobileNumber5) {
        this.customerMobileNumber5 = customerMobileNumber5;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
}
