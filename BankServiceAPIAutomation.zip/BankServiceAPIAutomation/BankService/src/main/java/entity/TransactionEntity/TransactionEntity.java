package entity.TransactionEntity;

import entity.Amount;
import entity.Transaction;
import entity.UserAccountDetails;

public class TransactionEntity {

    private Transaction transaction;
    private Amount amount = new Amount();
    private UserAccountDetails payer;
    private UserAccountDetails payee;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Amount getAmount() {
        return amount;
    }

    public void setAmount(Amount amount) {
        this.amount = amount;
    }

    public UserAccountDetails getPayer() {
        return payer;
    }

    public void setPayer(UserAccountDetails payer) {
        this.payer = payer;
    }

    public UserAccountDetails getPayee() {
        return payee;
    }

    public void setPayee(UserAccountDetails payee) {
        this.payee = payee;
    }
}