package entity;

public class AuthenticateList {

    private int mode;
    private String value;
    private String action;
    private String transactionRefNumber;
    private EAuthRequest eAuthRequest;

    public String getTransactionRefNumber() {
        return transactionRefNumber;
    }

    public void setTransactionRefNumber(String transactionRefNumber) {
        this.transactionRefNumber = transactionRefNumber;
    }

    public EAuthRequest geteAuthRequest() {
        return eAuthRequest;
    }

    public void seteAuthRequest(EAuthRequest eAuthRequest) {
        this.eAuthRequest = eAuthRequest;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
