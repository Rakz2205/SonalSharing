package entity;

public class DeviceInfo {

    private String dpId;
    private String rdsId;
    private String rdsVer;
    private String dc;
    private String mi;
    private String mc;

    public void setDpId(String dpId) {
        this.dpId = dpId;
    }

    public void setRdsId(String rdsId) {
        this.rdsId = rdsId;
    }

    public void setRdsVer(String rdsVer) {
        this.rdsVer = rdsVer;
    }

    public void setDc(String dc) {
        this.dc = dc;
    }

    public void setMi(String mi) {
        this.mi = mi;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }
}
