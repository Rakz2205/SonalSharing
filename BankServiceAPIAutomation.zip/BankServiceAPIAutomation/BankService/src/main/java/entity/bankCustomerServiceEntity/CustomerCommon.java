package entity.bankCustomerServiceEntity;

public class CustomerCommon {


}
