package entity.bankCustomerServiceEntity;

import entity.AuthenticateList;
import entity.User;

import java.util.List;

public class FaceRecognitionEntity extends CustomerCommon {

    private User user;
    private String scope;
    private List<AuthenticateList> authenticateList;

    public User getUser() {
        return user;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<AuthenticateList> getAuthenticateList() {
        return authenticateList;
    }

    public void setAuthenticateList(List<AuthenticateList> authenticateList) {
        this.authenticateList = authenticateList;
    }
}
