package entity.nodalAccount;

public class MerchantSettlementDetails {

    private String merchantName;
    private String merchantSettlementAccountNumber;
    private String merchantSettlementIFSCNumber;
    private String settlementAmount;
    private String dateOfSettlement;
    private String nodalAccountNumber;
    private String settlementBatchId;
    private String settlementIdentifier;
    private String merchantId;
    private String bankTransactionId;
    private String payoutTransactionId;
    private String transactionStatus;
    private String statusReason;
    private String type;
    private String subType;
    private String utrNumber;


    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantSettlementAccountNumber() {
        return merchantSettlementAccountNumber;
    }

    public void setMerchantSettlementAccountNumber(String merchantSettlementAccountNumber) {
        this.merchantSettlementAccountNumber = merchantSettlementAccountNumber;
    }

    public String getMerchantSettlementIFSCNumber() {
        return merchantSettlementIFSCNumber;
    }

    public void setMerchantSettlementIFSCNumber(String merchantSettlementIFSCNumber) {
        this.merchantSettlementIFSCNumber = merchantSettlementIFSCNumber;
    }

    public String getSettlementAmount() {
        return settlementAmount;
    }

    public void setSettlementAmount(String settlementAmount) {
        this.settlementAmount = settlementAmount;
    }

    public String getDateOfSettlement() {
        return dateOfSettlement;
    }

    public void setDateOfSettlement(String dateOfSettlement) {
        this.dateOfSettlement = dateOfSettlement;
    }

    public String getNodalAccountNumber() {
        return nodalAccountNumber;
    }

    public void setNodalAccountNumber(String nodalAccountNumber) {
        this.nodalAccountNumber = nodalAccountNumber;
    }

    public String getSettlementBatchId() {
        return settlementBatchId;
    }

    public void setSettlementBatchId(String settlementBatchId) {
        this.settlementBatchId = settlementBatchId;
    }

    public String getSettlementIdentifier() {
        return settlementIdentifier;
    }

    public void setSettlementIdentifier(String settlementIdentifier) {
        this.settlementIdentifier = settlementIdentifier;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getBankTransactionId() {
        return bankTransactionId;
    }

    public void setBankTransactionId(String bankTransactionId) {
        this.bankTransactionId = bankTransactionId;
    }

    public String getPayoutTransactionId() {
        return payoutTransactionId;
    }

    public void setPayoutTransactionId(String payoutTransactionId) {
        this.payoutTransactionId = payoutTransactionId;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getUtrNumber() {
        return utrNumber;
    }

    public void setUtrNumber(String utrNumber) {
        this.utrNumber = utrNumber;
    }

    public String getStatusReason() {
        return statusReason;
    }

    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }

}
