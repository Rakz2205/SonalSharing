package entity.customerEntity;

import java.util.ArrayList;
import java.util.List;

public class GetKycEntity extends CustomerCommon {

    private List<String> metaData = new ArrayList<>();
    private String responseType;

    public String getResponseType() {
        return responseType;
    }

    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }

    public List<String> getMetaData() {
        return metaData;
    }

    public void setMetaData(List<String> metaData) {
        this.metaData = metaData;
    }
}
