package entity.customerEntity;

import java.util.ArrayList;
import java.util.List;

public class GetAddressEntity extends CustomerCommon {

    private List<Integer> addressType = new ArrayList<>();

    public List<Integer> getAddressType() {
        return addressType;
    }

    public void setAddressType(List<Integer> metaData) {
        this.addressType = metaData;
    }
}