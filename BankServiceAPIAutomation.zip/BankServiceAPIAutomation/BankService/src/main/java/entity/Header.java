package entity;

import java.util.HashMap;
import java.util.Map;

public class Header {

    private static Map<String, String> mapHeader;

    public static Map<String, String> getHeader(String serviceType) {
        mapHeader = new HashMap<>();
        mapHeader.put("Content-Type", "application/json");

        try {
            switch (serviceType) {
                case "Transaction":

                    break;
                case "NonTransaction":

                    break;
                case "Authentication":
                    break;
                default:
                    throw new Exception("please enter the correct service type. Service type is : " + serviceType);
            }

            return mapHeader;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public Map<String, String> getInvalidHeader(String serviceType) {
        mapHeader = new HashMap<String, String>();

        try {
            switch (serviceType) {
                case "Transaction":
                    mapHeader.put("X-CHANNEL-ID", null);

                    break;
                case "NonTransaction":
                    break;
                case "Authentication":
                    break;
                default:
                    throw new Exception("please enter the correct service type. Service type is : " + serviceType);
            }

            return mapHeader;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}
