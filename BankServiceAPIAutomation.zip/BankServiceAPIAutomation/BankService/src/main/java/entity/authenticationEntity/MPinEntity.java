package entity.authenticationEntity;

import entity.Secure;
import entity.User;
import entity.Validations;

public class MPinEntity {
    private User user;
    private Validations validations;
    private String credentialType;
    private String credentialValue;
    private String oldCredentialValue;
    private Secure secure;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Validations getValidations() {
        return validations;
    }

    public void setValidations(Validations validations) {
        this.validations = validations;
    }

    public String getCredentialType() {
        return credentialType;
    }

    public void setCredentialType(String credentialType) {
        this.credentialType = credentialType;
    }

    public String getCredentialValue() {
        return credentialValue;
    }

    public void setCredentialValue(String credentialValue) {
        this.credentialValue = credentialValue;
    }

    public String getOldCredentialValue() {
        return oldCredentialValue;
    }

    public void setOldCredentialValue(String oldCredentialValue) {
        this.oldCredentialValue = oldCredentialValue;
    }

    public Secure getSecure() {
        return secure;
    }

    public void setSecure(Secure secure) {
        this.secure = secure;
    }
}
