package entity.authenticationEntity;

public class AuthorizationCodeEntity {

    private String bankCustomerID;
    private String authenticationMode;
    private String authorizationCode;
    private String authenticationScope;
    private int authenticationPurpose;
    private String extraInfo;

    public String getBankCustomerID() {
        return bankCustomerID;
    }

    public void setBankCustomerID(String bankCustomerID) {
        this.bankCustomerID = bankCustomerID;
    }

    public String getAuthenticationMode() {
        return authenticationMode;
    }

    public void setAuthenticationMode(String authenticationMode) {
        this.authenticationMode = authenticationMode;
    }

    public String getAuthorizationCode() {
        return authorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }

    public String getAuthenticationScope() {
        return authenticationScope;
    }

    public void setAuthenticationScope(String authenticationScope) {
        this.authenticationScope = authenticationScope;
    }

    public int getAuthenticationPurpose() {
        return authenticationPurpose;
    }

    public void setAuthenticationPurpose(int authenticationPurpose) {
        this.authenticationPurpose = authenticationPurpose;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }
}
