package entity.authenticationEntity;

import entity.AuthenticateList;
import entity.Secure;
import entity.User;

import java.util.List;

public class AuthenticateCredentialEntity {

    private User user;
    private String scope;
    private String encryptionKey;
    private List<AuthenticateList> authenticateList;
    private Secure secure;
    private int purpose;
    private String extraInfo;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getEncryptionKey() {
        return encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }

    public List<AuthenticateList> getAuthenticateList() {
        return authenticateList;
    }

    public void setAuthenticateList(List<AuthenticateList> authenticateList) {
        this.authenticateList = authenticateList;
    }

    public Secure getSecure() {
        return secure;
    }

    public void setSecure(Secure secure) {
        this.secure = secure;
    }

    public int getPurpose() {
        return purpose;
    }

    public void setPurpose(int purpose) {
        this.purpose = purpose;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }
}
