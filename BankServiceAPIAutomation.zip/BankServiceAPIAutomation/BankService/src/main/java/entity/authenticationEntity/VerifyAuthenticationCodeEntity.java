package entity.authenticationEntity;

import entity.AuthorizationCode;

import java.util.List;

public class VerifyAuthenticationCodeEntity {
    private String bankCustomerID;
    private List<AuthorizationCode> authorizationCode;
    private String authorizationScope;
    private String bankAccountNumber;

    public String getBankCustomerID() {
        return bankCustomerID;
    }

    public void setBankCustomerID(String bankCustomerID) {
        this.bankCustomerID = bankCustomerID;
    }

    public List<AuthorizationCode> getAuthorizationCode() {
        return authorizationCode;
    }

    public void setAuthorizationCode(List<AuthorizationCode> authorizationCode) {
        this.authorizationCode = authorizationCode;
    }

    public String getAuthorizationScope() {
        return authorizationScope;
    }

    public void setAuthorizationScope(String authorizationScope) {
        this.authorizationScope = authorizationScope;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }
}
