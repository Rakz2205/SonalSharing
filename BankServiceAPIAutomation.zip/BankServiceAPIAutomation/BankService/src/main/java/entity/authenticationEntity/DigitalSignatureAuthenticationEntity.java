package entity.authenticationEntity;

import entity.Secure;

public class DigitalSignatureAuthenticationEntity {

    private Object payload;
    private Secure secure;

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public Secure getSecure() {
        return secure;
    }

    public void setSecure(Secure secure) {
        this.secure = secure;
    }
}
