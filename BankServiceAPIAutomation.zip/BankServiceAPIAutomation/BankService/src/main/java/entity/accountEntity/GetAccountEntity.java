package entity.accountEntity;

import entity.customerEntity.CustomerCommon;

import java.util.ArrayList;
import java.util.List;

public class GetAccountEntity extends CustomerCommon {

    private List<String> metaData = new ArrayList<>();
    private String responseType;
    //private int restrictionType;

//    public int getRestrictionType() {
//        return restrictionType;
//    }
//
//    public void setRestrictionType(int restrictionType) {
//        this.restrictionType = restrictionType;
//    }

    public String getResponseType() {
        return responseType;
    }

    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }

    public List<String> getMetaData() {
        return metaData;
    }

    public void setMetaData(List<String> metaData) {
        this.metaData = metaData;
    }
}
