package entity;

public class Validations {

    private int type;
    private String otp;
    private String dateOfBirth;
    private String otpAuthCode;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getOtpAuthCode() {
        return otpAuthCode;
    }

    public void setOtpAuthCode(String otpAuthCode) {
        this.otpAuthCode = otpAuthCode;
    }
}
