package entity;

public class CaptureResponse {

        private String iCount;
        private String PidDatatype;
        private String rdsID;
        private String nmPoin;
        private String errInfo;
        private String iType;
        private String ver;
        private String rc;
        private String dpID;
        private String mc;
        private String sessionKey;
        private String tid;
        private String mi;
        private String dc;
        private String consent;
        private String errCode;
        private String qScore;
        private String saTxn;
        private String pCount;
        private String fCount;
        private String hmac;
        private String sa;
        private String ci;
        private String appCode;
        private String rdsVer;
        private String pType;
        private String Piddata;
        private String fType;

        public void setiCount(String iCount) {
                this.iCount = iCount;
        }

        public void setPidDatatype(String pidDatatype) {
                PidDatatype = pidDatatype;
        }

        public void setRdsID(String rdsID) {
                this.rdsID = rdsID;
        }

        public void setNmPoin(String nmPoin) {
                this.nmPoin = nmPoin;
        }

        public void setErrInfo(String errInfo) {
                this.errInfo = errInfo;
        }

        public void setiType(String iType) {
                this.iType = iType;
        }

        public void setVer(String ver) {
                this.ver = ver;
        }

        public void setRc(String rc) {
                this.rc = rc;
        }

        public void setDpID(String dpID) {
                this.dpID = dpID;
        }

        public void setMc(String mc) {
                this.mc = mc;
        }

        public void setSessionKey(String sessionKey) {
                this.sessionKey = sessionKey;
        }

        public void setTid(String tid) {
                this.tid = tid;
        }

        public void setMi(String mi) {
                this.mi = mi;
        }

        public void setDc(String dc) {
                this.dc = dc;
        }

        public void setConsent(String consent) {
                this.consent = consent;
        }

        public void setErrCode(String errCode) {
                this.errCode = errCode;
        }

        public void setqScore(String qScore) {
                this.qScore = qScore;
        }

        public void setSaTxn(String saTxn) {
                this.saTxn = saTxn;
        }

        public void setpCount(String pCount) {
                this.pCount = pCount;
        }

        public void setfCount(String fCount) {
                this.fCount = fCount;
        }

        public void setHmac(String hmac) {
                this.hmac = hmac;
        }

        public void setSa(String sa) {
                this.sa = sa;
        }

        public void setCi(String ci) {
                this.ci = ci;
        }

        public void setAppCode(String appCode) {
                this.appCode = appCode;
        }

        public void setRdsVer(String rdsVer) {
                this.rdsVer = rdsVer;
        }

        public void setpType(String pType) {
                this.pType = pType;
        }

        public void setPiddata(String piddata) {
                Piddata = piddata;
        }

        public void setfType(String fType) {
                this.fType = fType;
        }
}
