package entity;

public class EAuthRequest {

    private String aadhaarToken;
    private String consent;
    private String appCode;
    private String transactionRefNumber;
    private CaptureResponse captureResponse;
    private DeviceInfo deviceInfo;

    public void setAadhaarToken(String aadhaarToken) {
        this.aadhaarToken = aadhaarToken;
    }

    public void setConsent(String consent) {
        this.consent = consent;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public void setTransactionRefNumber(String transactionRefNumber) {
        this.transactionRefNumber = transactionRefNumber;
    }

    public void setCaptureResponse(CaptureResponse captureResponse) {
        this.captureResponse = captureResponse;
    }

    public void setDeviceInfo(DeviceInfo deviceInfo) {
        this.deviceInfo = deviceInfo;
    }
}
