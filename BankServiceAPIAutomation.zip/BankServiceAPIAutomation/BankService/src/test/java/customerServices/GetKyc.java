package customerServices;

import base.ConnectionSetup;
import client.customer.GetKycBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetKyc extends GetKycBL {

    @Test(dataProvider = "TestDataProvider")
    public void testGetKyc(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetKyc.class, (String) testData.get("TestDescription"));

        //  create get KYC payload
        String payload = createGetKycPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetKycHeader(testData);

        //  post getCustomer request
        Response getKycResponse = postGetKyc(payload, header);

        // validate api status code
        validateGetKycResponseStatus(getKycResponse, HttpStatus.SC_OK);

        // validate api response
        validateGetKycResponse(getKycResponse, testData);

    }
    @DataProvider(name = "TestDataProvider")
    public Object[][] test_data_provider() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetKyc", "getKyc");
    }

    @Test(dataProvider = "TestDataProviderGetKycNegativeCase")
    public void testGetKycNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetKyc.class, (String) testData.get("TestDescription"));

        //  create get KYC payload
        String payload = createGetKycPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetKycHeader(testData);

        //  post getCustomer request
        Response getKycResponse = postGetKyc(payload, header);

        // validate api status code
        validateGetKycResponseStatus(getKycResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetKycNegativeCase")
    public Object[][] TestDataProviderGetKycNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetKyc", "getKyc_Negative");
    }

    /*
    * Validate PAN card pattern for a given customer
    * */
    @Test(dataProvider = "GetKycPanDetails")
    public void testGetKycPanDetails(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetKyc.class, (String) testData.get("TestDescription"));

        //  create get KYC payload
        String payload = createGetKycPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetKycHeader(testData);

        //  post getCustomer request
        Response getKycResponse = postGetKyc(payload, header);

        // validate api status code
        validateGetKycResponseStatus(getKycResponse, HttpStatus.SC_OK);

        // validate PAN card Number
        validateGetKycPanNumber(getKycResponse, testData);

    }

    @DataProvider(name = "GetKycPanDetails")
    public Object[][] GetKycPanDetails() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetKyc", "getKyc_Pan_Details");
    }

    /*
     * Validate DOB in various IDENTITY_TYPE provided by a given customer
     * */
//    @Test(dataProvider = "TestDataProvider")
//    public void testGetKycVerifyDob(Map<Object, Object> testData) {
//
//        Reporter.initiateTestReport(GetKyc.class, (String) testData.get("TestDescription"));
//
//        //  create get KYC payload
//        String payload = createGetKycPayload(testData);
//
//        //  set header for non transaction services
//        Map<String, String> header = setGetKycHeader(testData);
//
//        //  post getCustomer request
//        Response getKycResponse = postGetKyc(payload, header);
//
//        // validate api status code
//        validateGetKycResponseStatus(getKycResponse, HttpStatus.SC_OK);
//
//        // validate PAN card Number
//        validateGetKycDob(getKycResponse, testData);
//    }


    /*
     * Verify response is empty if incorrect params are set in metadata while using CUSTOM response type
     * */

    @Test(dataProvider = "TestDataIncorrectCustomMataData")
    public void testGetKycIncorrectMataData(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetKyc.class, (String) testData.get("TestDescription"));

        //  create get KYC payload
        String payload = createGetKycPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetKycHeader(testData);

        //  post getCustomer request
        Response getKycResponse = postGetKyc(payload, header);

        validateKycDetailsIsNull(getKycResponse);

    }

    @DataProvider(name = "TestDataIncorrectCustomMataData")
    public Object[][] TestDataIncorrectCustomMataData() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetKyc", "incorrect_custom_MetaData");
    }


    @BeforeMethod
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
