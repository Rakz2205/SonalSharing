package customerServices;

import base.ConnectionSetup;
import client.customer.GetCustomerBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetCustomer extends GetCustomerBL {

    @Test(dataProvider = "TestDataProvider", groups = {"sanity", "All"})
    public void testGetCustomer(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetCustomer.class, (String) testData.get("TestDescription"));

        //  create get customer payload
        String payload = createGetCustomerPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetCustomerHeader(testData);

        //  post getCustomer request
        Response getCustomerResponse = postGetCustomer(payload, header);

        // validate api status code
        validateGetCustomerResponseStatus(getCustomerResponse, HttpStatus.SC_OK);

        //  validate getCustomer response
        validateGetCustomerResponse(getCustomerResponse, testData);

    }

    @DataProvider(name = "TestDataProvider")
    public Object[][] test_data_provider() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetCustomer", "getCustomer");
    }

    @Test(dataProvider = "TestDataProviderGetCustomerNegativeCase")
    public void testGetCustomerNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetCustomer.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetCustomerPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetCustomerHeader(testData);

        //  post request
        Response getAddressResponse = postGetCustomer(payload, header);

        // validate api status code
        validateGetCustomerResponseStatus(getAddressResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetCustomerNegativeCase")
    public Object[][] TestDataProviderGetCustomerNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetCustomer", "getCustomer_Negative");
    }

    @BeforeMethod(groups = {"sanity", "All"})
    public void beforeSetup() {
        boolean isConnected = false;
        for(int i =0; i<10; i++){
            try{
                if(!isConnected){
                    ConnectionSetup.createTestConnections();
                    isConnected=true;
                }
            }catch (RuntimeException e){
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"sanity", "All"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
