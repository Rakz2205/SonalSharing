package customerServices;

import base.ConnectionSetup;
import client.customer.GetNomineeBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetNominee extends GetNomineeBL {

    @Test(dataProvider = "TestDataProviderGetNominee")
    public void testGetNominee(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetNominee.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetNomineePayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetNomineeHeader(testData);

        //  post request
        Response getNomineeResponse = postGetNominee(payload, header);

        // validate api status code
        validateGetNomineeResponseStatus(getNomineeResponse, HttpStatus.SC_OK);

        //  validate get address response
        validateGetNomineeResponse(getNomineeResponse, testData);
    }

    @DataProvider(name = "TestDataProviderGetNominee")
    public Object[][] testDataProviderGetAddress() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetNominee", "getNominee");
    }

    @Test(dataProvider = "TestDataProviderGetNomineeNegativeCase")
    public void testGetAddressNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetNominee.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetNomineePayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetNomineeHeader(testData);

        //  post request
        Response getAddressResponse = postGetNominee(payload, header);

        // validate api status code
        validateGetNomineeResponseStatus(getAddressResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetNomineeNegativeCase")
    public Object[][] testDataProviderGetAddressNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetNominee", "getNominee_Negative");
    }

    @BeforeMethod
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
