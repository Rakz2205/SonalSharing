package customerServices;

import base.ConnectionSetup;
import client.customer.GetAddressBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetAddress extends GetAddressBL {

    @Test(dataProvider = "TestDataProviderGetAddress", groups = {"sanity", "All"})
    public void testGetAddress(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetAddress.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetAddressPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetAddressHeader(testData);

        //  post request
        Response getAddressResponse = postGetAddress(payload, header);

        // validate api status code
        validateGetAddressResponseStatus(getAddressResponse, HttpStatus.SC_OK);

        //  validate get address response
        validateGetAddressResponse(getAddressResponse, testData);
    }

    @DataProvider(name = "TestDataProviderGetAddress")
    public Object[][] testDataProviderGetAddress() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetAddress", "getAddress");
    }

    @Test(dataProvider = "TestDataProviderGetAddressNegativeCase")
    public void testGetAddressNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetAddress.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetAddressPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetAddressHeader(testData);

        //  post request
        Response getAddressResponse = postGetAddress(payload, header);

        // validate api status code
        validateGetAddressResponseStatus(getAddressResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetAddressNegativeCase")
    public Object[][] testDataProviderGetAddressNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetAddress", "getAddress_Negative");
    }

    @BeforeMethod(groups = {"sanity", "All"})
    public void beforeSetup() {
        boolean isConnected = false;
        for(int i =0; i<10; i++){
            try{
                if(!isConnected){
                    ConnectionSetup.createTestConnections();
                    isConnected=true;
                }
            }catch (RuntimeException e){
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"sanity", "All"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
