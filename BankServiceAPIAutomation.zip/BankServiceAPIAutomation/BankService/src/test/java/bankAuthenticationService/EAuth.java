package bankAuthenticationService;

import client.EAuthBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class EAuth extends EAuthBL {

    @Test(dataProvider = "TestDataProviderEAuth_Positive_200")
    public void testEAuth_Positive_200(Map<String, String> testData) {
        Reporter.initiateTestReport(EAuth.class, testData.get("TestDescription").toString());
        String payload = createEAuthPayload(testData);
        Map<String, String> header = setEAuthHeader(testData);
        Response eAuthResponse = postEAuth(payload, header);
        validateEAuthResponseStatus(eAuthResponse, HttpStatus.SC_OK);
        validateEAuthResponse(eAuthResponse, testData);

    }

    @DataProvider(name = "TestDataProviderEAuth_Positive_200")
    public Object[][] TestDataProviderEAuth_Positive_200() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "eAuth", "eAuth_Positive_200");
    }


    @Test(dataProvider = "TestDataProviderEAuth_Negative_400")
    public void testEAuth_Negative_400(Map<String, String> testData) {
        Reporter.initiateTestReport(EAuth.class, testData.get("TestDescription").toString());
        String payload = createEAuthPayload(testData);
        Map<String, String> header = setEAuthHeader(testData);
        Response eAuthResponse = postEAuth(payload, header);
        validateEAuthResponseStatus(eAuthResponse, HttpStatus.SC_BAD_REQUEST);
        validateEAuthResponse(eAuthResponse, testData);
    }

    @DataProvider(name = "TestDataProviderEAuth_Negative_400")
    public Object[][] TestDataProviderEAuth_Negative_400() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "eAuth", "eAuth_Negative_400");
    }

    @Test(dataProvider = "TestDataProviderEAuth_Negative_401")
    public void testEAuth_Negative_401(Map<String, String> testData) {
        Reporter.initiateTestReport(EAuth.class, testData.get("TestDescription").toString());
        String payload = createEAuthPayload(testData);
        Map<String, String> header = setEAuthHeader(testData);
        Response eAuthResponse = postEAuth(payload, header);
        validateEAuthResponseStatus(eAuthResponse, HttpStatus.SC_UNAUTHORIZED);
        validateEAuthResponse(eAuthResponse, testData);
    }

    @DataProvider(name = "TestDataProviderEAuth_Negative_401")
    public Object[][] TestDataProviderEAuth_Negative_401() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "eAuth", "eAuth_Negative_401");
    }


    @BeforeMethod
    public void beforeSetup() {
        //ConnectionSetup.createTestConnections();
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        //  ConnectionSetup.closeTestConnections();
    }

}
