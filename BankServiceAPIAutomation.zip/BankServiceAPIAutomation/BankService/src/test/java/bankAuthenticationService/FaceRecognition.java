package bankAuthenticationService;

import client.FaceRecognitionBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.utilities.fileUtils.ExcelUtility;
import utils.Reporter;

import java.util.Map;

public class FaceRecognition extends FaceRecognitionBL {

    @Test(dataProvider="TestDataProviderFaceRecognition_Positive_200")
    public void testFaceRecognition_positive(Map<Object, Object> testData) {
        Reporter.initiateTestReport(FaceRecognition.class, testData.get("TestDescription").toString());
        String payload = createFaceRecognitionPayload(testData);
        Map<String, String> header = setFaceRecognitionHeader(testData);
        Response faceRecognitionResponse = postFaceRecognition(payload, header);
        validateFaceRecognitionResponseStatus(faceRecognitionResponse, HttpStatus.SC_OK);
        validateFaceRecognitionResponse(faceRecognitionResponse, testData);
    }

    @DataProvider(name = "TestDataProviderFaceRecognition_Positive_200")
    public Object[][] TestDataProviderFaceRecognition() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "FaceRecognition", "faceRecognition_Positive");
    }


    @Test(dataProvider = "TestDataProviderFaceRecognitionNegativeCase_200")
    public void testFaceRecognitionNegativeCase_200(Map<Object, Object> testData){
        Reporter.initiateTestReport(FaceRecognition.class, testData.get("TestDescription").toString());
        String payload = createFaceRecognitionPayload(testData);
        Map<String, String> header = setFaceRecognitionHeader(testData);
        Response faceRecognitionResponse = postFaceRecognition(payload, header);
        validateFaceRecognitionResponseStatus(faceRecognitionResponse, HttpStatus.SC_OK);
        validateFaceRecognitionResponse(faceRecognitionResponse, testData);
    }

    @DataProvider(name = "TestDataProviderFaceRecognitionNegativeCase_200")
    public Object[][] TestDataProviderFaceRecognitionNegativeCase_200() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "FaceRecognition", "faceRecognition_Negative_200");
    }


    @Test(dataProvider = "TestDataProviderFaceRecognitionNegativeCase_400")
    public void testFaceRecognitionNegativeCase_400(Map<Object, Object> testData) {
        Reporter.initiateTestReport(FaceRecognition.class, testData.get("TestDescription").toString());
        String payload = createFaceRecognitionPayload(testData);
        Map<String, String> header = setFaceRecognitionHeader(testData);
        Response faceRecognitionResponse = postFaceRecognition(payload, header);
        validateFaceRecognitionResponseStatus(faceRecognitionResponse, HttpStatus.SC_BAD_REQUEST);
        validateFaceRecognitionResponse(faceRecognitionResponse, testData);
    }

    @DataProvider(name = "TestDataProviderFaceRecognitionNegativeCase_400")
    public Object[][] TestDataProviderFaceRecognitionNegativeCase_400() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "FaceRecognition", "faceRecognition_Negative_400");
    }


    @Test(dataProvider = "TestDataProviderFaceRecognitionNegativeCase_401")
    public void testFaceRecognitionNegativeCase_401(Map<Object, Object> testData) {
        utils.Reporter.initiateTestReport(FaceRecognition.class, testData.get("TestDescription").toString());
        String payload = createFaceRecognitionPayload(testData);
        Map<String, String> header = setFaceRecognitionHeader(testData);
        Response faceRecognitionResponse = postFaceRecognition(payload, header);
        validateFaceRecognitionResponseStatus(faceRecognitionResponse, HttpStatus.SC_UNAUTHORIZED);
        validateFaceRecognitionResponse(faceRecognitionResponse, testData);
    }

    @DataProvider(name = "TestDataProviderFaceRecognitionNegativeCase_401")
    public Object[][] TestDataProviderFaceRecognitionNegativeCase_401() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "FaceRecognition", "faceRecognition_Negative_401");
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);

    }

}
