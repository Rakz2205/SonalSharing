package accountService;

import base.ConnectionSetup;
import client.account.GetBalanceBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.util.Map;

public class GetBalance extends GetBalanceBL {

    @Test(dataProvider = "TestDataProviderGetBalance", groups = {"AEPS", "sanity", "All"})
    public void testGetBalance(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetBalance.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetBalancePayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetBalanceHeader(testData);

        //  post request
        Response getBalanceResponse = postGetBalance(payload, header);

        //  validate response time
        CommonMethods.validateAPIsTimeout(getBalanceResponse, 15000);

        // validate api status code
        validateGetBalanceResponseStatus(getBalanceResponse, HttpStatus.SC_OK);

        //  validate get balance response
        validateGetBalanceResponse(getBalanceResponse, (String) testData.get("AccountNumber"));

        /*//  post old request
        Response getBalanceResponseOld = getBalanceOld(testData);

        // validate api status code
        validateGetBalanceResponseStatus(getBalanceResponseOld, HttpStatus.SC_OK);

        //  validate get balance response
        validateGetBalanceResponse(getBalanceResponse, getBalanceResponseOld);*/
    }

    @DataProvider(name = "TestDataProviderGetBalance")
    public Object[][] testDataProviderGetBalance() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetBalance", "getBalance");
    }

    @Test(dataProvider = "TestDataProviderGetBalanceNegativeCase")
    public void testGetBalanceNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetBalance.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetBalancePayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetBalanceHeader(testData);

        //  post request
        Response getBalanceResponse = postGetBalance(payload, header);

        // validate api status code
        validateGetBalanceResponseStatus(getBalanceResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetBalanceNegativeCase")
    public Object[][] testDataProviderGetAddressNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetBalance", "getBalance_Negative");
    }

    @BeforeMethod(groups = {"AEPS", "All", "sanity"})
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"AEPS", "All", "sanity"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
