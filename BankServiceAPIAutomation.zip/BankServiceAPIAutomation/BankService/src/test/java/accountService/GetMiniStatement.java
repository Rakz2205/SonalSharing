package accountService;

import base.ConnectionSetup;
import client.account.GetMiniStatementBL;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetMiniStatement extends GetMiniStatementBL {

    @Test(dataProvider = "TestDataProviderGetMiniStatement")
    public void testGetMiniStatement(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetMiniStatement.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetMiniStatementPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetMiniStatementHeader(testData);

        //  post request
        Response getMiniStatementResponse = postGetMiniStatement(payload, header);

        // validate api status code
        validateGetMiniStatementResponseStatus(getMiniStatementResponse, HttpStatus.SC_OK);

        //  validate get address response
        //validateGetMiniStatementResponse(GetMiniStatementResponse, (String) testData.get("AccountNumber"));

        //  post old request
        //Response getMiniStatementResponseOld = getMiniStatementOld(testData);

        // validate api status code
        //validateGetMiniStatementResponseStatus(getMiniStatementResponseOld, HttpStatus.SC_OK);

        //  validate get address response
        //  validateGetMiniStatementResponse(getMiniStatementResponse, getMiniStatementResponseOld, (String) testData.get("AccountNumber"));
    }

    @DataProvider(name = "TestDataProviderGetMiniStatement")
    public Object[][] testDataProviderGetBalance() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetMiniStatement", "getMiniStatement");
    }

    @Test(dataProvider = "TestDataProviderGetMiniStatementNegativeCase")
    public void testGetMiniStatementNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetMiniStatement.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetMiniStatementPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetMiniStatementHeader(testData);

        //  post request
        Response getMiniStatementResponse = postGetMiniStatement(payload, header);

        // validate api status code
        validateGetMiniStatementResponseStatus(getMiniStatementResponse, HttpStatus.SC_BAD_REQUEST);

    }

    @DataProvider(name = "TestDataProviderGetMiniStatementNegativeCase")
    public Object[][] testDataProviderGetAddressNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetMiniStatement", "getMiniStatement_Negative");
    }

    @BeforeMethod
    public void beforeSetup() {
        boolean isConnected = false;
        for(int i =0; i<10; i++){
            try{
                if(!isConnected){
                    ConnectionSetup.createTestConnections();
                    isConnected=true;
                }
            }catch (RuntimeException e){
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
