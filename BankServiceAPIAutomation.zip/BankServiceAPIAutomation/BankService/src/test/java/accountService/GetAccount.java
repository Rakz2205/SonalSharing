package accountService;

import base.ConnectionSetup;
import client.account.GetAccountBL;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.fileUtils.ExcelUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.HashMap;
import java.util.Map;

public class GetAccount extends GetAccountBL {

    @Test(dataProvider = "TestDataProviderGetAccount", groups = {"sanity", "eNach", "All"})
    public void testGetAccount(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetAccount.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetAccountPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetAccountHeader(testData);

        //  post request
        Response getAccountResponse = postGetAccount(payload, header);

        // validate api status code
        validateGetAccountResponseStatus(getAccountResponse, HttpStatus.SC_OK);

        //  validate getAccount response
        validateGetAccountResponse(getAccountResponse, testData);
    }

    @DataProvider(name = "TestDataProviderGetAccount")
    public Object[][] TestDataProviderGetAccount() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetAccount", "getAccount");
    }

    @Test(dataProvider = "TestDataProviderGetAccountNegativeCase", groups = {"eNach", "All"})
    public void testGetAccountNegativeCase(Map<Object, Object> testData) {

        Reporter.initiateTestReport(GetAccount.class, (String) testData.get("TestDescription"));

        //  create get address payload
        String payload = createGetAccountPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setGetAccountHeader(testData);

        //  post request
        Response getBalanceResponse = postGetAccount(payload, header);

        // validate api status code
        validateGetAccountResponseStatus(getBalanceResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

    }

    @DataProvider(name = "TestDataProviderGetAccountNegativeCase")
    public Object[][] TestDataProviderGetAccountNegativeCase() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "GetAccount", "getAccount_Negative");
    }

    /*
    * Validate for a blocked account, account Closed Details are present.
    * */
    @Test(dataProvider = "GetBlockedAccount", groups = {"sanity", "eNach", "All"})
    public void testGetBlockedAccount(Map<Object, Object> testdata) {

        Reporter.initiateTestReport(GetAccount.class, "Validate for a blocked account, account Closed Details are present");

        String profileId= testdata.get("PROFILE_ID").toString();

        //  create get address payload
        String payload = createAccountPayloadUsingProfileID(profileId);

        //  set header for non transaction services
        Map<String, String> header = getDefaultHeader();

        //  post request
        Response getAccountResponse = postGetAccount(payload, header);

        // validate api status code
        validateGetAccountResponseStatus(getAccountResponse, HttpStatus.SC_OK);

        //  validate getAccount response
        validateBlockedAccountResponse(getAccountResponse, profileId);
    }

    @DataProvider(name = "GetBlockedAccount")
    public Object[][] GetBlockedAccount() {
        ConnectionSetup.createTestConnections();
        String query = "SELECT profile_id FROM profile WHERE account_id in (SELECT account_id FROM BANK_DETAILS WHERE ACCOUNT_ID IN (SELECT ACCOUNT_ID FROM ACCOUNT WHERE STATE='BLOCKED' AND BANK_NAME='JIO Payments Bank')) AND ROWNUM <= 3";
        return DataBaseUtility.getDatabaseDataProvider(dbBankService, query);
    }

    @BeforeMethod(groups = {"sanity", "All", "eNach"})
    public void beforeSetup() {
        boolean isConnected = false;
        for(int i =0; i<10; i++){
            try{
                if(!isConnected){
                    ConnectionSetup.createTestConnections();
                    isConnected=true;
                }
            }catch (RuntimeException e){
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"sanity", "All", "eNach"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}

