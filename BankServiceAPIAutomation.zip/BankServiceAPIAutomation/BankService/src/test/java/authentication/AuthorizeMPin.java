package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class AuthorizeMPin extends mPinBL {

    @Test(dataProvider = "TestDataProviderAuthMPin")
    public void testAuthMPin(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(AuthorizeMPin.class, String.format("Authorize m pin %1s - %2s", type, typeValue));
        Map<String, String> header = setMPinHeader(channelId, 121, null);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderAuthMPin")
    public Object[][] TestDataProviderAuthMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3137, "1234"},
                {MPIN_MOBILE_NUMBER, "9082848306", 8011, "1234"}
/*                {MPIN_BANK_CUSTOMER_ID, "2347757", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "1234"}*/
        };
    }

/*     //  only for PPI user
    @Test(dataProvider = "TestDataProviderAuthenticateCredential")
    public void testAuthenticateCredential(String type, String typeValue, int channelId, String pin) {
            Reporter.initiateTestReport(AuthorizeMPin.class, String.format("Authenticate Credential %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  create authenticate credentials
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");

        //  adding digital signature
        authenticateCredentialsPayload = AuthenticationBL.addDigitalSignature(authenticateCredentialsPayload, AuthenticateCredentialEntity.class);

        //  post authenticate credentials
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);

        //  verify the response status
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);

    } */

/*    @DataProvider(name = "TestDataProviderAuthenticateCredential")
    public Object[][] TestDataProviderAuthenticateCredential() {
        return new Object[][]{

                {MPIN_MOBILE_NUMBER, "8356903831", 3000, "0852"},
                {MPIN_MOBILE_NUMBER, "9002000002", 3000, "1357"},
                {MPIN_MOBILE_NUMBER, "7001111101", 3000, "1379"},
                {MPIN_MOBILE_NUMBER, "9812345678", 3000, "1357"},
                {MPIN_MOBILE_NUMBER, "8104912550", 3000, "1357"},
                {MPIN_MOBILE_NUMBER, "9625836528", 3000, "1357"},
                {MPIN_MOBILE_NUMBER, "7859999999", 3000, "1357"}
        };
    }

    @Test(dataProvider = "TestDataProviderAuthIncorrectMPin")
    public void testAuthIncorrectMPin(String type, String typeValue, int channelId, String pin) {

        Reporter.initiateTestReport(AuthorizeMPin.class, String.format("Authorize m pin %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  create authenticate credentials
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");

        //  adding digital signature
        authenticateCredentialsPayload = AuthenticationBL.addDigitalSignature(authenticateCredentialsPayload, AuthenticateCredentialEntity.class);

        //  post authenticate credentials
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);

        //  verify the response status
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_UNAUTHORIZED);

        //  verify response
        validateErrorMessages(responseAuthenticateCredentials, "Incorrect Credential", "111");

    }

    @DataProvider(name = "TestDataProviderAuthIncorrectMPin")
    public Object[][] TestDataProviderAuthIncorrectMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1111"},
        };
    }

    @Test(dataProvider = "TestDataProviderInvalidAuthCodeMPin")
    public void testInvalidAuthCodeMPin(String type, String typeValue, int channelId, String pin, String invalidCase, String jsonPath, String invalidValue, String action) {

        Reporter.initiateTestReport(AuthorizeMPin.class, String.format("Authorize code :  %1s invalid case - %2s", invalidCase, invalidValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  create authenticate credentials
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        ;

        //  adding digital signature
        authenticateCredentialsPayload = AuthenticationBL.addDigitalSignature(authenticateCredentialsPayload, AuthenticateCredentialEntity.class);

        //  post authenticate credentials
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);

        //  verify the response status
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);

        //  create Authorization Code Payload
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");

        //  modify payload
        authorizationCodePayload = CommonMethods.ChangeJsonPayload(authorizationCodePayload, action, jsonPath, invalidValue);

        //  post Authorization Code
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);

        //  verify the response status
        AuthenticationBL.validateResponseForInvalidAuthCase(responseAuthorizationCode, invalidCase, action);

    }

    @DataProvider(name = "TestDataProviderInvalidAuthCodeMPin")
    public Object[][] TestDataProviderInvalidAuthCodeMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234", CUSTOMER_ACCOUNT_NUMBER, PATH_BANK_ACCOUNT_NUMBER, null, ACTION_DELETE},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234", BANK_CUSTOMER_ID, PATH_BANK_CUSTOMER_ID, null, ACTION_DELETE},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234", AUTH_CODE, PATH_AUTH_AUTHORIZATION_CODE, null, ACTION_DELETE},

                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234", CUSTOMER_ACCOUNT_NUMBER, PATH_BANK_ACCOUNT_NUMBER, "999999999", ACTION_SET},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234", BANK_CUSTOMER_ID, PATH_BANK_CUSTOMER_ID, "000000", ACTION_SET},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "1234", AUTH_CODE, PATH_AUTH_AUTHORIZATION_CODE, "11111-ee84e66b4503-42bd-ee84e66b4503", ACTION_SET}
        };
    }*/

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
