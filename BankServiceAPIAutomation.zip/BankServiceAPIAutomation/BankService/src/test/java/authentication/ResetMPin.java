package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class ResetMPin extends mPinBL {


    @Test(dataProvider = "TestDataProviderResetMPin")
    public void testResetMPin(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(ResetMPin.class, String.format("reset m pin %1s - %2s", type, typeValue));
        String otp = AuthenticationBL.getOTP(type, typeValue, channelId, 121);
        String mPinPayload = createSetResetMPinPayload(type, typeValue, VALIDATION_RESET_DOB_AUTH_CODE, pin, null, otp);
        Map<String, String> header = setMPinHeader(channelId, 121, null);
        Response response = postResetMPin(mPinPayload, header);
        validateMPinResponseStatus(response, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderResetMPin")
    public Object[][] TestDataProviderResetMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3137, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2382856", 3137, "1234"},
                {MPIN_MOBILE_NUMBER, "9082848306", 8011, "1234"}
                /*{MPIN_BANK_CUSTOMER_ID, "2347757", 3137, "1234"}
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "1234"}*/
        };
    }

    @Test(dataProvider = "TestDataProviderResetMPinWithDigitalSignature")
    public void testResetMPinWithDigitalSignature(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(ResetMPin.class, String.format("reset m pin with digital signature. %1s - %2s", type, typeValue));
        //  RegisterChannelBL.RegisterAuthenticationChannel(channelId);
        String mPinPayload = createSetResetMPinPayload(type, typeValue, VALIDATION_DIGITAL_SIGNATURE_DOB, pin, null, null);
        Map<String, String> header = setMPinHeader(channelId, 121, mPinPayload);
        Response response = postResetMPin(mPinPayload, header);
        validateMPinResponseStatus(response, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderResetMPinWithDigitalSignature")
    public Object[][] TestDataProviderResetMPinWithDigitalSignature() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352763", 8011, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2382856", 8011, "1234"},
                {MPIN_MOBILE_NUMBER, "9082848306", 8011, "1234"}
                /*{MPIN_BANK_CUSTOMER_ID, "2347757", 3137, "1234"}
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "1234"}*/
        };
    }

/*    @Test(dataProvider = "TestDataProviderResetWithInvalidMPin")
    public void testResetWithInvalidMPin(String type, String typeValue, int channelId, String pin) {

        Reporter.initiateTestReport(ResetMPin.class, String.format("reset m pin with invalid pin %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createSetResetMPinPayload(type, typeValue, VALIDATION_RESET_DOB_AUTH_CODE, pin, null, "");

        //  add digital signature
        mPinPayload = AuthenticationBL.addDigitalSignature(mPinPayload, MPinEntity.class);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  post m pin
        Response response = postResetMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_BAD_REQUEST);

        //  verify response
        validateErrorMessages(response, "Invalid Characters in Credential, Required: Numeric", "108");

    }

    @DataProvider(name = "TestDataProviderResetWithInvalidMPin")
    public Object[][] TestDataProviderResetWithInvalidMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "12AA"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "12  "},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, ".1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234.0"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "    "},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "****"}
        };
    }

    @Test(dataProvider = "TestDataProviderResetMPinInvalidDateOfBirth")
    public void testResetMPinWithInvalidDateOfBirth(String type, String typeValue, int channelId, String pin, String dob) {

        Reporter.initiateTestReport(ResetMPin.class, String.format("reset m pin with invalid date of birth %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createSetResetMPinPayloadWithIncorrectDOB(type, typeValue, pin, dob);

        //  add digital signature
        mPinPayload = AuthenticationBL.addDigitalSignature(mPinPayload, MPinEntity.class);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  post m pin
        Response response = postResetMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_UNAUTHORIZED);

        //  verify response
        validateErrorMessages(response, "Failed Validation(s): DOB", "106");

    }

    @DataProvider(name = "TestDataProviderResetMPinInvalidDateOfBirth")
    public Object[][] TestDataProviderResetMPinInvalidDateOfBirth() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234", "11-11-1900"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234", "01-Jan-1993"},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234", "33-01-1993"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234", "01-13-1993"}

        };
    }*/

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
