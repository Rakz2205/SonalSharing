package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class AuthenticateMPin extends mPinBL {

    @Test(dataProvider = "TestDataProviderAuthenticateMPin")
    public void testAuthenticateMPin(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(AuthenticateMPin.class, "Authenticate MPin. Type : " + type + " | Value : " + typeValue);
        Map<String, String> header = setOTPHeader(channelId, 121);
        String mPinPayload = AuthenticationBL.createAuthenticateMPinPayload(type, typeValue, pin);
        Response responseAuthenticateMPin = AuthenticationBL.postOTP(mPinPayload, header);
        validateMPinResponseStatus(responseAuthenticateMPin, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderAuthenticateMPin")
    public Object[][] TestDataProviderAuthenticateMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2397873", 3137, "1234"},
/*                {MPIN_MOBILE_NUMBER, "9915164625", 3137, "1234"}*/
        };
    }

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
