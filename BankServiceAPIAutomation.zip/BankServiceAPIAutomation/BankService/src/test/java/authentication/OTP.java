package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class OTP extends mPinBL {

/*    @Test(dataProvider = "TestDataProviderOTP")
    public void testOTP(String mobileNumber, int channelId) {

      Reporter.initiateTestReport(OTP.class, "Generate and verify OTP. Mobile number : " + mobileNumber);

        //  set header
        Map<String, String> header = setMPinHeader(channelId);

        //  generate otp payload
        String otpPayload = AuthenticationBL.createOTPPayload(mobileNumber, "generate", "");

        //  adding digital signature
        otpPayload = AuthenticationBL.addDigitalSignature(otpPayload, AuthenticateCredentialEntity.class);

        //  post generate otp
        Response responseGenerateOTP = AuthenticationBL.postOTP(otpPayload, header);

        //  verify the generate otp status
        AuthenticationBL.validateAuthenticationResponseStatus(responseGenerateOTP, HttpStatus.SC_OK);

        //   get otp from the db
        String otp = AuthenticationBL.getOTPFromDatabase(mobileNumber);

        //  verify otp payload
        String verifyOTPPayload = AuthenticationBL.createOTPPayload(mobileNumber, "verify", otp);

        //  adding digital signature
        verifyOTPPayload = AuthenticationBL.addDigitalSignature(verifyOTPPayload, AuthenticateCredentialEntity.class);

        //  post verify otp
        Response responseVerifyOtp = AuthenticationBL.postOTP(verifyOTPPayload, header);

        //  verify the response status
        AuthenticationBL.validateAuthenticationResponseStatus(responseVerifyOtp, HttpStatus.SC_OK);

        // validate response
        AuthenticationBL.validateOTPResponse(responseVerifyOtp, mobileNumber);

*//*        //  create Authorization Code Payload
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseVerifyOtp);

        //  post Authorization Code
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);

        //  verify the response status
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);*//*

    }*/

    @Test(dataProvider = "TestDataProviderOTP")
    public void testOTP(String type, String typeValue, int channelId, int traceId) {
        Reporter.initiateTestReport(OTP.class, "Generate and verify OTP. Type : " + type + " | Value : " + typeValue);
        Map<String, String> header = setOTPHeader(channelId, traceId);
        String otpPayload = AuthenticationBL.createOTPPayload(type, typeValue, "generate", "");
        Response responseGenerateOTP = AuthenticationBL.postOTP(otpPayload, header);
        Assert.assertEquals(responseGenerateOTP.jsonPath().getString("status"), "SUCCESS");
        AuthenticationBL.validateAuthenticationResponseStatus(responseGenerateOTP, HttpStatus.SC_OK);
        String otp = AuthenticationBL.getOTPFromDatabase(type, typeValue);
        String verifyOTPPayload = AuthenticationBL.createOTPPayload(type, typeValue, "verify", otp);
        Response responseVerifyOtp = AuthenticationBL.postOTP(verifyOTPPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseVerifyOtp, HttpStatus.SC_OK);
        AuthenticationBL.validateOTPResponse(responseVerifyOtp, type, typeValue);
    }

    @DataProvider(name = "TestDataProviderOTP")
    public Object[][] TestDataProviderOTP() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2397873", 3137, 121},
                {MPIN_MOBILE_NUMBER, "9915164625", 3137, 121}
        };
    }

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
