package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class ChangeMPin extends mPinBL {

    @Test(dataProvider = "TestDataProviderChangeMPin")
    public void testChangeMPin(String type, String typeValue, int channelId, String oldPin, String newPin) {
        Reporter.initiateTestReport(ChangeMPin.class, String.format("change m pin using %1s - %2s", type, typeValue));
        //RegisterChannelBL.RegisterChannel(channelId);*/
        String mPinPayload = createChangeMPinPayload(type, typeValue, oldPin, newPin);
        Map<String, String> header = setMPinHeader(channelId, 121, null);
        Response response = postChangeMPin(mPinPayload, header);
        validateMPinResponseStatus(response, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, newPin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderChangeMPin")
    public Object[][] TestDataProviderChangeMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3137, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2382856", 3137, "1234", "1234"},
                {MPIN_MOBILE_NUMBER, "9082848306", 8011, "1234", "1234"}

                /*{MPIN_BANK_CUSTOMER_ID, "2347757", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344729", 3000, "1234", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2344719", 3000, "1234", "1234"}*/
        };
    }

/*    @Test(dataProvider = "TestDataProviderChangeWithInvalidMPin")
    public void testChangeWithInvalidMPin(String type, String typeValue, int channelId, String oldPin, String newPin) {

        Reporter.initiateTestReport(ChangeMPin.class, String.format("change m pin with invalid new pin %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createChangeMPinPayload(type, typeValue, oldPin, newPin);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  post m pin
        Response response = postChangeMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_BAD_REQUEST);

        //  verify response
        validateErrorMessages(response, "Invalid Characters in Credential, Required: Numeric", "108");

    }

    @DataProvider(name = "TestDataProviderChangeWithInvalidMPin")
    public Object[][] TestDataProviderChangeWithInvalidMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "1234", "12AA"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "1234", "12  "},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "1234", ".1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234", "1234.0"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "1234", "    "},
                {MPIN_BANK_CUSTOMER_ID, "2347757", 3000, "1234", "****"}
        };
    }

    @Test(dataProvider = "TestDataProviderChangeMPinWithIncorrectCredential")
    public void testChangeMPinWithIncorrectCredential(String type, String typeValue, int channelId, String oldPin, String newPin) {

        Reporter.initiateTestReport(ChangeMPin.class, String.format("change m pin with invalid old pin %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createChangeMPinPayload(type, typeValue, oldPin, newPin);

        //  set header
        Map<String, String> header = setMPinHeader(channelId, 121, null);

        //  post m pin
        Response response = postChangeMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_UNAUTHORIZED);

        //  verify response
        validateErrorMessages(response, "Incorrect Credential", "111");

    }

    @DataProvider(name = "TestDataProviderChangeMPinWithIncorrectCredential")
    public Object[][] TestDataProviderChangeMPinWithIncorrectCredential() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "12AA", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "5643", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, "9999", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "0987", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "6565", "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2347757", 3000, "1230", "1234"}
        };
    }*/

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
