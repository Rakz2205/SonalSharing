package authentication;

import base.ConnectionSetup;
import client.authentication.AuthenticationBL;
import client.authentication.mPinBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class SetMPin extends mPinBL {

    @Test(dataProvider = "TestDataProviderSetMPin")
    public void testSetMPin(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(SetMPin.class, String.format("Set m pin using %1s - %2s", type, typeValue));
        String otpAuthCode = AuthenticationBL.getOTPAuthCode(type, typeValue, channelId, 121);
        String mPinPayload = createSetResetMPinPayload(type, typeValue, VALIDATION_SET_DOB_AUTH_CODE, pin, otpAuthCode, null);
        Map<String, String> header = setMPinHeader(channelId, 121, null);
        Response response = postSetMPin(mPinPayload, header);
        validateMPinResponseStatus(response, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderSetMPin")
    public Object[][] TestDataProviderSetMPin() {
        return new Object[][]{
                {MPIN_MOBILE_NUMBER, "8149686291", 3137, "1234"},
/*                {MPIN_MOBILE_NUMBER, "7040404061", 3000, "1234"},
                {MPIN_BANK_CUSTOMER_ID, "2382856", 3000, "1234"}
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "1234"}
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3137, "1234"}*/
        };
    }

    @Test(dataProvider = "TestDataProviderSetMPinWithDigitalSignature")
    public void testSetMPinWithDigitalSignature(String type, String typeValue, int channelId, String pin) {
        Reporter.initiateTestReport(SetMPin.class, String.format("Set m pin with digital signature %1s - %2s", type, typeValue));
        //  RegisterChannelBL.RegisterAuthenticationChannel(channelId);
        String mPinPayload = createSetResetMPinPayload(type, typeValue, VALIDATION_DIGITAL_SIGNATURE_DOB, pin, null, null);
        Map<String, String> header = setMPinHeader(channelId, 121, mPinPayload);
        Response response = postSetMPin(mPinPayload, header);
        validateMPinResponseStatus(response, HttpStatus.SC_OK);
        String authenticateCredentialsPayload = AuthenticationBL.createMPinAuthenticateCredentialPayload(type, typeValue, pin, 1, "Authentication Info");
        Response responseAuthenticateCredentials = AuthenticationBL.postAuthenticateCredentials(authenticateCredentialsPayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthenticateCredentials, HttpStatus.SC_OK);
        String authorizationCodePayload = AuthenticationBL.createMPinAuthorizationCodePayload(responseAuthenticateCredentials, "7");
        Response responseAuthorizationCode = AuthenticationBL.postAuthorizationCode(authorizationCodePayload, header);
        AuthenticationBL.validateAuthenticationResponseStatus(responseAuthorizationCode, HttpStatus.SC_OK);
    }

    @DataProvider(name = "TestDataProviderSetMPinWithDigitalSignature")
    public Object[][] TestDataProviderSetMPinWithDigitalSignature() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2435368", 8011, "1234"}
        };
    }

/*    @Test(dataProvider = "TestDataProviderSetInvalidMPin")
    public void testSetInvalidMPin(String type, String typeValue, int channelId, String pin) {

        Reporter.initiateTestReport(SetMPin.class, String.format("Set invalid m pin using %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createSetResetMPinPayload(type, typeValue, pin);

        //  add digital signature
        mPinPayload = AuthenticationBL.addDigitalSignature(mPinPayload, MPinEntity.class);

        //  set header
        Map<String, String> header = setMPinHeader(channelId);

        //  post m pin
        Response response = postSetMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_BAD_REQUEST);

        //  verify response
        validateErrorMessages(response, "Invalid Characters in Credential, Required: Numeric", "108");

    }

    @DataProvider(name = "TestDataProviderSetInvalidMPin")
    public Object[][] TestDataProviderInvalidSetMPin() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "1824909", 3000, "12AA"},
                {MPIN_BANK_CUSTOMER_ID, "1824911", 3000, "12  "},
                {MPIN_BANK_CUSTOMER_ID, "2206946", 3000, ".1234"},
                {MPIN_BANK_CUSTOMER_ID, "2435368", 3000, "1234.0"},
                {MPIN_BANK_CUSTOMER_ID, "2438403", 3000, "    "},
                {MPIN_BANK_CUSTOMER_ID, "2352763", 3000, "****"}
        };
    }

    @Test(dataProvider = "TestDataProviderSetMPinInvalidDateOfBirth")
    public void testSetMPinWithInvalidDateOfBirth(String type, String typeValue, int channelId, String pin, String dob) {

        Reporter.initiateTestReport(SetMPin.class, String.format("Set m pin incorrect data of birth. %1s - %2s", type, typeValue));

        //  register channel id
        RegisterChannelBL.RegisterChannel(channelId);

        //  create change m pin payload
        String mPinPayload = createSetResetMPinPayloadWithIncorrectDOB(type, typeValue, pin, dob);

        //  add digital signature
        mPinPayload = AuthenticationBL.addDigitalSignature(mPinPayload, MPinEntity.class);

        //  set header
        Map<String, String> header = setMPinHeader(channelId);

        //  post m pin
        Response response = postResetMPin(mPinPayload, header);

        //  verify the response status
        validateMPinResponseStatus(response, HttpStatus.SC_UNAUTHORIZED);

        //  verify response
        validateErrorMessages(response, "Failed Validation(s): DOB", "106");

    }

    @DataProvider(name = "TestDataProviderSetMPinInvalidDateOfBirth")
    public Object[][] TestDataProviderSetMPinInvalidDateOfBirth() {
        return new Object[][]{
                {MPIN_BANK_CUSTOMER_ID, "2352764", 3000, "1234", "11-11-1900"},
                {MPIN_BANK_CUSTOMER_ID, "2352765", 3000, "1234", "01-Jan-1993"},
                {MPIN_BANK_CUSTOMER_ID, "2406165", 3000, "1234", "33-01-1993"},
                {MPIN_BANK_CUSTOMER_ID, "2344728", 3000, "1234", "01-13-1993"}
        };
    }*/

    @BeforeMethod()
    public void beforeSetup() {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
