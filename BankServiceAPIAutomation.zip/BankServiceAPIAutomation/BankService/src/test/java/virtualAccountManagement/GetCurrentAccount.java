package virtualAccountManagement;

import base.ConnectionSetup;
import client.virtualAccountManagement.GetCurrentAccountBL;
import com.utilities.connectionUtils.DataBaseUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class GetCurrentAccount extends GetCurrentAccountBL {

    @Test(dataProvider = "TestDataProviderGetCurrentAccount")
    public void TestGetCurrentAccount(String virtualAccountNumber, int channelId) {

        Reporter.initiateTestReport(GetCurrentAccount.class, String.format("Get current account. Virtual account number : %1s", virtualAccountNumber));

        //  create payload
        String payload = createGetCurrentAccountPayload(virtualAccountNumber);

        //  set header
        Map<String, String> header = setGetBalanceHeader(channelId);

        //  post get current account
        Response response = postGetCurrentAccount(payload, header);

        //  validate status code
        validateGetCurrentAccountResponseStatus(response, HttpStatus.SC_OK);

        //  validate response
        validateGetCurrentAccountResponse(response, virtualAccountNumber);
    }

    @DataProvider(name = "TestDataProviderGetCurrentAccount")
    public Object[][] TestDataProviderGetCurrentAccount() {
        return new Object[][]{
                {"RILD909090909", 3542},
                {"RILD909090911", 3542},
        };
    }

    @Test(dataProvider = "TestDataProviderGetCurrentAccountNotExist")
    public void TestGetCurrentAccountNotExist(String virtualAccountNumber, int channelId) {

        Reporter.initiateTestReport(GetCurrentAccount.class, String.format("Get current account. Incorrect virtual account number : %1s", virtualAccountNumber));

        //  create payload
        String payload = createGetCurrentAccountPayload(virtualAccountNumber);

        //  set header
        Map<String, String> header = setGetBalanceHeader(channelId);

        //  post get current account
        Response response = postGetCurrentAccount(payload, header);

        //  validate status code
        validateGetCurrentAccountResponseStatus(response, HttpStatus.SC_INTERNAL_SERVER_ERROR);

        //  validate response
        validateGetCurrentAccountFailedResponse(response, VIRTUAL_ACCOUNT_NOT_EXIST, ERROR_CODE_5904);
    }

    @DataProvider(name = "TestDataProviderGetCurrentAccountNotExist")
    public Object[][] TestDataProviderGetCurrentAccountNotExist() {
        return new Object[][]{
                {"RILD909090901", 3542},
                {"RILD909090901", 3542},
                {"RTLD", 3542},
        };
    }

    @Test(dataProvider = "TestDataProviderGetCurrentDeactivatedAccount")
    public void TestGetCurrentDeactivatedAccount(Map<String, String> testData) {

        Reporter.initiateTestReport(GetCurrentAccount.class, String.format("Get current account. Inactive virtual account number : %1s", testData.get("VIRTUAL_ACCOUNT_NUMBER")));

        //  create payload
        String payload = createGetCurrentAccountPayload(testData.get("VIRTUAL_ACCOUNT_NUMBER"));

        //  set header
        Map<String, String> header = setGetBalanceHeader(3542);

        //  post get current account
        Response response = postGetCurrentAccount(payload, header);

        //  validate status code
        validateGetCurrentAccountResponseStatus(response, HttpStatus.SC_INTERNAL_SERVER_ERROR);

        //  validate response
        validateGetCurrentAccountFailedResponse(response, ACCOUNT_IS_INACTIVE, ERROR_CODE_5909);
    }

    @DataProvider(name = "TestDataProviderGetCurrentDeactivatedAccount")
    public Object[][] TestDataProviderGetCurrentDeactivatedAccount() {
        ConnectionSetup.createVAMConnection();

        String query = "Select VIRTUAL_ACCOUNT_NUMBER from VIRTUAL_ACCOUNT " +
                "where STATUS = 'DEACTIVATED' order by CREATED_AT desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbVAM, query);
    }

    @BeforeMethod
    public void beforeSetup() {
        ConnectionSetup.createVAMConnection();
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeVAMConnection();
    }
}