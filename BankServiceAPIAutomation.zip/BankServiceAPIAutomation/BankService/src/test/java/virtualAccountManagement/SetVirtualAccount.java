package virtualAccountManagement;

import base.ConnectionSetup;
import client.virtualAccountManagement.SetVirtualAccountBL;
import com.utilities.connectionUtils.DataBaseUtility;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;

import java.util.Map;

public class SetVirtualAccount extends SetVirtualAccountBL {

    @Test(dataProvider = "TestDataProviderSetVirtualAccountActiveAndDeactivate")
    public void TestSetVirtualAccountActiveAndDeactivate(Map<Object, Object> testData) {

        Reporter.initiateTestReport(SetVirtualAccount.class, String.format("Activate and Deactivate virtual account. Virtual account number : %1s", testData.get("VIRTUAL_ACCOUNT_NUMBER")));

        //  create payload
        String payload = createSetVirtualAccountPayload(testData, false);

        //  set header
        Map<String, String> header = setSetVirtualAccountHeader(3542);

        //  post set virtual account
        Response responseDeActivate = postSetVirtualAccount(payload, header);

        //  validate status code
        validateSetVirtualAccountResponseStatus(responseDeActivate, HttpStatus.SC_OK);

        //  validate response
        validateSetVirtualAccountResponse(responseDeActivate);

        //  create payload
        payload = createSetVirtualAccountPayload(testData, true);

        //  post set virtual account
        Response responseActivate = postSetVirtualAccount(payload, header);

        //  validate status code
        validateSetVirtualAccountResponseStatus(responseActivate, HttpStatus.SC_OK);

        //  validate response
        validateSetVirtualAccountResponse(responseActivate);

    }

    @DataProvider(name = "TestDataProviderSetVirtualAccountActiveAndDeactivate")
    public Object[][] TestDataProviderSetVirtualAccountActiveAndDeactivate() {
        ConnectionSetup.createVAMConnection();

        String query = "Select CORPORATE_CLIENT_CODE, VIRTUAL_ACCOUNT_NUMBER, CORPORATE_CUSTOMER_CODE, CUSTOMER_NAME, CUSTOMER_EMAIL from VIRTUAL_ACCOUNT " +
                "where STATUS = 'ACTIVE' order by CREATED_AT desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbVAM, query);
    }

    @Test(dataProvider = "TestDataProviderSetVirtualAccountUpdateDeactivatedAccount")
    public void TestSetVirtualAccountUpdateDeactivatedAccount(Map<Object, Object> testData) {

        Reporter.initiateTestReport(SetVirtualAccount.class, String.format("Update deactivate virtual account. Virtual account number : %1s", testData.get("VIRTUAL_ACCOUNT_NUMBER")));

        //  create payload
        String payload = createSetVirtualAccountPayload(testData, false);

        //  set header
        Map<String, String> header = setSetVirtualAccountHeader(3542);

        //  post set virtual account
        Response responseDeActivate = postSetVirtualAccount(payload, header);

        //  validate status code
        validateSetVirtualAccountResponseStatus(responseDeActivate, HttpStatus.SC_INTERNAL_SERVER_ERROR);

        //  validate response
        validateSetVirtualAccountFailedResponse(responseDeActivate, VIRTUAL_ACCOUNT_NOT_DEACTIVATED, ERROR_CODE_5906);

        // validate logging
        //validateSetVirtualAccount()

    }

    @DataProvider(name = "TestDataProviderSetVirtualAccountUpdateDeactivatedAccount")
    public Object[][] TestDataProviderSetVirtualAccountUpdateDeactivatedAccount() {
        ConnectionSetup.createVAMConnection();

        String query = "Select CORPORATE_CLIENT_CODE, VIRTUAL_ACCOUNT_NUMBER, CORPORATE_CUSTOMER_CODE, CUSTOMER_NAME, CUSTOMER_EMAIL from VIRTUAL_ACCOUNT " +
                "where STATUS = 'DEACTIVATED' order by CREATED_AT desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbVAM, query);
    }

    @Test(dataProvider = "TestDataProviderSetVirtualAccountActiveAndDeactivate")
    public void TestSetVirtualAccountUpdateActivatedAccount(Map<Object, Object> testData) {

        Reporter.initiateTestReport(SetVirtualAccount.class, String.format("Update active virtual account. Virtual account number : %1s", testData.get("VIRTUAL_ACCOUNT_NUMBER")));

        //  create payload
        String payload = createSetVirtualAccountPayload(testData, true);

        //  set header
        Map<String, String> header = setSetVirtualAccountHeader(3542);

        //  post set virtual account
        Response responseDeActivate = postSetVirtualAccount(payload, header);

        //  validate status code
        validateSetVirtualAccountResponseStatus(responseDeActivate, HttpStatus.SC_INTERNAL_SERVER_ERROR);

        //  validate response
        validateSetVirtualAccountFailedResponse(responseDeActivate, VIRTUAL_ACCOUNT_NOT_ACTIVE, ERROR_CODE_5906);

    }

    @Test(dataProvider = "TestDataProviderCreateVirtualAccount")
    public void TestCreateVirtualAccount(String corporateCode, String emails, int channelId, boolean isActive) {

        Reporter.initiateTestReport(SetVirtualAccount.class, String.format("Create virtual account."));

        //  create payload
        String payload = createSetVirtualAccountPayload(corporateCode, emails, isActive);

        //  set header
        Map<String, String> header = setSetVirtualAccountHeader(channelId);

        //  post set virtual account
        Response responseDeActivate = postSetVirtualAccount(payload, header);

        //  validate status code
        validateSetVirtualAccountResponseStatus(responseDeActivate, HttpStatus.SC_OK);

        //  validate response
        validateSetVirtualAccountResponse(responseDeActivate);

    }

    @DataProvider(name = "TestDataProviderCreateVirtualAccount")
    public Object[][] TestDataProviderCreateVirtualAccount() {
        return new Object[][]{
                {"RILD", "Shashank2.Singh@ril.com", 3542, true},
                /*{"RILS", "Shashank2.Singh@ril.com,Shashank2.Singh@ril.com", 3542, true},*/
        };
    }

    //@Test(dataProvider = "TestDataProviderSetVirtualAccountInvalidCase")
    public void TestSetVirtualAccountInvalidCase(String invalidCase, String action, Object invalidValue, String accountNumber, int channelId, String errorCode, String errorMessage, int responseStatus) {

        Reporter.initiateTestReport(SetVirtualAccount.class, String.format("Negative case, Set virtual account. Invalid Case : %1s and Invalid value : %2s", invalidCase, invalidValue));

        //  create payload
        createSetVirtualAccountPayload(accountNumber);

        //  modify payload
        String payload = modifySetVirtualAccountPayload(invalidCase, action, invalidValue);

        //  set header
        Map<String, String> header = setSetVirtualAccountHeader(channelId);

        //  post set virtual account
        Response responseDeActivate = postSetVirtualAccount(payload, header);

/*        //  validate status code
        validateSetVirtualAccountResponseStatus(responseDeActivate, HttpStatus.SC_OK);

        //  validate response
        validateSetVirtualAccountResponse(responseDeActivate);*/

    }

    @DataProvider(name = "TestDataProviderSetVirtualAccountInvalidCase")
    public Object[][] TestDataProviderSetVirtualAccountInvalidCase() {
        return new Object[][]{

                {VIRTUAL_ACCOUNT_ID, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_ID, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_ID, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_CLIENT_CODE, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CLIENT_CODE, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CLIENT_CODE, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_ACCOUNT_STATUS, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_ACCOUNT_STATUS, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_ACCOUNT_STATUS, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_NUMBER, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_NUMBER, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_NUMBER, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_CUSTOMER_CODE, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_CODE, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_CODE, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_CUSTOMER_NAME, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_NAME, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_NAME, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_CUSTOMER_EMAIL, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_EMAIL, ACTION_SET, "", "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CUSTOMER_EMAIL, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},

                {VIRTUAL_ACCOUNT_CREATED_BY, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CREATED_BY, ACTION_SET, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
                {VIRTUAL_ACCOUNT_CREATED_BY, ACTION_DELETE, null, "RILD909090912", 3542, "", "", HttpStatus.SC_INTERNAL_SERVER_ERROR},
        };
    }

    @BeforeMethod
    public void beforeSetup() {

        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createVAMConnection();
                    isConnected = true;
                } else {
                    break;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeVAMConnection();
    }
}
