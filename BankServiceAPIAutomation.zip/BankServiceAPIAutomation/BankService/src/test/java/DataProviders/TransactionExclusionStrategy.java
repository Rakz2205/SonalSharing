package DataProviders;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import entity.Transaction;
import entity.TransactionMethod;

import java.util.List;

public class TransactionExclusionStrategy implements ExclusionStrategy {

    private String param;
    private Class clsName;

    TransactionExclusionStrategy(String s, Class cls){
        this.param=s;
        this.clsName=cls;
    }

    @Override
    public boolean shouldSkipField(FieldAttributes f) {
        return f.getDeclaringClass() == clsName && f.getName().equals(param);

    }
    public boolean shouldSkipClass(Class<?> clazz) {
        return false;
    }

//    public boolean shouldSkipClass(Class<?> clazz) {
//        return  (clazz.getDeclaringClass() == Transaction.class && clazz.getSimpleName().equals("method"));
//    }

}

/*    public static void main(String[] args){

        //to exclude a parameter from serializing.
        TransactionExclusionStrategy strategy = new TransactionExclusionStrategy("entityId", InitiatingEntity.class);
        //strategy.setParam("currency");

        //TransactionExclusionStrategy strategy1 = new TransactionExclusionStrategy("invoice");
        //strategy1.setParam("idempotentKey");

//        TransactionExclusionStrategy strategy2 = new TransactionExclusionStrategy("invoice");
        //strategy2.setParam("invoice");

        Gson gson = new GsonBuilder().setExclusionStrategies(strategy).create();

        String idempotentKey = CommonMethods.generateNewIdempotentKey();
        InitiatingEntity initiatingEntity = CommonMethods.getDefaultInitiatingEntity();
        TransactionMethod transactionMethod = CommonMethods.getDefaultTransactionMethod();
        int applicationId = Constants.APPLICATION_ID_3132;
        Transaction transaction = CommonMethods.createTransaction(idempotentKey, initiatingEntity, transactionMethod, applicationId);

        System.out.println(gson.toJson(transaction));

    }*/
