package DataProviders;

import base.ConnectionSetup;
import base.SetUp;
import com.utilities.connectionUtils.DataBaseUtility;
import org.apache.http.HttpStatus;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import utils.CommonMethods;

import java.util.*;

public class CreditTxnDataProvider extends SetUp {

    static String payeeAccount;
    static String payeeIFSC;

    public static Object[][] returnTestData(List<String> groups, Map<String, Object[][]> dataSet) {
        if (groups.contains("All")) {
            return getTestData(dataSet);
        } else {
            Map<String, Object[][]> dataMap = new HashMap<>();
            for (String key : dataSet.keySet()) {
                if (groups.contains(key))
                    dataMap.put(key, dataSet.get(key));
            }
            return getTestData(dataMap);
        }
    }

    private static int getSize(Map<String, Object[][]> dataSet) {
        int count = 0;
        for (String str : dataSet.keySet()) {
            count = count + dataSet.get(str).length;
        }
        return count;
    }

    private static Object[][] getTestData(Map<String, Object[][]> dataSet) {
        Object[][] result = new Object[getSize(dataSet)][];
        int destPos = 0;

        for (String str : dataSet.keySet()) {
            System.arraycopy(dataSet.get(str), 0, result, destPos, dataSet.get(str).length);
            destPos = destPos + dataSet.get(str).length;
        }
        return result;
    }

    public static Object[][] concat(Object[][] var1, Object[][] var2) {
        List<Object[]> mergeList = new LinkedList<>();
        for (Object[] obj1 : var1) {
            for (Object[] obj2 : var2) {
                mergeList.add(concatAll(obj1, obj2));
            }
        }
        return mergeList.toArray(new Object[0][0]);
    }

    @SafeVarargs
    public static <T> T[] concatAll(T[] first, T[]... rest) {
        //calculate the total length of the final object array after the concat
        int totalLength = first.length;
        for (T[] array : rest) {
            totalLength += array.length;
        }
        //copy the first array to result array and then copy each array completely to result
        T[] result = Arrays.copyOf(first, totalLength);
        int offset = first.length;
        for (T[] array : rest) {
            System.arraycopy(array, 0, result, offset, array.length);
            offset += array.length;
        }
        return result;
    }


    @DataProvider(name = "ENachCreditTransaction")
    public static Object[][] ENachCreditTransaction(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", dataProviderCreditTransactionENach());
        dataProvider.put("sanity", dataProviderCreditTransactionENach());

        return returnTestData(allIncludedGroups, dataProvider);
    }


    @DataProvider(name = "CreditTransaction")
    public static Object[][] CreditTransaction(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("UPI", dataProviderCreditTransactionUPI());
        dataProvider.put("AEPS", dataProviderCreditTransactionAEPS());
        dataProvider.put("sanity", dataProviderCreditTransactionSanity());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] dataProviderCreditTransactionENach() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_576, DEFAULT_SIT_GL_ACCOUNT, payeeIFSC, ENTITY_ID_8012, APPLICATION_ID_8012, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditTransactionAEPS() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_525, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {SUB_TYPE_576, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {SUB_TYPE_523, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditTransactionSanity() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_580, payeeAccount, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {SUB_TYPE_580, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditTransactionUPI() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_580, payeeAccount, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {SUB_TYPE_580, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {SUB_TYPE_580, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {SUB_TYPE_580, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1}
        };
    }


    @DataProvider(name = "CreditReversalOnDebitFreezeAccount")
    public static Object[][] CreditReversalOnDebitFreezeAccount(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", eNach_ReversalOnDebitFreezeAccount());
        dataProvider.put("AEPS", dataProviderCreditReversalOnDebitFreezeAccountAEPS());
        dataProvider.put("UPI", dataProviderCreditReversalOnDebitFreezeAccountUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] eNach_ReversalOnDebitFreezeAccount() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_576, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8012, APPLICATION_ID_8012, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditReversalOnDebitFreezeAccountAEPS() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_525, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {SUB_TYPE_576, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {SUB_TYPE_523, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditReversalOnDebitFreezeAccountUPI() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_580, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {SUB_TYPE_580, SIT_CURRENT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {SUB_TYPE_580, DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {SUB_TYPE_580, SIT_CURRENT_DEBIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1}
        };
    }


    @DataProvider(name = "CreditTransactionWithFreezeAccount")
    public static Object[][] CreditTransactionWithFreezeAccount(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", eNach_CreditTransactionWithFreezeAccountNACH());
        dataProvider.put("AEPS", dataProviderCreditTransactionWithFreezeAccountAEPS());
        dataProvider.put("UPI", dataProviderCreditTransactionWithFreezeAccountUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] eNach_CreditTransactionWithFreezeAccountNACH() {
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_576, CommonMethods.getDefaultTotalFreezeAccountNumber(), payeeIFSC, ENTITY_ID_8012,
                        APPLICATION_ID_8012, 1, ERROR_CODE_21005, INVALID_TRANSACTION_NOT_PERMITTED}
        };
    }

    public static Object[][] dataProviderCreditTransactionWithFreezeAccountAEPS() {
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_525, CommonMethods.getDefaultCreditFreezeAccountNumber(), payeeIFSC, ENTITY_ID_8001,
                        APPLICATION_ID_3132, 1, ERROR_CODE_30523, INVALID_FREEZE_MSG},

                {SUB_TYPE_576, CommonMethods.getDefaultTotalFreezeAccountNumber(), payeeIFSC, ENTITY_ID_8001,
                        APPLICATION_ID_3132, 1, ERROR_CODE_21005, INVALID_TRANSACTION_NOT_PERMITTED},

                {SUB_TYPE_523, CommonMethods.getDefaultCloseAccountNumber(), payeeIFSC, ENTITY_ID_8001,
                        APPLICATION_ID_3132, 1, ERROR_CODE_21002, INVALID_ACCOUNT_NUMBER}
        };
    }

    public static Object[][] dataProviderCreditTransactionWithFreezeAccountUPI() {
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();
        return new Object[][]{
                {SUB_TYPE_580, CommonMethods.getDefaultCreditFreezeAccountNumber(), payeeIFSC, ENTITY_ID_8001,
                        APPLICATION_ID_3133, MODE_1, ERROR_CODE_30523, ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG},

                {SUB_TYPE_580, CommonMethods.getDefaultCreditFreezeAccountNumber(), payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1, ERROR_CODE_30523,
                        ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG},

                {SUB_TYPE_580, SIT_CURRENT_CREDIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_8001,
                        APPLICATION_ID_3133, MODE_1, ERROR_CODE_30523, ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG},

                {SUB_TYPE_580, SIT_CURRENT_CREDIT_FREEZE_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1, ERROR_CODE_30523,
                        ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG},
        };
    }


    @DataProvider(name = "CreditTransactionIfKeyExist")
    public static Object[][] CreditTransactionIfKeyExist(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", eNach_CreditTransactionIfKeyExist());
        dataProvider.put("AEPS", dataProviderCreditTransactionIfKeyExistAEPS());
        dataProvider.put("UPI", dataProviderCreditTransactionIfKeyExistUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] eNach_CreditTransactionIfKeyExist() {
        ConnectionSetup.createTestConnections();
        String query = "Select * from (Select IDEMPOTENT_KEY, INVOICE, APPLICATION_ID from jpb_transaction where " +
                "METHOD_TYPE = " + TYPE_CREDIT + " and STATUS = 'SUCCESS' and INITIATING_ENTITY_ID = " +
                ENTITY_ID_8012 + " ORDER BY CREATED desc) where rownum <= 2";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }

    public static Object[][] dataProviderCreditTransactionIfKeyExistAEPS() {
        ConnectionSetup.createTestConnections();

        String query = "Select IDEMPOTENT_KEY, INVOICE, APPLICATION_ID from jpb_transaction where " +
                "METHOD_TYPE = " + TYPE_CREDIT + " and STATUS = 'SUCCESS' and INITIATING_ENTITY_ID = " + ENTITY_ID_8001
                + " ORDER BY CREATED desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }

    public static Object[][] dataProviderCreditTransactionIfKeyExistUPI() {
        ConnectionSetup.createTestConnections();

        String query = "Select IDEMPOTENT_KEY, INVOICE, APPLICATION_ID from jpb_transaction where " +
                "METHOD_TYPE = " + TYPE_CREDIT + " and STATUS = 'SUCCESS' and INITIATING_ENTITY_ID = " + ENTITY_ID_9000
                + " ORDER BY CREATED desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }


    @DataProvider(name = "CreditReversalForFailedCreditTransactions")
    public static Object[][] CreditReversalForFailedCreditTransactions(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", eNach_CreditReversalForFailedCreditTransactions());
        dataProvider.put("AEPS", dataProviderCreditReversalForFailedCreditTransactionsAEPS());
        dataProvider.put("UPI", dataProviderCreditReversalForFailedCreditTransactionsUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] eNach_CreditReversalForFailedCreditTransactions() {
        ConnectionSetup.createTestConnections();

        String query = "Select * from jpb_transaction where Status = 'FAILED' and METHOD_TYPE = " + TYPE_CREDIT + " and \n" +
                "METHOD_SUB_TYPE not in (0, 524) and INITIATING_ENTITY_ID = " + ENTITY_ID_8012 + " and APPLICATION_ID != 0 and PROCESSOR_TRANSACTION_ID is not null \n" +
                "and CURRENCY !=0 and TRANSACTION_MODE !=0 and CAPTURE_METHOD !=0 and PAYEE_BANK_IFSC is not null and PAYEE_CUSTOMER_TYPE !=0  and TRANSACTION_ID = ORIGINAL_TRANSACTION_ID \n" +
                "and PAYEE_ACCOUNT_NUMBER = '30000000042280' ORDER BY CREATED desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }

    public static Object[][] dataProviderCreditReversalForFailedCreditTransactionsAEPS() {
        ConnectionSetup.createTestConnections();

        String query = "Select * from jpb_transaction where Status = 'FAILED' and METHOD_TYPE = " + TYPE_CREDIT + " and \n" +
                "METHOD_SUB_TYPE not in (0, 524) and INITIATING_ENTITY_ID = " + ENTITY_ID_8001 + " and APPLICATION_ID != 0 and PROCESSOR_TRANSACTION_ID is not null \n" +
                "and CURRENCY !=0 and TRANSACTION_MODE !=0 and CAPTURE_METHOD !=0 and PAYEE_BANK_IFSC is not null and PAYEE_CUSTOMER_TYPE !=0  and TRANSACTION_ID = ORIGINAL_TRANSACTION_ID \n" +
                "and PAYEE_ACCOUNT_NUMBER = '30000000042280' ORDER BY CREATED desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }

    public static Object[][] dataProviderCreditReversalForFailedCreditTransactionsUPI() {
        ConnectionSetup.createTestConnections();

        String query = "Select * from jpb_transaction where Status = 'FAILED' and METHOD_TYPE = " + TYPE_CREDIT + " and \n" +
                "METHOD_SUB_TYPE not in (0, 524) and INITIATING_ENTITY_ID = " + ENTITY_ID_9000 + " and APPLICATION_ID != 0 and PROCESSOR_TRANSACTION_ID is not null \n" +
                "and CURRENCY !=0 and TRANSACTION_MODE !=0 and CAPTURE_METHOD !=0 and PAYEE_BANK_IFSC is not null and PAYEE_CUSTOMER_TYPE !=0  and TRANSACTION_ID = ORIGINAL_TRANSACTION_ID \n" +
                "and PAYEE_ACCOUNT_NUMBER = '30000000042280' ORDER BY CREATED desc fetch first 3 rows only";

        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }


    @DataProvider(name = "ENachCreditTransactionInValidSubType")
    public static Object[][] ENachCreditTransactionInValidSubType(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", eNach_CreditTransactionInValidSubType());
        return returnTestData(allIncludedGroups, dataProvider);
    }


    @DataProvider(name = "CreditTransactionInValidSubType")
    public static Object[][] CreditTransactionInValidSubType(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("AEPS", dataProviderCreditTransactionInValidSubTypeAEPS());
        dataProvider.put("UPI", dataProviderCreditTransactionInValidSubTypeUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] eNach_CreditTransactionInValidSubType() {
        return new Object[][]{

                {700, DEFAULT_SIT_GL_ACCOUNT, payeeIFSC, ENTITY_ID_8012, APPLICATION_ID_8012, MODE_1},
                {5, DEFAULT_SIT_GL_ACCOUNT, payeeIFSC, ENTITY_ID_8012, APPLICATION_ID_8012, MODE_1},
                {111, DEFAULT_SIT_GL_ACCOUNT, payeeIFSC, ENTITY_ID_8012, APPLICATION_ID_8012, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditTransactionInValidSubTypeAEPS() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();

        return new Object[][]{
                {700, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {5, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1},
                {111, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3132, MODE_1}
        };
    }

    public static Object[][] dataProviderCreditTransactionInValidSubTypeUPI() {
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();

        return new Object[][]{
                {700, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {5, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {111, payeeAccount, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},

                {700, payeeAccount, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {5, payeeAccount, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {111, payeeAccount, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},


                {700, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {5, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {111, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},

                {700, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {5, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {111, SIT_CURRENT_ACCOUNT, payeeIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1}
        };
    }


    @DataProvider(name = "ENachCreditTransactionInvalidCases")
    public static Object[][] ENachCreditTransactionInvalidCases(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] negativeCases = creditTransactionInvalidTypes();

        dataProvider.put("eNach", concat(negativeCases, eNach_Pair()));
        return returnTestData(allIncludedGroups, dataProvider);
    }


    @DataProvider(name = "CreditTransactionInvalidCases")
    public static Object[][] InvalidDataProvider(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] negativeCases = creditTransactionInvalidTypes();

        dataProvider.put("AEPS", concat(negativeCases, AEPSPair()));
        dataProvider.put("UPI", concat(negativeCases, UPIPair()));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] creditTransactionInvalidTypes() {
        return new Object[][]{
                {TRANSACTION, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_TRANSACTION_ERROR_MSG},
                {TRANSACTION, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_TRANSACTION_ERROR_MSG},

                {IDEMPOTENT_KEY, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_IDEMPOTENT_KEY_ERROR_MSG},
                {IDEMPOTENT_KEY, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_IDEMPOTENT_KEY_ERROR_MSG},

                {INVOICE, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_INVOICE_ERROR_MSG},
                {INVOICE, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_INVOICE_ERROR_MSG},

                {CURRENCY, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_CURRENCY_ERROR_MSG_1},
                {CURRENCY, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_CURRENCY_ERROR_MSG_1},
                {CURRENCY, 000, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30503, INVALID_CURRENCY_ERROR_MSG_3},
                {CURRENCY, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {CURRENCY, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_CURRENCY_ERROR_MSG_1},
                {CURRENCY, 65656, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30503, INVALID_CURRENCY_ERROR_MSG_3},
                {CURRENCY, 333.0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30503, INVALID_CURRENCY_ERROR_MSG_3},
                {CURRENCY, 0.356, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30503, INVALID_CURRENCY_ERROR_MSG_3},
                {CURRENCY, -356, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30503, INVALID_CURRENCY_ERROR_MSG_3},

                {METHOD_SUBTYPE, 000, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG},
                {METHOD_SUBTYPE, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {METHOD_SUBTYPE, 333.0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG},
                {METHOD_SUBTYPE, 0.356, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG},
                {METHOD_SUBTYPE, 025.5, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG},
                {METHOD_SUBTYPE, -550, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG},

                {MODE, 000, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},
                {MODE, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {MODE, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {MODE, 6, false, null, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},
                {MODE, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {MODE, "", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {MODE, 7.0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},
                {MODE, -7, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},

                {METHOD, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_METHOD_ERROR_MSG},
                {METHOD, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_METHOD_ERROR_MSG},

                {CAPTURE_METHOD, 000, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30508, INVALID_CAPTURE_METHOD_ERROR_MSG},
                {CAPTURE_METHOD, 3, false, null, HttpStatus.SC_OK, ERROR_CODE_30508, INVALID_CAPTURE_METHOD_ERROR_MSG},
                {CAPTURE_METHOD, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {CAPTURE_METHOD, 7.0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30508, INVALID_CAPTURE_METHOD_ERROR_MSG},
                {CAPTURE_METHOD, 0.1, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30508, INVALID_CAPTURE_METHOD_ERROR_MSG},
                {CAPTURE_METHOD, -1, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30508, INVALID_CAPTURE_METHOD_ERROR_MSG},

                {LIVE_MODE, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_LIVE_MODE_ERROR_MSG},
                {LIVE_MODE, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_LIVE_MODE_ERROR_MSG},
                {LIVE_MODE, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_LIVE_MODE_ERROR_MSG},
                {LIVE_MODE, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {LIVE_MODE, 1.1, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {LIVE_MODE, 0.1, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},

                {APPLICATION_ID, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_APPLICATION_ID_ERROR_MSG},
                {APPLICATION_ID, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_APPLICATION_ID_ERROR_MSG},

                {INITIATING_ENTITY_TIMESTAMP, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_TIMESTAMP_ERROR_MSG},
                {INITIATING_ENTITY_TIMESTAMP, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_TIMESTAMP_ERROR_MSG},
                {INITIATING_ENTITY_TIMESTAMP, "01/11/2019", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {INITIATING_ENTITY_TIMESTAMP, "2020-06-01", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {INITIATING_ENTITY, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_INITIATING_ENTITY_ERROR_MSG},
                {INITIATING_ENTITY, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_INITIATING_ENTITY_ERROR_MSG},

                {ENTITY_ID, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_ENTITY_ERROR_MSG},
                {ENTITY_ID, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_ENTITY_ERROR_MSG},
                {ENTITY_ID, 2435687, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {ENTITY_ID, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_TRAN_MSG},
                {ENTITY_ID, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_ENTITY_ERROR_MSG},
                {ENTITY_ID, 0.8001, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {ENTITY_ID, 234.44, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {ENTITY_ID, -8001, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},

                {AMOUNT, null, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},
                {AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},

                {AMOUNT_NET_AMOUNT, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {AMOUNT_NET_AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {AMOUNT_NET_AMOUNT, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_AMOUNT_ERROR_MSG},
                {AMOUNT_NET_AMOUNT, "", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {AMOUNT_NET_AMOUNT, 0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},
                {AMOUNT_NET_AMOUNT, 0.00, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},
                {AMOUNT_NET_AMOUNT, -1, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},
                {AMOUNT_NET_AMOUNT, -1.1, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30529, INVALID_AMOUNT},


                {AMOUNT_GROSS_AMOUNT, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {AMOUNT_GROSS_AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {AMOUNT_GROSS_AMOUNT, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_AMOUNT_ERROR_MSG},
                {AMOUNT_GROSS_AMOUNT, "", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},

                {PAYEE, null, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30515, INVALID_PAYEE_ERROR_MSG},
                {PAYEE, null, true, ACTION_DELETE, HttpStatus.SC_OK, ERROR_CODE_30515, INVALID_PAYEE_ERROR_MSG},

                {TYPE, null, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},
                {TYPE, null, true, ACTION_DELETE, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},
                {TYPE, "Testing", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, ERROR_CODE_30000, INVALID_VALUE_PAYEE},
                {TYPE, "", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},
                {TYPE, 0, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},
                {TYPE, 6, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},

                //  Issue : Accepting type
                {TYPE, 3.4, true, ACTION_SET, HttpStatus.SC_OK, "", ""},

                {TYPE, 0.6, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},
                {TYPE, -1, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30507, INVALID_PAYEE_TYPE_ERROR_MSG},

                {ACCOUNT_NUMBER, null, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30515, INVALID_PAYEE_ERROR_MSG},
                {ACCOUNT_NUMBER, null, true, ACTION_DELETE, HttpStatus.SC_OK, ERROR_CODE_30515, INVALID_PAYEE_ERROR_MSG},

                // issue : No error
                {ACCOUNT_NUMBER, "$%^%&&*&*(&(*&", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30526, INVALID_PAYEE_ACCOUNT},
                {ACCOUNT_NUMBER, "-30000000031911", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30524, INVALID_ACCOUNT_DETAILS},
                {ACCOUNT_NUMBER, "+30000000031911", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30524, INVALID_ACCOUNT_DETAILS},

                {BANK_IFSC, null, true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30518, INVALID_NON_JBP_ACCOUNT_MSG},
                {BANK_IFSC, null, true, ACTION_DELETE, HttpStatus.SC_OK, ERROR_CODE_30518, INVALID_NON_JBP_ACCOUNT_MSG},
                {BANK_IFSC, "$%^%&&*&*(&(*&", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30518, INVALID_NON_JBP_ACCOUNT_MSG},
                {BANK_IFSC, "-JIOP0000001", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30518, INVALID_NON_JBP_ACCOUNT_MSG},
                {BANK_IFSC, "+JIOP0000001", true, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30518, INVALID_NON_JBP_ACCOUNT_MSG}
        };
    }

    public static Object[][] eNach_Pair() {
        return new Object[][]{
                {SUB_TYPE_576, ENTITY_ID_8012, APPLICATION_ID_8012}
        };
    }

    public static Object[][] AEPSPair() {
        return new Object[][]{
                {SUB_TYPE_576, ENTITY_ID_8001, APPLICATION_ID_3132},
                {SUB_TYPE_525, ENTITY_ID_8001, APPLICATION_ID_3132},
                {SUB_TYPE_523, ENTITY_ID_8001, APPLICATION_ID_3132}
        };
    }

    public static Object[][] UPIPair() {
        return new Object[][]{
                {SUB_TYPE_580, ENTITY_ID_8001, APPLICATION_ID_3133},
                {SUB_TYPE_580, ENTITY_ID_9000, APPLICATION_ID_9000}
        };
    }


    @DataProvider(name = "CreditTransactionReversalInvalidCases")
    public static Object[][] CreditTransactionReversalInvalidCases(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] negativeCases = creditTransactionReversalInvalidTypes();

        dataProvider.put("AEPS", concat(negativeCases, AEPSPair()));
        dataProvider.put("UPI", concat(negativeCases, UPIPair()));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] creditTransactionReversalInvalidTypes() {
        return new Object[][]{
                {APPLICATION_ID, 1234, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_50011, INVALID_TRANSACTION_NOT_FOUND_MSG},
                {APPLICATION_ID, 1234, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_50011, INVALID_TRANSACTION_NOT_FOUND_MSG},

                {ENTITY_ID, 1234, false, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},
                {ENTITY_ID, 1234, false, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG},

                {ORIGINAL_ID, "1234", false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_50011, INVALID_TRANSACTION_NOT_FOUND_MSG},
                {ORIGINAL_ID, "1234", false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_50011, INVALID_TRANSACTION_NOT_FOUND_MSG},

                //  Issue : Working fine for reversal
                {TYPE, 0, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},
                {TYPE, 5, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},

                //  Issue : Working fine for reversal
                {AMOUNT_NET_AMOUNT, 2.0, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30520, INVALID_AMOUNT},
                {AMOUNT_NET_AMOUNT, 2.0, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30520, INVALID_AMOUNT},

                {METHOD_TYPE, TYPE_DEBIT, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30524, INVALID_ACCOUNT_DETAILS},
                {METHOD_TYPE, TYPE_CREDIT, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30524, INVALID_ACCOUNT_DETAILS},

                //  Issue : No error message
                {METHOD_SUBTYPE, SUB_TYPE_DEBIT_REVERSAL, false, ACTION_SET, HttpStatus.SC_OK, "", ""},
                {METHOD_SUBTYPE, SUB_TYPE_DEBIT_REVERSAL, false, ACTION_SET, HttpStatus.SC_OK, "", ""},

                {MODE, 9, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},
                {MODE, 5, false, ACTION_SET, HttpStatus.SC_OK, ERROR_CODE_30509, INVALID_MODE_ERROR_MSG},

                //  Issue : Working fine
                {ACCOUNT_NUMBER, "30000000031911", true, ACTION_SET, HttpStatus.SC_OK, "", ""},
                {ACCOUNT_NUMBER, "30000000031911", true, ACTION_SET, HttpStatus.SC_OK, "", ""}
        };
    }

    /*
     * Data Provider for TestCase: TestDebitTxnInvalidHeader
     * */
    @DataProvider(name = "CreditTxnInvalidHeader")
    public static Object[][] CreditTxnInvalidHeader(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", concat(dataProviderCreditTransactionENach(), invalidHeaderData()));
        dataProvider.put("sanity", concat(dataProviderCreditTransactionENach(), invalidHeaderData()));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] invalidHeaderData() {
        return new Object[][]{
                {"X-API-KEY", "C584F4DA62A767731F"},
                {"X-API-KEY", null },

                {"X-CHANNEL-ID", "5555"},
                {"X-CHANNEL-ID", null },
        };
    }
}
