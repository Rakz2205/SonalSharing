package DataProviders;

import base.SetUp;
import org.apache.http.HttpStatus;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import utils.CommonMethods;

import java.util.*;

public class DebitTxnDataProvider extends SetUp {

    static String payerAccount;
    static String payerIFSC;
    static String payeeAccount;
    static String payeeIFSC;

    public static Object[][] returnTestData(List<String> groups, Map<String, Object[][]> dataSet) {
        if (groups.contains("All")) {
            return getTestData(dataSet);
        } else {
            Map<String, Object[][]> dataMap = new HashMap<>();
            for (String key : dataSet.keySet()) {
                if (groups.contains(key))
                    dataMap.put(key, dataSet.get(key));
            }
            return getTestData(dataMap);
        }
    }

    private static int getSize(Map<String, Object[][]> dataSet) {
        int count = 0;
        for (String str : dataSet.keySet()) {
            count = count + dataSet.get(str).length;
        }
        return count;
    }

    private static Object[][] getTestData(Map<String, Object[][]> dataSet) {
        Object[][] result = new Object[getSize(dataSet)][];
        int destPos = 0;

        for (String str : dataSet.keySet()) {
            System.arraycopy(dataSet.get(str), 0, result, destPos, dataSet.get(str).length);
            destPos = destPos + dataSet.get(str).length;
        }
        return result;
    }

    //merge two 2D arrays, row-wise
    public static Object[][] concat(Object[][] var1, Object[][] var2) {
        List<Object[]> mergeredList = new LinkedList<Object[]>();
        for (Object[] o : var1) {
            for (Object[] o2 : var2) {
                mergeredList.add(concatAll(o, o2));
            }
        }
        return mergeredList.toArray(new Object[0][0]);
    }

    @SafeVarargs
    public static <T> T[] concatAll(T[] first, T[]... rest) {
        //calculate the total length of the final object array after the concat
        int totalLength = first.length;
        for (T[] array : rest) {
            totalLength += array.length;
        }
        //copy the first array to result array and then copy each array completely to result
        T[] result = Arrays.copyOf(first, totalLength);
        int offset = first.length;
        for (T[] array : rest) {
            System.arraycopy(array, 0, result, offset, array.length);
            offset += array.length;
        }
        return result;
    }

    /*
    * eNACH- entity, applicationID,entityId & Mode pair
    * */
    @DataProvider(name = "eNachPair")
    public static Object[][] eNachPair() {
        return new Object[][]{
                {SUB_TYPE_576, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1}
        };
    }

    /*
     * UPI- entity, applicationID,entityId & Mode pair
     * */
    @DataProvider(name = "UPIdata")
    public static Object[][] UPIPair() {
        return new Object[][]{
                {SUB_TYPE_580, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1},
                {SUB_TYPE_580, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1}
        };
    }

    /*
     * Data Provider for TestCase: TestDebitTxnWithVariousSubType
     * */
    @DataProvider(name = "DebitTransactionData")
    public static Object[][] DebitTransactionData(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", concat(eNachPair(), accountData()));
        dataProvider.put("UPI", concat(UPIPair(), accountData()));
        dataProvider.put("sanity", dataProviderSanity());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    /*
     * eNACH Sanity data provider -entity id 8011 pair with application ID and subtype
     * */
    @DataProvider(name = "dataProviderSanity")
    public static Object[][] dataProviderSanity() {
        return new Object[][]{
                //enach positive data
                {SUB_TYPE_576, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1, DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC},
                {SUB_TYPE_576, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1, SIT_CURRENT_ACCOUNT, SIT_CURRENT_ACCOUNT_BANK_IFSC},

                {SUB_TYPE_580, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1, DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC},

                {SUB_TYPE_580, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1, DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC}


        };
    }

    /*
     * Data Provider for TestCase: TestDebitTxnErrorInvalidSubType
     * */
    @DataProvider(name = "InValidSubTypeDpr")
    public static Object[][] InValidSubTypeData(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", InValidSubTypeNach());
        dataProvider.put("UPI", InValidSubTypeUPI());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    /*
     * eNACH- entity id 8011 pair with application ID and invalid subtype
     * */
    @DataProvider(name = "InValidSubTypeNach")
    public static Object[][] InValidSubTypeNach() {
        return new Object[][]{
                {700, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1},
                {0, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1},
                {-1, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1},
        };
    }

    /*
     * UPI- entity pair with application ID and invalid subtype
     * */
    @DataProvider(name = "InValidSubTypeUPI")
    public static Object[][] InValidSubTypeUPI() {
        return new Object[][]{
                {700, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1},
                {5, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1},
                {111, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1},

                {700, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1},
                {5, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1},
                {111, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1}
        };
    }

    /*
     * Data Provider for TestCase: TestDebitReversal
     * */
    @DataProvider(name = "DebitReversalDpr")
    public static Object[][] DebitReversalDpr(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        Object[][] payerDetails = payerAccountAndIFsc();

        dataProvider.put("eNach", concat(eNachPair(), payerDetails));
        dataProvider.put("UPI", concat(UPIPair(),accountData()));
        dataProvider.put("sanity", DebitReversalSanity());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    /*
    * Test data for payer account number and IFSC code.
    * */
    @DataProvider(name = "payerAccountAndIFsc")
    public static Object[][] payerAccountAndIFsc(){

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{
                {payerAccount, payerIFSC}
        };
    }

    @DataProvider(name = "DebitReversalSanity")
    public static Object[][] DebitReversalSanity() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{
                // enach data sanity
                {SUB_TYPE_576, APPLICATION_ID_8011, ENTITY_ID_8011, MODE_1, payerAccount, payerIFSC},
                {SUB_TYPE_580, APPLICATION_ID_3133, ENTITY_ID_8001, MODE_1, payerAccount, payerIFSC},
                {SUB_TYPE_580, APPLICATION_ID_9000, ENTITY_ID_9000, MODE_1, payerAccount, payerIFSC}
        };
    }

    /*
     * Data Provider for TestCase: TestDebitReversalForReversedTxn
     * */
    @DataProvider(name = "DebitReversalForReversedTx")
    public static Object[][] DebitReversalForReversedTx(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        Object[][] payerDetails = payerAccountAndIFsc();

        //dataProvider.put("eNach", DebitReversalNACH());
        dataProvider.put("eNach", concat(eNachPair(), payerDetails));
        dataProvider.put("UPI", concat(UPIPair(), accountData()));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    /*
     * Data Provider for TestCase: TestDebitReversalWithInvalidMethod
     * */
    @DataProvider(name = "ReversalWithInvalidMethod")
    public Object[][] ReversalWithInvalidMethod(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] invalidData = reversalInvalidMethod();

        //dataProvider.put("eNach", reversalInvalidMethodNACH());
        dataProvider.put("eNach", concat(eNachPair(), invalidData));
        dataProvider.put("UPI", concat(UPIPair(), invalidData));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    @DataProvider(name = "reversalInvalidMethod")
    public Object[][] reversalInvalidMethod() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{
                { payerAccount, payerIFSC, TYPE_CREDIT },
                { payerAccount, payerIFSC, TYPE_DEBIT },
                { payerAccount, payerIFSC, "100100"},
        };
    }

    /*
     * Data Provider for TestCase: TestDebitReversalWithInvalidEntityOrAppID
     * */
    @DataProvider(name = "DebitReversalInvalidId")
    public Object[][] DebitReversalInvalidId(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] invalidData = ReversalInvalidId();

        //dataProvider.put("eNach", ReversalInvalidIdNACH());
        dataProvider.put("eNach", concat(eNachPair(), invalidData));
        dataProvider.put("UPI", concat(UPIPair(), invalidData));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    @DataProvider(name = "ReversalInvalidId")
    public Object[][] ReversalInvalidId() {

        return new Object[][]{
                {APPLICATION_ID, INVALID_APP_ID_1111},
                {ENTITY_ID, INVALID_ENTITY_ID_9999},
        };
    }

    @DataProvider(name = "InvalidDataProvider")
    public static Object[][] InvalidDataProvider(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        Object[][] negativeCases = DebitTransactionInvalidTypes();

        //dataProvider.put("eNach", concat(eNachPair(), negativeCases));
        dataProvider.put("eNach", concat(eNachPair(), negativeCases));
        dataProvider.put("UPI", concat(UPIPair(), negativeCases));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    /**
     * params to be given in data provider
     * String: invalidParamCase (parameter being modified)
     * Object: invalidValue (parameter value to be modified to)
     * boolean: modifySerialization (true: to change value after serialization)
     * String: action (ACTION_SET/ACTION_DELETE, valid only if modifySerialization = true)
     * int: statusCode (expected response of these params)
     * String: error messge expected
     * String: error code expected
     */
    @DataProvider(name = "DebitTransactionInvalidTypes")
    public static Object[][] DebitTransactionInvalidTypes() {
        return new Object[][]{
                //invalid test data: transaction
                {TRANSACTION, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_TRANSACTION_ERROR_MSG, ERROR_CODE_30000},
                {TRANSACTION, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_TRANSACTION_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: Idempotent Key
                {IDEMPOTENT_KEY, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_IDEMPOTENT_KEY_ERROR_MSG, ERROR_CODE_30000},
                //{IDEMPOTENT_KEY, "4.", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST}, unable to set this value!
                {IDEMPOTENT_KEY, "", false, null, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},

                //invalid test data: invoice
                {INVOICE, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_INVOICE_ERROR_MSG, ERROR_CODE_30000},
                {INVOICE, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_INVOICE_ERROR_MSG, ERROR_CODE_30000},
                {INVOICE, "", true, ACTION_SET, HttpStatus.SC_OK, INVALID_INVOICE_ERROR_MSG, ERROR_CODE_30000},
                {INVOICE, " ", true, ACTION_SET, HttpStatus.SC_OK, INVALID_INVOICE_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: currency
                {CURRENCY, 1, false, null, HttpStatus.SC_OK, INVALID_CURRENCY_ERROR_MSG_3, ERROR_CODE_30503},
                {CURRENCY, 0, false, null, HttpStatus.SC_OK, INVALID_CURRENCY_ERROR_MSG_3, ERROR_CODE_30503},
                {CURRENCY, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_CURRENCY_ERROR_MSG_1, ERROR_CODE_30000},
                {CURRENCY, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_CURRENCY_ERROR_MSG_1, ERROR_CODE_30000},
                {CURRENCY, -356, false, null, HttpStatus.SC_OK, INVALID_CURRENCY_ERROR_MSG_3, ERROR_CODE_30503},
                {CURRENCY, "-356", true, ACTION_SET, HttpStatus.SC_OK, INVALID_CURRENCY_ERROR_MSG_3, ERROR_CODE_30503},
                {CURRENCY, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_CURRENCY_ERROR_MSG_1, ERROR_CODE_30000},
                {CURRENCY, " ", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_CURRENCY_ERROR_MSG_1, ERROR_CODE_30000},

                //invalid test data: TIMESTAMP
                {INITIATING_ENTITY_TIMESTAMP, "2000-05-11T13:44:09.204Z", false, null, HttpStatus.SC_OK, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000}, //SHOULD WE ACEPT OLD TRANSACTION DATE?
                {INITIATING_ENTITY_TIMESTAMP, "2020-06-11 13:44:09.204", false, null, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, "2000/05/11T13:44:09.204Z", false, null, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, "", false, null, HttpStatus.SC_BAD_REQUEST, INVALID_TIMESTAMP_ERROR_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, "     ", false, null, HttpStatus.SC_BAD_REQUEST, INVALID_TIMESTAMP_ERROR_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, "TIMESTAMP", false, null, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_TIMESTAMP_ERROR_MSG, ERROR_CODE_30000},
                {INITIATING_ENTITY_TIMESTAMP, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_TIMESTAMP_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: Mode
                {MODE, 5, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, 0, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, -1, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, -2, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, -3, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, -4, false, null, HttpStatus.SC_OK, INVALID_MODE_ERROR_MSG, ERROR_CODE_30509},
                {MODE, "1.01", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},

                {MODE, "  ", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {MODE, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {MODE, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},

                //invalid test data: TYPE
                {METHOD_TYPE, 0, false, null, HttpStatus.SC_OK, INVALID_METHOD_TYPE_MSG_1, ERROR_CODE_30504},
                {METHOD_TYPE, "111.0", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {METHOD_TYPE, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_METHOD_TYPE_MSG_2, ERROR_CODE_30000},
                {METHOD_TYPE, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_METHOD_TYPE_MSG_2, ERROR_CODE_30000},
                {METHOD_TYPE, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_METHOD_TYPE_MSG_2, ERROR_CODE_30000},

                //invalid test data: subType
                {METHOD_SUBTYPE, 0, false, null, HttpStatus.SC_OK, INVALID_SUBTYPE_ERROR_MSG, ERROR_CODE_30505},
                //{METHOD_SUBTYPE, null, true, ACTION_SET, HttpStatus.SC_OK, INVALID_SUBTYPE_ERROR_MSG, ERROR_CODE_30505},
                {METHOD_SUBTYPE, "testValue", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {METHOD_SUBTYPE, 333.0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_SUBTYPE_ERROR_MSG, ERROR_CODE_30505},
                {METHOD_SUBTYPE, 0.111, true, ACTION_SET, HttpStatus.SC_OK, INVALID_SUBTYPE_ERROR_MSG, ERROR_CODE_30505},
                //{METHOD_SUBTYPE, null, true, ACTION_DELETE, HttpStatus.SC_OK, INVALID_SUBTYPE_ERROR_MSG, ERROR_CODE_30503},

                //invalid test data: captureMethod
                {CAPTURE_METHOD, 0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, "", true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, " ", true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, "testValue", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
                {CAPTURE_METHOD, 7.0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, 0.1, true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, null, true, ACTION_DELETE, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},
                {CAPTURE_METHOD, null, true, ACTION_SET, HttpStatus.SC_OK, INVALID_CAPTURE_METHOD_ERROR_MSG, ERROR_CODE_30508},

                //invalid test data: LiveMode
//                {LIVE_MODE, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_LIVE_MODE_ERROR_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_LIVE_MODE_ERROR_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_LIVE_MODE_ERROR_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, "testValue", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, 1, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, 0, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},
//                {LIVE_MODE, "true false", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_TRAN_MSG, ERROR_CODE_30000},

                //invalid test data: Application Id
                {APPLICATION_ID, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_APPLICATION_ID_ERROR_MSG, ERROR_CODE_30000},
                {APPLICATION_ID, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, INVALID_APPLICATION_ID_ERROR_MSG, ERROR_CODE_30000},
                {APPLICATION_ID, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_APPLICATION_ID_ERROR_MSG, ERROR_CODE_30000},
                {APPLICATION_ID, " ", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_APPLICATION_ID_ERROR_MSG, ERROR_CODE_30000},
                {APPLICATION_ID, 0, true, ACTION_SET, HttpStatus.SC_OK, TRANSACTION_NOT_PERMITTED_ERROR_MSG, ERROR_CODE_21005},
                {APPLICATION_ID, 3132.1, true, ACTION_SET, HttpStatus.SC_OK, INVALID_APPLICATION_ID_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: Callback URL
//                {CALLBACK_URL, null, true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, "", ""},
//                {CALLBACK_URL, null, true, ACTION_DELETE, HttpStatus.SC_BAD_REQUEST, "", ""},
//                {CALLBACK_URL, "http://", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, "", ""},
//                {CALLBACK_URL, "https://", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, "", ""},
//                {CALLBACK_URL, "", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, "", ""},
//                {CALLBACK_URL, "    ", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, "", ""},

                //invalid test data: Amount Object
                {AMOUNT, null, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},

                //invalid test data: Net Amount
                {AMOUNT_NET_AMOUNT, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_NET_AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_NET_AMOUNT, "1.1.1", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_AMOUNT_ERROR_MSG, ERROR_CODE_30000},
                {AMOUNT_NET_AMOUNT, "-1", true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_NET_AMOUNT, 0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_NET_AMOUNT, 0.00, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_NET_AMOUNT, -1, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_NET_AMOUNT, 100001, true, ACTION_SET, HttpStatus.SC_OK, INSUFFICIENT_FUNDS_ERROR_MSG, ERROR_CODE_21004},
                {AMOUNT_NET_AMOUNT, "", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_NET_AMOUNT, "   ", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_NET_AMOUNT, "GrossNull", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_AMOUNT_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: Gross Amount
                {AMOUNT_GROSS_AMOUNT, "   ", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_GROSS_AMOUNT, null, true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_GROSS_AMOUNT, null, true, ACTION_DELETE, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_GROSS_AMOUNT, "1.1.1", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_AMOUNT_ERROR_MSG, ERROR_CODE_30000},
                {AMOUNT_GROSS_AMOUNT, "-1", true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_GROSS_AMOUNT, 0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_GROSS_AMOUNT, 0.00, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_GROSS_AMOUNT, -1.0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_AMOUNT, ERROR_CODE_30529},
                {AMOUNT_GROSS_AMOUNT, 100001, true, ACTION_SET, HttpStatus.SC_OK, "", ""},
                {AMOUNT_GROSS_AMOUNT, "", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},
                {AMOUNT_GROSS_AMOUNT, "   ", true, ACTION_SET, HttpStatus.SC_INTERNAL_SERVER_ERROR, INVALID_SOME_TECHNICAL_ERROR_MSG, ERROR_CODE_6011},

                //invalid test data: Payer Type
                {TYPE, 0, true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, 5, true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, -1, true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, "", true, ACTION_DELETE, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, " ", true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, null, true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, 1.1, true, ACTION_SET, HttpStatus.SC_OK, INVALID_PAYER_TYPE_ERROR_MSG, ERROR_CODE_30506},
                {TYPE, "1.1", true, ACTION_SET, HttpStatus.SC_BAD_REQUEST, INVALID_VALUE_PAYER_ERROR_MSG, ERROR_CODE_30000},

                //invalid test data: Payer Object
                {PAYER, null, true, ACTION_SET, HttpStatus.SC_OK, PAYER_DETAILS_REQUIRED_ERROR_MSG, ERROR_CODE_30514},
                {PAYER, null, true, ACTION_DELETE, HttpStatus.SC_OK, PAYER_DETAILS_REQUIRED_ERROR_MSG, ERROR_CODE_30514},

                //invalid test data: Payer Object
                {BANK_IFSC, null, true, ACTION_SET, HttpStatus.SC_OK, INVALID_ACCOUNT_DETAILS, ERROR_CODE_30524},
                {BANK_IFSC, null, true, ACTION_DELETE, HttpStatus.SC_OK, INVALID_ACCOUNT_DETAILS, ERROR_CODE_30524},
                {BANK_IFSC, "", true, ACTION_SET, HttpStatus.SC_OK, INVALID_ACCOUNT_DETAILS, ERROR_CODE_30524}
        };
    }

    @DataProvider(name = "AccountNumberProvider")
    public static Object[][] AccountNumberProvider(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();
        Object[][] accountData = accountData();

        //dataProvider.put("eNach", accountDataNACH());
        dataProvider.put("eNach", concat(eNachPair(), accountData));
        dataProvider.put("UPI", concat(UPIPair(), accountData));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] accountData() {
        return new Object[][]{
                {DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC},
                {SIT_CURRENT_ACCOUNT, SIT_CURRENT_ACCOUNT_BANK_IFSC},
        };
    }

    @DataProvider(name = "FreezeAccountDPr")
    public static Object[][] FreezeAccountDPr(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Object[][] dataFreezeCases = debitFreezeAccountData();

        Map<String, Object[][]> dataProvider = new HashMap<>();

        //dataProvider.put("eNach", concat(eNachPair(), dataFreezeCases));
        dataProvider.put("eNach", concat(eNachPair(), debitFreezeAccountData()));
        dataProvider.put("UPI", concat(UPIPair(), dataFreezeCases));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] debitFreezeAccountData() {
        return new Object[][]{
                {DEFAULT_SIT_DEBIT_FREEZE_ACCOUNT, DEFAULT_SIT_DEBIT_FREEZE_BANK_IFSC, DEBIT_FREEZE},
                {DEFAULT_SIT_TOTAL_FREEZE_ACCOUNT, DEFAULT_SIT_TOTAL_FREEZE_BANK_IFSC, TOTAL_FREEZE},

                //{SIT_CURRENT_TOTAL_FREEZE_ACCOUNT, SIT_CURRENT_TOTAL_FREEZE_ACCOUNT_BANK_IFSC, TOTAL_FREEZE},
                {SIT_CURRENT_DEBIT_FREEZE_ACCOUNT, SIT_CURRENT_DEBIT_FREEZE_ACCOUNT_BANK_IFSC, DEBIT_FREEZE}
        };
    }

    @DataProvider(name = "NeftOutward")
    public static Object[][] OutWardNeftData(ITestContext context){
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Object[][] payerPayee = payerAndPayeeData();

        Map<String, Object[][]> dataProvider = new HashMap<>();
        dataProvider.put("eNach1", concat(eNachPair(),payerPayee ));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] payerAndPayeeData() {
        return new Object[][]{
                {DEFAULT_SIT_GL_ACCOUNT_1, payeeIFSC, "80100000001", "SBIN0004557"},
                {DEFAULT_SIT_GL_ACCOUNT_2, payeeIFSC, "80100000002", "SBIN0004557"},
        };
    }

    @DataProvider(name = "closedAccountData")
    public static Object[][] closedAccountData(ITestContext context){
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payeeIFSC = CommonMethods.getDefaultPayeeBankIFSCNumber();

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Object[][] closedAccount = dormantAndClosedAccount();

        Map<String, Object[][]> dataProvider = new HashMap<>();
        dataProvider.put("eNach", concat(eNachPair(),closedAccount ));
        dataProvider.put("UPI", concat(UPIPair(),closedAccount));

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] dormantAndClosedAccount() {
        return new Object[][]{
                {SIT_CURRENT_CLOSED_ACCOUNT, SIT_CURRENT_CLOSED_ACCOUNT_BANK_IFSC, CLOSED_ACCOUNT},
                {DEFAULT_SIT_CLOSED_ACCOUNT, DEFAULT_SIT_CLOSED_BANK_IFSC, CLOSED_ACCOUNT},

                {SIT_DORMANT_ACCOUNT, SIT_DORMANT_ACCOUNT_BANK_IFSC, DORMANT_ACCOUNT},
                {SIT_CURRENT_DORMANT_ACCOUNT, SIT_CURRENT_DORMANT_ACCOUNT_BANK_IFSC, DORMANT_ACCOUNT}

        };
    }

    /*
     * Data Provider for TestCase: TestDebitTxnInvalidHeader
     * */
    @DataProvider(name = "DebitTxnInvalidHeader")
    public static Object[][] DebitTxnInvalidHeader(ITestContext context) {

        List<String> allIncludedGroups = Arrays.asList(context.getIncludedGroups());
        Map<String, Object[][]> dataProvider = new HashMap<>();

        dataProvider.put("eNach", concat(eNachPair(), invalidHeaderData()));
        dataProvider.put("UPI", concat(UPIPair(), invalidHeaderData()));
        dataProvider.put("sanity", dataProviderSanity());

        return returnTestData(allIncludedGroups, dataProvider);
    }

    public static Object[][] invalidHeaderData() {
        return new Object[][]{
                {DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC, "X-API-KEY", "C584F4DA62A767731F"},
                {SIT_CURRENT_ACCOUNT, SIT_CURRENT_ACCOUNT_BANK_IFSC, "X-API-KEY", null },

                {DEFAULT_SIT_PAYER_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC, "X-CHANNEL-ID", "5555"},
                {SIT_CURRENT_ACCOUNT, SIT_CURRENT_ACCOUNT_BANK_IFSC, "X-CHANNEL-ID", null },
        };
    }

}


