package transactions;

import base.ConnectionSetup;
import client.account.GetBalanceBL;
import client.transaction.AuthCaptureCancelBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.util.Map;

public class AuthCaptureCancel extends AuthCaptureCancelBL {

    String payerAccount;
    String payerIFSC;

    @Test(dataProvider = "TestDataProviderAuthTransaction", groups = {"UPI", "All"})
    public void TestAuthTransaction(String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(AuthCaptureCancel.class, String.format("Auth transaction positive flow."));

        //  create payload
        String payload = createAuthTransactionPayload(accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get balance before performing auth transaction
        Map<String, Double> beforeGetBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setAuthCaptureCancelTransactionHeader();

        //  post request
        Response authTransactionResponse = postAuthCaptureCancelTransaction(payload, header);

        // validate api status code
        validateAuthCaptureCancelTransactionResponseStatus(authTransactionResponse, HttpStatus.SC_OK);

        //  get balance after performing auth transaction
        Map<String, Double> afterOnHoldBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  validate the response
        validateAuthCaptureCancelTransactionResponse(authTransactionResponse, beforeGetBalance, afterOnHoldBalance);
    }

    @DataProvider(name = "TestDataProviderAuthTransaction")
    public Object[][] TestDataProviderAuthTransaction() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{

                {payerAccount, payerIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {payerAccount, payerIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1}
        };
    }

    @Test(dataProvider = "TestDataProviderCancelTransaction", groups = {"UPI", "All"})
    public void TestCancelTransaction(String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(AuthCaptureCancel.class, String.format("Cancel transaction positive flow."));

        //  create payload
        String payload = createAuthTransactionPayload(accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get balance before performing auth transaction
        Map<String, Double> beforeGetBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setAuthCaptureCancelTransactionHeader();

        //  post request
        Response authTransactionResponse = postAuthCaptureCancelTransaction(payload, header);

        // validate api status code
        validateAuthCaptureCancelTransactionResponseStatus(authTransactionResponse, HttpStatus.SC_OK);

        //  get balance after performing auth transaction
        Map<String, Double> afterGetBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  validate the response
        validateAuthCaptureCancelTransactionResponse(authTransactionResponse, beforeGetBalance, afterGetBalance);

        //  create cancel payload
        String cancelPayload = createCaptureCancelTransactionPayload(TYPE_CANCEL);

        //  post request
        Response cancelTransactionResponse = postAuthCaptureCancelTransaction(cancelPayload, header);

        // validate api status code
        validateAuthCaptureCancelTransactionResponseStatus(cancelTransactionResponse, HttpStatus.SC_OK);

        //  get balance after performing cancel transaction
        Map<String, Double> onHoldBalanceAfterCancelTransaction = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  validate the response
        validateAuthCaptureCancelTransactionResponse(cancelTransactionResponse, beforeGetBalance, onHoldBalanceAfterCancelTransaction);
    }

    @DataProvider(name = "TestDataProviderCancelTransaction")
    public Object[][] TestDataProviderCancelTransaction() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{
                {payerAccount, payerIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {payerAccount, payerIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1}
        };
    }

    @Test(dataProvider = "TestDataProviderCaptureTransaction", groups = {"UPI", "All"})
    public void TestCaptureTransaction(String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(AuthCaptureCancel.class, String.format("Capture transaction positive flow."));

        //  create payload
        String payload = createAuthTransactionPayload(accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get balance before performing auth transaction
        Map<String, Double> beforeGetBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setAuthCaptureCancelTransactionHeader();

        //  post request
        Response authTransactionResponse = postAuthCaptureCancelTransaction(payload, header);

        // validate api status code
        validateAuthCaptureCancelTransactionResponseStatus(authTransactionResponse, HttpStatus.SC_OK);

        //  get balance after performing auth transaction
        Map<String, Double> afterGetBalance = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  validate the response
        validateAuthCaptureCancelTransactionResponse(authTransactionResponse, beforeGetBalance, afterGetBalance);

        //  create cancel payload
        String capturePayload = createCaptureCancelTransactionPayload(TYPE_CAPTURE);

        //  post request
        Response captureTransactionResponse = postAuthCaptureCancelTransaction(capturePayload, header);

        // validate api status code
        validateAuthCaptureCancelTransactionResponseStatus(captureTransactionResponse, HttpStatus.SC_OK);

        //  get balance after performing cancel transaction
        Map<String, Double> balanceAfterCaptureTransaction = new GetBalanceBL().postGetBalanceWithOnHoldBalance(accountNumber);

        //  validate the response
        validateAuthCaptureCancelTransactionResponse(captureTransactionResponse, afterGetBalance, balanceAfterCaptureTransaction);
    }

    @DataProvider(name = "TestDataProviderCaptureTransaction")
    public Object[][] TestDataProviderCaptureTransaction() {
        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();
        return new Object[][]{
                {"30000000028570", "JIOP0000001", ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {"30000000040880", "JIOP0000001", ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {"30000000010612", "JIOP0000001", ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},
                {payerAccount, payerIFSC, ENTITY_ID_8001, APPLICATION_ID_3133, MODE_1},

                {"30000000028570", "JIOP0000001", ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {"30000000040880", "JIOP0000001", ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {"30000000010612", "JIOP0000001", ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1},
                {payerAccount, payerIFSC, ENTITY_ID_9000, APPLICATION_ID_9000, MODE_1}
        };
    }

    @BeforeMethod(groups = {"UPI", "All"})
    public void beforeSetup() {
        isStore = false;
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"UPI", "All"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
