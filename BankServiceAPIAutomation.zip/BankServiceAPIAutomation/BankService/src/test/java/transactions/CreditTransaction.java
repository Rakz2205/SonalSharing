package transactions;

import DataProviders.CreditTxnDataProvider;
import base.ConnectionSetup;
import client.account.GetBalanceBL;
import client.transaction.CreditTransactionBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.lang.reflect.Method;
import java.util.Map;

public class CreditTransaction extends CreditTransactionBL {

    @Test(dataProvider = "CreditTransaction", groups = {"UPI"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransactionWithNarration(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        String amountBeforeCredit, amountAfterCredit;

        Reporter.initiateTestReport(CreditTransaction.class, String.format("Credit transaction with Narration. Subtype %s", subType));

        //  create payload
        createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  generate description
        String transactionStatementDescriptor = "TRAN_" + accountNumber + "_" + bankIFSC;

        //  create updated payload
        String payload = addNarrationInTransaction(transactionStatementDescriptor);

        //  get total balance before performing credit transaction
        amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  get total balance before performing credit transaction
        amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountBeforeCredit, amountAfterCredit);
    }


    @Test(dataProvider = "CreditTransaction", groups = {"UPI", "AEPS", "All", "sanity"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransaction(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        String amountBeforeCredit = null, amountAfterCredit = null;

        Reporter.initiateTestReport(CreditTransaction.class, String.format("Positive flow Credit transaction with subtype %s", subType));

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing credit transaction
        amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  get total balance before performing credit transaction
        amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountBeforeCredit, amountAfterCredit);
    }

    @Test(dataProvider = "CreditTransaction", groups = {"UPI", "AEPS", "All", "sanity"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversal(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class, "Credit transaction and reversal with subtype : " + subType);

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        String reversalPayload = createCreditReversalPayload();

        //  post request
        Response creditTransactionReversalResponse = postCreditTransaction(reversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit reversal
        String amountAfterReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountAfterCredit, amountAfterReversal);

    }

    @Test(dataProvider = "CreditTransactionIfKeyExist", groups = {"AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testDataProviderCreditTransactionIfKeyExist(Map<Object, Object> testData) {

        Reporter.initiateTestReport(CreditTransaction.class, String.format("Credit transaction if idempotent key %s already present.", testData.get("IDEMPOTENT_KEY")));

        //  create payload
        String payload = createCreditTransactionPayload((String) testData.get("IDEMPOTENT_KEY"), (String) testData.get("INVOICE"),
                Integer.parseInt((String) testData.get("APPLICATION_ID")));

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse);
    }

    @Test(dataProvider = "CreditTransactionWithFreezeAccount", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransactionWithFreezeAccount(int subType, String accountNumber, String bankIFSC, int entityId,
                                                       int applicationId, int mode, String errorCode, String errorMessage) {

        Reporter.initiateTestReport(CreditTransaction.class, "Credit transaction with freeze accounts " + accountNumber);

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        //  get total balance before performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        // Validate that transaction failed
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, errorCode, errorMessage);

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeCredit, amountAfterCredit);
    }

    @Test(dataProvider = "CreditTransactionInValidSubType", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTxnErrorInvalidSubType(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class, "Test Credit Transaction With Invalid SubType: " + subType);

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        //  validate response
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG);

    }


    @Test(dataProvider = "CreditTransactionInvalidCases", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransactionInvalidTypes(String invalidParamCase, Object invalidValue,
                                                  boolean modifySerialization, String action, int statusCode,
                                                  String errorCode, String errorMessage, int subType, int entityId, int applicationId) {

        String originalAccountNumber = null, amountAfterCredit = null;

        Reporter.initiateTestReport(CreditTransaction.class, "Test Credit transaction with invalid :" + invalidParamCase);

        //  create payload
        createCreditTransactionPayload(subType, applicationId, entityId);

        // modify the payload
        String modifiedPayload = modifyCreditTxnPayload(invalidParamCase, invalidValue, modifySerialization, action);

        //  get account number
        originalAccountNumber = transactionEntity.getPayee().getAccountNumber();

        //  get total balance before performing debit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(originalAccountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(modifiedPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, statusCode);

        //  get total balance before performing debit transaction
        amountAfterCredit = new GetBalanceBL().postGetBalance(originalAccountNumber);

        // validate failure status, code and Message
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, errorCode, errorMessage);

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeCredit, amountAfterCredit);
    }

    //TODO: Need to check with Chandra,
    // Issue, user can able to perform reversal for Failed Transactions
    @Test(dataProvider = "CreditReversalForFailedCreditTransactions", groups = {"AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversalForFailedCreditTxn(Map<Object, Object> testData) {

        Reporter.initiateTestReport(CreditTransaction.class, String.format("Credit reversal for failed credit transactions with subtype %s1. Original Transaction ID is : %s", testData.get("METHOD_SUB_TYPE"), testData.get("ORIGINAL_TRANSACTION_ID")));

        //  create payload
        String payload = createCreditReversalPayload(testData);

        //  get account number
        String getAccountNumber = transactionEntity.getPayee().getAccountNumber();

        //  check balance before performing reversal
        String amountBeforeReversal = new GetBalanceBL().postGetBalance(getAccountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  check balance after performing reversal
        String amountAfterReversal = new GetBalanceBL().postGetBalance(getAccountNumber);

        //  validate the response
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, null, null);

        //  validate balance
        Assert.assertEquals(amountBeforeReversal, amountAfterReversal);

    }


    @Test(dataProvider = "CreditTransaction", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testDebitReversalAfterCreditTransaction(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class, "Debit reversal after credit transaction reversal with subtype : " + subType);

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload();

        //  post reversal request
        Response creditTransactionDebitReversalResponse = postCreditTransaction(reversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionDebitReversalResponse, HttpStatus.SC_OK);

        //  get total balance after reversal
        String amountAfterDebitReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        CommonMethods.validateFailedTransactionResponse(creditTransactionDebitReversalResponse, ERROR_CODE_21021, INVALID_MESSAGE_FORMAT_ERROR_MSG);

        // verify balance
        verifyAccountBalanceUnchanged(amountAfterCredit, amountAfterDebitReversal);

    }

    //Issue TODO: we can perform multiple re-reversal success transactions on single credit transaction
    @Test(dataProvider = "CreditTransaction", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversalForReversedTxn(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class,
                "Test Credit Reversal for a credit transaction where credit reversal is already successful");

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response debitTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(debitTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        String reversalPayload = createCreditReversalPayload();

        //  post request
        Response creditTransactionReversalResponse = postCreditTransaction(reversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit reversal
        String amountAfterReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionReversalResponse, amountAfterCredit, amountAfterReversal);

        //  create reversal payload to request reversal again for same transaction
        String reReversalPayload = createCreditReversalPayload();

        //  post request
        Response creditTransactionReReversalResponse = postCreditTransaction(reReversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionReReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit reversal
        String amountAfterReReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate response
        CommonMethods.validateFailedTransactionResponse(creditTransactionReReversalResponse, "", "");

        // verify balance
        Assert.assertEquals(amountAfterReversal, amountAfterReReversal);

    }


    @Test(dataProvider = "CreditTransactionReversalInvalidCases", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversalForInvalidValues(String invalidParamCase, Object invalidValue,
                                                   boolean modifySerialization, String action, int statusCode,
                                                   String errorCode, String errorMessage, int subType, int entityId, int applicationId) {

        Reporter.initiateTestReport(CreditTransaction.class, "Test Credit Reversal for a transaction for invalid " + invalidParamCase);

        //  create payload
        String payload = createCreditTransactionPayload(subType, applicationId, entityId);

        //  get Account number
        String accountNumber = transactionEntity.getPayee().getAccountNumber();

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  Verify status is success & then validate the response
        validateCreditTransactionResponse(creditTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        createCreditReversalPayload();

        // modify reversal payload
        String modifyReversalPayLoad = modifyCreditTxnPayload(invalidParamCase, invalidValue, modifySerialization, action);

        //  post request
        Response creditTransactionReversalResponse = postCreditTransaction(modifyReversalPayLoad, header);

        // get balance
        String amountAfterReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  verify status code
        validateCreditTransactionResponseStatus(creditTransactionReversalResponse, statusCode);

        // validate reversal failure
        CommonMethods.validateFailedTransactionResponse(creditTransactionReversalResponse, errorCode, errorMessage);

        // verify balance after invalid reversal
        Assert.assertEquals(amountAfterCredit, amountAfterReversal);
    }

    //  TODO: Issues : able to perform reversal for the updated amount
    @Test(dataProvider = "CreditTransaction", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversalForIncorrectAmount(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class,
                "Test Credit Reversal for incorrect amount.");

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);
        Double txnAmount = transactionEntity.getAmount().getNetAmount();

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response debitTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(debitTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        String reversalPayload = createCreditReversalPayload();

        // change net & gross amount in the reversal Payload
        double invalidReversalAmount = txnAmount + 2;
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_NET_AMOUNT, invalidReversalAmount);
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_GROSS_AMOUNT, invalidReversalAmount);

        //  post request
        Response creditTransactionReversalResponse = postCreditTransaction(reversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit reversal
        String amountAfterReversal = new GetBalanceBL().postGetBalance(accountNumber);

        // validate api status code
        CommonMethods.validateFailedTransactionResponse(creditTransactionReversalResponse, ERROR_CODE_30520, INVALID_AMOUNT);

        // verify balance
        Assert.assertEquals(amountAfterReversal, amountAfterReversal);

    }

    //  TODO: Issues : able to perform reversal for the updated amount
    @Test(dataProvider = "CreditReversalOnDebitFreezeAccount", groups = {"UPI", "AEPS", "All"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditReversalOnDebitFreezeAccount(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class,
                "Test Credit Reversal for a credit transaction On debit freeze account");

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);
        Double txnAmount = transactionEntity.getAmount().getNetAmount();

        //  get total balance before performing credit transaction
        String amountBeforeCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response debitTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit transaction
        String amountAfterCredit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateCreditTransactionResponse(debitTransactionResponse, amountBeforeCredit, amountAfterCredit);

        //  create reversal payload
        String reversalPayload = createCreditReversalPayload();

        // change net & gross amount in the reversal Payload
        double invalidReversalAmount = txnAmount + 2;
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_NET_AMOUNT, invalidReversalAmount);
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_GROSS_AMOUNT, invalidReversalAmount);

        //  post request
        Response creditTransactionReversalResponse = postCreditTransaction(reversalPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing credit reversal
        String amountAfterReversal = new GetBalanceBL().postGetBalance(accountNumber);

        // validate api status code
        CommonMethods.validateFailedTransactionResponse(creditTransactionReversalResponse, ERROR_CODE_30520, INVALID_AMOUNT);

        // verify balance
        Assert.assertEquals(amountAfterReversal, amountAfterReversal);

    }

    @BeforeMethod(groups = {"UPI", "AEPS", "All", "sanity"})
    public void beforeSetup(Method m) {
        isStoreOriginalTransactionId = false;

        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"UPI", "AEPS", "All", "sanity"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
