package transactions;

import DataProviders.CreditTxnDataProvider;
import DataProviders.DebitTxnDataProvider;
import base.ConnectionSetup;
import client.transaction.CreditTransactionBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.util.Map;

public class ENachCreditTransaction extends CreditTransactionBL {

    @Test(dataProvider = "ENachCreditTransaction", groups = {"eNach"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransactionWithNarration(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(ENachCreditTransaction.class, String.format("Credit transaction With Narration. Subtype %s", subType));

        //  create payload
        createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  generate description
        String transactionStatementDescriptor = "TRAN_" + accountNumber + "_" + bankIFSC;

        //  create updated payload
        String payload = addNarrationInTransaction(transactionStatementDescriptor);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, null, null);
    }

    @Test(dataProvider = "ENachCreditTransaction", groups = {"eNach", "sanity"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransaction(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(ENachCreditTransaction.class, String.format("Positive flow Credit transaction with subtype %s", subType));

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_OK);

        //  validate the response
        validateCreditTransactionResponse(creditTransactionResponse, null, null);
    }

    @Test(dataProvider = "ENachCreditTransactionInValidSubType", groups = {"eNach"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTxnErrorInvalidSubType(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(ENachCreditTransaction.class, "Test Credit Transaction With Invalid SubType: " + subType);

        //  create payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        //  validate response
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, ERROR_CODE_30505, INVALID_SUBTYPE_ERROR_MSG);

    }

    @Test(dataProvider = "ENachCreditTransactionInvalidCases", groups = {"eNach"}, dataProviderClass = CreditTxnDataProvider.class)
    public void testCreditTransactionInvalidTypes(String invalidParamCase, Object invalidValue,
                                                  boolean modifySerialization, String action, int statusCode,
                                                  String errorCode, String errorMessage, int subType, int entityId, int applicationId) {

        Reporter.initiateTestReport(ENachCreditTransaction.class, "Test Credit transaction with invalid :" + invalidParamCase);

        //  create payload
        createCreditTransactionPayload(subType, DEFAULT_SIT_GL_ACCOUNT, DEFAULT_SIT_PAYER_BANK_IFSC, entityId, applicationId, 1);
        //createCreditTransactionPayload(subType, applicationId, entityId);

        // modify the payload
        String modifiedPayload = modifyCreditTxnPayload(invalidParamCase, invalidValue, modifySerialization, action);

        //  set header for non transaction services
        Map<String, String> header = setCreditTransactionHeader();

        //  post request
        Response creditTransactionResponse = postCreditTransaction(modifiedPayload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, statusCode);

        // validate failure status, code and Message
        CommonMethods.validateFailedTransactionResponse(creditTransactionResponse, errorCode, errorMessage);

    }

    /*
     * Verify debit transaction for various method subType with invalid header
     * 1. Create a debit transaction with various subtype
     * 2. Add an invalid Header
     * 3. Verify error code
     * */
    @Test(dataProvider = "CreditTxnInvalidHeader", groups = {"eNach", "All", "sanity"}, dataProviderClass = CreditTxnDataProvider.class)
    public void TestCreditTxnInvalidHeader(int subType, String accountNumber, String bankIFSC, int entityId, int applicationId, int mode, String headerItem, String invalidVal) {

        Reporter.initiateTestReport(ENachCreditTransaction.class, "Test Credit Transaction With Header: " +headerItem+ " = "+ invalidVal);

        // create the payload
        String payload = createCreditTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setInvalidCreditTransactionHeader(headerItem, invalidVal);

        // post the request
        Response creditTransactionResponse = postCreditTransaction(payload, header);

        // validate api status code
        validateCreditTransactionResponseStatus(creditTransactionResponse, HttpStatus.SC_UNAUTHORIZED);

        verifyPermissionDeniedMessage(creditTransactionResponse);

    }

    @BeforeMethod(groups = {"eNach", "sanity"})
    public void beforeSetupENach() {
        isENach = true;
        isStoreOriginalTransactionId = false;
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"eNach", "sanity"})
    public void afterSetupENach(ITestResult testResult) {
        isENach = false;
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
