package transactions;

import base.ConnectionSetup;
import client.account.GetBalanceBL;
import client.transaction.FundTransferBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.lang.reflect.Method;
import java.util.Map;

public class FundTransfer extends FundTransferBL {

    String payerAccount;
    String payeeAccount;
    String payerIFSC;

    @Test(dataProvider = "FundTransfer",  groups = {"eNach", "All"})
    public void testFundTransfer(int subType, String payerAccountNumber, String payeeAccountNumber, String bankIFSC, int entityId, int applicationId, int mode) {

        Reporter.initiateTestReport(CreditTransaction.class, String.format("fund transfer with subtype : %s ", subType));

        //  get total balance before performing fund transfer
        String amountBeforeFundTransfer = new GetBalanceBL().postGetBalance(payeeAccountNumber);

        //  create payload
        String payload = createFundTransferPayload(subType, payerAccountNumber, payeeAccountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setFundTransferHeader();

        //  post request
        Response fundTransferResponse = postFundTransfer(payload, header);

        // validate api status code
        validateFundTransferResponseStatus(fundTransferResponse, HttpStatus.SC_OK);

        //  get total balance before performing fund transfer
        String amountAfterFundTransfer = new GetBalanceBL().postGetBalance(payeeAccountNumber);

        //  validate response
        validateFundTransferResponse(fundTransferResponse, amountBeforeFundTransfer, amountAfterFundTransfer);
    }

    @DataProvider(name = "FundTransfer")
    public Object[][] TestDataProviderFundTransfer() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();

        return new Object[][]{

/*                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1},*/
                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1},
                {SUB_TYPE_550, SIT_CURRENT_ACCOUNT, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1}
        };
    }


    @Test(dataProvider = "FundTransferWithInvalidHeader",  groups = {"eNach", "All"})
    public void testFundTransferWithInvalidHeader(int subType, String payerAccountNumber, String payeeAccountNumber, String bankIFSC, int entityId, int applicationId, int mode, String headerItem, String invalidVal) {

        Reporter.initiateTestReport(CreditTransaction.class, "fund transfer with With invalid Header: " +headerItem+ " = "+ invalidVal);

        //  create payload
        String payload = createFundTransferPayload(subType, payerAccountNumber, payeeAccountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setInvalidFundTransferHeader(headerItem, invalidVal);

        //  post request
        Response fundTransferResponse = postFundTransfer(payload, header);

        // validate api status code
        validateFundTransferResponseStatus(fundTransferResponse, HttpStatus.SC_UNAUTHORIZED);

        verifyPermissionDeniedMessage(fundTransferResponse);
    }

    @DataProvider(name = "FundTransferWithInvalidHeader")
    public Object[][] FundTransferWithInvalidHeader() {

        payerAccount = CommonMethods.getDefaultPayerAccountNumber();
        payeeAccount = CommonMethods.getDefaultPayeeAccountNumber();
        payerIFSC = CommonMethods.getDefaultPayerBankIFSCNumber();

        return new Object[][]{

/*                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1},*/
                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-API-KEY", "C584F4DA62A767731F"},
                {SUB_TYPE_550, SIT_CURRENT_ACCOUNT, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-API-KEY", "C584F4DA62A767731F"},

                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-API-KEY", null},
                {SUB_TYPE_550, SIT_CURRENT_ACCOUNT, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-API-KEY", null},

                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-CHANNEL-ID", "5555"},
                {SUB_TYPE_550, SIT_CURRENT_ACCOUNT, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-CHANNEL-ID", "5555"},

                {SUB_TYPE_550, payerAccount, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-CHANNEL-ID", null},
                {SUB_TYPE_550, SIT_CURRENT_ACCOUNT, payeeAccount, payerIFSC, ENTITY_ID_8013, APPLICATION_ID_8013, MODE_1, "X-CHANNEL-ID", null}
        };
    }


    @BeforeMethod(groups = {"eNach", "All"})
    public void beforeSetup(Method m) {
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"eNach", "All"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
