package transactions;

import DataProviders.DebitTxnDataProvider;
import base.ConnectionSetup;
import client.account.GetBalanceBL;
import client.transaction.DebitTransactionBL;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.TransactionEntity.TransactionEntity;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.CommonMethods;
import utils.Reporter;

import java.util.Map;


public class DebitTransaction extends DebitTransactionBL {

    @Test(dataProvider = "DebitTransactionData", groups = {"eNach", "UPI"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTxnWithNarration(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit Transaction With Narration. SubType: " + subType);

        //  create payload
        createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  generate description
        String transactionStatementDescriptor = "TRAN_" + accountNumber + "_" + bankIFSC;

        //  create updated payload
        String payload = addNarrationInTransaction(transactionStatementDescriptor);

        //String payload = createJsonPayload(transactionEntityObj);

        //  get total balance before performing credit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        // add digital signature
        //header = addDigitalSignature(header, payload, initiatingEntityID);

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance before performing credit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);
    }

    /*
     * Verify debit transaction for various method subType
     * 1. Create a debit transaction with various subtype
     * 2. Check that transaction is successful
     * 3. Verify user account balance
     * */
    @Test(dataProvider = "DebitTransactionData", groups = {"eNach", "UPI", "All", "sanity"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTxn(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit Transaction With SubType: " + subType);

        //  create payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);
        //String payload = createJsonPayload(transactionEntityObj);

        //  get total balance before performing credit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        // add digital signature
        //header = addDigitalSignature(header, payload, initiatingEntityID);

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance before performing credit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);
    }

    /*
     * Verify debit transaction for various method subType with invalid header
     * 1. Create a debit transaction with various subtype
     * 2. Add an invalid Header
     * 3. Verify error code
     * */
    @Test(dataProvider = "DebitTxnInvalidHeader", groups = {"eNach", "UPI", "All", "sanity"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTxnInvalidHeader(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC, String headerItem, String invalidVal) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit Transaction With invalid Header: " +headerItem+ " = "+ invalidVal);

        // create the payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  set header for non transaction services
        Map<String, String> header = setInvalidDebitTransactionHeader(headerItem, invalidVal);

        // post the request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_UNAUTHORIZED);

        verifyPermissionDeniedMessage(debitTransactionResponse);

    }
        /*
     * Test Debit Reversal for a debit transaction
     * */
    @Test(dataProvider = "DebitReversalDpr", groups = {"UPI", "All", "sanity"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversal(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        Reporter.initiateTestReport(DebitTransaction.class,
                "Debit transaction and reversal with subtype : " + subType);

        //  create payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        // validate transaction is successful
        validateDebitTransactionSuccess(debitTransactionResponse);

        //  get total balance after performing Debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload();

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing debit transaction
        String amountAfterReversal = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  validate the response
        validateDebitTransactionResponse(debitTransactionReversalResponse, amountAfterDebit, amountAfterReversal);
    }

    /*
     * verify debit transaction if the invalid subType is given in Input
     * */
    @Test(dataProvider = "InValidSubTypeDpr", groups = {"eNach", "UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTxnErrorInvalidSubType(int subType, int applicationId, int initiatingEntityID, int mode) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit Transaction With Invalid SubType: " + subType);

        //  create payload
        TransactionEntity transactionEntityObj = createDebitTransactionPayload(subType, applicationId, initiatingEntityID, mode);
        String payload = createJsonPayload(transactionEntityObj);

        Map<String, String> header = setDebitTransactionHeader();

        Response debitTransactionResponse = postDebitTransaction(payload, header);

        validateFailedTransactionResponse(debitTransactionResponse, "30505", "Method SubType provided is invalid");
    }

    /*
     * Test debit reversal for a failed transaction
     * 1. Initiate a debit reversal for a failed debit transaction
     * 2. Verify that debit reversal is not successful
     * 3. Verify status, failure code, failure message
     * */
    @Test(dataProvider = "TestDataProviderDebitReversalForFailedTxn", groups = {"All"})
    public void TestDebitReversalForFailedTxn(Map<Object, Object> testData) {

        Reporter.initiateTestReport(DebitTransaction.class,
                "Debit Reversal for failed debit transactions. Original Transaction ID :" + testData.get("ORIGINAL_TRANSACTION_ID"));

        //  create payload
        String payload = createDebitReversalPayload(testData);

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  validate the response
        validateFailedTransactionResponse(debitTransactionResponse, "", "");
    }

    @DataProvider(name = "TestDataProviderDebitReversalForFailedTxn")
    public Object[][] TestDataProviderDebitReversalForFailedTxn() {
        ConnectionSetup.createTestConnections();
        //TODO: modify query to fetch valid entityID, callBackURl, application ID,  update gen. update in both Cr & Dr

        String query = "Select * from jpb_transaction where Status = 'FAILED' and METHOD_TYPE = 111 and " +
                "METHOD_SUB_TYPE not in (0, 523) and INITIATING_ENTITY_ID !=0 and APPLICATION_ID != 0 and PROCESSOR_TRANSACTION_ID is not null " +
                "and CURRENCY !=0 and TRANSACTION_MODE !=0 and CAPTURE_METHOD !=0 and PAYER_ACCOUNT_NUMBER is not null " +
                "and PAYER_BANK_IFSC is not null and PAYER_CUSTOMER_TYPE !=0 ORDER BY CREATED desc fetch first 4 rows only";
        return DataBaseUtility.getDatabaseDataProvider(dbTransactionService, query);
    }

    /*
     * Test Debit Reversal for a debit transaction where debit reversal is already successful
     * 1. Fetch balance
     * 2. Do a Debit transaction
     * 3. Check debit successful
     * 4. Do a debit reversal for above debit Txn
     * 5. Verify successful reversal (check amount being credit to the payer)
     * 6. Do a debit reversal again for same debit transaction
     * 7. Verify error message & check user account balance does not change due to incorrect reversal
     * */
    //TODO: gather information on how many times i can try reversal for a given txn when reversal is already done
    @Test(dataProvider = "DebitReversalForReversedTx", groups = {"UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversalForReversedTxn(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        Reporter.initiateTestReport(DebitTransaction.class,
                "Test Debit Reversal for a debit transaction where debit reversal is already successful");

        //  create payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        // validate transaction is successful
        validateDebitTransactionSuccess(debitTransactionResponse);

        //  get total balance after performing Debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload();

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance after performing debit transaction
        String amountAfterReversal = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  validate the response
        validateDebitTransactionResponse(debitTransactionReversalResponse, amountAfterDebit, amountAfterReversal);


        //  create reversal payload to request reversal again for same transaction
        String reReversalPayload = createDebitReversalPayload();

        //  post request
        Response debitTransactionReReversalResponse = postDebitTransaction(reReversalPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionReReversalResponse, HttpStatus.SC_OK);

        validateFailedTransactionResponse(debitTransactionReReversalResponse, "", "");
    }

    /*
     * Debit reversal with invalid Type i.e incorrect method type
     * 1. Fetch balance
     * 2. Do a Debit transaction
     * 3. Check debit successful
     * 4. Do a credit reversal for above debit Txn
     * 5. Verify failure message
     * 6. Verify that user account balance does not change due to incorrect reversal
     * */
    @Test(dataProvider = "ReversalWithInvalidMethod", groups = {"UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversalWithInvalidMethod(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC, Object invalidType) {

        Reporter.initiateTestReport(DebitTransaction.class,
                "Test Reversal for a debit transaction when Method-Type is incorrect i.e. " + invalidType.toString());

        //  create Debit transaction payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing Debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance after performing debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload & modify the Method Type

        String reversalPayload = createDebitReversalPayload();
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_METHOD_TYPE, invalidType);

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionReversalResponse, HttpStatus.SC_OK);

        //  get total balance before performing debit transaction
        String amountAfterFailReversal = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateFailedTransactionResponse(debitTransactionReversalResponse, "30504", "Method Type provided is invalid");

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountAfterDebit, amountAfterFailReversal);
    }

    /*
     * Debit reversal with invalid Application ID
     * 1. Fetch balance
     * 2. Do a Debit transaction
     * 3. Check debit successful
     * 4. Do a debit reversal for above Txn with invalid Application ID
     * 5. Verify failure message
     * 6. Verify that user account balance does not change due to incorrect debit reversal
     * */
    @Test(dataProvider = "DebitReversalInvalidId", groups = {"UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversalWithInvalidEntityOrAppID(int subType, int applicationId, int initiatingEntityID, int mode, String invalidParamCase, Object invalidApplicationID) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit Reversal for a transaction with invalid:" + invalidParamCase);

        //  create payload
        TransactionEntity transactionEntityObj = createDebitTransactionPayload(subType, applicationId, initiatingEntityID, mode);
        String payload = createJsonPayload(transactionEntityObj);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        //  get total balance before performing credit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        //  Verify status is success & then validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload(invalidParamCase, invalidApplicationID);

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);


        switch (invalidParamCase) {
            case (APPLICATION_ID):

                // validate api status code
                validateDebitTransactionResponseStatus(debitTransactionReversalResponse, HttpStatus.SC_OK);

                // validate reversal failure for application ID
                validateFailedTransactionResponse(debitTransactionReversalResponse, ERROR_CODE_50011, INVALID_TRANSACTION_NOT_FOUND_MSG);
                break;

            case (ENTITY_ID):

                // validate api status code
                validateDebitTransactionResponseStatus(debitTransactionReversalResponse, HttpStatus.SC_INTERNAL_SERVER_ERROR);

                // validate reversal failure for application ID
                validateFailedTransactionResponse(debitTransactionReversalResponse, ERROR_CODE_6011, INVALID_SOME_TECHNICAL_ERROR_MSG);
                break;

        }

        String amountAfterReversal = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountAfterDebit, amountAfterReversal);
    }

    /*
     * Debit transaction with invalid param values.
     * */
    @Test(dataProvider = "InvalidDataProvider", groups = {"eNach", "UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestInvalidDebitTransactions(int subType, int applicationId, int entityId, int mode, String invalidParamCase,
                                             Object invalidValue, boolean modifySerialization, String action,
                                             int statusCode, String errorMsg, String errorCode) {

        Reporter.initiateTestReport(DebitTransaction.class, "Test Debit transaction with invalid param; " + invalidParamCase + ": invalid Value - " + invalidValue);

        //  create payload
        TransactionEntity transactionEntityObj = createDebitTransactionPayload(subType, applicationId, entityId, mode);
        String payload = createJsonPayload(transactionEntityObj);

        String originalAccountNumber = transactionEntity.getPayer().getAccountNumber();

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(originalAccountNumber);

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        String modifiedPayload = null;

        if (invalidParamCase.equalsIgnoreCase(AMOUNT_NET_AMOUNT)) {
            modifiedPayload = modifyDebitTxnPayload(invalidParamCase, invalidValue, modifySerialization, action);
            // modify the both net amount & gross amount
            if (invalidParamCase.equalsIgnoreCase("GrossNull")) {
                modifiedPayload = CommonMethods.ChangeJsonPayload(modifiedPayload, ACTION_SET, PATH_AMOUNT_NET_AMOUNT, 1);
                modifiedPayload = CommonMethods.ChangeJsonPayload(modifiedPayload, ACTION_DELETE, PATH_AMOUNT_GROSS_AMOUNT, null);
            } else {
                modifiedPayload = CommonMethods.ChangeJsonPayload(modifiedPayload, ACTION_SET, PATH_AMOUNT_NET_AMOUNT, invalidValue);
                modifiedPayload = CommonMethods.ChangeJsonPayload(modifiedPayload, ACTION_SET, PATH_AMOUNT_GROSS_AMOUNT, invalidValue);
            }
        } else {
            // modify the payload
            modifiedPayload = modifyDebitTxnPayload(invalidParamCase, invalidValue, modifySerialization, action);
        }

        //  post request
        Response debitTransactionResponse = postDebitTransaction(modifiedPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, statusCode);

        // validate failure status, code and Message
        CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, errorCode, errorMsg);

        //  get total balance before performing debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeDebit, amountAfterDebit);
    }

    /*
     * Perform a debit transaction when debit amount is more than actual balance.
     * 1. Fetch balance
     * 2. Do a Debit transaction with amount more than actual balance
     * 3. Verify Debit Failure
     * 4. Verify that user account balance does not change due to incorrect debit txn
     * */
    @Test(dataProvider = "AccountNumberProvider", groups = {"UPI", "eNach", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTransactionsAmountExceed(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        String desc = "Debit transaction when debit amount is more than actual balance. subType: " + subType + " entityId: " + entityId + " applicationId: " + applicationId;
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        //  create payload
        createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        double amountForTxn = Double.parseDouble(amountBeforeDebit) + 10;

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //change the amount
        transactionEntity.getAmount().setNetAmount(amountForTxn);

        //modify the gross amount and create the body
        String modifiedPayload = modifyDebitTxnPayload(AMOUNT_GROSS_AMOUNT, amountForTxn, true, ACTION_SET);

        //  post request
        Response debitTransactionResponse = postDebitTransaction(modifiedPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, ERROR_CODE_21004, INSUFFICIENT_FUNDS_ERROR_MSG);

        //  get total balance before performing debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeDebit, amountAfterDebit);
    }

    /*
     * Perform a debit transaction when the account is under DEBIT or TOTAL FREEZE
     * 1. Fetch balance
     * 2. Do a Debit transaction with a valid amount
     * 3. Verify Debit Failure
     * 4. Verify that user account balance does not change due to incorrect debit txn
     * */
    @Test(dataProvider = "FreezeAccountDPr", groups = {"UPI", "eNach", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTransactionsFreezeAcc(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC, String freezeCase) {

        String desc = "Debit transaction when Account is under DEBIT or TOTAL Freeze. subType: " + subType + " entityId: " + entityId + " applicationId: " + applicationId;
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        //  create payload
        String debitPayload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(debitPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        // Validate that transaction failed response
        switch (freezeCase) {

            case (DEBIT_FREEZE):
            case (TOTAL_FREEZE):
                CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, ERROR_CODE_30523, ACCOUNT_FREEZED_OR_INVALID_ERROR_MSG);
                break;
            default:
                CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, "", "");
        }

        //  get total balance before performing debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeDebit, amountAfterDebit);
    }

    /*
     * Perform a debit reversal transaction when the amount is different from original transaction
     * 1. Fetch balance
     * 2. Do a Debit transaction with a valid amount
     * 3. Verify Debit success
     * 4. Verify that user account balance is deducted by the amount transacted
     * 5. Do a reversal txn from above Txn but with different amount
     * 6. Verify transaction Failure
     * 7. Verify that balance is unchanged i.e. amount is not credited back to the payer
     * */
    @Test(dataProvider = "DebitReversalDpr", groups = {"UPI", "AEPS", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversalIncorrectAmount(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        String desc = "Debit Reversal when Amount is incorrect";
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        //  create payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);
        double txnAmount = transactionEntity.getAmount().getNetAmount();

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        // validate transaction is successful
        validateDebitTransactionSuccess(debitTransactionResponse);

        //  get total balance after performing Debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload();

        // change net & gross amount in the reversal Payload
        double invalidReversalAmount = txnAmount + 2;
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_NET_AMOUNT, invalidReversalAmount);
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_AMOUNT_GROSS_AMOUNT, invalidReversalAmount);

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);

        // validate api status code
        validateDebitTransactionFailure(debitTransactionReversalResponse, ERROR_CODE_30520, INVALID_AMOUNT);

        //  get total balance after performing debit transaction
        String amountAfterReversal = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        // Validate the balance is unchanged i.e. amount is not credited back to the payer
        verifyAccountBalanceUnchanged(amountAfterReversal, amountAfterDebit);
    }

    /*
     * Perform a debit reversal transaction when original transaction ID is invalid
     * 1. Fetch balance
     * 2. Do a Debit transaction with a valid amount
     * 3. Verify Debit success
     * 4. Verify that user account balance is deducted by the amount transacted
     * 5. Do a reversal txn from above Txn but with different amount
     * 6. Verify transaction Failure
     * 7. Verify that balance is unchanged i.e. amount is not credited back to the payer
     * */
    @Test(dataProvider = "DebitReversalDpr", groups = {"UPI", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitReversalInvalidOriginalId(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC) {

        String desc = "Perform a debit reversal transaction when original transaction ID is invalid";
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        //  create payload
        String payload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        // validate transaction is successful
        validateDebitTransactionSuccess(debitTransactionResponse);

        //  get total balance after performing Debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  validate the response
        validateDebitTransactionResponse(debitTransactionResponse, amountBeforeDebit, amountAfterDebit);

        //  create reversal payload
        String reversalPayload = createDebitReversalPayload();

        //change original ID in reversal payload
        reversalPayload = CommonMethods.ChangeJsonPayload(reversalPayload, ACTION_SET, PATH_ORIGINAL_ID, "");

        //  post request
        Response debitTransactionReversalResponse = postDebitTransaction(reversalPayload, header);

        // validate api status code
        validateDebitTransactionFailure(debitTransactionReversalResponse, ERROR_CODE_21021, MESSAGE_FORMAT_ERROR);

        //  get total balance after performing debit transaction
        String amountAfterReversal = new GetBalanceBL().postGetBalance(transactionEntity.getPayer().getAccountNumber());

        // Validate the balance is unchanged i.e. amount is not credited back to the payer
        verifyAccountBalanceUnchanged(amountAfterDebit, amountAfterReversal);
    }

    /*
     * Perform outward NEFT flow for a given GL account & a third party account
     * */
    @Test(dataProvider = "NeftOutward", groups = {"eNach", "sanity"})//, dataProviderClass = DebitTxnDataProvider.class)
    public void TestOutwardNEFT(int subType, int applicationId, int entityId, int mode, String payerAccount, String payerIFSC, String payeeAccount, String payeeIFSC) {

        String desc = "Perform outward NEFT flow for a given GL account & a third party account";
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        // Create the payload
        TransactionEntity transactionEntityObj = createDebitTransactionPayload(subType, applicationId, entityId, mode);
        transactionEntityObj.setPayer(CommonMethods.getGenericPayer(payerAccount, payerIFSC));
        transactionEntityObj.setPayee(CommonMethods.getGenericPayee(payeeAccount, payeeIFSC));
        transactionEntityObj.getTransaction().setMethod(CommonMethods.getTransactionMethod(421, 550));
        String payload = createJsonPayload(transactionEntityObj);

        //  get total balance before performing the transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(payerAccount);

        //  set header for transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransactionPayouts(payload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);


        //  get total balance after performing the transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(payerAccount);

    }

    @DataProvider(name = "NeftOutward")
    public static Object[][] OutWardNeftData() {
        return new Object[][]{
                {SUB_TYPE_576, APPLICATION_ID_8013, ENTITY_ID_8013, MODE_1, DEFAULT_SIT_GL_ACCOUNT_1,
                        DEFAULT_SIT_PAYER_BANK_IFSC, "09001100567", "SBIN0004557"},
                {SUB_TYPE_576, APPLICATION_ID_8013, ENTITY_ID_8013, MODE_1, DEFAULT_SIT_GL_ACCOUNT_2,
                        DEFAULT_SIT_PAYER_BANK_IFSC, "09001100567", "SBIN0004557"},
        };
    }

    /*
     * Perform a debit transaction when the account is closed
     * 1. Fetch balance
     * 2. Do a Debit transaction with a valid amount
     * 3. Verify Debit Failure
     * 4. Verify that user account balance does not change due to incorrect debit txn
     * */
    @Test(dataProvider = "closedAccountData", groups = {"UPI", "eNach", "All"}, dataProviderClass = DebitTxnDataProvider.class)
    public void TestDebitTransactionsClosedAcc(int subType, int applicationId, int entityId, int mode, String accountNumber, String bankIFSC, String AccState) {

        String desc = "Debit transaction when Account is closed or dormant. subType: " + subType + " entityId: " + entityId + " applicationId: " + applicationId;
        Reporter.initiateTestReport(DebitTransaction.class, desc);

        //  create payload
        String debitPayload = createDebitTransactionPayload(subType, accountNumber, bankIFSC, entityId, applicationId, mode);

        //  get total balance before performing debit transaction
        String amountBeforeDebit = new GetBalanceBL().postGetBalance(accountNumber);

        //  set header for non transaction services
        Map<String, String> header = setDebitTransactionHeader();

        //  post request
        Response debitTransactionResponse = postDebitTransaction(debitPayload, header);

        // validate api status code
        validateDebitTransactionResponseStatus(debitTransactionResponse, HttpStatus.SC_OK);

        switch (AccState) {
            case (CLOSED_ACCOUNT):
                CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, "30527", "Account is closed");
                break;
            case (DORMANT_ACCOUNT):
                CommonMethods.validateFailedTransactionResponse(debitTransactionResponse, "30528", "Account is Inactive/Dormant");
                break;
        }

        //  get total balance before performing debit transaction
        String amountAfterDebit = new GetBalanceBL().postGetBalance(accountNumber);

        // verify balance after invalid reversal
        verifyAccountBalanceUnchanged(amountBeforeDebit, amountAfterDebit);
    }

    @BeforeMethod(groups = {"UPI", "eNach", "All", "sanity"})
    public void beforeSetup() {
        isStoreOriginalTransactionId = false;
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod(groups = {"UPI", "eNach", "All", "sanity"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }
}
