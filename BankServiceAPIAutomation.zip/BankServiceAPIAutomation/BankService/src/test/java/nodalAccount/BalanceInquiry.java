package nodalAccount;

import base.ConnectionSetup;
import client.nodalAccount.BalanceInquiryBL;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.Reporter;
import virtualAccountManagement.GetCurrentAccount;

import java.util.Map;

public class BalanceInquiry extends BalanceInquiryBL {


    @Test(dataProvider = "TestDataProviderBalanceInquiry")
    public void TestBalanceInquiry(String accountNumber) {

        Reporter.initiateTestReport(GetCurrentAccount.class, String.format("Balance Inquiry : Account number is %1s", accountNumber));

        //  create payload
        String payload = createBalanceInquiryPayload(accountNumber);

        //  set header
        Map<String, String> header = setBalanceInquiryHeader();

        //  post get current account
        Response response = postBalanceInquiry(payload, header);

        //  validate status code
        validateBalanceInquiryResponseStatus(response, HttpStatus.SC_OK);

        //  validate response
        //validateBalanceInquiryResponse(response, accountNumber);

    }

    @DataProvider(name = "TestDataProviderBalanceInquiry")
    public Object[][] TestDataProviderBalanceInquiry() {
        return new Object[][]{
                {"4000003563815900"},
        };
    }

    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }

}
