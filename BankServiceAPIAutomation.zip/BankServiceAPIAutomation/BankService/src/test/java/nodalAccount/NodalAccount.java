package nodalAccount;

import base.ConnectionSetup;
import client.nodalAccount.NodalAccountBL;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.FileSecurity;
import utils.Reporter;

import java.nio.file.Path;
import java.nio.file.Paths;

public class NodalAccount extends NodalAccountBL {

    @Test(dataProvider = "TestDataProviderMerchantSettlement")
    public void testMerchantSettlement(int recordCount) {

        Reporter.initiateTestReport(NodalAccount.class, "Test Merchant Settlement.");

        //  create test data file for nodal account
        String filePath = createSettlementFile(recordCount);
        Path path = Paths.get(filePath);

        //  encrypt file
        String encryptFileName = FileSecurity.encryptFile(path.getParent().toString(), path.getFileName().toString());

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is processed and present in  processed folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_PROCESS_PATH + encryptFileName);

        //  check if record present in database
        NodalAccountBL.checkRecordExistInDatabase(encryptFileName);

        //  validate nodal transaction
        //  it will validate only success transaction
        //  also stores the value of success and failed transaction
        validateNodalTransaction();

        //  check records in response file
        validateSettlementRecordsInResponseFile(path);

    }

    @DataProvider(name = "TestDataProviderMerchantSettlement")
    public Object[][] TestDataProviderMerchantSettlement() {
        return new Object[][]{
                {2}
        };
    }

    @Test(dataProvider = "TestDataProviderMerchantSettlementDuplicateFileCheck")
    public void testMerchantSettlementDuplicateFileCheck(int recordCount) {

        Reporter.initiateTestReport(NodalAccount.class, "Duplicate Merchant Settlement .");

        //  create test data file for nodal account
        String filePath = createSettlementFile(recordCount);
        Path path = Paths.get(filePath);

        //  encrypt file
        String encryptFileName = FileSecurity.encryptFile(path.getParent().toString(), path.getFileName().toString());

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is processed and present in  processed folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_PROCESS_PATH + encryptFileName);

        //  check if record present in database
        NodalAccountBL.checkRecordExistInDatabase(encryptFileName);

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is in input folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH + encryptFileName);
    }

    @DataProvider(name = "TestDataProviderMerchantSettlementDuplicateFileCheck")
    public Object[][] TestDataProviderMerchantSettlementDuplicateFileCheck() {
        return new Object[][]{
                {1}
        };
    }

    @Test(dataProvider = "MerchantMasterDuplicateFileCheck")
    public void testMerchantMasterDuplicateFileCheck(int recordCount) throws InterruptedException {

        Reporter.initiateTestReport(NodalAccount.class, "Test Merchant Master");

        //  create test data file for nodal account
        String filePath = createMerchantMasterFile(recordCount);
        Path path = Paths.get(filePath);

        //  encrypt file
        String encryptFileName = FileSecurity.encryptFile(path.getParent().toString(), path.getFileName().toString());

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is processed and present in  processed folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_PROCESS_PATH + encryptFileName);

        //  wait file to process
        Thread.sleep(2000);

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is in input folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH + encryptFileName);
    }

    @DataProvider(name = "MerchantMasterDuplicateFileCheck")
    public Object[][] TestDataProviderMerchantMasterDuplicateFileCheck() {
        return new Object[][]{
                {1}
        };
    }

    @Test(dataProvider = "MerchantMaster")
    public void testMerchantMaster(int recordCount) throws InterruptedException {

        Reporter.initiateTestReport(NodalAccount.class, "Test Merchant Master");

        //  create test data file for nodal account
        String filePath = createMerchantMasterFile(recordCount);
        Path path = Paths.get(filePath);

        //  encrypt file
        String encryptFileName = FileSecurity.encryptFile(path.getParent().toString(), path.getFileName().toString());

        //  move file to SFTP
        NodalAccountBL.uploadFileOverSftp(SIT_NODAL_ACCOUNT_SFTP_IN_DIR_PATH, path.getParent().toString(), encryptFileName);

        //  Check if file is processed and present in  processed folder
        NodalAccountBL.checkFileExist(SIT_NODAL_ACCOUNT_SFTP_IN_PROCESS_PATH + encryptFileName);

        //  wait file to process
        Thread.sleep(2000);
    }

    @DataProvider(name = "MerchantMaster")
    public Object[][] TestDataProviderMerchantMaster() {
        return new Object[][]{
                {1}
        };
    }

    @BeforeMethod()
    public void beforeSetup() {
        //ConnectionSetup.createSSHConnections();
        ConnectionSetup.createNodalAccountConnection();
        ConnectionSetup.createCBSConnection();
        boolean isConnected = false;
        for (int i = 0; i < 10; i++) {
            try {
                if (!isConnected) {
                    ConnectionSetup.createTestConnections();
                    isConnected = true;
                }
            } catch (RuntimeException e) {
                System.out.println("error while creating database connection, retrying.");
            }
        }
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeSSHConnections();
        ConnectionSetup.closeTestConnections();
    }

}
