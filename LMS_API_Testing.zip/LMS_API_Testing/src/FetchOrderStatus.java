import java.util.HashMap;

import org.json.JSONObject;

import com.base.Response;

import io.restassured.path.json.JsonPath;
import io.restassured.*;

public class FetchOrderStatus {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}
	
	public String getSessionId(String username, String password) {
		
		HashMap<String, String> header = new HashMap<>();
		header.put("Connection", "keep-alive");
		header.put("Accept", "application/json, text/javascript, */*; q=0.01");
		header.put("Origin", "https://10.144.108.164:8080");
		header.put("X-Requested-With", "XMLHttpRequest");
		header.put("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36");
		header.put("Content-Type", "application/json");
		header.put("Sec-Fetch-Site", "same-origin");
		header.put("Sec-Fetch-Mode", "cors");
		header.put("Referer", "https://10.144.108.164:8080/rsilpmc/");
		header.put("Accept-Encoding", "gzip, deflate, br");
		header.put("Accept-Language", "en-US,en;q=0.9");
		
		
		HashMap<String, String> formParams = new HashMap<>();
		/*formParams.put("username", username);
		formParams.put("password", password);
		formParams.put("grant_type", "password");
		formParams.put("client_id", "dps-ui-app");*/

		String endpointHost = "https://10.144.108.164:8080/rsilpmc/userlogin";
		String arrParam[] = { endpointHost, "" };

		JSONObject objJSON = new JSONObject();
		Response postResponse = restapi.call("post", arrParam, objJSON, header, formParams, "");
		Assert.assertEquals(postResponse.statusCode(), 200, "KeyCloak - getToken error");
		JsonPath jsonPathEvaluator = postResponse.getBody().jsonPath();
		return jsonPathEvaluator.get("access_token").toString();

	}
	
	public Response call(String strVerb, String arrParam[], JSONObject objJSON, HashMap<String, String> header,
			HashMap<String, String> formParams, String strFuture) {

		try {

			RestAssured.baseURI = arrParam[0];
			httpRequest = RestAssured.given();
			JSONObject jsonBody = objJSON;
			boolean formParamSet = false;

			addHeader(header);
			formParamSet = addBodyFormParams(formParams);

			if (formParamSet) {
				// Cannot set formParams and body both for API calls
			} else {
				// Add the JSON to the body of the request
				httpRequest.body(jsonBody.toString());
			}

			// Post the request and return the response
			Response response = makeCall(strVerb, arrParam[1]);

			LOGGER.info(strVerb + " call - " + arrParam[0] + arrParam[1] + ", JSON: " + objJSON + ", Status: "
					+ response.getStatusLine() + ". Response Time - " + response.time());
			return response;

		} catch (Exception e) {
			LOGGER.info(strVerb + " call - " + arrParam[0] + arrParam[1] + ", JSON: " + objJSON + ", Exception: "
					+ e.getMessage());
		}
		return null;

	}


}
