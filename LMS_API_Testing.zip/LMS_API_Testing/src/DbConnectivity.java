import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnectivity {
	public static Connection db_Connection = null;
	public static void main(String[] args) throws SQLException 
	{
		// TODO Auto-generated method stub
		
		String myQuery="select SOL_ID from custom.city_pin_mapper where PIN_CODE='125063'";
		String cHost="10.144.109.127";
		String cSID="LLMDEVDB";
		String cUserName="SI_LMS1";
		String sPassword="Dghtjh#gh5";
		String sPort="1521";
		
		create_database_connection_Oracle(cHost,sPort,cSID,cUserName,sPassword);
		ResultSet objTemp = execute_select_statement(myQuery);
		objTemp.next();
		//System.out.println(objTemp.getString("SOL_ID"));
		
		System.out.println(objTemp.getObject(0));
	}
	
	public static ResultSet execute_select_statement(String query) {
        ResultSet resultSet = null;
        try {
            Statement statement = db_Connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            resultSet = statement.executeQuery(query);

            System.out.println(query);
        } catch (Exception e) {
            throw new RuntimeException("Error while executing the select query.");
        }
        return resultSet;
    }
	
	/**
     * Method to create the Oracle database connection
     */
    public static void create_database_connection_Oracle(String host,String port, String SID, String username, String password) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("jdbc:oracle:thin:@"+host+":"+port+":"+SID+""+ ""+username+""+ ""+password+"");
            db_Connection = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+SID+"", ""+username+"", ""+password+"");

        } catch (Exception e) {
            throw new RuntimeException("Error while creating the DB connection", e);
        }
    }
}
