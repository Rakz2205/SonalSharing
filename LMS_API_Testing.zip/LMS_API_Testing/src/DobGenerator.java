
public class DobGenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// YYYYMMDD
		
		int sYear=1971;
		int sMon=1;

	}

}
