## Learn how to install Appium
## Use command line for installation
http://appium.io/getting-started.html


##Android
0. Install Android studio - Latest Version
1. Install AVD emulator - "Nexus 5 API 23"

##IOs
0. Install latest IOs from xcode


