package com.oneview.iOsPoc;

import java.net.URL;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.base.TestBase;

public class Poc extends TestBase{
	
	
	
	/**
	 * Ios Test Bed Appium
	 * */
	
	public void IosDriverSetup() throws Exception {
		RemoteWebDriver rWd;
		// set up appium
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "iOS");
		capabilities.setCapability(CapabilityType.VERSION, "6.1");
		capabilities.setCapability(CapabilityType.PLATFORM, "Mac");
		capabilities.setCapability("app","/Users/username/Downloads/InternationalMountains   /build/Release-iphonesimulator/InternationalMountains.app");
		// set the driver on 
		rWd = new RemoteWebDriver(new URL("http://127.0.0.1:4725/wd/hub"), capabilities);
		}
	
}
