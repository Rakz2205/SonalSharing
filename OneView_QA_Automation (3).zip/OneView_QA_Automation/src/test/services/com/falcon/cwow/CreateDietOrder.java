package com.oneview.cwow;

public class CreateDietOrder {

}
