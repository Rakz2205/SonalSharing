package com.oneview.services;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static com.jayway.restassured.RestAssured.*;
import static org.junit.Assert.*;
//import com.falcon.callers.AuditServiceCaller;

public class AuditService {
	private AuditServiceCaller asc = new AuditServiceCaller();
	
	@BeforeMethod
	public void setup() throws Exception{
		//health check of the audit logging queue
		String body = get(asc.getBaseUri()).andReturn().asString();
		//can't use the rest-assured XmlPath object to parse the response as the server response doesn't return valid xml.
		//the xml fragment intermigles xml syntax and is not valid as per https://stackoverflow.com/questions/9473380/xml-schema-validation-error-prefix-is-not-bound
		//resorting to a java String to parse the response for the queue name.
//		XmlPath xml = new XmlPath(body);
//		xml.setRoot("queue");
//		String auditQueue = xml.getString("name");
//		assertThat(auditQueue, equalTo("jms.queue.audit"));
		//Test
		Boolean validResponse;
		validResponse = body.contains(asc.getQueueName());
		assertTrue(validResponse);
	}
	
	@Test(priority=0, groups = { "bvt" },description= "As a user I should be able to "
			+ "create a log message and put it on the queue and make a call to the DB "
			+ "to determine if the audit message was written to the database")
	public void auditQueueLogsMessage() throws InterruptedException{
		//create a log message and put it on the queue
		given().header(asc.getRequestHeaderTag0(), asc.getRequestHeaderValue0()).and().
				request().body(asc.getRequestBody()).
		when().post(asc.getBaseUri() + asc.getRequestEndpoint() ).
		then().statusCode(201);
		// TASK: make a call to the DB to determine if the audit message was written to the database
		// TODO
		
	}
	
	
	@AfterMethod
	public void tear(){
		//nothing to do here
	}

}

