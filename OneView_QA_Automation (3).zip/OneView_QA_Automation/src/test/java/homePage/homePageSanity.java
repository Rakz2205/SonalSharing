
package homePage;

import java.util.HashMap;
import java.util.logging.Logger;
import org.testng.annotations.BeforeSuite;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.base.Drivers;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.apps.keycloak.KeycloakAPIComponent;

public class homePageSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private HomePageComponent homePageComp;
	private String inputParamUserName = "";
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();

	@Parameters({ "userName" })
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering homePageSanity.BeforeSuite with parameter(s) userName: " + userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", "qadoc001");
	}

	@Parameters({ "userName" })
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering homePageSanity.AfterSuite with parameter(s) userName: " + userName);
		kcAPI.resetUserAttributes(userName);
	}

	@Test(groups = { "Sanity", "CWOW Tabs",
			"Order Screen" }, description = "Verify the Billing api status response")
	public void verifyBillingAPIStatus() throws Exception {
		LOGGER.info("Entering homePageSanity.verifyBillingAPIStatus()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
// To get the API status we need to use the keyword ex: "cwow" and for snappy api "phyportal"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("billing");
		if (!mTAPIResponse.isBillingUp()) {
			Assert.fail("billing API status is down. The following response was captured: isBillingUp="+mTAPIResponse.isBillingUp());
		}
	}

	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = { "Sanity",
			"Home Page" }, dependsOnMethods = {
					"verifyBillingAPIStatus" }, description = "Verify the Keycloak entitlement profile of Physician for OVBS Home Page")
	public void verifyPhysicianProfile(String browserName) {
		LOGGER.info("Entering homePageSanity.verifyPhysicianProfile with parameter(s) userName: " + inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		homePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);
		homePageComp.getInAStatus(inputParamUserName);
		homePageComp.clearPendoTOSModals();
		homePageComp.verifyHomePageOpens();
		homePageComp.verifyNavMenuDisplay();
		homePageComp.verifyCommsHubDisplay();
		homePageComp.verifyMyTasksComponents();
		homePageComp.verifyDavitaAppsDisplay();
	}

	public void preExecutionSetUp(String browserName, String userName) {
		Drivers aWd = new Drivers();
		try {
			getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		} catch (Exception e) {
			Assert.fail("Unable to create the WebDriver");
		}

		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
	}
}
