package ToBeDeleted;

import java.util.List;

import com.base.DataBase;

import io.restassured.response.ResponseBody;

public class DBConnectService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String SnappyLabResultDBQuery="SELECT to_char(r.req_seq_no) ||'-'|| o.identifier ||'-'|| to_char(org.organism_seq_no) ||'-'|| to_char(a.antibiotic_seq_no) AS micro_pk,lr.lab_rslt_seq_no,org.organism_seq_no,n.note_seq_no,lro.LAB_RSLT_ORGANISM_SEQ_NO ,o.offering_seq_no,a.antibiotic_seq_no,o.descr AS test_name,o.identifier AS test_id,v.idrequisitionlab AS requisitionid,rt.descr AS GROWTH,ro.specimen_src AS SOURCE,to_char(r.collection_date,'mm/dd/yy') AS COLLECTION_DATE,to_char(lr.rpt_date,'mm/dd/yy') AS RESULT_DATE,to_char(lr.rpt_date,'hh24mi') AS RESULT_TIME,decode(NVL(to_char(lr.rpt_date,'mm/dd/yyyy'),'Prelim'),'Prelim','Prelim','Final') AS PHASE ,org.descr AS FOUND_ORGANISM,lroa.sensitivity AS SUSCEPTIBILITY_RESULTS,a.descr AS antibiotic,lroa.lab_rslt_alpha AS microscopy,lroa.antibiotic_units ,NVL(v.sitedesc,'Unknown') AS SITE,to_char(n.note_txt) AS Labnote FROM requisitions r LEFT OUTER JOIN lab_results lr ON lr.req_seq_no = r.req_seq_no LEFT OUTER JOIN offerings o ON o.offering_seq_no = lr.offering_seq_no LEFT OUTER JOIN lab_result_organisms lro ON lr.lab_rslt_seq_no = lro.lab_rslt_seq_no LEFT OUTER JOIN requisition_offerings ro ON ro.req_seq_no = r.req_seq_no AND ro.req_offering_seq_no = lr.req_offering_seq_no LEFT OUTER JOIN result_types rt ON rt.rslt_type_cd = lr.rslt_type_cd AND SYSDATE BETWEEN rt.begin_date AND rt.end_date LEFT OUTER JOIN organisms org ON org.organism_seq_no = lro.organism_seq_no LEFT OUTER JOIN lab_result_orgnsm_antibiotics lroa ON lroa.lab_rslt_organism_seq_no = lro.lab_rslt_organism_seq_no LEFT OUTER JOIN antibiotics a ON a.antibiotic_seq_no = lroa.antibiotic_seq_no LEFT OUTER JOIN result_notes rn ON rn.lab_rslt_seq_no = lr.lab_rslt_seq_no LEFT OUTER JOIN notes n ON n.note_seq_no = rn.note_seq_no LEFT OUTER JOIN falcon.requisitions_micro_di_vw v ON v.req_seq_no = r.req_seq_no AND v.org_pr_seq_no = r.org_pr_seq_no AND v.pat_pr_seq_no = r.pat_pr_seq_no AND v.collection_date = r.collection_date WHERE r.pat_pr_seq_no = 7814455 AND r.req_type_cd = 'MICRO-DI'";
		DataBase db=new DataBase();
		ResponseBody aRespBody = db.postQuery(SnappyLabResultDBQuery);
		
		// storing responseBody value into list
		List MICRO_PK = aRespBody.jsonPath().getList("MICRO_PK");
		List ANTIBIOTIC_SEQ_NO = aRespBody.jsonPath().getList("ANTIBIOTIC_SEQ_NO");
		
		System.out.println(MICRO_PK.size());
		System.out.println(ANTIBIOTIC_SEQ_NO.size());
	}

}

/* Output
 25
 25 
 */
