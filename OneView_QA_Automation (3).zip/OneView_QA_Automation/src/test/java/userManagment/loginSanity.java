package userManagment;

import java.util.HashMap;
import java.util.logging.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.base.Drivers;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;

public class loginSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private String inputParamUserName="";
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();

	@Parameters({"userName"})
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering loginSanity.BeforeSuite with parameter(s) userName: "+userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", "qadoc001");
	}
	
	@Parameters({"userName"})
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering loginSanity.AfterSuite with parameter(s) userName: "+userName);
		kcAPI.resetUserAttributes(userName);
	}
	
	@Test(groups = { "Sanity", "login",
			"Order Screen" }, description = "Verify the login api status response")
	public void verifyLoginAPIStatus() throws Exception {
		LOGGER.info("Entering loginSanity.verifyLoginAPIStatus()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
// To get the API status we need to use the keyword ex: "cwow" and for snappy api "phyportal"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("login");
		if (!mTAPIResponse.isLoginUp()) {
			Assert.fail("Login API status is down. The following response was captured: isLoginUp="+mTAPIResponse.isLoginUp());
		}
}
	
	@Test(dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class, dependsOnMethods = {
	"verifyLoginAPIStatus" }, groups = { "Sanity", "Login" }, 
			description = "Verify the login page")
	public void verifylogin(String browserName) {
		LOGGER.info("Entering loginSanity.verifylogin with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		
	}
	
	public void preExecutionSetUp(String browserName, String userName) {
		Drivers aWd = new Drivers();
		try {
			getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		} catch (Exception e) {
			Assert.fail("Unable to create the WebDriver");
		}
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);	
	}


}
