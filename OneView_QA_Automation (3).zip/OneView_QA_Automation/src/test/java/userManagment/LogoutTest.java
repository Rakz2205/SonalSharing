package userManagment;

import java.io.IOException;
import java.util.logging.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.LogoutComponent;
import com.base.Drivers;
import com.base.DriversMan;
import com.base.GenericVariable;
import com.base.Retry;
import com.base.TestBase.URL_Path;

public class LogoutTest {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	DriversMan mdm = new DriversMan();
	private LogoutComponent loc;
	private LoginComponent l;

	@Parameters({"browserName", "userName"})
	@BeforeMethod
	public void setup(String browserName, String userName) throws Exception {
		Drivers aWd = new Drivers();
		if (browserName.isEmpty()) {
			browserName = GenericVariable.CHROME;
		}
		if (userName.isEmpty()) {
			userName = GenericVariable.CHROME;
		}
		mdm.setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
	}

	@Test(retryAnalyzer = Retry.class, priority = 0, groups = { "functional", "bvt", "security",
			"web" }, description = "As a user I should be able to logout the falcon app ")
	public void logout(String userName) throws InterruptedException {
		LOGGER.info("Logout ");
		loc = new LogoutComponent(mdm.getDriver());
		l = new LoginComponent(mdm.getDriver());
		
		l.login(userName);
		loc.logMe_Out();
		//loc.logMe_Out();
	}

	@AfterMethod
	public void takeScreenShot(ITestResult testResult) throws IOException {
		//genericmethods.takeScreenShot(testResult);
	}

}
