package userManagment;

import java.util.logging.Logger;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.Retry;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.LogoutComponent;

public class LogOutSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	//private KeycloakAPIComponent kcAPI;
	private HomePageComponent homePageComp;
	private LogoutComponent logoutComp;
	private String inputParamUserName="";
	
	@Parameters({"userName"})
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering LogOutSanity.BeforeSuite with parameter(s) userName: "+userName);
		inputParamUserName = userName;
	}

	
	@Test(dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class,retryAnalyzer = Retry.class, priority = 0, groups = { "Sanity", "LogOut"},
			description = "As a user I should be able to logout the Oneview app and redirected to the Davita SSO application with the user name displayed in the Username field")
	public void verifyLogout(String browserName) {
		LOGGER.info("Entering HomePageSanity.verifyLogout with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		logoutComp = new LogoutComponent(getMdm().getDriver());
		logoutComp.logOut();
		logoutComp.verifyUserName(inputParamUserName);
	}
	
	public void preExecutionSetUp(String browserName, String userName) {
		Drivers aWd = new Drivers();
		try {
			getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		} catch (Exception e) {
			Assert.fail("Unable to create the WebDriver");
		}
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		homePageComp= new HomePageComponent(getMdm().getDriver(), null);
		homePageComp.clearPendoTOSModals();
	}
}