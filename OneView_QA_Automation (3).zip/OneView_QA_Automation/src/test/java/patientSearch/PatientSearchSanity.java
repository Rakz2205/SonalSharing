package patientSearch;

import java.util.HashMap;
import java.util.logging.Logger;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.apps.oneview.common.PatientSearch;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;

public class PatientSearchSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private PatientSearch src;
	private HomePageComponent HomePageComp;
	String inputParamUserName="";
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();
	
	@Parameters({"userName"})
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering PatientSearchSanity.BeforeSuite with parameter(s) userName: "+userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", GenericVariable.Phyportal_username);
	}
	
	@Parameters({"userName"})
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering PatientSearchSanity.AfterSuite with parameter(s) userName: "+userName);
		kcAPI.resetUserAttributes(userName);
	}
	
	@Test( groups = { "Sanity", "Patient Search" }, 
			description = "Verify the PatientAPIStatus response")
	public void verifyPatientSearchAPIStatus() throws Exception {
		LOGGER.info("Entering PatientSearchSanity.PatientSearchSanity()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
		// To get the API status we need to use the keyword ex: "cwow" and for snappy api "snappy"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("patientSearch");
		if (!mTAPIResponse.isPatientSearchUp()) {
			Assert.fail("patientSearch API status is down. The following response was captured: isPatientSearchUp="+mTAPIResponse.isPatientSearchUp());
		}
	}
	
	@Test( dataProvider="BrowserNameList", dataProviderClass=BrowserNameProvider.class, dependsOnMethods = {
			"verifyPatientSearchAPIStatus"}, groups = { "Sanity", "Patient Search" }, 
			description = "Verify the patients charts appear after selecting a patient")
	public void verifyPatientCharts(String browserName, HashMap searchNameList) throws Exception {
		LOGGER.info("Entering PatientSearchSanity.verifyPatientCharts with parameter(s)"
				+ " userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		String tempName = (String) searchNameList.get("searchName");
		src.searchPatient(tempName);
	}
	
	@Test( enabled = true ,dataProvider="BrowserNameList", dataProviderClass=BrowserNameProvider.class, dependsOnMethods = {
			"verifyPatientSearchAPIStatus"}, groups = { "Sanity", "Patient Search" }, 
			description = "AUT-54 - Verify physician is searching a string with no matching patient")
	public void verifyPatientSearchForNoMatchingPatient(String browserName, HashMap searchNameList) throws Exception {
		LOGGER.info("Entering PatientSearchSanity.verifyPatientSearchForNoMatchingPatient"
				+ " with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		String tempName = (String) searchNameList.get("searchName");
		src.patientSearch(tempName);
		src.verifySearchHeader(tempName);
	}

	@Test (enabled = true , dataProvider="BrowserNameList", dataProviderClass=BrowserNameProvider.class, dependsOnMethods = {
			"verifyPatientSearchAPIStatus"}, groups = { "Sanity", "Patient Search" }, 
			description = "AUT-32 - Verify physician is searching a string with matching patient")
	public void verifyPatientSearchForMatchingPatient(String browserName, HashMap searchNameList) throws Exception {
		LOGGER.info("Entering PatientSearchSanity.verifyPatientSearchForMatchingPatient"
				+ " with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		String tempName = (String) searchNameList.get("searchName");
		src.patientSearch(tempName);
		src.verifySearchHeader(tempName);
		src.verifyPatientList(tempName);
	}
	
	public void preExecutionSetUp(String browserName, String userName) throws Exception {
		LOGGER.info("Entering PatientSearchSanity.preExecutionSetUp with parameter(s) browserName: "+browserName);
		Drivers aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		src = new PatientSearch(getMdm().getDriver());
		
		HomePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);	
		HomePageComp.clearPendoTOSModals();
	}
}