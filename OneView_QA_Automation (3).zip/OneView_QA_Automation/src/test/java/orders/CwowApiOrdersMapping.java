package orders;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.apps.cwow.CwowAPIComponents;
import com.apps.cwow.CwowMappingComponents;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.CwowOrdersComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.base.Drivers;
import com.base.Retry;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.base.GenericVariable;

public class CwowApiOrdersMapping extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private CwowOrdersComponent orderComp;
	private CwowAPIComponents cwowAPI;
	private CwowMappingComponents cwowComp;
	private GenericVariable gv;
	private KeycloakAPIComponent kcAPI;
	private MTAPIResponse MTA;
	String responseCode;
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();


	public void preExecutionSetUp(String browserName,String userName) throws Exception {
		LOGGER.info("Entering CwowAPIMappingTest.preExecutionSetUp with parameter(s) browserName: "+browserName);
		Drivers aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);	
	
}
	@Test( enabled = true, groups = { "Sanity", "CWOW Tabs",  //only works on qa
		"Order Screen" },  priority = 0,description = "Verify the Cwow api status response")
		public void verifyCWOWAPIStatus() throws Exception {
		kcAPI = new KeycloakAPIComponent();
		MTA = new MTAPIResponse(kcAPI.getrptToken());
		LOGGER.info("Entering CwowOrdersSanity.verifyCWOWAPIStatus()");
		// To get the API status we need to use the keyword ex: "cwow" and for snappy api "phyportal"
		apiStatusMap = MTA.getMapOfApiStatus("cwow");
		if (!MTA.isCwowUp()) {
	    Assert.fail("Cwow API status is down. The following response was captured: isCwowUp="+MTA.isCwowUp());
}
	}

	
	 @Test
	  (priority = 1, enabled = false) //dependsOnMethods = {"verifyCWOWAPIStatus"}) ,
	  public void recordCheckDnr() throws Exception {	  
		  	cwowAPI = new CwowAPIComponents();
			 String guid = cwowAPI.checkForExistingOrder("DNR%20Order", gv.CwowMpi2);
		    if (!guid.isEmpty()) {
			 
		    cwowAPI.enterInError(guid, "EnterInError.txt");
		 }
		 
	  }
	 
  @Test // retryAnalyzer = Retry.class , //dependsOnMethods = {"verifyCWOWAPIStatus"} ,
  (enabled = false ,dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class , priority = 2, groups = { "integration" , "api" , "web", "BrowserList:chrome" }, 
description = "As a user I should be able to create an order via a api and verify the order detials page values match")
  public void mapApiRecordtoOneviewDetailsDnr(String browserName) throws Exception {
		LOGGER.info("Creating cwow dnr record and mapping api data to oneview big screen details page");
		preExecutionSetUp(browserName, gv.OV_USER_1);
		orderComp = new CwowOrdersComponent(getMdm().getDriver()); 
		cwowAPI = new CwowAPIComponents();
		cwowComp = new CwowMappingComponents();
		String guid = cwowAPI.createCwowOrders("dnr", "DnrOrder.txt");
		Map api = cwowAPI.dnrOrderListDetails(guid);
		orderComp.navigateToOrderTab();
		Map ov = orderComp.OrderDetailsList("DNR", gv.CWOW_PATIENT_LAST_NAME6);
		cwowComp.compareList(api, ov , "DNR");
		cwowAPI.enterInError(guid, "enterInError.txt");
  }
  
 
  @Test //retryAnalyzer = Retry.class , //dependsOnMethods = {"verifyCWOWAPIStatus"} ,
  ( enabled = false ,dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class ,  priority = 2, groups = { "integration" , "api" , "web" , "BrowserList:chrome" }, 
description = "As a user I should be able to create an order via a api and verify the order summary page values match")
  public void mapApiRecordtoOneviewSummaryDnr(String browserName) throws Exception {
		LOGGER.info("Creating cwow dnr record and mapping api data to oneview big screen summary page");
		preExecutionSetUp(browserName, gv.OV_USER_1);
		orderComp = new CwowOrdersComponent(getMdm().getDriver());
		cwowAPI = new CwowAPIComponents();
		cwowComp = new CwowMappingComponents();
		String guid = cwowAPI.createCwowOrders("dnr", "DnrOrder.txt");
		Map api = cwowAPI.OrderListSummary(guid, "dnr", "dnr");
		orderComp.navigateToOrderTab();
		Map ov = orderComp.OrderSummaryList("DNR" , GenericVariable.CWOW_PATIENT_LAST_NAME6);
		cwowComp.compareList(api, ov , "DNR");
		cwowAPI.enterInError(guid , "enterInError.txt");
  }
    // */

  @Test
  (priority = 1 , enabled = true) //dependsOnMethods = {"verifyCWOWAPIStatus"} ,
  public void recordCheckDiet() throws Exception {	  
	  	cwowAPI = new CwowAPIComponents();
		 String guid = cwowAPI.checkForExistingOrder("Diet%20Order", gv.CwowMpi1);
	    if (!guid.isEmpty()) {
		 
	    cwowAPI.enterInError(guid, "EnterInError.txt");
	 }
	 
  }
  @Test // retryAnalyzer = Retry.class ,  dependsOnMethods = {"verifyCWOWAPIStatus"}
  (enabled = false ,dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class , priority = 2, groups = { "integration" , "api" , "web", "BrowserList:Chrome"  }, 
	description = "As a user I should be able to create an order via a api and verify the order detials page values match")
  public void mapApiRecordtoOneviewDetailsDiet(String browserName) throws Exception {
		LOGGER.info("Creating cwow diet record and mapping api data to oneview big screen details page");
		preExecutionSetUp(browserName, gv.OV_USER_1);
		orderComp = new CwowOrdersComponent(getMdm().getDriver()); 
		cwowAPI = new CwowAPIComponents();
		cwowComp = new CwowMappingComponents(); 
		String guid = cwowAPI.createCwowOrders("diet", "DietOrder.txt");
	 	Map api = cwowAPI.dietOrderListDetails(guid);
		orderComp.navigateToOrderTab();
		Map ov = orderComp.OrderDetailsList("DIET", gv.CWOW_PATEINT_LAST_NAME7);
		cwowComp.compareList(api, ov , "DIET");
		cwowAPI.enterInError(guid , "EnterInError.txt");
  }
  
  @Test //retryAnalyzer = Retry.class ,
  ( enabled = true ,dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class ,  priority = 2, groups = { "integration" , "api" , "web" ,"BrowserList:Chrome" }, 
description = "As a user I should be able to create an order via a api and verify the order summary page values match")
  public void mapApiRecordtoOneviewSummaryDiet(String browserName) throws Exception {
		LOGGER.info("Creating cwow diet record and mapping api data to oneview big screen summary page");
		preExecutionSetUp(browserName,gv.OV_USER_1);
		orderComp = new CwowOrdersComponent(getMdm().getDriver());
		cwowComp = new CwowMappingComponents();
		cwowAPI = new CwowAPIComponents();
		String guid = cwowAPI.createCwowOrders("diet", "DietOrder.txt");
		Map api = cwowAPI.OrderListSummary(guid, "diet", "diet");
		orderComp.navigateToOrderTab();
		Map ov = orderComp.OrderSummaryList("DIET" , gv.CWOW_PATEINT_LAST_NAME7);
		cwowComp.compareList(api, ov , "DIET");
		cwowAPI.enterInError(guid, "EnterInError.txt");
  }

  
}
