package orders;

import java.util.HashMap;
import java.util.logging.Logger;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.Assert;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.apps.oneview.common.SnappyComponent;
import com.apps.keycloak.KeycloakAPIComponent;

public class snappyOrdersSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private HomePageComponent homePageComp;
	private SnappyComponent snappyComponent;
	private String inputParamUserName = "";
	private String activeDirectory;
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();

	@Parameters({ "userName" })
	@BeforeSuite
	public void beforeSuite(String userName) throws Exception {
		LOGGER.info("Entering SnappyOrdersSanity.BeforeSuite with parameter(s) userName: " + userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", GenericVariable.Phyportal_username);
	}

	@Parameters({ "userName" })
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering SnappyOrdersSanity.AfterSuite with parameter(s) userName: " + userName);
		kcAPI.resetUserAttributes(userName);
	}

	@Test(groups = { "Sanity", "snappy" }, description = "Verify phyportal API status response")
	public void verifyPhyPortalAPIStatus() throws Exception {
		LOGGER.info("Entering SnappyOrdersSanity.verifyPhyPortalAPIStatus()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
		// To get the API status we need to use the keyword ex: "cwow" and for snappy
		// api "phyportal"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("phyportal");
		if (!mTAPIResponse.isSnappyUp()) {
			Assert.fail("Snappy API status is down. The following response was captured: isSnappyUp="+mTAPIResponse.isSnappyUp());
		}
	}

	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, dependsOnMethods = {
			"verifyPhyPortalAPIStatus" }, groups = {
					"Sanity" }, description = "As a user I should be able to login the Oneview app and validate the header and footer data for snappy orders")
	public void verifySnappyOrderPanels(String browserName) {
		LOGGER.info("Entering SnappyOrdersSanity.verifySnappyOrderPanels with parameter(s) userName: "
				+ inputParamUserName + " browser type:" + browserName);
		preExecutionSetUp(browserName, inputParamUserName);
		snappyComponent = new SnappyComponent(getMdm().getDriver());
		snappyComponent.clickOnOrders();
		snappyComponent.validateSnappyPanelData();
	}

	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, dependsOnMethods = {
			"verifyPhyPortalAPIStatus" }, groups = { "Sanity", "Snappy Tabs",
					"Panels Data Count" }, description = "As a user I should be able to retrieve the order counts from the Snappy API, login to the Oneview app and validate the recent and total order counts for snappy panels")
	public void verifySnappyOrderPanelsCount(String browserName) throws Exception {
		LOGGER.info("Entering SnappyOrdersSanity.verifySnappyOrderPanelsCount with parameter(s) userName: "
				+ inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		snappyComponent = new SnappyComponent(getMdm().getDriver());
		snappyComponent.clickOnOrders();
		activeDirectory = kcAPI.getActiveDirectoryID();
		snappyComponent.totalSnappyOrdersCountVerificationFromAPIvsUIPanel(activeDirectory);
		snappyComponent.recentSnappyOrdersCountVerificationFromAPIvsUIPanel(activeDirectory);
	}

	public void preExecutionSetUp(String browserName, String userName) {
		LOGGER.info("Entering SnappyOrdersSanity.preExecutionSetUp with userName: " + userName);
		Drivers aWd = new Drivers();
		try {
			getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		} catch (Exception e) {
			Assert.fail("Unable to create the WebDriver");
		}
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		homePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);
		homePageComp.clearPendoTOSModals();
	}
}
