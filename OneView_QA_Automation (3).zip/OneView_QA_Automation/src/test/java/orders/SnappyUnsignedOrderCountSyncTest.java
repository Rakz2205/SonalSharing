package orders;

import java.util.logging.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.PhysicianPortalComponent;
import com.apps.oneview.common.SnappyComponent;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;

public class SnappyUnsignedOrderCountSyncTest extends TestBase 
{
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private Drivers aWd;
	private LoginComponent lgn;
	private SnappyComponent pc;
	private PhysicianPortalComponent pp;
	
	@BeforeMethod
	public void setup() throws Exception {
		aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup("chrome", URL_Path.PhysicianPortal));
		
	}
	
	@Test(enabled = true, priority = 0, groups = { "functional", "OnePhysician", "Snappy Order Count Matching",
	"web" }, description = "FCA-4871 Check Unsigned Snappy count between DPS and PP")
	public void countMatch() throws Exception 
	{
		preExecutionSetup();
		String ppOrderCount= pp.getUnsignedOrderCount();
		
		getMdm().getDriver().close();
		
		aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup("chrome", URL_Path.OneViewBase));
		pc = new SnappyComponent(getMdm().getDriver(	
				
				));
		pp= new PhysicianPortalComponent(getMdm().getDriver());
		
		// Login to the application dps
		LOGGER.info("Login to dps");
		lgn = new LoginComponent(getMdm().getDriver());
		lgn.login(GenericVariable.SnappyUser2);
		
		pc.Click_On_Snappy_Tab();
		
		int dpsOrderCount=pc.getUnsignedOrderCountPhysicainPortal();
		
		pc.Verify_PpCount_with_DPSCount(Integer.parseInt(ppOrderCount), dpsOrderCount);
		
	}
	
	public void preExecutionSetup()
	{
		pc = new SnappyComponent(getMdm().getDriver());
		pp = new PhysicianPortalComponent(getMdm().getDriver());
		
		// Login to the application
		LOGGER.info("Login to Phyportal");
		lgn = new LoginComponent(getMdm().getDriver());
		lgn.login(GenericVariable.Phyportal_username);
	}
	

}
