package orders;

import java.util.HashMap;
import java.util.logging.Logger;
import org.testng.annotations.BeforeSuite;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;
import com.apps.oneview.common.SnappyComponent;
import com.apps.keycloak.KeycloakAPIComponent;

public class allOrdersCountMatchSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private SnappyComponent snappyComp;
	private HomePageComponent homePageComp;
	private String inputParamUserName = "";
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();

	@Parameters({ "userName" })
	@BeforeSuite
	public void beforeSuite(String userName) throws Exception {
		LOGGER.info("Entering AllOrdersCountMatchSanity.BeforeSuite with parameter(s) userName: " + userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", GenericVariable.Phyportal_username);
	}

	@Parameters({ "userName" })
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering AllOrdersCountMatchSanity.AfterSuite with parameter(s) userName: " + userName);
		kcAPI.resetUserAttributes(userName);
	}

	@Test(groups = { "Sanity", "TotalOrdersCount", "cwow", "snappy" }, description = "Verify Status of the API's")
	public void verifyOrdersAPIStatus() throws Exception {
		LOGGER.info("Entering AllOrdersCountMatchSanity.verifyOrdersAPIStatus()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
		//To get the API status we need to use the keyword ex: "cwow" and for snappy api "phyportal"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("cwow", "phyportal");
		if (!mTAPIResponse.isCwowUp() || !mTAPIResponse.isSnappyUp()) {
			Assert.fail("Orders API status is down.  The following responses were captured: isCwowUp="+mTAPIResponse.isCwowUp()+" isSnappyUp="+mTAPIResponse.isSnappyUp());
		}
	}

	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = { "Sanity",
			"MatchTotalOrderCount" }, dependsOnMethods = {
					"verifyOrdersAPIStatus" }, description = "Verify the Match for TotalOrderCount against sum of cwow and snappy")
	public void verifyMatchTotalOrderCount(String browserName) {
		LOGGER.info("Entering AllOrdersCountMatchSanity.verifyMatchTotalOrderCount with parameter(s) userName: "
				+ inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		snappyComp = new SnappyComponent(getMdm().getDriver());
		snappyComp.clickOnOrders();
		snappyComp.matchTotalOrderCountvsCwowAndSnappy();
	}

	public void preExecutionSetUp(String browserName, String userName) {
		LOGGER.info("Entering AllOrdersCountMatchSanity.preExecutionSetUp with userName: " + userName);
		Drivers aWd = new Drivers();
		try {
			getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		} catch (Exception e) {
			Assert.fail("Unable to create the WebDriver");
		}

		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		homePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);
		homePageComp.clearPendoTOSModals();
	}
}
