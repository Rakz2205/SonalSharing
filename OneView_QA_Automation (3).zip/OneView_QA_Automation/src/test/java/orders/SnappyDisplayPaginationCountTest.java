package orders;

import java.util.logging.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.SnappyComponent;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;

public class SnappyDisplayPaginationCountTest extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private Drivers aWd;
	private LoginComponent lgn;
	private SnappyComponent pc;

	
	@BeforeMethod
	public void setup() throws Exception {
		aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup("chrome", URL_Path.OneViewBase));
	}
	
	@Test(priority = 0, groups = { "functional", "OnePhysician", "PaginationCount",
			"web", "TestRailId:3"}, description = "FCA4876 & FCA4877 - User is able to click on snappy tab,get total no of order count , "
			+"left arrow button should disable and right arrow is enable if order count is greater than 20")
			public void Pagecount() {
				preExecutionSetup();
				pc.Click_On_Snappy_Tab();
				pc.readTotalCount();
				pc.GetTotalOrderCount();
				
			}
			@Test(priority = 0, groups = { "functional", "OnePhysician", "Count of snappy orders",
			"web", "TestRailId:5" }, description = "FCA4871:count of snappy orders, " + 
					"Click on snappy tab and user is able to match order badge count with(cwow +snappy order),"
					+"Dispute and sign one order")
			public void CountOfSnappyOrders() {
				String planId = "Pagecount:2";
				preExecutionSetup();
				pc.Click_On_Snappy_Tab();//click on snappy tab
				pc.MatchTotalOrderCount();//addition of cwow and snappy order count
				pc.DisputeSingleOrderCountChanged();//dispute first order from first page detail screen
			}
			
			public void preExecutionSetup()
			{
				pc = new SnappyComponent(getMdm().getDriver());
				
				// Login to the application
				LOGGER.info("Login");
				lgn = new LoginComponent(getMdm().getDriver());
				lgn.login(GenericVariable.SnappyUser2);
			}
		}

