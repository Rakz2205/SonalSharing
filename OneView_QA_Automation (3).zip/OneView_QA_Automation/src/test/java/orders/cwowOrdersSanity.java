package orders;

import java.util.HashMap;
import java.util.logging.Logger;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.base.Drivers;
import com.base.GenericVariable;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.CwowOrdersComponent;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.MTAPIResponse;


public class cwowOrdersSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private CwowOrdersComponent orderComp;
	private HomePageComponent homePageComp;
	String responseCode;
	String inputParamUserName = "";
	HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();

	@BeforeSuite
	@Parameters({ "userName" })
	public void beforeSuite(String userName) throws Exception {
		LOGGER.info("Entering CwowOrdersSanity.BeforeSuite with parameter(s) userName: " + userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", GenericVariable.Phyportal_username);
	}

	@AfterSuite
	@Parameters({ "userName" })
	public void afterSuite(String userName) {
		LOGGER.info("Entering CwowOrdersSanity.AfterSuite with parameter(s) userName: " + userName);
		kcAPI.resetUserAttributes(userName);
	}

	@Test(groups = { "Sanity", "CWOW Tabs",
			"Order Screen" }, description = "Verify the Cwow api status response")
	public void verifyCWOWAPIStatus() throws Exception {
		LOGGER.info("Entering CwowOrdersSanity.verifyCWOWAPIStatus()");
		MTAPIResponse mTAPIResponse = new MTAPIResponse(kcAPI.getrptToken());
		// To get the API status we need to use the keyword ex: "cwow" and for snappy api "phyportal"
		apiStatusMap = mTAPIResponse.getMapOfApiStatus("cwow");
		if (!mTAPIResponse.isCwowUp()) {
			Assert.fail("Cwow API status is down. The following response was captured: isCwowUp="+mTAPIResponse.isCwowUp());
		}
	}
	
	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = { "Sanity",
			"CWOW Tabs",
			"Order Screen" }, description = "Verify the CWOW Tab when screen size is Big", dependsOnMethods = {
					"verifyCWOWAPIStatus" })
	public void verifyCWOWBigScreen(String browserName) throws Exception {
		LOGGER.info("Entering CwowOrdersSanity.verifyCWOWBigScreen with parameter(s) browserName: " + browserName);
		preExecutionSetUp(browserName, inputParamUserName);
		orderComp = new CwowOrdersComponent(getMdm().getDriver());

		// Navigate to orders tab
		orderComp.navigateToOrderTab();

		// verify orders tab is open

		orderComp.verifyOrderPageOpens();
		// verify cwow order has default focus

		orderComp.verifyCwowHasDefaultFocus();

		// set portal size cwow data is displayed as list

		orderComp.setSizeAndVerifyOrderView("Big");

	}

	@Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = { "Sanity",
			"CWOW Tabs",
			"Order Screen" }, description = "Verify the CWOW Tab when screen size is Medium", dependsOnMethods = {
					"verifyCWOWAPIStatus" })
	public void verifyCWOWMediumScreen(String browserName) throws Exception {
		LOGGER.info("Entering CwowOrdersSanity.verifyCWOWMediumScreen with parameter(s) browserName: " + browserName);
		preExecutionSetUp(browserName, inputParamUserName);
		orderComp = new CwowOrdersComponent(getMdm().getDriver());

		// Navigate to orders tab
		orderComp.navigateToOrderTab();

		// verify orders tab is open

		orderComp.verifyOrderPageOpens();
		// verify cwow order has default focus

		orderComp.verifyCwowHasDefaultFocus();

		// set portal size cwow data is displayed as list

		orderComp.setSizeAndVerifyOrderView("Medium");

	}

	public void preExecutionSetUp(String browserName, String userName) throws Exception {
		LOGGER.info("Entering CwowOrdersSanity.preExecutionSetUp with parameter(s) browserName: " + browserName);
		Drivers aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		homePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);
		homePageComp.clearPendoTOSModals();
	}
}