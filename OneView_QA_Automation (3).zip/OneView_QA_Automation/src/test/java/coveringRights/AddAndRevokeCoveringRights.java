package coveringRights;

import java.util.logging.Logger;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.base.Drivers;
import com.base.Retry;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.oneview.common.CoveringRightsComponent;
import com.apps.oneview.common.HomePageComponent;
import com.apps.oneview.common.LoginComponent;
import com.apps.keycloak.KeycloakAPIComponent;

public class AddAndRevokeCoveringRights extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private KeycloakAPIComponent kcAPI;
	private HomePageComponent homePageComp;
	CoveringRightsComponent crComp;
	String inputParamUserName="";
	
	@Parameters({"userName"})
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering AddAndRevokeCoveringRights.BeforeSuite with parameter(s) userName: "+userName);
		inputParamUserName = userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", "qadoc001");
	}
	
	@Parameters({"userName"})
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering AddAndRevokeCoveringRights.AfterSuite with parameter(s) userName: "+userName);
		kcAPI.resetUserAttributes(userName);
	}

	@Test(dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class , 
			retryAnalyzer = Retry.class,priority = 0, groups = { "Sanity", "CoveringRights"}, 
			description = "Verify covering rights are assigned to the physician "
					+ "and Edit Facilities and View History links are displayed")
	public void verifyCoveringRightsAdded(String browserName) throws Exception {
		LOGGER.info("Entering AddAndRevokeCoveringRights.verifyCoveringRightsAdded "
				+ "with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		String physName = crComp.addCoveringRights();
		crComp.verifyEditFacilitiesLinkForPhys(physName);
		crComp.verifyViewHistoryLinkForPhys(physName);
	}
	
	@Test(dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class , 
			retryAnalyzer = Retry.class,priority = 1, groups = { "Sanity", "CoveringRights"}, 
			description = "Verify covering rights are revoked and today's date is displayed"
					+ " on Modal which opens by clicking on View History link")
	public void verifyCoveringRightsRevoked(String browserName) throws Exception {
		LOGGER.info("Entering AddAndRevokeCoveringRights.verifyCoveringRightsRevoked "
				+ "with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName, inputParamUserName);
		String physName = crComp.getPhysicianWithCoveringRights();
		crComp.clickToDisableCoveringRights(physName);
		crComp.verifyDateInViewHistoryModal(physName);
	}
	
	public void preExecutionSetUp(String browserName, String userName) throws Exception {
		LOGGER.info("Entering AddAndRevokeCoveringRights.preExecutionSetUp with parameter(s) browserName: "+browserName);
		Drivers aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
		
		homePageComp = new HomePageComponent(getMdm().getDriver(), kcAPI);
		homePageComp.clearPendoTOSModals();	
		
		crComp = new CoveringRightsComponent(getMdm().getDriver());
		crComp.navToCoveringRights();
	}
}
