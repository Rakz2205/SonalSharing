package DialysisSchedule;

import java.util.logging.Logger;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.base.Drivers;
import com.base.Retry;
import com.base.TestBase;
import com.customannotations.BrowserNameProvider;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.DialysisScheduleComponent;
import com.apps.oneview.common.LoginComponent;

public class DialysisScheduleSanity extends TestBase {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private DialysisScheduleComponent dialysisSchComp;
	private KeycloakAPIComponent kcAPI;
	String inputParamUserName="";
	
	@Parameters({"userName"})
	@BeforeSuite
	public void beforeSuite(String userName) {
		LOGGER.info("Entering DialysisScheduleSanity.BeforeSuite with parameter(s) userName: "+userName);
		inputParamUserName=userName;
		if (kcAPI == null) {
			kcAPI = new KeycloakAPIComponent();
		}
		kcAPI.setPhysAttrib(userName, "PHYS", "BOTH", "qadoc001");
	}
	
	@Parameters({"userName"})
	@AfterSuite
	public void afterSuite(String userName) {
		LOGGER.info("Entering DialysisScheduleSanity.AfterSuite with parameter(s) userName: "+userName);
		kcAPI.resetUserAttributes(userName);
	}
	
	
	
	@Test(dataProvider="BrowserNameList",dataProviderClass=BrowserNameProvider.class , retryAnalyzer = Retry.class,priority = 0, groups = { "Sanity", "Dialysis Schedule","BrowserList:Chrome:Firefox"}, 
			description = "Verify Dialysis Scheduler facility selection")
	public void DialysisScheduleFacilitySelection(String browserName) throws Exception {
		LOGGER.info("Entering DialysisScheduleSanity.DialysisScheduleFacilitySelection with parameter(s) userName: "+inputParamUserName);
		preExecutionSetUp(browserName,inputParamUserName);
		dialysisSchComp=new DialysisScheduleComponent(getMdm().getDriver());
		//Navigate to Patient Tab
		dialysisSchComp.navigateToPatientTab();
		
		//Select facility
		String selectedFacility=dialysisSchComp.selectFacility();
		//Verify Patients, dialysis scheduler application is opened
		
		dialysisSchComp.verifyPatientScreen();
		
		//Verify filter display selected facility Name
		dialysisSchComp.verifySelectedFiltersDisplay(selectedFacility);
		
		//Verify data table header is displayed
		dialysisSchComp.verifyDialysisTableHearderDisplays();
		
		//Verify Facility selected is retained after switching panes
		dialysisSchComp.verifySwitchingRetainsFacility(selectedFacility);
	}
	
	public void preExecutionSetUp(String browserName,String userName) throws Exception {
		LOGGER.info("Entering DialysisScheduleSanity.preExecutionSetUp with parameter(s) browserName: "+browserName);
		Drivers aWd = new Drivers();
		getMdm().setWebDriver(aWd.setup(browserName, URL_Path.OneViewBase));
		
		LoginComponent loginComp = new LoginComponent(getMdm().getDriver());
		loginComp.login(userName);
	}
}
