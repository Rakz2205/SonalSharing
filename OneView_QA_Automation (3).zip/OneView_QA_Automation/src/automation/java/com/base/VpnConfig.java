package com.base;

public class VpnConfig {
	
	public static final String ENABLED = "enable";
	public static final String DISABLED="disable";
	public static final String VPN_CONFIG = DISABLED;
	

}
