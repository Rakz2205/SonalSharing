package com.base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DataBase {
	private Connection con = null;

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	/**
	 * To create connection with DataBase
	 * 
	 * @param connectionString
	 *            Connection string of the DB
	 * @param uname
	 *            User name
	 * @param password
	 *            Password
	 */
	public void createConnection(String connectionString, String uname, String password) {
		LOGGER.info("createConnection: " + connectionString);
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Class.forName("oracle.jdbc.driver.OracleDriver");

			con = DriverManager.getConnection(connectionString, uname, password);
			LOGGER.info("createConnection: " + con);
			LOGGER.info("Con Status: " + con.isClosed());

		} catch (SQLException ex) {
			LOGGER.warning("SQL exception in createConnection" + ex.getMessage());
			Assert.assertTrue(false, "SQL exception in createConnection");
		} catch (ClassNotFoundException e) {
			LOGGER.warning("ClassNotFoundException in createConnection " + e.getMessage());
			Assert.assertTrue(false, "ClassNotFoundException in createConnection");
		}
	}

	/**
	 * To execute select query on DB
	 * 
	 * @param query
	 *            query to be executed
	 * @return Resultset results returned by the query
	 */
	public ResultSet executeQuery(String query) {
		LOGGER.info("executeQuery: " + query);
		ResultSet rs = null;

		Statement stmt = null;
		try {
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(query);

			return rs;
		} catch (SQLException e) {
			LOGGER.warning("SQL exception in executeQuery");
			Assert.assertTrue(false, "SQL exception in executeQuery");
			return rs;
		}
	}

	/**
	 * To execute update or delete query on DB
	 * 
	 * @param query
	 *            query to be executed
	 * @return no of rows updated
	 */
	public int executeUpdate(String query) {
		LOGGER.info("executeUpdate: " + query);

		Statement stmt = null;
		int res = 0;
		try {
			stmt = con.createStatement();
			res = stmt.executeUpdate(query);
			return res;
		} catch (SQLException e) {
			LOGGER.warning("SQL exception in executeUpdate");
			Assert.assertTrue(false, "SQL exception in executeUpdate");
			return res;
		}
	}

	/**
	 * Closes the DataBase connection
	 */
	public void closeConnection() {
		LOGGER.info("closeConnection");
		try {
			if (con != null)
				con.close();

		} catch (SQLException e) {
			LOGGER.warning("SQL exception in closeConnection");
		}
	}

	/**
	 * To get the connection
	 * 
	 * @return Returns the DB connection string
	 */
	public Connection getConnection() {
		return con;
	}
	
	public List returnColList(ResultSet rs, String colName) 
	{
		
		List arrTemp = new ArrayList();
		
		try
		{
			//ResultSetMetaData rsmd = rs.getMetaData();
			while(rs.next()) {
		    	String str = rs.getObject(colName)+"";
		    	arrTemp.add(str);
			}
			
			rs.beforeFirst();
		}
		catch(Exception e)
		{
			//arrTemp.add(null);
			//System.out.println(e.printStackTrace());
			System.out.println(arrTemp.isEmpty());
		}
		
		
		return arrTemp;
	}
	
	public Response postQuery(String body) {
		// get the envProperty from the system
		String envProperty = System.getProperty("oneViewEnv");
		if (envProperty == null || envProperty.isEmpty()) {
			envProperty = "ci";
		}
		// set up our request
		RestAssured.baseURI = GenericVariable.dbConnectUrl;
		RequestSpecification httpRequest = RestAssured.given();
		// add header values
		httpRequest.header("Content-Type", "text/plain");
		// Add a queryParams
		httpRequest.queryParam("env", envProperty);
		// Add body
		httpRequest.body(body);
		// LOGGER.info("Query posted: " +body);
		try {
			return httpRequest.post();

		} catch (Exception e) {
			// LOGGER.info("post to " + GenericVariable.dbConnectUrl + " with a body of: " +
			// body
			// + " failed with an Exception: " + e.getMessage());
		}

		return null;
	}
}

