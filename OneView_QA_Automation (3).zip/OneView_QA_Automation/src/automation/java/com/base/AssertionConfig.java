package com.base;

import java.util.logging.Logger;

import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

public class AssertionConfig extends TestBase{
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	protected Assertion hardAssert = new Assertion();
	protected SoftAssert softAssert = new SoftAssert();

}
