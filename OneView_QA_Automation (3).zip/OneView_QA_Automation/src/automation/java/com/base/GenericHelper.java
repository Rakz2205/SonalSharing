package com.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.openqa.selenium.support.Color;

import com.base.TestBase.URL_Path;

public class GenericHelper {
	private static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private static final String[] BUILDS = {"17134", "16299", "17763"};

	/**
	 * selecting random emulator from an array Auth: Grace T
	 */

	public static String[] arr = {};
	public static String deviceName;

	public static String getDeviceName() {
		return deviceName;
	}

	public static void setDeviceName(String deviceName) {
		GenericHelper.deviceName = deviceName; 
	}

	public static void setLaptoparray(String[] laptoparray) {
		arr = laptoparray;
	}

	public static String[] getLaptoparray() {
		return arr;
	}

	public static String select_Random_From_Array(String[] items) {
		setLaptoparray(items);

		int arrayFound = new Random().nextInt(arr.length);
		String a = Arrays.toString(getLaptoparray());
		List<String> myList = new ArrayList<String>(Arrays.asList(a.split(",")));
		System.out.println("Executing script using: " + myList.get(arrayFound));
		LOGGER.info("Found " + myList.get(arrayFound));

		// system should not select the same index for two different runs

		if (myList.get(arrayFound).equals(deviceName)) {

			if (arrayFound >= 1) {
				arrayFound--;
				String a1 = Arrays.toString(getLaptoparray());
				List<String> myList1 = new ArrayList<String>(Arrays.asList(a1.split(",")));
				System.out.println("Executing script using: " + myList1.get(arrayFound));
				LOGGER.info("Found " + myList1.get(arrayFound));
				setDeviceName(myList1.get(arrayFound));
			}

			if (arrayFound < 1) {

				arrayFound++;
				;
				String a1 = Arrays.toString(getLaptoparray());
				List<String> myList1 = new ArrayList<String>(Arrays.asList(a1.split(",")));
				System.out.println("Executing script using: " + myList1.get(arrayFound));
				LOGGER.info("Found " + myList1.get(arrayFound));
				setDeviceName(myList1.get(arrayFound));

			}

		} else {
			setDeviceName(myList.get(arrayFound));
		}

		return arr[new Random().nextInt(arr.length)];
	}

	/**
	 * Replace with ocurence Auth: Grace T
	 */

	public static String replaceNthOcurrence(String str, String toFind, String toReplace, int ocurrence) {
		Pattern p = Pattern.compile(Pattern.quote(toFind));
		Matcher m = p.matcher(str);
		StringBuffer sb = new StringBuffer(str);
		int i = 0;
		while (m.find()) {
			if (++i == ocurrence) {
				sb.replace(m.start(), m.end(), toReplace);
				break;
			}
		}
		return sb.toString();
	}

	/**
	 * Organized loggers Auth Grace T
	 **/
	public static void build_LogFile() {
		UseLogger tester = new UseLogger();
		try {
			MyLogger.setup();
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Problems with creating the log files");
		}
		tester.doSomeThingAndLog();
	}

	/**
	 * Method to compare two lists ignoring case
	 * 
	 * @author Neha Sinha
	 * 
	 * @param list1
	 * @param list2
	 * @return returns true if both the list are equal
	 */
	public static boolean equalsIgnoreCase(List<String> list1, List<String> list2) {
		if (list1.size() != list2.size()) {
			LOGGER.info("equalsIgnoreCase| List size doesn't match: List 1" + list1 + " List2: " + list2);
			return false;
		}
		for (Iterator<String> iter1 = list1.iterator(), iter2 = list2.iterator(); iter1.hasNext();) {
			if (!iter1.next().equalsIgnoreCase(iter2.next())) {
				LOGGER.info("equalsIgnoreCase| List doesn't match: List 1" + list1 + " List2: " + list2);
				return false;
			}
		}
		return true;
	}

	/**
	 * Converts a string to title case Ex: If input is 'how are you', the output
	 * will be 'How Are You'
	 * 
	 * @author Neha Sinha
	 * 
	 * @param strText text to be converted
	 * @return the title case string
	 */
	public static String toTitleCase(String strText) {
		if (strText == null)
			return null;

		StringBuilder sb = new StringBuilder(strText.length());

		for (String word : strText.split(" ")) {
			if (!word.isEmpty()) {
				sb.append(word.substring(0, 1).toUpperCase());
				sb.append(word.substring(1).toLowerCase());
			}
			if (!(sb.length() == strText.length()))
				sb.append(" ");
		}

		String txt = sb.toString();
		if (txt.contains("-")) {
			sb = new StringBuilder(txt.length());
			for (String word : txt.split("-")) {
				if (!word.isEmpty()) {
					sb.append(word.substring(0, 1).toUpperCase());
					sb.append(word.substring(1));
				}
				if (!(sb.length() == txt.length()))
					sb.append("-");
			}
		}
		return sb.toString();
	}

	/**
	 * 
	 * @author Rakesh Gupta
	 * @param inputDate Date in String which need to be format
	 * @param pattern   Pattern in which date should be format ex : MM/DD/YYYY
	 * @return formatted date , if input Date is not as date , it will return same
	 *         value
	 */

	public static String dateFormat(String inputDate, String pattern) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		try {
			inputDate = simpleDateFormat.format(new Date(inputDate));
		} catch (Exception e) {
		}

		return inputDate;
	}

	/**
	 * 
	 * @author Rakesh Gupta
	 * @param inputArray      Array which contains all the value
	 * @param datatobematched Value which need to be search in array
	 * @return true if the element is present else it will return false
	 */

	public static boolean CheckInArray(String[] inputArray, String datatobematched) {
		List<String> arrstrTemp = Arrays.asList(inputArray);
		for (int listIterator = 0; listIterator < arrstrTemp.size(); listIterator++) {
			String strTemp = arrstrTemp.get(listIterator).toUpperCase();
			arrstrTemp.set(listIterator, strTemp);
		}
		boolean objTemp = Arrays.asList(inputArray).contains(datatobematched);
		if (objTemp)
			return true;
		else
			return false;
	}
	/**
	 * Makes the execution wait for the specified seconds.
	 * @param seconds = the number of seconds the script excecution to be paused.
	 * @return void
	 */
	public static void sleepSeconds(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			LOGGER.setLevel(Level.SEVERE);
			LOGGER.severe("System die while sleeping");
			e.printStackTrace();
		}
	}
	
	/**
	 * Converts RGB to Hex
	 * @param someRgbColor String representing the rgb value
	 * @return Hexidecimal color as a String
	 */
	public static String convertRGBToHex(String someRgbColor) {
		String hexColor = Color.fromString(someRgbColor).asHex();
		return hexColor;
	}
	
	/**
	 * Gets the system property oneViewEnv to return the 
	 * appropriate base url for an application in that environment 
	 * @return Returns base url of the application under test
	 */
	
	public static String getBaseURL(URL_Path url) {
		String oneViewEnv;
		String env = System.getProperty("oneViewEnv");
		if (env != null) {
			oneViewEnv = env.toUpperCase();
		} else {
			oneViewEnv = "QA";
		}
		String baseUrl = null;
		if ((oneViewEnv != null) && !(oneViewEnv.isEmpty())) {
			switch (oneViewEnv) {
			case "QA":
				if (url.equals(URL_Path.CWOW)) {
					baseUrl = GenericVariable.CWOW_QA_HOST;
				} else if (url.equals(URL_Path.PhysicianPortal)) {
					baseUrl = GenericVariable.Physician_portal_url;
				} else if (url.equals(URL_Path.KeycloakUsers)) {
					baseUrl = GenericVariable.DPS_QA_HOST + GenericVariable.URLKeyCloakUsersSuffix;
				} else if (url.equals(URL_Path.CWOWAPICOMMAND)) {
				    baseUrl = GenericVariable.CWOW_QA_API;
				} else if (url.equals(URL_Path.CWOWAPISEARCH)) {
				    baseUrl = GenericVariable.CWOW_QA_API_SEARCH;
				} else if (url.equals(URL_Path.CWOWAPIQUERY)) {
				    baseUrl = GenericVariable.CWOW_QA_API_QUERY;	    
			  	} else {
					baseUrl = GenericVariable.DPS_QA_HOST;
				}
				break;
			case "CI":
				if (url.equals(URL_Path.CWOW)) {
					baseUrl = GenericVariable.CWOW_INT_HOST;
				} else if (url.equals(URL_Path.PhysicianPortal)) {
					baseUrl = GenericVariable.Physician_portal_url;
				} else if (url.equals(URL_Path.KeycloakUsers)) {
					baseUrl = GenericVariable.DPS_CI_HOST + GenericVariable.URLKeyCloakUsersSuffix;
				} else if (url.equals(URL_Path.CWOWAPICOMMAND)) {
					baseUrl = GenericVariable.CWOW_INT_API;
				} else if (url.equals(URL_Path.CWOWAPISEARCH)) {
				    baseUrl = GenericVariable.CWOW_INT_API_SEARCH;
				} else if (url.equals(URL_Path.CWOWAPIQUERY)) {
				    baseUrl = GenericVariable.CWOW_INT_API_QUERY;		
				} else {
					baseUrl = GenericVariable.DPS_CI_HOST;
				}
				break;
			case "RC":
				if (url.equals(URL_Path.CWOW)) {
					baseUrl = GenericVariable.CWOW_QA_HOST;
				} else if (url.equals(URL_Path.PhysicianPortal)) {
					baseUrl = GenericVariable.Physician_portal_url;
				} else if (url.equals(URL_Path.KeycloakUsers)) {
					baseUrl = GenericVariable.DPS_RC_HOST + GenericVariable.URLKeyCloakUsersSuffix;
				} else if (url.equals(URL_Path.CWOWAPICOMMAND)) {
					baseUrl = GenericVariable.CWOW_RC_API;
				} else if (url.equals(URL_Path.CWOWAPISEARCH)) {
				    baseUrl = GenericVariable.CWOW_RC_API_SEARCH;
				} else if (url.equals(URL_Path.CWOWAPIQUERY)) {
				    baseUrl = GenericVariable.CWOW_RC_API_QUERY;		
				} else {
					baseUrl = GenericVariable.DPS_RC_HOST;
				}
				break;
			default:
				baseUrl = GenericVariable.DPS_QA_HOST;
				break;
			}
			if (url.equals(URL_Path.OneViewOrders)) {
				baseUrl = baseUrl + GenericVariable.OrderUrlSuffix;
			} else if (url.equals(URL_Path.OneViewPatients)) {
				baseUrl = baseUrl + GenericVariable.PatientsUrlSuffix;
			}
		} else {
			baseUrl = GenericVariable.DPS_QA_HOST;
		}
		return baseUrl;

	}
	
	@SuppressWarnings("unused")
	public static HashMap fetchValueFromExcel(String testName) throws IOException 
	{
		String projectLocation = System.getProperty("user.dir") + "\\InputDataProvider";
		String inputFilePath=projectLocation+"//"+testName+".xls";
		
		//read value from excel and store in a hash map
		//importing excel sheet
		File srcFile=new File(inputFilePath);
	
		//load the file
		FileInputStream finput=new FileInputStream(srcFile);
		
		//load workbook
		
		HSSFWorkbook workbook =new HSSFWorkbook(finput);
		
		//load sheet
		HSSFSheet sheet=workbook.getSheetAt(0);
		
		//fetch the value
		HSSFCell cell;
		
		// creating local HashMap
		
		HashMap objTemp=new HashMap();
		DataFormatter dataFormatter = new DataFormatter();
		for(int excelInc=1;excelInc<sheet.getLastRowNum();excelInc++)
		{
			cell=sheet.getRow(excelInc).getCell(0);
			
			String parameterName=dataFormatter.formatCellValue(cell);
			
			cell=sheet.getRow(excelInc).getCell(1);
			
			String parameterValue=dataFormatter.formatCellValue(cell);
			objTemp.put(parameterName, parameterValue);
		}
		return objTemp;
	}

	/**
	 * Gets the windows build number from the environment 
	 * @return String representing the build number
	 */
    public static String getWinBuild() {
        String osName = findSysInfo("OS Version:");
        if (!osName.isEmpty()) {
            for (String build : BUILDS) {
                if (osName.contains(build)) {
                    return build;
                }
            }
        }
        return "";
    }	
  
	/**
	 * Gets the line of output associated with the term
	 * @param search term the FINDSTR function should match 
	 * @return String line of output containing the search term
	 */
    public static String findSysInfo(String term) {
        try {
            Runtime rt = Runtime.getRuntime();
            Process pr = rt.exec("CMD /C SYSTEMINFO | FINDSTR /B /C:\"" + term + "\"");
            BufferedReader in = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            return in.readLine();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        return "";
    }
    
	  /**
		 * @param fileName  from local drive  
		 * @return file as string
		 * turns txt file into a string  
		 */
	  
	  public static String readFileAsString( String fileName) throws Exception
	  	{
		  String data = "";
		  data = new String(Files.readAllBytes(Paths.get(fileName)));
		  return data;
		  
	  	}
}
