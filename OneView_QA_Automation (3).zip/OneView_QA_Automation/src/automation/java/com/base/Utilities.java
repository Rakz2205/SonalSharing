package com.base;

public class Utilities {

	public static String fetchPropertyValue(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
