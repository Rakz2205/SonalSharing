package com.base;



import org.openqa.selenium.WebDriver;

public class DriversMan {
    private ThreadLocal<WebDriver> webDriver = new ThreadLocal<WebDriver>();   
    //private Drivers aDriver = new Drivers();
    //private Drivers factory = new Drivers(null);
 
    public WebDriver getDriver() {
        return webDriver.get();
    }
 
    public synchronized void setWebDriver(WebDriver wd) {
    	webDriver.set(wd);
    }
    
//    public void setWebDriver(String browser, String url) {
//        try {
//			webDriver.set(aDriver.setup(browser, url));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    }
    
//    public void setWebDriver(String browser, String url, String deviceName) {
//        try {
//			webDriver.set(aDriver.setup(browser, url));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    }
    
    public void tearDown() {
    	//aDriver.tearDown(webDriver.get());
        	//webDriver.get().close();
    	if(webDriver.get()!=null) {
        	webDriver.get().quit();
    	}
    }
    
}
