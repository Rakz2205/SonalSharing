package com.base;

import java.util.logging.Logger;

import com.base.GenericVariable;

import io.restassured.RestAssured;

public class Rest {

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	public static String goal;
	public static String type;

	public static String getType() {
		return type;
	}

	public static void setType(String type) {
		Rest.type = type;
	}

	public static String getGoal() {
		return goal;
	}

	public static void setGoal(String goal) {
		Rest.goal = goal;
	}

	/**
	 * Pass goal parameter for transform create and confirm to create order--->
	 * Grace T
	 */
	
	public static void setup() {
		System.out.println(getGoal()+"  "+getType());
		if (getGoal() == null) {
			LOGGER.info("goal cannot be null in the setup method");
		}
		if (getGoal().isEmpty()) {
			LOGGER.info("goal cannot be empty in the setup method");
		}

		if (getType() == null) {
			LOGGER.info("type cannot be null in the setup method");
		}
		if (getType().isEmpty()) {
			LOGGER.info("type cannot be empty in the setup method");
		}
		if (getGoal().equalsIgnoreCase("create")) {

			if (getType().equalsIgnoreCase("diet")) {
				String basePath = System.getProperty("server.base");
				if (basePath == null) {
					LOGGER.info("Using path: " + GenericVariable.DIET_ORDER_CREATEEVENT_PATH);
					basePath = GenericVariable.DIET_ORDER_CREATEEVENT_PATH;
				}
				RestAssured.basePath = basePath;

				String baseHost = System.getProperty("server.host");
				if (baseHost == null) {
					LOGGER.info("Using host: " + GenericVariable.DIET_ORDER_CREATEEVENT_HOST);
					baseHost = GenericVariable.DIET_ORDER_CREATEEVENT_HOST;
				}
				RestAssured.baseURI = baseHost;
			} else if (getType().equalsIgnoreCase("treatment")) {

			} else if (getType().equals("lab")) {

			} else if (getType().equals("hemodialysis")) {
				LOGGER.info("Not yet implemented in project and framework");

			} else {
				LOGGER.info(
						"type is not recognized by the framework. Verify type is added in both CWOW and Automation framework");
			}

		} else if (getGoal().equalsIgnoreCase("transform")) {
			if (getType().equalsIgnoreCase("diet")) {
				String basePath = System.getProperty("server.base");
				if (basePath == null) {
					LOGGER.info("Using path: " + GenericVariable.TRANSFORM_ORDER_CREATEEVENT_PATH);
					basePath = GenericVariable.TRANSFORM_ORDER_CREATEEVENT_PATH;
				}
				RestAssured.basePath = basePath;

				String baseHost = System.getProperty("server.host");
				if (baseHost == null) {
					LOGGER.info("Using host: " + GenericVariable.TRANSFORM_ORDER_CREATEEVENT_HOST);
					baseHost = GenericVariable.TRANSFORM_ORDER_CREATEEVENT_HOST;
				}
				RestAssured.baseURI = baseHost;
			} else if (getType().equalsIgnoreCase("treatment")) {

			} else if (getType().equals("lab")) {

			} else if (getType().equals("hemodialysis")) {
				LOGGER.info("Not yet implemented in project and framework");

			} else {
				LOGGER.info(
						"type is not recognized by the framework. Verify type is added in both CWOW and Automation framework");
			}

		} else if (getGoal().equalsIgnoreCase("confirm")) {
			if (getType().equalsIgnoreCase("diet")) {
				String basePath = System.getProperty("server.base");
				if (basePath == null) {
					LOGGER.info("Using path: " + GenericVariable.CONFIRM_ORDER_CREATEEVENT_PATH);
					basePath = GenericVariable.CONFIRM_ORDER_CREATEEVENT_PATH;
				}
				RestAssured.basePath = basePath;

				String baseHost = System.getProperty("server.host");
				if (baseHost == null) {
					LOGGER.info("Using host: " + GenericVariable.TRANSFORM_ORDER_CREATEEVENT_HOST);
					baseHost = GenericVariable.TRANSFORM_ORDER_CREATEEVENT_HOST;
				}
				RestAssured.baseURI = baseHost;
			} else if (getType().equalsIgnoreCase("treatment")) {

			} else if (getType().equals("lab")) {

			} else if (getType().equals("hemodialysis")) {
				LOGGER.info("Not yet implemented in project and framework");

			} else {
				LOGGER.info(
						"type is not recognized by the framework. Verify type is added in both CWOW and Automation framework");
			}
		} else {
			LOGGER.info(
					"Goal is not recognized by the framework. Verify type is added in both CWOW and Automation framework");
		}
		
		System.out.println("success!!");
	}

}
