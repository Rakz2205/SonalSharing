package com.base;

import java.util.logging.Logger;
import org.junit.rules.MethodRule;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;
import org.openqa.selenium.WebDriver;

public class ManyBrowsers implements MethodRule {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public static WebDriver driver;

	// @BeforeClass
	public Statement apply(final Statement base, FrameworkMethod method, Object target) {
		return new Statement() {

			@Override
			public void evaluate() throws Throwable {
				Drivers aWd = new Drivers();
				// RUN FIREFOX
				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				// create chrome instance
				driver = aWd.setup("firefox", null);
				base.evaluate();

				// RUN CHROME
				// File f = //PATH to CHROME DRIVER
				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				// create chrome instance
				driver = aWd.defaultDriver();
				base.evaluate();

				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				// create chrome instance
				driver = aWd.defaultDriver();
				base.evaluate();

				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				// create chrome instance
				driver = aWd.defaultDriver();
				base.evaluate();

			}
		};

	}

}
