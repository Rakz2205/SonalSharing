package com.base;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Logger;

import org.apache.commons.httpclient.auth.AuthenticationException;


import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;

public class jiraIntegration {
	
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
    //https://jiratest.davita.com/secure/Dashboard.jspa
	static String jiraHost = "http://localhost:8080/rest/api/latest/issue";
	static String Uname = "gtshihata";
	static String Password = "Davita123456!";

	public static String invokePostMethod() throws IOException {

		Client client = Client.create();
		WebResource webResource = client.resource(jiraHost);

		String data = "{'fields':{'project':{'key':'DEMO'},'summary':'REST Test','issuetype':{'name':'Bug'}}}";

		String auth = new String(Base64.encode(Uname + ":" + Password));
		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").post(ClientResponse.class, data);
		int statusCode = response.getStatus();

		if (statusCode == 401) {
			throw new AuthenticationException("Invalid Username or Password");
		} else if (statusCode == 403) {
			throw new AuthenticationException("Forbidden");
		} else if (statusCode == 200 || statusCode == 201) {
			System.out.println("Ticket Create succesfully");
		} else {
			System.out.print("Http Error : " + statusCode);
		}
		// // ******************************Getting Responce
		// body*********************************************
		BufferedReader inputStream = new BufferedReader(new InputStreamReader(response.getEntityInputStream()));
		String line = null;
		while ((line = inputStream.readLine()) != null) {
			System.out.println(line);

		}
		return response.getEntity(String.class);

	}

}