package com.base;

public class GenericVariable {

	// Falcon Url section


	public static final String DPS_QA_HOST = "https://qa.oneviewdps.davita.com/";
	public static final String DPS_CI_HOST = "https://ci.oneviewdps.davita.com/";
	public static final String DPS_RC_HOST = "https://rc.oneviewdps.davita.com/";
	public static final String BaseUrl = "https://qa.oneviewdps.davita.com/";
	public static final String OrderUrlSuffix = "/Orders";
	public static final String RoundingUrlSuffix = "/rounding_ui";
	public static final String dashboardUrl = BaseUrl;
	public static final String PatientsUrlSuffix = "#/patients";
	public static final int intElementWaitTimeout = 6;
	public static final String DEFAULT_HOST = "https://qa.oneviewdps.davita.com";
	public static final String TESTRAIL_HOST = "http://10.186.117.130:80";

	// OV DPS Credential Section
	public static final String OV_USER_1 = "jojoseph";
	public static final String AUTOMATION_SANITY_PWD ="P@ssword1";
	public static final String OV_USER_1_NAME = "Joseph, Joju";
	public static final String OV_USER_2 = "ipaduser1";
	public static final String OV_USER_3 = "hhelderman";
	public static final String OV_USER_3_NAME = "Helderman, J";
	public static final String OV_USER_4 = "pchowdhury";
	public static final String OV_USER_5 = "crobertson";
	public static final String OV_DEFAULT_PASSWORD = "1";
	public static final String OV_PASSWORD_3 = "j";	
	public static final String CHROME = "chrome";
	public static final String EDGE = "MicrosoftEdge";
	public static final String FIREFOX = "firefox";
	public static final String OV_LOGO_REL_PATH="assets/images/DaVita_Logo_RGB_2C.png";
	
	
	
	
	//TestRail credentials
	public static final String TESTRAIL_USERNAME = "svc_flcntestauto@davita.com";
	public static final String TESTRAIL_PASSWORD = "abc123";	

	/**
	 * CWOW url section
	 */

	public static final String CWOW_INT_HOST = "https://cwow-int.davita.com/";
	public static final String CWOW_QA_HOST = "https://cwow-qa.davita.com";
	public static final String CWOW_RC_HOST = "https://cwow-stg.davita.com";
	public static final String CWOW_RC_API = "https://cwow-zuul-stage.davita.com/cwow-orders-command/v2/orders/";
	public static final String CWOW_INT_API = "https://cwow-zuul-int.davita.com/cwow-orders-command/v2/orders/";
	public static final String CWOW_QA_API = "https://cwow-zuul-qa.davita.com/cwow-orders-command/v2/orders/";
	public static final String CWOW_INT_API_SEARCH = "https://cwow-zuul-int.davita.com/cwow-orders-search/v2/orders/";
	public static final String CWOW_QA_API_SEARCH = "https://cwow-zuul-qa.davita.com/cwow-orders-search/v2/orders/";
	public static final String CWOW_RC_API_SEARCH = "https://cwow-zuul-stage.davita.com/cwow-orders-search/v2/orders/";
	public static final String CWOW_INT_API_QUERY = "https://cwow-zuul-int.davita.com/cwow-orders-query/v2/orders/";
	public static final String CWOW_QA_API_QUERY = "https://cwow-zuul-qa.davita.com/cwow-orders-query/v2/orders/";
	public static final String CWOW_RC_API_QUERY = "https://cwow-zuul-stage.davita.com/cwow-orders-query/v2/orders/";
	/**
	 * end of CWOW url section
	 */
	// Servers variables CWOW
	public static final String DIET_ORDER_CREATEEVENT_HOST = "http://sea1a2pappu279.davita.corp/";
	public static final String TRANSFORM_ORDER_CREATEEVENT_HOST = "https://cwow-int.davita.com";
	// CWOW Path
	public static final String DIET_ORDER_CREATEEVENT_PATH = "DecisionService/rest/v1/CommandEventsRuleApp/CommandEventRules";
	public static final String TRANSFORM_ORDER_CREATEEVENT_PATH = "/platform-command-controller/api/command/transform-process";
	public static final String CONFIRM_ORDER_CREATEEVENT_PATH = "/cwowmt-order-microservice/orders";
	// CWOW Credential Section
	public static final String CWOW_USERNAME_1 = "ACAMBRON";
	public static final String CWOW_USERNAME_2 = "ABUCKLE";
	public static final String CWOW_USERNAME_3 = "AB24124";
	public static final String CWOW_USERNAME_AUTOMATION_RESTRICTED=CWOW_USERNAME_1;
	public static final String CWOW_PASSWORD_AUTOMATION_RESTRICTED="H6g9F4*!";
	public static final String CWOW_PASSWORD = "H6g9F4*!";
	public static final String CWOW_PASSWORD_2 = "Hag7P4*!";
	// end of CWOW Credential Section


	// Mailing credentials
	public static final String GMAIL_USERNAME = "angular.automation.team";
	public static final String GMAIL_PASSWORD = "Angular1234";

	// team email
	public static final String GRACE_MAIL = "angular.automation.team";
	public static final String KEITH_MAIL = "Angular1234";
	public static final String KUNAL_MAIL = "angular.automation.team";
	public static final String MAGESH_MAIL = "Angular1234";
	public static final String YOLANDA_MAIL = "angular.automation.team";
	public static final String TAMARA_MAIL = "Angular1234";

	// Generic variable Section
	public static final String logintitle = "Login - DaVita Village Login Service";
	public static final String LOGOUT_TITLE = "Physician Solutions";
	// Devices Section
	public static final String BlackBerry_Z30 = "BlackBerry Z30";
	public static final String Blackberry_PlayBook = "Blackberry PlayBook";
	public static final String Galaxy_Note_3 = "Galaxy Note 3";
	public static final String Galaxy_Note_II = "Galaxy Note II";
	public static final String Galaxy_S_III = "Galaxy S III";
	public static final String Kindle_Fire_HDX = "Kindle Fire HDX";
	public static final String LG_Optimus_L70 = "LG Optimus L70";
	public static final String Laptop_with_HiDPI_screen = "Laptop with HiDPI screen";
	public static final String Laptop_with_MDPI_screen = "Laptop with MDPI screen";
	public static final String Laptop_with_touch = "Laptop with touch";
	public static final String Microsoft_Lumia_550 = "Microsoft Lumia 550";
	public static final String Microsoft_Lumia_950 = "Microsoft Lumia 950";
	public static final String Nexus_10 = "Nexus 10";
	public static final String Nexus_4 = "Nexus 4";
	public static final String Nexus_5 = "Nexus 5";
	public static final String Nexus_6 = "Nexus 6";
	public static final String Nexus_7 = "Nexus 7";
	public static final String Nokia_Lumia_520 = "Nokia Lumia 520";
	public static final String Nokia_N9 = "Nokia N9";
	public static final String iPad_Mini = "iPad Mini";
	public static final String iPhone_4 = "iPhone 4";
	public static final String Galaxy_S5 = "Galaxy S5";
	public static final String Nexus_5X = "Nexus 5X";
	public static final String Nexus_6P = "Nexus 6P";
	public static final String iPhone_5 = "iPhone 5";
	public static final String iPhone_6 = "iPhone 6";
	public static final String iPhone_6_Plus = "iPhone 6 Plus";
	public static final String iPad = "iPad";

	public static final String[] mobileArray = new String[] { BlackBerry_Z30, Blackberry_PlayBook, Galaxy_Note_3,
			Galaxy_S_III, Kindle_Fire_HDX, LG_Optimus_L70, Laptop_with_HiDPI_screen, Laptop_with_MDPI_screen,
			Laptop_with_touch, Microsoft_Lumia_550, Microsoft_Lumia_950, Nexus_10, Nexus_4, Nexus_5, Nexus_6, Nexus_7,
			Nokia_Lumia_520, Nokia_N9, iPad_Mini, iPhone_4, Galaxy_S5, Nexus_5X, Nexus_6P, iPhone_5, iPhone_6,
			iPhone_6_Plus, iPad };

	/**
	 * Devices Array grouping
	 */

	public static final String[] iPhoneArray = new String[] { iPhone_4, iPhone_5, iPhone_6, iPhone_6_Plus };

	public static final String[] iPadArray = new String[] { iPad_Mini, iPad };

	public static final String[] NexusArray = new String[] { Nexus_10, Nexus_4, Nexus_5, Nexus_6, Nexus_7, Nexus_5X,
			Nexus_6P };

	public static final String[] OXArray = new String[] { iPad_Mini, iPhone_4, iPhone_5, iPhone_6, iPhone_6_Plus,
			iPad };
	public static final String[] AndroidArray = new String[] { Galaxy_Note_3, Galaxy_S_III, LG_Optimus_L70, Nexus_10,
			Nexus_4, Nexus_5, Nexus_6, Nexus_7, Galaxy_S5, Nexus_5X, Nexus_6P };

	public static final String[] WindowsArray = new String[] { Microsoft_Lumia_550, Microsoft_Lumia_950,
			Nokia_Lumia_520, Nokia_N9 };

	public static final String[] LapTopArray = new String[] { Laptop_with_HiDPI_screen, Laptop_with_MDPI_screen,
			Laptop_with_touch };

	/**
	 * Order Summary Headers
	 */
	public final String PATIENT = "Patient";
	public final String FACILITY = "Facility";
	public final String STATUS = "Status";
	public final String ENTERED = "Entered";
	public final String ORDER = "Order";
	public final String JUSTIFICATION = "Justification";

	// Credentials to be used for DaVita One Physician App scripts
	// Added by pnayak - 02/01/18
	// username of Davita user having NPI and security page after login#
	public static final String usernameDvOPNPISecurityPage = "qadoc001";
	public static final String pwdDvOPNPISecurityPage = "j";

	// username of Davita user having NPI and NO security page after login#
	public static final String usernameDvOPNPINoSecurityPage = "jla98762";
	public static final String pwdDvOPNPINoSecurityPage = "j";
	public static final String lnDvOPNPINoSecurityPage = "Julia";
	public static final String fnDvOPNPINoSecurityPage = "Lewis";

	// username of Davita user having No NPI and security page after login#
	public static final String usernameDvOPNoNPISecurityPage = "NeedInfo";
	public static final String pwdDvOPNoNPISecurityPage = "NeedInfo";

	// username of Davita user having No NPI and NO security page after login#
	public static final String usernameDvOPNoNPINoSecurityPage = "jla98762";
	public static final String pwdDvOPNoNPINoSecurityPage = "j";

	// username of Non-Davita users#
	public static final String usernameNonDavita = "NeedInfo";
	public static final String pwdNonDavita = "NeedInfo";
	
	// username of Davita user not registered in COMMs Hub having NPI and NO security page after login#
	public static final String usernameNotInCommsNoSecPage = "qadoc001";
	public static final String pwdNotInCommsNoSecPage = "j";
	
	//Username of DaVita user registered in Comms Hub having security page and comms cards data
	public static final String usernameInCommsSecPageCommsData = "rlynn";
	public static final String pwdInCommsSecPageCommsData = "robert";
	public static final String lnInCommsSecPageCommsData = "Robert";
	public static final String fnInCommsSecPageCommsData = "Lynn";
	public static final String npiInCommsSecPageCommsData = "1851388862";

	/***
	 * Diet order details Auth:Grace Tshihata
	 */
	public static final String CaloriesArray =  "30";
	public static final String ProteinArray = "1.3";
	public static final String DIET_ORDER_OTHER_MODIFICATION =  "medicationTest1";

	public static final String DIET_AND_TX_ORDER_ORDER_SOURCE = "Secure Message";
	public static final String DIET_AND_TX_ORDER_PROVIDERS = "joseph";
	public static final String DIET_AND_TX_ORDER_PROVIDERS2 = "Robertson";
	
	/**
	 * Tx order details Auth Grace T*/
	
	public static final String TX_FREQUENCY = "One time a week";

	public static final String Bicarbonate ="28";
	public static final String Dialysate_Temperature="38";
	public static final String Base_Sodium ="135";
	public static final String Blood_Flow_Rate ="200";
	public static final String Dialysate_Flow_Rate = "300";

	/**
	 * Dispute/Refute 
	 */
	
	public static final String RefuteReason =   "Verify text is same";
	public static final String VerifyDisputeAgain = "DISPUTE AGAIN";
	public static final String Justication_Text = "abe";
	
	/*
	 * Snappy username
	 * added by snehal
	 */
	public static final String SnappyUser = "Vcg66103";
	public static final String SnappyPassword = "victor";
	/*
	 * Snappy username
	 * added by snehal
	 */
	public static final String SnappyUser2 = "annrinehart";
	public static final String SnappyPassword2 = "ann";
	
	/*
	 * Snappy username
	 * added by snehal
	 */
	public static final String SnappyUser3 = "jamesevanson";
	public static final String SnappyPassword3 = "james";
	
	
	/*Physicain portal url and credentials
	 * added by snpatil
	 * */
	public static final String Phyportal_username = "qadoc001";
	public static final String Phyportal_passworrd = "1";
	
	public static final String Physician_portal_url = "https://physportalqa.davita.com";
	/*
	
	 /* Dialysis schedule :Neha Sinha
	 **/
	public static final String[] DialysisScheduleHeader = new String[] { "Patient Name", "Time Left"};
	
	public static final String[] Days = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
			"Saturday" };
	
	public static final String[] Days_DB = new String[] { "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday",
			"Thursday", "Friday", };


	/**
	 * DataBase Constants :Neha Sinha
	 * Depricated 08/15/2018 : Keith Reine
	 **/
	
	//Kindly add your username and password below
	public static final String dbQAUsername = "UserNameHere";
	public static final String dbQAPassword = "PasswordHere";
	
	public static final String dbQAConnectionString = "jdbc:oracle:thin:@sea1a3flcnd01.davita.com:1533:FLCNQA3";
	public static final String noContentToDisplay = "No Content to Display";
	public static final String dashboardErrorMsg = "Sorry, you do not have permission to access this page.";
	
	/**
	 * db_connect
	 * Auth: Keith R*/
	public static final String dbConnectUrl = "http://sea1l3falpa01.davita.com:8080/automation/query";
	/**
	 * Order Signing 
	 * Auth: Grace T*/
	
	public static final String Diet = "DIET";
	public static final String treatment = "TX";
	public static final String aretialNeedle="JMS, WINGEATER, 14G x 1, SHARP , TWIN";
	public static final String Venous_Needle ="JMS, WINGEATER, 14G x 1, SHARP , TWIN";
	public static final String Tx_Dialyzer ="Fresenius, F, 3, 230";
	public static final String Dialysate ="FMC, ACID- LIQUID, 0K-2.25Ca, GALLON - (4/CS)";
	
	
	
	
	/**
	 * Data cleanup
	 * Auth: Grace*/
	public static final String WrongProvider = "Wrong Provider";
	public static final String CWOW_PATIENT_FIRST_NAME = "Agar";
	public static final String CWOW_PATIENT_LAST_NAME = "Dorine";
	public static final String CWOW_PATIENT_FIRST_NAME2 = "Archer";
	public static final String CWOW_PATIENT_LAST_NAME2 = "Woong";
	public static final String CWOW_PATIENT_FIRST_NAME3 = "Archer";
	public static final String CWOW_PATIENT_LAST_NAME3 = "Eberardo";//k
	public static final String CWOW_PATIENT_FIRST_NAME4 = "Rousse";
	public static final String CWOW_PATIENT_LAST_NAME4 = "Brower";
	public static final String CWOW_PATIENT_FIRST_NAME5 ="Ankers";
	public static final String CWOW_PATIENT_LAST_NAME5 = "Krystina";
	public static final String CWOW_PATIENT_FIRST_NAME6 = "Sanna";
	public static final String CWOW_PATIENT_LAST_NAME6 = "Chesnutt";
	public static final String CWOW_PATEINT_LAST_NAME7 = "Dunnam";
	public static final String CWOW_PATEINT_LAST_NAME8 = "Howd";
	public static final String CWOW_PATEINT_LAST_NAME9 = "Joseph";
	public static final String CWOW_PATEINT_LAST_NAME10 = "Berky";
	

	/** 
	 * Cwow API
	 */
	public static final String CwowApiUserName1 = "AACOVIO";
	public static final String CwowApiUserName2 = "rhartman";
	public static final String CwowApiAuth = "Bearer 1242";
	public static final String CwowfacilityId = "03436";
	public static final String AEFilePath = "C:\\dev\\workspace\\OneView_QA_Automation\\src\\resource\\java\\CwowOrdersfiles\\";
	public static final String CwowMpi1 = "1605375";
	public static final String CwowMpi2 = "1819576";

	/**
	 * COMMs hub API
	 */
	public static final String COMMsHubResetDataURI = "https://commscoreservice-ppqa.mybluemix.net/api/v2/comms/cmscontents";
	public static final String COMMsHubPartnerID = "b2FNmAT483kDPWKsKzuGMoF9blAAMcVV";
	
	/*
	  * Dispute reason displayed on order page
	  */
	 public static final String DisputeOtherReason = "Other Reason";
	 public static final String[] OrderDisputeReason = new String[] { "Not My Patient", "Duplicate", "Discontinued In Error", 
	               "Order Not Given By Me", "Order Detail Incorrect", "Other Reason" };
	
	public static final String COMMsHubSecretID = "sNqhECBkh9w5obnb";
	public static final String COMMsHubDataURI = "https://commspartnerqa-test.apigee.net";
	
	
	public static final String URLKeyCloakUsersSuffix= "auth/admin/master/console/#/realms/dps";
	public static final String KeyCloakUsername = "qaautomation";
	public static final String KeyCloakPassword = "P@ssword1";
	public static final String KeyCloakURLSuffix = "auth/admin/realms/dps/users/";
	
	public static final String[] LabAndTreatmentDefaultField = new String[] { "TIME (TX - PRESCRIBED)", "IDWG", "PRE WEIGHT", 
            "TARGET WEIGHT", "POST WEIGHT"};
	public static final String DEBUG_USER_AUTH = "Basic ZGVidWcgdXNlcjpwYXNzd29yZA==";
	/**
	 * Phys-Portal Service Info
	 * Auth: Rama T*/
	public static final String Phy_Portal_Host = "http://192.168.37.212:8050/";		
	public static final String Phy_Portal_MT_suffix = "UnsignedOrders";
	/**
	 * CWOW-Service Info*/
	public static final String CWOW_MT_SUFFIX = "api/orders/cwow/disputeReasons";
	/**
	 * Phys-Portal MT Service Info*/
	public static final String PHY_PORTAL_MT_SUFFIX = "api/orders/physician-portal/dispute-reasons";	
	/**
	 * INA - PIXIT Service Info*/
	public static final String PIXIT_INA_HOST = "https://api-piet-app-sit.davita.com:8084";
	public static final String PIXIT_X_APP = "portal-web";
	public static final String PIXIT_X_VAULTROLE = "MD";
	/**
	 * OVBS Users/med-check Service Info*/
	public static final String USERS_MT_SUFFIX = "api/users";
	public static final String USERS_MEDCHECK_SUFFIX = "/med-check";
	public static final String USERS_PENDING_RX_COUNT = "/pending-prescription/count";
	/**
	 * Patients Service Info*/	
	public static final String PATIENTS_MT_SUFFIX = "api/patients";
	public static final String PATIENTS_SEARCH_SUFFIX = "/v1";
	/**
	 * Billing-info for home page validation*/
	public static final String BILLING_MT_SUFFIX = "api/billing/users/validate";
}

