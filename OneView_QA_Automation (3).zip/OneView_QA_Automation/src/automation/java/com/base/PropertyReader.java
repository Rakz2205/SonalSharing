/**
	 * grace tshihata
	 */
package com.base;

import java.util.logging.Logger;

public class PropertyReader {

	@SuppressWarnings("unused")
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

}
