package com.base;


import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.angular.ngWebDriver.NgWebDriver;

public class ActionsWithWaits {
	private static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private NgWebDriver ngdriver;
	private JavascriptExecutor js;

	public ActionsWithWaits(WebDriver wd){
		WebDriver driver = wd;
		LOGGER.info(wd.toString());
		js = (JavascriptExecutor) driver;
		driver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);
		ngdriver = new NgWebDriver(js);
	}


	public void waitForAngular(){
		Boolean angularFinished = ngdriver.waitForAngularLoad();
		//ngdriver.waitForAngularRequestsToFinish();
		LOGGER.info("Angular testabilites complete = "+angularFinished.toString());
		//LOGGER.info("Angular testabilites complete");
	}
}
