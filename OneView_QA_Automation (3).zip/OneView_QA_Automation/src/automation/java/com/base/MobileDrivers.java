package com.base;
/**
 * Grace Tshihata
 * */
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class MobileDrivers extends AppiumServer{
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	// Mac
	private static String sdkPath = "/Users/gtshihata/Library/Android/sdk/";// or for windows D:/Android/adt-bundle-windows-x86_64-20140702/sdk/
	private static String adbPath = sdkPath + "platform-tools" + File.separator + "adb";
	private static String emulatorPath = sdkPath + "tools" + File.separator + "emulator";
	
	// Windows
	private static String wsdkPath = "D:/Android/adt-bundle-windows-x86_64-20140702/sdk/"; //TODO: add correct path 
	private static String wadbPath = wsdkPath + "platform-tools" + File.separator + "adb";
	private static String wemulatorPath = wsdkPath + "tools" + File.separator + "emulator";
	
	// Similators names
	//cmd: 
	// open emulaor: emulator -avd Nexus_5_API_23
	private static String android ="Nexus_5_API_23";
	private static String apple = "";
	
	
	public static void setupAndroid(String OS_Can_Be_mac_Or_windows) throws MalformedURLException{
		startMacServer();
		setups(OS_Can_Be_mac_Or_windows);
		File f = new File("src/main/java");
		File fs = new File(f,"ApiDemos-debug.apk");
		LOGGER.info("Successfully found apk file and Path");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5 API 23");
		capabilities.setCapability(MobileCapabilityType.APP,fs.getAbsolutePath());
		capabilities.setCapability("takesScreenshot", true); 
		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>( new URL("http://127.0.0.1:4723/wd/hub"), capabilities) ;		
		LOGGER.info("Successfully Started app on port 4723");
	}
	
	public static void main(String[] args) throws MalformedURLException {
		startMacServer();
		setups("mac");
		//genericmethods.sleep3second();
		File f = new File("src/main/java");
		File fs = new File(f,"ApiDemos-debug.apk");
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus 5 API 23");
		capabilities.setCapability(MobileCapabilityType.APP,fs.getAbsolutePath());
		
		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>( new URL("http://127.0.0.1:4723/wd/hub"), capabilities) ;
		//capabilities.setCapability("deviceName", "Test");
//		capabilities.setCapability("automationName","android-app");
//		capabilities.setCapability("platformName", "Android");
//		capabilities.setCapability("app", app.getAbsolutePath());
//		capabilities.setCapability("app-package", "Package name");
//		capabilities.setCapability("app-activity", "Activity");
//		capabilities.setCapability("takesScreenshot", true); 
		//driver= new RemoteWebDriver( new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
//		driver= new AndroidDriver( new URL("http://127.0.0.1:4723/wd/hub"), capabilities) ;
//		
		closeEmulator();
	}
	
	/**
	 * Starts an emulator for the provided AVD name
	 * 
	 * @param nameOfAVD
	 */
	public static void launchMacEmulator(String nameOfAVD) {
		LOGGER.info("Starting emulator for '" + nameOfAVD + "' ...");
	 String[] aCommand = new String[] { emulatorPath, "-avd", nameOfAVD };
	 try {
	  Process process = new ProcessBuilder(aCommand).start();
	  process.waitFor(180, TimeUnit.SECONDS);
	  LOGGER.info("Emulator launched successfully!");
	 } catch (Exception e) {
	  e.printStackTrace();
	 }
	}
	
	public static void launchWindowEmulator(String nameOfAVD) {
		LOGGER.info("Starting emulator for '" + nameOfAVD + "' ...");
		 String[] aCommand = new String[] { wemulatorPath, "-avd", nameOfAVD };
		 try {
		  Process process = new ProcessBuilder(aCommand).start();
		  process.waitFor(180, TimeUnit.SECONDS);
		  LOGGER.info("Emulator launched successfully!");
		 } catch (Exception e) {
		  e.printStackTrace();
		 }
		}
	
	public static void setups(String OXSystem){
		if (OXSystem.equalsIgnoreCase("Windows")){
			LOGGER.info("Starting emulator for '" + android + "' ...");
			 String[] aCommand = new String[] { wemulatorPath, "-avd", android};
			 try {
			  Process process = new ProcessBuilder(aCommand).start();
			  process.waitFor(180, TimeUnit.SECONDS);
			  LOGGER.info("Emulator launched successfully!");
			 } catch (Exception e) {
			  e.printStackTrace();
			 }
		}else if (OXSystem.equalsIgnoreCase("Mac")){
			LOGGER.info("Starting emulator for '" + android + "' ...");
			 String[] aCommand = new String[] { emulatorPath, "-avd", android };
			 try {
			  Process process = new ProcessBuilder(aCommand).start();
			  process.waitFor(180, TimeUnit.SECONDS);
			  LOGGER.info("Emulator launched successfully!");
			 } catch (Exception e) {
			  e.printStackTrace();
			 }
		}
	}
	

	
	/**
	 * Kills all running emulators
	 */
	public static void closeEmulator() {
		LOGGER.info("Killing emulator...");
	 String[] aCommand = new String[] { adbPath, "emu", "kill" };
	 try {
	  Process process = new ProcessBuilder(aCommand).start();
	  process.waitFor(1, TimeUnit.SECONDS);
	  LOGGER.info("Emulator closed successfully!");
	 } catch (Exception e) {
	  e.printStackTrace();
	 }
	}
	

}
