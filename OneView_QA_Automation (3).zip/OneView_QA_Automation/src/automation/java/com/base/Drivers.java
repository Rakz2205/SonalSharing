package com.base;

import java.io.File;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import com.apps.oneview.common.ConfigCaller;
import com.apps.oneview.common.EnvironmentCaller;
import com.base.TestBase.URL_Path;

public class Drivers extends ConfigCaller {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	String baseDriverLocation = "src/Automation/java/com/webdrivers";
	String edgeDriverLocation = "src/Automation/java/com/webdrivers/edge";
	WebDriver wd = null;

	public void setHost(URL_Path url, WebDriver wd) {
		try {
			this.wd = wd;
			String baseUrl = GenericHelper.getBaseURL(url);

			LOGGER.info(wd.toString());
			wd.get(baseUrl);
			LOGGER.info("Url opened: " + baseUrl);

			// below line added by pnayak - 02/01
			wd.manage().window().maximize();
		} catch (RuntimeException r) {
			r.printStackTrace();
			LOGGER.severe("Failed to pass URL to browser ! See SetHost Method for more detail");

		}
	}

	public WebDriver setup(String browser, URL_Path url, String deviceName) throws Exception {
		WebDriver wd = null;
		try {
			if (browser == null) {
				LOGGER.severe("Browser value cannot be null");
				System.exit(0);
			}
			if (url == null) {
				LOGGER.severe("Url value cannot be null");
				System.exit(0);
			}
			if (deviceName == null) {
				LOGGER.severe("Url value cannot be null");
				System.exit(0);
			}
			if (browser.isEmpty()) {
				LOGGER.severe("Browser value cannot be null");
				System.exit(0);
			}
			if (deviceName.isEmpty()) {
				LOGGER.severe("Url value cannot be null");
				System.exit(0);
			}

			if (browser.toLowerCase().equals("chrome")) {

				System.setProperty("webdriver.chrome.driver",
						String.valueOf(new ChromeDriverBinarySupplier().get(Paths.get("target"))));

				Map<String, String> mobileEmulation = new HashMap<>();

				mobileEmulation.put("deviceName", deviceName);

				Map<String, Object> chromeOptions = new HashMap<>();

				chromeOptions.put("mobileEmulation", mobileEmulation);

				DesiredCapabilities capabilities = DesiredCapabilities.chrome();

				capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
				wd = new ChromeDriver(capabilities);
			} else if (browser.toLowerCase().equals("firefox")) {
				System.setProperty("webdriver.gecko.driver", new File(baseDriverLocation+"/geckodriver.exe").getAbsolutePath());
				wd = new FirefoxDriver();
				wd.manage().window().maximize();
			} else {
				LOGGER.severe("Browser not supported for mobileEmulation");
				System.exit(0);

			}
			setHost(url, wd);
		} catch (RuntimeException e) {
			e.printStackTrace();
			LOGGER.severe("Failed to set chrome mobileEmulation. See: setup for mobileEmulation in Drivers");

		}
		return wd;
	}

	public WebDriver defaultDriver() {
		WebDriver wd = null;
		OSValidator os = new OSValidator();
		if (os.getOS().equals(mac())) {
			LOGGER.info("starting Chrome");
			System.setProperty("webdriver.chrome.driver", new File(baseDriverLocation+"/chromedriver236").getAbsolutePath());
			// create chrome instance
			wd = new ChromeDriver();
		} else if (os.getOS().equals(windows())) {
			// set path to chromedriver.exe
			System.setProperty("webdriver.chrome.driver", new File(baseDriverLocation+"/chromedriver.exe").getAbsolutePath());
			// create chrome instance
			wd = new ChromeDriver();
		}
		return wd;
	}

	static String plaform;

	public static String getPlaform() {
		return plaform;
	}

	public static void setPlaform(String plaform) {
		Drivers.plaform = plaform;
	}

	public static void setPlaftorm() {
		try {
			String OS_NAME = getProperty("os.name").toLowerCase();
			String OS_ARCH = getProperty("os.arch");
			String TMP = getProperty("java.io.tmpdir");
			if (OS_NAME.contains("linux")) {
				setPlaform("linux");
			}
			if (OS_NAME.contains("win")) {
				setPlaform("windows");
			}
			if (OS_NAME.contains("Mac OS X")) {
				setPlaform("mac");
			}
		} catch (RuntimeException e) {

			LOGGER.severe("System failed while trying to figure out OS.");

		}
	}
	/*
	 * public static void main(String[] args) {
	 * System.getProperties().list(System.out); }
	 */

	// // @BeforeClass
	// @Parameters("browser")
	@SuppressWarnings("deprecation")
	public WebDriver setup(String browser, URL_Path url) throws Exception {
		WebDriver wd = null;
		OSValidator os = new OSValidator();

		try {

			// Check if parameter passed from TestNG is 'firefox'
			if (browser.equalsIgnoreCase("firefox")) {
				LOGGER.info("Opening Firefox browser ");
				if (os.getOS().equals(mac())) {
					LOGGER.info("mac not yet set up");
				} else if (os.getOS().equals(windows())) {
					System.setProperty("webdriver.gecko.driver", new File(baseDriverLocation+"/geckodriver.exe").getAbsolutePath());
					FirefoxProfile geoDisabled = new FirefoxProfile();
					geoDisabled.setPreference("geo.enabled", false);
					geoDisabled.setPreference("geo.provider.use_corelocation", false);
					geoDisabled.setPreference("geo.prompt.testing", false);
					geoDisabled.setPreference("geo.prompt.testing.allow", false);
					FirefoxOptions options = new FirefoxOptions();
					options.setProfile(geoDisabled);
					wd = new FirefoxDriver(options);
				}
				LOGGER.info("Successfully Completed Opening Firefox browser ");

			}
			// Check if parameter passed as 'chrome'
			else if (browser.equalsIgnoreCase("chrome")) {
				LOGGER.info("Opening CHROME browser ");
				if (os.getOS().equals(mac())) {
					// set path to chromedriver.exe
					System.setProperty("webdriver.chrome.driver", new File(baseDriverLocation+"/chromedriver236").getAbsolutePath());
					// create chrome instance
					wd = new ChromeDriver();

					LOGGER.info("Successfully Completed Opening CHROME browser ");
				} else if (os.getOS().equals(windows())) {
					LOGGER.info("Opening CHROME browser ");
					// set path to chromedriver.exe
					System.setProperty("webdriver.chrome.driver", new File(baseDriverLocation+"/chromedriver.exe").getAbsolutePath());
					// configure the driver for behaviors that aren't standard
					ChromeOptions options = new ChromeOptions();
					options.addArguments("start-maximized");
					options.addArguments("--disable-geolocation");
					// create chrome instance
					wd = new ChromeDriver(options);

					LOGGER.info("Successfully Completed Opening CHROME browser ");
				}

			}
			// Check if parameter passed as 'Edge'
			else if (browser.equalsIgnoreCase("Edge")) {
				// set path to Edge.exe
				System.setProperty("webdriver.edge.driver", new File(edgeDriverLocation+GenericHelper.getWinBuild()+"/MicrosoftWebDriver.exe").getAbsolutePath());
				// turn off geolocation
				EdgeOptions edgeOptions = new EdgeOptions();
				edgeOptions.setCapability("locationContextEnabled", false);
				// create Edge instance
				wd = new EdgeDriver();
			} else if (browser.equalsIgnoreCase("ie")) {

				System.setProperty("webdriver.ie.driver", new File(baseDriverLocation+"/IEDriverServer.exe").getAbsolutePath());
				// Set desired capabilities to Ignore IEDriver zoom level
				// settings and disable
				// native events.
				//DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
				//caps.setCapability("EnableNativeEvents", false);
				//caps.setCapability("ignoreZoomSetting", true);
				// caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
				// true);
				//caps.setCapability("requireWindowFocus", true);

				// Initialize InternetExplorerDriver Instance using new
				// capability.
				InternetExplorerOptions expectedInternetExplorerOptions = new InternetExplorerOptions();
				expectedInternetExplorerOptions.setCapability("locationContextEnabled", false);
				wd = new InternetExplorerDriver(expectedInternetExplorerOptions);
				// instance.manage().timeouts().implicitlyWait(15,
				// TimeUnit.SECONDS);

				// Press CTRL + 0 keys of keyboard to set IEDriver Instance zoom
				// level to 100%.
				//wd.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
				//wd.manage().window().maximize();

				// Safari using in-build selenium driver
			} else if (browser.equalsIgnoreCase("safari")) {
				wd = new SafariDriver();
			} else {
				// If no browser passed throw exception
				throw new Exception("Browser is not correct");
			}

		} catch (RuntimeException e) {
			e.printStackTrace();
			LOGGER.severe(
					"Fail opening browser ! Exception while trying to open browser. See Drivers class for more details");
		}
		setHost(url, wd);
		return wd;
	}

	// public void tearDown(WebDriver wd) {
	// if (wd != null) {
	// wd.quit();
	// }
	// }

}