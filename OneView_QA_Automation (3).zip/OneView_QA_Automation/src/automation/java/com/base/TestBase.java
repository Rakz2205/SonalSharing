package com.base;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class TestBase {

	private DriversMan mdm = new DriversMan();
	
	//login creds password Map
	public static final Map<String, String> LOGIN_CREDS = new HashMap<String, String>() {{
        put("jojoseph", "P@ssword1");
        put("hhelderman", "hhelderman");
        put("annrinehart", "annrinehart");
    }};

    // Homepage TaskCard Map
	public static final Map<String, String> TASK_CARDS = new HashMap<String, String>() {{
        put("unsigned-order-task", "Unsigned Orders");
        put("incomplete-physician-questionnaire-task", "Licensure & Certification Questionnaire");
        put("invoice-attestation-task", "Invoice & Attestations");
        put("pending-prescriptions-task", "Pending Prescriptions");
        put("falcon-silver-link", "Start & Complete Encounters");
    }};
    
	public enum Order_Header {
		PATIENT, FACILITY, STATUS, ENTERED, ORDER, JUSTIFICATION
	}

	public enum Refute_Header {
		DEMO, ORDER, NOTES

	}

	public DriversMan getMdm() {
		return mdm;
	}

	public static enum Mock_Status {
		ENABLED, DISABLED,
	}

	public static enum Order_Status {
		SIGNED, UNSIGNED, CHG, ERROR, DISCONTINUED, REFUTED, DISPUTED
	}

	public enum String_Of_Order_Type {
		TX {
			public String toString() {
				return "TX";
			}
		},

		DIET {
			public String toString() {
				return "DIET";
			}
		}
	}

	public enum Order_Type {
		DIET, TX
	}

	public enum Partial_UF {
		YES, NO, NOT_USABLE;
	}

	public enum Heparin_Free_tx {
		YES, NO, NOT_USABLE;
	}

	public enum Concurrent_Accesses {
		YES, NO, NOT_USABLE;
	}

	public enum Perform_Partial_UF {
		Start_of_Tx, End_of_Tx;
	}

	public enum Justification {
		ESRD;
	}

	public enum App_Name {
		Patients, Orders, Covering_Rights, Home
	}

	public enum Root_Menu_Items {
		HOME, PATIENTS, TASKS, SETTINGS
	}

	public enum Cwow_Verify_Type {
		Order, Task
	}

	public enum Dispute_Type {
		Summary, Detail
	}

	public enum CR_History_Type {
		CURRENT, HISTORICAL
	}

	public enum URL_Path {

		CWOW, OneViewBase, OneViewOrders, OneViewPatients, PhysicianPortal, KeycloakUsers , CWOWAPICOMMAND , CWOWAPIQUERY , CWOWAPISEARCH

	}
	
	//Initializing the variable ArrayList containing Tabs
	public static final ArrayList<String> patientChartTabNames = new ArrayList<String>
		(Arrays.asList("Labs", "ESRD/AKI Mgmt", "Clinical Summary", "Profile"));
}
