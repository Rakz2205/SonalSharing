package com.base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;

import com.apps.testrail.TestRailComponent;
import com.base.DriversMan;

public class ScreenshotListener extends TestListenerAdapter {
	@Override
	public void onTestFailure(ITestResult result) {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String methodName = result.getName();
		if (!result.isSuccess()) {
			TestBase test = (TestBase) result.getInstance();
			DriversMan aDriverMan = (DriversMan) test.getMdm();
			TakesScreenshot driver = (TakesScreenshot) aDriverMan.getDriver();
			File scrFile = driver.getScreenshotAs(OutputType.FILE);
			try {
				String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath()
						+ "/target/surefire-reports";
				File destFile = new File((String) reportDirectory + "/failure_screenshots/" + methodName + "_"
						+ formater.format(calendar.getTime()) + ".png");
				FileUtils.copyFile(scrFile, destFile);
				//System.out.println("Output Directory: "+result.getTestContext().getOutputDirectory());
				if (result.getTestContext().getOutputDirectory().contains("test-output")) {
					//System.out.println("Absolute Path");
					Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
					+ "' height='100' width='100'/> </a>");
				} else {
					//System.out.println("Relative Path");
					Reporter.log("<a href='./failure_screenshots/" + destFile.getName() + 
						     "'> <img src='./failure_screenshots/" + destFile.getName() + 
						     "' height='100' width='100'/> </a>");
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
			//adding a call to the TestRailComponent until we can completely switch over in the future.
//			TestRailComponent trc = new TestRailComponent();
//			trc.addResultForCase(result);
			aDriverMan.tearDown();
		}
		
	}
	
	@Override
	public void onTestSuccess(ITestResult result) {
		TestBase test = (TestBase) result.getInstance();
		DriversMan aDriverMan = (DriversMan) test.getMdm();
		//adding a call to the TestRailComponent until we can completely switch over in the future.
//		TestRailComponent trc = new TestRailComponent();
//		trc.addResultForCase(result);
		aDriverMan.tearDown();
	}
	@Override
	public void onTestSkipped(ITestResult result) {
		TestBase test = (TestBase) result.getInstance();
		DriversMan aDriverMan = (DriversMan) test.getMdm();
		//adding a call to the TestRailComponent until we can completely switch over in the future.
//		TestRailComponent trc = new TestRailComponent();
//		trc.addResultForCase(result);
		aDriverMan.tearDown();
	}
}