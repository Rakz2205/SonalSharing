package com.base;

import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMailTLS {

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	public static String CWOW_STATUS;


	public static String getCWOW_STATUS() {
		return CWOW_STATUS;
	}


	public static void setCWOW_STATUS(String cWOW_STATUS) {
		CWOW_STATUS = cWOW_STATUS;
	}
	
	public static void main(String[] args) {
		//down(args);
		System.out.println(getCWOW_STATUS());
	}


	public static void down(String[] args) {

		final String username = "angular.automation.team@gmail.com";
		final String password = "Angular1234";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("from-email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("grace.tshihata@davita.com"));
			message.setSubject("CWOW IS DOWN");
			setCWOW_STATUS("CWOW IS DOWN");
			message.setText("Dear angular Team,"
						+ "\n\n This email is let you know that CWOW services are down, please follow up with the CWOW team \n\n"
						+ "for more precision!");
			
		

			Transport.send(message);

			LOGGER.info("Email sent");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void up(String[] args) {

		final String username = "angular.automation.team@gmail.com";
		final String password = "Angular1234";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("from-email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("grace.tshihata@davita.com"));
			message.setSubject("CWOW IS BACK UP AND RUNNING");
			setCWOW_STATUS("CWOW IS BACK UP AND RUNNING");
			message.setText("Dear angular Team,"
						+ "\n\n This email is let you know that CWOW services are down, please follow up with the CWOW team \n\n"
						+ "for more precision!");
			
		

			Transport.send(message);

			LOGGER.info("Email sent");
			System.out.println("Email sent");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}