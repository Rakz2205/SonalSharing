package com.customannotations;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

public class enableTest implements IAnnotationTransformer {

	// Do not worry about calling this method as testNG calls it behind the scenes before EVERY method (or test).
	// It will disable single tests, not the entire suite like SkipException
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod){

		List<String> tcList = getTestCaseList();
		String envTestRunId  = System.getProperty("runId");
		// If we have chose not to run this test then disable it.
	    if ((envTestRunId!= null) && (tcList != null) && (!tcList.contains(getMyPlanIds(annotation, testMethod)))){
	        annotation.setEnabled(false);
	    }
	    else if(tcList == null) {
	    		annotation.setEnabled(true);
	    }
	}

	// logic YOU control

	private List<String> getTestCaseList() {
		String envTestRailPlanIds = System.getProperty("oneViewPlanIds");
		List<String> testCaseList = null;
		if (envTestRailPlanIds != null && !envTestRailPlanIds.isEmpty()) {
			String[] aPlanArr = envTestRailPlanIds.split(":");  
			testCaseList = new ArrayList<String>(Arrays.asList(aPlanArr));
		}

		return testCaseList;
	}

	private String getMyPlanIds(ITestAnnotation annotation, Method testMethod) {
		String[] testGroups = annotation.getGroups();
		for (String group : testGroups) {
			if (group.contains("TestRailId")) {
				String[] elements = group.split(":");
				return elements[1];
			}
		}
		return null;
	}
	
}
