package com.customannotations;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.base.GenericHelper;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

public class BrowserNameProvider 
{
	 @DataProvider(name="BrowserNameList")
     public static Object[][] getDataFromDataprovider(Method m) throws IOException
	 {
		
		 HashMap hashmap=getParameterMap(m.getName());
		 ArrayList browsersNames=getBrowserName(m);
		 Object[][] objTemp = returnDataProvider(browsersNames,hashmap);
		 return objTemp;
	 }
	 
	 
	 private static ArrayList getBrowserName(Method m) {
		// get groups from @Test annotation metadata
			ArrayList objTemp=new ArrayList();
			Annotation anno = m.getAnnotation(Test.class);
			String strTemp=anno.toString();
			strTemp=strTemp.replaceAll(" ", "");
			
			strTemp=strTemp.substring(strTemp.indexOf("groups=[")+8, strTemp.indexOf("]", strTemp.indexOf("groups=[")+8));
			
			if(strTemp.contains("BrowserList"))
			{
				String[] arrTemp = strTemp.split(",");
				
				for(int arrTempCounter=0;arrTempCounter<arrTemp.length;arrTempCounter++)
				{
					if(arrTemp[arrTempCounter].contains("BrowserList"))
					{
						strTemp=arrTemp[arrTempCounter];
						break;
					}
				}
				arrTemp = strTemp.split(":");
				for(int arrTempCounter=1;arrTempCounter<arrTemp.length;arrTempCounter++)
				{
					objTemp.add(arrTemp[arrTempCounter].toLowerCase());
				}
				
				return objTemp;
			}
			else
			{
				objTemp.add("chrome");
				objTemp.add("firefox");
				objTemp.add("edge");
				return objTemp;
			}
			
	}


	private static HashMap getParameterMap(String testName) throws IOException {
		 // TODO Auto-generated method stub
		 
		 //check if excel exist
		 Boolean fileStat=checkIfFileExist(testName);
		 
		 if(fileStat)
		 {
			 HashMap inputParameter=GenericHelper.fetchValueFromExcel(testName);
			 return inputParameter;
		 }
		 else
		 {
			// return empty hash map
			 
			 return new HashMap();
		 }
		 
	}

	private static Boolean checkIfFileExist(String testName) {
		
		String projectLocation = System.getProperty("user.dir") + "\\InputDataProvider";
		String inputFilePath=projectLocation+"//"+testName+".xls";
		File file = new File(inputFilePath);
		if(file.exists() && !file.isDirectory()) { 
		    return true;
		}
		else
		{
			return false;
		}
	}


	public static Object[][] returnDataProvider(ArrayList browsersNames, HashMap hashmap)
	 {
		 
		 String windowVersion=System.getProperty("os.name");
		 double windowVersionNum=Double.parseDouble(windowVersion.replaceAll("Windows ", ""));
		 
		 if(windowVersionNum < 10)
		 {
			 if(browsersNames.contains("edge"))
				 browsersNames.remove("edge");
		 }
		 
		 if(hashmap.size()<= 0)
		 {
			 Object[][] objTemp=new Object[browsersNames.size()][1];
			 for(int objAddCounter=0;objAddCounter<browsersNames.size();objAddCounter++)
			 {
				 objTemp[objAddCounter][0]=browsersNames.get(objAddCounter);
			 }
			 return objTemp;
		 }
		 else
		 {
			 Object[][] objTemp=new Object[browsersNames.size()][2];
			 for(int objAddCounter=0;objAddCounter<browsersNames.size();objAddCounter++)
			 {
				 objTemp[objAddCounter][0]=browsersNames.get(objAddCounter);
				 objTemp[objAddCounter][1]=hashmap;
			 }
			 return objTemp;
		 }		 
	 }
}
