package com.apps.testrail;

import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;

import org.json.JSONObject;
import org.testng.ITestResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.base.GenericVariable;
import com.base.Drivers;
import com.base.RestAPI;
import io.restassured.response.Response;

public class TestRailComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	//adding a call to the TestRailComponent until we can completely switch over in the future.

	/**
	 * Function to get TestRail credentials initial implementation will only support
	 * basic authorization as it is only for a POC and this method will be enhanced
	 * in the future
	 * 
	 * @return bearer token for Authorization
	 */
	public HashMap<String, String> getAuthorization() {
		HashMap<String, String> creds = new HashMap<String, String>();
		// TODO: Add code to get SSO token from the AD server.

		String authString = GenericVariable.TESTRAIL_USERNAME + ":" + GenericVariable.TESTRAIL_PASSWORD;
		String authStringEnc = new String(Base64.getEncoder().encodeToString(authString.getBytes()));
		authStringEnc = "Basic "+authStringEnc;
		creds.put("Authorization", authStringEnc);
		
		return creds;
	}

	/**
	 * addResultForCase - 
	 * 				Use the TestRail API to update results for a test case in a particular test run
	 *				We are building the response object using object mapper also contains the map configuring the result status. 
	 * 
	 * @param aResult
	 *            aResult will have the result of the test
	 *            ITestResultObject captured by the listener
	 *         
	 * @return Response of the API call
	 */
	public Response addResultForCase(ITestResult aResult) {
		ObjectMapper mapper = new ObjectMapper();
		TestCase trTestCase = new TestCase();
		int status = 0;
		String comment = null;
		Duration timeSpan;
		Instant testStart = Instant.ofEpochMilli(aResult.getStartMillis());
		Instant testEnd = Instant.ofEpochMilli(aResult.getEndMillis());
		timeSpan = Duration.between(testStart, testEnd);
		String body = null;
		
		// Get the status and comments of the test on trTestCase
		if (aResult.getStatus() == ITestResult.SUCCESS) {
			status = 1;
			comment = "Passed";
		} else if (aResult.getStatus() == ITestResult.FAILURE) {
			status = 5; 
			comment = aResult.getThrowable().getMessage();
		} else if (aResult.getStatus() == ITestResult.SKIP) {
			status = 4;
			comment = "Skipped";
		}
		// Set the duration of the test on trTestCase
		trTestCase.setCreatedOn(testStart.toEpochMilli());
		String jsonTimeSpan  = String.format("%d:%02d:%02d", timeSpan.getSeconds() / 3600, 
					 						(timeSpan.getSeconds() % 3600) / 60, 
					 						(timeSpan.getSeconds() % 60));
		trTestCase.setElapsed(jsonTimeSpan);
		trTestCase.setStatusId(status);
		trTestCase.setComment(comment);
		// Create the json body of the Request
		try {
			body = mapper.writeValueAsString(trTestCase);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		// Call the Rest API to post the results to TestRail
		return callTestRail(getAuthorization(), body, Integer.toString(getCaseId(aResult)));
	}
	
	/**
	 * Get the current test case id from the method groups metadata
	 * 
	 * @param aResult
	 *            ITestResultObject captured by the listener
	 * @return int value of the test id
	 */
	public int getCaseId(ITestResult aResult) {	
		String[] testGroups = aResult.getMethod().getGroups();
		for (String group : testGroups) {
			if (group.contains("TestRailId")) {
				String[] elements = group.split(":");
				return Integer.valueOf(elements[1]).intValue();
			}
		}

		return 0;
	}
	

	/**
	 * Executing an api call to testrail with Authentication, body and case_id
	 * 
	 * @param auth 
	 * 			- authorization object to connect to testrail
	 * @param body 
	 * 			- request body to be posted to testrail
	 * 
	 * @param caseId - the case_id for which the result has to be updated
	 * 
	 * @return response from the testrail
	 */
	public Response callTestRail(HashMap<String,String> auth, String body, String caseId) {	
		Response aResponse = null;
		RestAPI restInterface = new RestAPI();
		String runId = System.getProperty("runId");
		String trApi = "/testrail/index.php?/api/v2/add_result_for_case/"+runId+"/"+caseId;
		JSONObject aBody = new JSONObject(body);
		String[] arrParam = { GenericVariable.TESTRAIL_HOST, trApi };
		auth.put("Content-Type", "application/json");
		HashMap<String, String> formParams = new HashMap<String, String>();
		aResponse = restInterface.call("post", arrParam, aBody, auth, formParams, null);
		
		
		return aResponse;
	}
}
