package com.apps.testrail;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "comment", "created_on", "elapsed", "status_id" })
public class TestCase {

	@JsonProperty("comment")
	private String comment;
	@JsonProperty("created_on")
	private long createdOn;
	@JsonProperty("elapsed")
	private String elapsed;
	@JsonProperty("status_id")
	private Integer statusId;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("status_id")
	public Integer getStatusId() {
		return statusId;
	}

	@JsonProperty("status_id")
	public void setStatusId(Integer anInt) {
		this.statusId = anInt;
	}

	@JsonProperty("comment")
	public String getComment() {
		return comment;
	}

	@JsonProperty("comment")
	public void setComment(String aString) {
		this.comment = aString;
	}

	@JsonProperty("created_on")
	public long getCreatedOn() {
		return createdOn;
	}

	@JsonProperty("created_on")
	public void setCreatedOn(long aLong) {
		this.createdOn = aLong;
	}

	@JsonProperty("elapsed")
	public String getElapsed() {
		return elapsed;
	}

	@JsonProperty("elapsed")
	public void setElapsed(String elapsedTime) {
		this.elapsed = elapsedTime;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
