package com.apps.pixit;

import java.util.HashMap;
import java.util.logging.Logger;

import org.json.JSONObject;
import org.testng.Assert;

import com.base.Drivers;
import com.base.GenericVariable;
import com.base.RestAPI;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class PixitAPIComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	/**
	 * Function to get the InA user for an active directory id
	 * 
	 * @param username active directory user name
	 */
	public Boolean isInAEnabled(String username) {
		LOGGER.info("enter PixitAPIComponent.isInAEnabled");
		// In the current davita system topology, there is only one InA test environment
		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericVariable.PIXIT_INA_HOST+"/api/v4/users/"+username.toLowerCase();
		String arrGetParam[] = { endpointHost, "" };

		// hard coding the header 
		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("X-application", GenericVariable.PIXIT_X_APP);		
		header.put("X-vaultRole", GenericVariable.PIXIT_X_VAULTROLE);
		header.put("X-userId", username.toLowerCase());
		header.put("Authorization", GenericVariable.DEBUG_USER_AUTH);
		JSONObject objGetJSON = new JSONObject();

		Response getResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		if (getResponse != null && getResponse.statusCode() == 200) {
			return true;
		} else {
			return false;
		}
	}
}
