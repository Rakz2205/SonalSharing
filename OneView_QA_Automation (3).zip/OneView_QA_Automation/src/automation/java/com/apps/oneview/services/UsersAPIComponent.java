package com.apps.oneview.services;

import java.util.HashMap;
import java.util.logging.Logger;

import org.json.JSONObject;
import org.testng.Assert;

import com.base.Drivers;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.RestAPI;
import com.base.TestBase;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class UsersAPIComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private static String usersMedCheckURL = GenericHelper.getBaseURL(TestBase.URL_Path.OneViewBase)+GenericVariable.USERS_MT_SUFFIX+GenericVariable.USERS_MEDCHECK_SUFFIX;
	
	/**
	 * Function to determine if the user exists in MedCheck
	 * 
	 * @param username active directory user name
	 */
	public Boolean isMedCheckEnabled(String token) {
		LOGGER.info("enter UsersServiceComponent.isMedCheckEnabled");
		String arrGetParam[] = { usersMedCheckURL + GenericVariable.USERS_PENDING_RX_COUNT, "" };
		HashMap<String, String> formParams = new HashMap<>();


		HashMap<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + token);
		JSONObject objGetJSON = new JSONObject();

		Response getResponse = restapi.call("head", arrGetParam, objGetJSON, header, formParams, "");
		if (getResponse != null && getResponse.statusCode() == 200) {
			return true;
		} else {
			return false;
		}
	}
}
