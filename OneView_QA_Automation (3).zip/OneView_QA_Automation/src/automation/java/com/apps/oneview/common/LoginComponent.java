package com.apps.oneview.common;

import java.util.List;
import java.util.logging.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.GenericWebMethods;
import com.base.TestBase;

public class LoginComponent {
	WebDriver webdriver;
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private LoginCaller lg = new LoginCaller();
	GenericWebMethods gwm;
	loginFactory objLogin;
	LoginPage objHomePage;
	private LogoutCaller loc = new LogoutCaller();

	// KWR: added a copy of the driver instance to genericwebmethods and had to add
	// a constructor
	public LoginComponent(WebDriver wd) {
		gwm = new GenericWebMethods(wd);
	}

	
	/**
	 * Login to the DPS application
	 * 
	 * @author Prashant Nayak
	 * @Modified Rakesh Gupta
	 * @param strUsername - Login username
	 */
	public void login(String strUsername) {
		LOGGER.info("Log in user as: " + strUsername);

		LoginCaller lg = new LoginCaller();
		
		String strPassword=TestBase.LOGIN_CREDS.get(strUsername.toLowerCase());
		if(strPassword==null)
			strPassword=TestBase.LOGIN_CREDS.get("jojoseph");
		
		// Enter username, password and click on login button
		gwm.enterText(gwm.getWebElement(gwm.getBy("id", lg.username_Id())), strUsername, true);
		gwm.enterText(gwm.getWebElement(gwm.getBy("id", lg.password_Id())), strPassword, true);
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", lg.login_submit_btn_id())));

		// if security question OK button appears click on it, else skip it
		List<WebElement> objSecQuestionOKBtn = gwm.getWebElements(gwm.getBy("id", lg.setup_Security_Question_ok_id()));

		if (objSecQuestionOKBtn.size() == 1) {
			objSecQuestionOKBtn.get(0).click();
		}

		// Click on Cancel button on Security question and answers page
		// if Cancel button appears click on it, else skip it
		List<WebElement> objCancelBtn = gwm.getWebElements(gwm.getBy("id", lg.security_Questions_Cancel_id()));

		if (objCancelBtn.size() == 1) {
			objCancelBtn.get(0).click();
		} else {
			// Check if error message is displayed
			List<WebElement> objErrorMsg = gwm.getWebElements(gwm.getBy("id", lg.login_errorcode_xpath()));
			if (objErrorMsg.size() > 0) {
				String strErrorText = objErrorMsg.get(0).getText();
				if (strErrorText.contains("code")) {
					Assert.assertEquals(false, true,
							"User - " + strUsername + " could not login. Error: " + strErrorText);
					LOGGER.info("Login Error: " + strErrorText);
				}
			}
		}
	}
	
	public void click_Ok_On_Setup_Security_question() {
		// LOGGER.info(m.setup_Security_Question_ok);
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", lg.setup_Security_Question_ok_id())));
	}

	public void click_Security_Questions_Cancel() {
		// LOGGER.info(m.setup_Security_Question_ok);
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", lg.security_Questions_Cancel_id())));
	}


}
