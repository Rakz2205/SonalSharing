
package com.apps.oneview.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

/*import com.oneview.callers.PhysicianPortalCaller;*/

	@SuppressWarnings("static-access")
	public class PhysicianPortalCaller {

		private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

		private static PhysicianPortalCaller PropertiesCache;
		private final static Properties configProp = new Properties();
		private static String Propertyfilename = "PhysicianPortal.properties";

		public PhysicianPortalCaller setPropertyfilename(String Propertyfilename) {
			this.Propertyfilename = Propertyfilename;
			return this;

		}

		/***
		 * configcaller loads the property called in the .properties file
		 */

		public PhysicianPortalCaller() {
			// Private constructor to restrict new instances
			InputStream in = this.getClass().getClassLoader().getResourceAsStream(Propertyfilename);
			LOGGER.info("Reading properties from file: " + Propertyfilename);
			try {
				configProp.load(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// Bill Pugh Solution for singleton pattern

		/**
		 * Directive: Only use the static methods for testing the framework
		 * functionality. Write getters to access specific properties so that no
		 * input strings are hard coded in your tests.
		 */

		public static class ResourceLoader {
			private static final PhysicianPortalCaller INSTANCE = new PhysicianPortalCaller();
		}

		public static PhysicianPortalCaller getInstance() {
			return ResourceLoader.INSTANCE;
		}

		public static String getProperty(String key) {
			return configProp.getProperty(key);
		}

		public Set<String> getAllPropertyNames() {
			return configProp.stringPropertyNames();
		}

		public boolean containsKey(String key) {
			return configProp.containsKey(key);
		}

		public void setProperty(String key, String value) {
			configProp.setProperty(key, value);
		}
		
		//adding callers

		public String username_Id() {
			return PropertiesCache.getInstance().getProperty("username_id");
		}
		
		public String password_Id() {
			return PropertiesCache.getInstance().getProperty("password_id");
		}
		
		public String login_submit_btn_id() {
			return PropertiesCache.getInstance().getProperty("login_submit_btn_id");
		}
		
		public String Unsigned_Order() {
			return PropertiesCache.getInstance().getProperty("Unsigned_Order");
		}
		//To access order type
		//Enter intOrderNo:1-unsigned orders ,2-pending orders ,3-invoice & attestations
		public String getAllOrderCountXpath(String intOrderNo) {
			return PropertiesCache.getInstance().getProperty("AllOrdercount").replace("intNo", intOrderNo);
		}
		public String Sort_Filter_dietOrder() {
			return PropertiesCache.getInstance().getProperty("Sort_and_Filter");
		}
		public String OpenOrderTypeFilter() {
			return PropertiesCache.getInstance().getProperty("Order_Types");
		}
		public String Select_from_opened_Dropdown(String strRowNo) {
			return PropertiesCache.getInstance().getProperty("Select_Value_From_Open_dropdown").replace("intNo", strRowNo);
		}
		public String Click_On_Apply_btn() {
			return PropertiesCache.getInstance().getProperty("Apply_button");
		}
		public String Select_Order_No(String strOrderRow) {
			return PropertiesCache.getInstance().getProperty("select_row_of_Order").replace("intOrderNO", strOrderRow);
		}
		public String get_Order_Detail_On_hover() {
			return PropertiesCache.getInstance().getProperty("Order_Diet_Details_On_hover");
		}
		//To access : Patient name,DOB,Facility,Start date
		public String On_hover_Diet_info() {
			return PropertiesCache.getInstance().getProperty("Order_info_On_hover");
			//return PropertiesCache.getInstance().getProperty("Order_info_On_hover").replace("intType", intTypeAndDate);
		}
		
		// below getter is to fetch value from PP order detail page
		public String orderDetail_ProtienValue() {
			return PropertiesCache.getInstance().getProperty("Protien_Value_PP");
		}
		
		public String orderDetail_DiabeticStatusValue() {
			return PropertiesCache.getInstance().getProperty("Diabetic_Status_PP");
		}
		public String orderDetail_SodiumValue() {
			return PropertiesCache.getInstance().getProperty("Sodium_PP");
		}
		public String orderDetail_CarbohydrateValue() {
			return PropertiesCache.getInstance().getProperty("Carbohydrate_PP");
		}
		public String orderDetail_PotassiumValue() {
			return PropertiesCache.getInstance().getProperty("Potassium_PP");
		}
		public String orderDetail_PhosphorusValue() {
			return PropertiesCache.getInstance().getProperty("Phosphorus_PP");
		}
		public String orderDetail_CaloriesValue() {
			return PropertiesCache.getInstance().getProperty("Calories_PP");
		}
		public String orderDetail_FluidValue() {
			return PropertiesCache.getInstance().getProperty("Fluid_PP");
		}
		public String orderDetail_AdditionalNotesValue() {
			return PropertiesCache.getInstance().getProperty("Additional_Notes_PP");
		}
		public String orderDetail_ExtenderValue() {
			return PropertiesCache.getInstance().getProperty("Extender_PP");
		}
		public String orderDetail_NephrologistNameValue() {
			return PropertiesCache.getInstance().getProperty("Nephrologist_Name_PP");
		}
		public String orderDetail_EnteredByValue() {
			return PropertiesCache.getInstance().getProperty("Entered_By_PP");
		}
		public String orderDetail_CodedByValue() {
			return PropertiesCache.getInstance().getProperty("Coded_By_PP");
		}
		public String orderDetail_PrescriberNameValue() {
			return PropertiesCache.getInstance().getProperty("Prescriber_Name_PP");
		}
		public String orderDetail_NotedNameValue() {
			return PropertiesCache.getInstance().getProperty("Noted_Name_PP");
		}
		public String orderDetail_NotedByDateValue() {
			return PropertiesCache.getInstance().getProperty("Noted_By_Date_PP");
		}
		public String orderDetail_PrescriberDateValue() {
			return PropertiesCache.getInstance().getProperty("Prescriber_Date_PP");
		}
		public String orderDetail_Coded_DateValue() {
			return PropertiesCache.getInstance().getProperty("Coded_Date_PP");
		}
		public String orderDetail_EnteredByDateValue() {
			return PropertiesCache.getInstance().getProperty("Entered_By_Date_PP");
		}
		public String orderDetail_OrderId() {
			return PropertiesCache.getInstance().getProperty("Order_Id_PP");
		}
		public String orderDetail_NameValue() {
			return PropertiesCache.getInstance().getProperty("orderDetail_NameValue");
		}
		public String orderDetail_Dob_Age_Gender_Value() {
			return PropertiesCache.getInstance().getProperty("orderDetail_Dob_Age_Gender_Value");
		}
		public String orderDetail_OrderTypeValue() {
			return PropertiesCache.getInstance().getProperty("orderDetail_OrderTypeValue");
		}
		public String orderDetail_FacilityValue() {
			return PropertiesCache.getInstance().getProperty("orderDetail_FacilityValue");
		}
		public String orderDetail_StartDateValue() {
			return PropertiesCache.getInstance().getProperty("orderDetail_StartDateValue");
		}
		public String Start_End_Date() {
			return PropertiesCache.getInstance().getProperty("Start_End_Date");
		}
		public String Open_Order_Status_Filter() {
			return PropertiesCache.getInstance().getProperty("Order_Status");
		}
		public String Order_details_part1() {
			return PropertiesCache.getInstance().getProperty("Order_details_part1");
		}
		public String Order_details_part2() {
			return PropertiesCache.getInstance().getProperty("Order_details_part2");
		}
		public String loadingIcon() {
			return PropertiesCache.getInstance().getProperty("loadingIcon");
		}
		public String changeOrderData() {
			return PropertiesCache.getInstance().getProperty("changeOrderData");
		}
		public String loadingIconDetailPage() {
			return PropertiesCache.getInstance().getProperty("loadingIconDetailPage");
		}
		
	}
