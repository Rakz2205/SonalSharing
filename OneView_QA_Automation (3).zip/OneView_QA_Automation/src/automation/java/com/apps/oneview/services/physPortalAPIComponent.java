package com.apps.oneview.services;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.base.Drivers;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.RestAPI;
import com.base.TestBase;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class physPortalAPIComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private int totalOrders = 0;
	private String endpointHost;
	private HashMap<String, String> header;
	private JSONObject objJSON;
	private HashMap<String, String> formParams;
	private String[] arrParam;
	/**
	 * Function to get the UnassignedOrders
	 * 
	 * @param username login username
	 * @throws Exception 
	 */
	public int getUnassignedOrderCount(String username) throws Exception {
		LOGGER.info("Executing physPortalAPIComponent.getUnassignedOrderCount");
		try {
			setAPIParameters(username, "1");
			Response postResponsed = restapi.call("post", arrParam, objJSON, header, formParams, "");
			JsonPath jsonPathEvaluator = postResponsed.getBody().jsonPath();
			totalOrders = Integer.parseInt(jsonPathEvaluator.get("TotalOrders").toString().trim());
		} catch (Exception ex) {
			//LOGGER.info("Exception: " + ex);
			throw new Exception(
					"Error fetching getUnassignedOrderCount");
		}
		return totalOrders;
	}

	/**
	 * Function to set API Parameters
	 * 
	 * @param username login username
	 * 
	 * @param take     count of orders
	 * 
	 * @return null
	 * @throws Exception 
	 * @throws JSONException 
	 */
	public void setAPIParameters(String username, String take) throws JSONException, Exception {
		LOGGER.info("Entering physPortalAPIComponent.apiDetails");
		formParams = new HashMap<>();
		endpointHost = GenericVariable.Phy_Portal_Host;
		arrParam = new String[] { endpointHost + GenericVariable.Phy_Portal_MT_suffix, "" };
		header = new HashMap<>();
		header.put("Authorization", GenericVariable.DEBUG_USER_AUTH);
		header.put("PhyPortal-CurrentUser", username.trim());
		header.put("Content-Type", "application/json");
		objJSON = new JSONObject();
		objJSON.put("Take", take);
		objJSON.put("OrderStatus", getOrderStatusList(username));
		objJSON.put("OrderTypes", getOrderTypes(username));
	}

	/**
	 * Function to get the OrderType list
	 * 
	 * @param username
	 * 
	 * @return null
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public String getOrderTypeList(String username) throws Exception {
		StringBuilder sb = new StringBuilder();
		try {
			LOGGER.info("Entering physPortalAPIComponent.apiDetailsToGetOrderTypeList");
			HashMap formParams = new HashMap<>();
			String endpointHost = GenericVariable.Phy_Portal_Host;
			String[] arrParam = new String[] { endpointHost + GenericVariable.Phy_Portal_MT_suffix + "/TypesList", "" };
			HashMap header = new HashMap<>();
			header.put("Authorization", GenericVariable.DEBUG_USER_AUTH);
			header.put("PhyPortal-CurrentUser", username.trim());
			Response getResponse = restapi.call("get", arrParam, objJSON, header, formParams, "");
			String json = getResponse.asString();
			JSONArray orderTypes = new JSONArray(json);
			sb.append("[");
			for (int index = 0; index < orderTypes.length(); index++) {
				sb.append(((JSONObject) orderTypes.get(index)).getInt("m_Item2") + ",");
			}
			sb.append("]");
		} catch (Exception e) {
			//LOGGER.info("Exception e: " + e);
			throw new Exception(
					"Error fetching getOrderTypeList");
		}
		return sb.toString();
	}

	/**
	 * Function to get OrderStatus list
	 * 
	 * @param username
	 * 
	 * @return null
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public String getOrderStatusList(String username) throws Exception {
		StringBuilder sb = new StringBuilder();
		try {
			LOGGER.info("Entering physPortalAPIComponent.apiDetailsToGetOrderStatusList");
			HashMap formParams = new HashMap<>();
			String endpointHost = GenericVariable.Phy_Portal_Host;
			String[] arrParam = new String[] { endpointHost + GenericVariable.Phy_Portal_MT_suffix + "/StatusList",
					"" };
			HashMap header = new HashMap<>();
			header.put("Authorization", GenericVariable.DEBUG_USER_AUTH);
			header.put("PhyPortal-CurrentUser", username.trim());
			Response getResponse = restapi.call("get", arrParam, objJSON, header, formParams, "");
			String json = getResponse.asString();
			JSONArray jsonArray = new JSONArray(json);
			sb.append("[");
			for (int index = 0; index < jsonArray.length(); index++) {
				sb.append(((JSONObject) jsonArray.get(index)).getInt("IdOrderStatus") + ",");
			}
			sb.append("]");
		} catch (Exception ex) {
			//LOGGER.info("Exception e: " + ex);
			throw new Exception(
					"Error fetching getOrderStatusList");
		}
		return sb.toString();
	}

	/**
	 * Function to get the RecentUnassignedOrderCount
	 * 
	 * @param username
	 * 
	 * @return counter
	 * @throws Exception 
	 */
	public int getRecentUnassignedOrderCount(String username) throws Exception {
		LOGGER.info("Entering physPortalAPIComponent.getRecentUnassignedOrderCount");
		int recentOrderCounts = 0;
		try {
			long orderCount = getTotalSnappyUnassignedOrdersCount(username) + 1;
			setAPIParameters(username, Long.toString(orderCount));
			Response postResponsed = restapi.call("post", arrParam, objJSON, header, formParams, "");
			recentOrderCounts = parseResponse(postResponsed.asString());
		} catch (Exception ex) {
			//LOGGER.info("Exception: " + ex);
			throw new Exception(
					"Error getting getRecentUnassignedOrderCount");
		}
		return recentOrderCounts;
	}

	/**
	 * Function to get the Status
	 * 
	 * @param username
	 * @throws Exception 
	 */
	public String getOrderStatus(String username) throws Exception {
		return getOrderStatusList(username);
	}

	/**
	 * Function to get the OrderTypes
	 * 
	 * @param username
	 * @throws Exception 
	 */
	public String getOrderTypes(String username) throws Exception {
		return getOrderTypeList(username);
	}

	/**
	 * Function to get the TotalOrder count from the response
	 * 
	 * @param username
	 * 
	 * @return totalOrder
	 * @throws Exception 
	 */
	public long getTotalSnappyUnassignedOrdersCount(String username) throws Exception {
		LOGGER.info("Entering physPortalAPIComponent.getTotalSnappyUnassignedOrdersCount");
		Integer totalOrder = 0;
		try {
			setAPIParameters(username, "1");
			Response postResponsed = restapi.call("post", arrParam, objJSON, header, formParams, "");
			String json = postResponsed.asString();
			JSONObject jsonObject = new JSONObject(json);
			totalOrder = (Integer) jsonObject.get("TotalOrders");
		} catch (Exception ex) {
			//LOGGER.info("Exception: " + ex);
			throw new Exception(
					"Error getting getTotalSnappyUnassignedOrdersCount");
			
		}
		return totalOrder;
	}

	/**
	 * Function to parse the UnsignedOrders to get the RecentOrders
	 * 
	 * @param json
	 * 
	 * @throws ParseException
	 */
	private int parseResponse(String json) throws Exception {
		LOGGER.info("Entering physPortalAPIComponent.parseResponse");
		int orderCount = 0;
		JSONObject jsonObject = new JSONObject(json);
		JSONArray unassignedOrder = (JSONArray) jsonObject.get("UnSignedOrders");
		for (int index = 0; index < unassignedOrder.length(); index++) {
			if (extractDateGmt((JSONObject) unassignedOrder.getJSONObject(index))) {
				orderCount++;
			}
		}
		return orderCount;
	}

	/**
	 * Function to extract the number of days from the current date
	 * 
	 * @param order
	 */
	private boolean extractDateGmt(JSONObject order) {
		LOGGER.info("Entering physPortalAPIComponent.extractDateGmt: ");
		String dateGmt = (String) order.get("DateTimeEnteredGMT");
		LocalDateTime instant = LocalDateTime.parse(dateGmt);
		LocalDateTime current = LocalDateTime.now();
		long numberOfDays = instant.until(current, ChronoUnit.DAYS);
		return (numberOfDays < 8);

	}

	/**
	 * Function makes a call to get the Snappy Dispute reasons response
	 * 
	 * @param bearerToken
	 * @return response
	 */
	public int getPhyPortalUnsignedOrdersStatus(String bearerToken) {
		LOGGER.info("Entering physPortalAPIComponent.getPhyPortalUnsignedOrdersStatus");
		HashMap<String, String> formParams = new HashMap<>();
		String arrGetParam[] = {
				GenericHelper.getBaseURL(TestBase.URL_Path.OneViewBase) + GenericVariable.PHY_PORTAL_MT_SUFFIX, "" };

		HashMap<String, String> header = new HashMap<>();
		header.put("Accept", "application/json");
		header.put("Authorization", "Bearer " + bearerToken);
		JSONObject objGetJSON = new JSONObject();

		Response GetResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		return GetResponse.getStatusCode();
	}
}