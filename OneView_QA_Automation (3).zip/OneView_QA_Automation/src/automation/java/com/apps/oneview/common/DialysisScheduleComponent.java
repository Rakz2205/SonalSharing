package com.apps.oneview.common;


import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.base.GenericWebMethods;

public class DialysisScheduleComponent {
	WebDriver webdriver;
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private DialysisScheduleCaller dsc = new DialysisScheduleCaller();
	private EnvironmentCaller ec = new EnvironmentCaller();
	private GenericWebMethods gwm;

	public DialysisScheduleComponent(WebDriver wd) {
		LOGGER.info("enter DialysisScheduleComponent constructor");
		gwm = new GenericWebMethods(wd);
	}
	
	/***
	 * Function to navigate Patient Tab
	 * 
	 */
	public void navigateToPatientTab() 
	{
		LOGGER.info("enter DialysisScheduleComponent.navigateToPatientTab");
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id",dsc.homePagePatientTabId())));
		
	}
	
	/***
	 * Function to Select First Facility from Dropdown
	 * 
	 */
	public String selectFacility() 
	{
		LOGGER.info("enter DialysisScheduleComponent.selectFacility");
		//Make sure the Modal is displayed before we attempt to interact with the window with selenium.
		gwm.waitForElementToBeVisbile(gwm.getWebElement(By.cssSelector(dsc.selectFacilityModalCss())));
		//Selecting facility
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath",dsc.selectFacilityDropdownModalXpath())));
		String facilityName=gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", dsc.firstFacilityValueCSS())));
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("cssSelector",dsc.firstFacilityValueCSS())));
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("cssSelector",dsc.selectFacilityModalContinueButtonCss())));
		gwm.waitForTextInElement(gwm.getWebElements(gwm.getBy("cssSelector",dsc.patientFiltersCSS())).get(2), facilityName);
		
		return facilityName;
	}
	
	/***
	 * Function to verify Patient Screen and Dialysis Filters
	 * 
	 */
	public void verifyPatientScreen() {
		LOGGER.info("enter DialysisScheduleComponent.verifyPatientScreen");
		String strTemp=gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", dsc.patientLabelHeaderCSS())));
		
		Assert.assertTrue(strTemp.toUpperCase().contains("PATIENTS"), "Verify Patients Screen is displayed");
		
		List<WebElement> objTemp = gwm.getWebElements(gwm.getBy("cssSelector",dsc.patientFiltersCSS()));
		Assert.assertEquals(objTemp.size(), 3, "Verify Patient Screen Dialysis Schedule filters are displayed");
		
	}
	
	/***
	 * Function to verify whether filter is selected properly
	 * 
	 */
	public void verifySelectedFiltersDisplay(String selectedFacility) 
	{
		LOGGER.info("enter DialysisScheduleComponent.verifySelectedFiltersDisplay");
		List<WebElement> objTemp = gwm.getWebElements(gwm.getBy("cssSelector",dsc.patientFiltersCSS()));
		String uiFilter=gwm.readWebElementText(objTemp.get(2));
		
		Assert.assertEquals(uiFilter.toUpperCase(),selectedFacility.toUpperCase(), "Verify Selected Facility is displayed in filter");
		
	}
	
	/***
	 * Function to Verify dialysis table header
	 * 
	 */
	public void verifyDialysisTableHearderDisplays() {
		LOGGER.info("enter DialysisScheduleComponent.verifyDialysisTableHearderDisplays");
		
		gwm.isElementPresent(gwm.getBy("cssSelector", dsc.dialysisDataTableCSS()));
		
		Assert.assertTrue(true, "Verify Dialysis Schedule Table Header is Displayed");
	}

	/***
	 * Function to verify Facility retains after switching between screens
	 * 
	 */
	
	public void verifySwitchingRetainsFacility(String selectedFacility) 
	{
		LOGGER.info("enter DialysisScheduleComponent.verifySwitchingRetainsFacility");
		
		//clicking on Home Page Tab
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id",dsc.homePageTabId())));
		
		//clicking back to Patient Tab
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id",dsc.homePagePatientTabId())));
		
		//Validating Facility is not changed
		List<WebElement> objTemp = gwm.getWebElements(gwm.getBy("cssSelector",dsc.patientFiltersCSS()));

		gwm.waitForTextToBePresentInElement(objTemp.get(2), selectedFacility,  (int)ec.getWaitTimeout(), false);
		
		String uiFilter=gwm.readWebElementText(objTemp.get(2));
		
		Assert.assertEquals(uiFilter.toUpperCase(),selectedFacility.toUpperCase(), "Verify after navigating to other module selected Dialysis Filter is retained");
	}
	
}
