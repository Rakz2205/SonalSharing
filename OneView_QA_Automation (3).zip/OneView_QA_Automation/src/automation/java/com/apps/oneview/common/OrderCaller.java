package com.apps.oneview.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

@SuppressWarnings("static-access")
public class OrderCaller {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private static OrderCaller PropertiesCache;
	private final static Properties configProp = new Properties();
	private static String Propertyfilename = "order.properties";

	public OrderCaller setPropertyfilename(String Propertyfilename) {
		this.Propertyfilename = Propertyfilename;
		return this;
	}
	
	/***
	 * configcaller loads the property called in the .properties file
	 */

	public OrderCaller() {
		// Private constructor to restrict new instances
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(Propertyfilename);
		LOGGER.info("Reading properties from file: " + Propertyfilename);
		try {
			configProp.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Bill Pugh Solution for singleton pattern

	/**
	 * Directive: Only use the static methods for testing the framework
	 * functionality. Write getters to access specific properties so that no input
	 * strings are hard coded in your tests.
	 */

	public static class ResourceLoader {
		private static final OrderCaller INSTANCE = new OrderCaller();
	}

	public static OrderCaller getInstance() {
		return ResourceLoader.INSTANCE;
	}

	public static String getProperty(String key) {
		return configProp.getProperty(key);
	}

	public Set<String> getAllPropertyNames() {
		return configProp.stringPropertyNames();
	}

	public boolean containsKey(String key) {
		return configProp.containsKey(key);
	}

	public void setProperty(String key, String value) {
		configProp.setProperty(key, value);
	}

	/**
	 * adding all callers for environments this is where you call a specific
	 * environment please do not hardcode the in your code add a propertycaller for
	 * it under this segment.
	 */

	public String homePageTaskId() {
		return PropertiesCache.getInstance().getProperty("homePageTaskId");
	}

	public String homePageTaskOrdersId() {
		return PropertiesCache.getInstance().getProperty("homePageTaskOrdersId");
	}

	public String ordersLabelHeaderCSS() {
		return PropertiesCache.getInstance().getProperty("ordersLabelHeaderCSS");
	}

	public String cwowActiveFocusCSS() {
		return PropertiesCache.getInstance().getProperty("cwowActiveFocusCSS");
	}

	public String cwowOrderTableViewCSS() {
		return PropertiesCache.getInstance().getProperty("cwowOrderTableViewCSS");
	}

	public String pageLoaderXpath() {
		return PropertiesCache.getInstance().getProperty("pageLoaderXpath");
	}

	public String signSingleOrderModalID() {
		return PropertiesCache.getInstance().getProperty("signSingleOrderModalID");
	}

	public String signSingleOrderFromModalID() {
		return PropertiesCache.getInstance().getProperty("signSingleOrderFromModalID");
	}

	public String clickOnSnappyTab() {
		return PropertiesCache.getInstance().getProperty("snappyTab");
	}
	
	public String cwowOrdersTab() {
		return PropertiesCache.getInstance().getProperty("cwowOrdersTab");
	}
	
	public String totalCount() {
		return PropertiesCache.getInstance().getProperty("paginationCount");
	}

	public String rightArrowPagination() {
		return PropertiesCache.getInstance().getProperty("pageRightArrow");
	}

	public String leftArrowPagination() {
		return PropertiesCache.getInstance().getProperty("pageLeftArrow");
	}

	public String snappyTabOrderCount() {
		return PropertiesCache.getInstance().getProperty("snappyTabOrderCount");
	}

	public String snappyOrderBadgeCount() {
		return PropertiesCache.getInstance().getProperty("snappyOrderCountReadCSS");
	}

	public String orderCountRead(String strOrderclass) {
		return PropertiesCache.getInstance().getProperty("allOrderCountRead").replace("strOrdername", strOrderclass);
	}

	/**
	 * Function: get_order_grid
	 * 
	 * @param loc = value can be name for tagName, null for Css
	 * 
	 * @return Function will return the value of the specified property
	 */
	public String getOrderGrid(String loc) {
		if ((loc != null) && (loc.equals("name"))) {
			return PropertiesCache.getInstance().getProperty("orderGridTagName");
		} else {
			return PropertiesCache.getInstance().getProperty("orderGridCSS");
		}
	}
	
	/**
	 * Function: get_refuted_order_grid
	 * @param loc
	 *            = value can be name for tagName, css for Css, null for by XPath
	 * @return Function will return the value of the specified property
	 */
	public String getRefutedOrderGrid(String loc) {
		if ((loc != null) && (loc.equals("name"))) {
			return PropertiesCache.getInstance().getProperty("refutedOrderGridTagName");
		} else {
			return PropertiesCache.getInstance().getProperty("refutedOrderGridCss");
		}
	}

	public String getCwowOrderGridRows() {
		return PropertiesCache.getInstance().getProperty("orderSummaryDataRow");

	}

	public String spinnerInsideOrder() {
		return PropertiesCache.getInstance().getProperty("spinnerInsideOrder");
	}

	public String signButtonSummaryExpanded(String rowNum) {
		return PropertiesCache.getInstance().getProperty("signButtonSummaryExpanded").replace("%rowNumber", rowNum);
	}

	public String orderRow(String rowNum) {
		return PropertiesCache.getInstance().getProperty("orderRow").replace("%rowNumber", rowNum);
	}

	public String orderIDDetailPage() {
		return PropertiesCache.getInstance().getProperty("orderIDDetailPage");
	}

	public String disputeBtnOnDetailPage() {
		return PropertiesCache.getInstance().getProperty("disputeBtnOnDetailPage");
	}

	public String selectDisputeReasonDropDownButton() {
		return PropertiesCache.getInstance().getProperty("selectDisputeReasonDropDownButton");
	}

	public String selectReasonFromDisputeDropDown() {
		return PropertiesCache.getInstance().getProperty("disputeReasonList");
	}

	public String clickOnDisputeButton() {
		return PropertiesCache.getInstance().getProperty("disputeButton");
	}

	public String orderBadgeCount() {
		return PropertiesCache.getInstance().getProperty("orderCountReadClass");
	}

	public String cwowOrderBadgeCount() {
		return PropertiesCache.getInstance().getProperty("cwowOrderCountReadCSS");
	}

	public String orderNavigation() {
		return PropertiesCache.getInstance().getProperty("orderNavigation");
	}

	public String orderDetailCloseButton() {
		return PropertiesCache.getInstance().getProperty("orderDetailCloseButton");
	}

	public String summaryColText(String rowNum, String colNum) {
		String strTemp = PropertiesCache.getInstance().getProperty("summaryColText");
		return String.format(strTemp, rowNum, colNum);
	}

	public String hoverSummaryScreen(String rowNum, String colNum) {
		String strTemp = PropertiesCache.getInstance().getProperty("hoverSummaryScreen");
		return String.format(strTemp, rowNum, colNum);
	}

	public String mouseHoverTextUsingXpath() {
		return PropertiesCache.getInstance().getProperty("mouseHover");
	}

	public String patientNameClass() {
		return PropertiesCache.getInstance().getProperty("patientNameClass");
	}

	public String patientAgeId() {
		return PropertiesCache.getInstance().getProperty("patientAgeId");
	}

	public String patientDOBId() {
		return PropertiesCache.getInstance().getProperty("patientDOBId");
	}

	public String patientGenderId() {
		return PropertiesCache.getInstance().getProperty("patientGenderId");
	}

	public String patientFacilityId() {
		return PropertiesCache.getInstance().getProperty("patientFacilityId");
	}

	public String dateFormatPattern() {
		return PropertiesCache.getInstance().getProperty("dateFormatPattern");
	}
	
	public String dateFormatPattern2() {
		return PropertiesCache.getInstance().getProperty("dateFormatPattern2");
	}

	public String orderDetailPageAllFieldsClass() {
		return PropertiesCache.getInstance().getProperty("orderDetailPageAllFieldsClass");
	}

	public String orderDetailPageAllFieldsLabelClass() {
		return PropertiesCache.getInstance().getProperty("orderDetailPageAllFieldsLabelClass");
	}
	
	public String orderDetailPageAllFieldsSubClass() {
		return PropertiesCache.getInstance().getProperty("orderDetailPageAllFieldsSubClass");
	}	
	
	public String orderDetailPageAllFieldsSubLabelClass() {
		return PropertiesCache.getInstance().getProperty("orderDetailPageAllFieldsSubLabelClass");
	}

	public String detailPageLoadingBar() {
		return PropertiesCache.getInstance().getProperty("detailPageLoadingBar");
	}

	public String clickSignOrDisputeModal(String rowNum) {
		return PropertiesCache.getInstance().getProperty("clickSignOrDisputeModal").replace("%rowNumber", rowNum);
	}

	public String clickOnDisputeOption(String rowNum) {
		return PropertiesCache.getInstance().getProperty("clickOnDisputeOption").replace("%rowNumber", rowNum);
	}

	public String fetchDisputeReason() {
		return PropertiesCache.getInstance().getProperty("fetchDisputeReason");
	}

	public String disputeButtonSummaryPage() {
		return PropertiesCache.getInstance().getProperty("disputeButtonSummaryPage");
	}

	public String enterReasonForDispute() {
		return PropertiesCache.getInstance().getProperty("enterReasonForDispute");
	}

	public String pageLoader() {
		return PropertiesCache.getInstance().getProperty("loaderClassName");
	}

	public String fetchDetailPageDisputeOptions() {
		return PropertiesCache.getInstance().getProperty("fetchDetailPageDisputeOptions");
	}

	public String clickOnSignInOption(String rowNum) {
		return PropertiesCache.getInstance().getProperty("clickOnSignInOption").replace("%rowNumber", rowNum);
	}

	public String clickOnSignDetailPage() {
		return PropertiesCache.getInstance().getProperty("clickOnSignDetailPage");
	}

	public String clickCheckboxOnSnappyPage(String rowNum) {
		return PropertiesCache.getInstance().getProperty("clickCheckboxOnSnappyPage").replace("%rowNumber", rowNum);
	}

	public String signButtonFooter() {
		return PropertiesCache.getInstance().getProperty("signButtonFooter");
	}

	public String cwowTab() {
		return PropertiesCache.getInstance().getProperty("cwowTab");
	}

	public String getAllOrdersHeaderTextCSS() {
		return PropertiesCache.getInstance().getProperty("allOrdersHeaderTextCSS");
	}

	public String getRecentOrdersHeaderTextCSS() {
		return PropertiesCache.getInstance().getProperty("recentOrdersHeaderTextCSS");
	}
	
	public String patientMPId() {
		return PropertiesCache.getInstance().getProperty("patientMPId");	
	}
	
	public String dnrPolicyXpath() {
		return PropertiesCache.getInstance().getProperty("dnrPolicyXpath");
		 		 
	 }
	
	public String sodiumProfileXpath() {
		return PropertiesCache.getInstance().getProperty("sodiumProfileXpath");
		
	}
	
	public String sodiumPrnInstructionsXpath() {
		return PropertiesCache.getInstance().getProperty("sodiumPrnInstructionsXpath");
	}
	
	public String sodiumPerformWithXpath() {
		return PropertiesCache.getInstance().getProperty("sodiumPerformWithXpath");
	}
	
	public String ufProfileXpath() {
		return PropertiesCache.getInstance().getProperty("ufProfileXpath");
	}
	
	public String ufPrnInstructionsXpath() {
		return PropertiesCache.getInstance().getProperty("ufPrnInstructionsXpath");
	}
	
	public String ufPerformWithXpath() {
		return PropertiesCache.getInstance().getProperty("ufPerformWithXpath");
	}
	
	 public String detailsPageExitId() {
		 return PropertiesCache.getInstance().getProperty("detailsPageExitId");
	 }
	public String recentOrdersCountCSS() {
		return PropertiesCache.getInstance().getProperty("recentOrdersCountCSS");
	}
	public String ghostLoaderCSS() {
		return PropertiesCache.getInstance().getProperty("ghostLoaderCSS");
	}
	public String totalOrderCountRead() {
		return PropertiesCache.getInstance().getProperty("allOrdersCountReadCSS");
	}
	
}

