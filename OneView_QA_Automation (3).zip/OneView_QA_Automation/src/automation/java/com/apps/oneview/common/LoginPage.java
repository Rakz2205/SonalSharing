package com.apps.oneview.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/*import com.oneview.callers.LeftMenu;
import com.oneview.callers.LoginCaller;*/

public class LoginPage extends LeftMenu {
	
	WebDriver driver;

    By homePageUserName = By.xpath(menu_username_path());

    

    public LoginPage(WebDriver driver){

        this.driver = driver;

    }

    

    //Get the User name from Home Page

        public String getHomePageDashboardUserName(){

         return    driver.findElement(homePageUserName).getText();

        }

}
