package com.apps.oneview.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

@SuppressWarnings("static-access")
public class SearchCaller {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private static SearchCaller PropertiesCache;
	private final static Properties configProp = new Properties();
	private static String Propertyfilename = "search.properties";

	public SearchCaller setPropertyfilename(String Propertyfilename) {
		this.Propertyfilename = Propertyfilename;
		return this;

	}

	/***
	 * configcaller loads the property called in the .properties file
	 */

	public SearchCaller() {
		// Private constructor to restrict new instances
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(Propertyfilename);
		LOGGER.info("Reading properties from file: " + Propertyfilename);
		try {
			configProp.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Bill Pugh Solution for singleton pattern

	/**
	 * Directive: Only use the static methods for testing the framework
	 * functionality. Write getters to access specific properties so that no
	 * input strings are hard coded in your tests.
	 */

	public static class ResourceLoader {
		private static final SearchCaller INSTANCE = new SearchCaller();
	}

	public static SearchCaller getInstance() {
		return ResourceLoader.INSTANCE;
	}

	public static String getProperty(String key) {
		return configProp.getProperty(key);
	}

	public Set<String> getAllPropertyNames() {
		return configProp.stringPropertyNames();
	}

	public boolean containsKey(String key) {
		return configProp.containsKey(key);
	}

	public void setProperty(String key, String value) {
		configProp.setProperty(key, value);
	}

	public String getSearchIconID() {
		return PropertiesCache.getInstance().getProperty("searchIcon");
	}
	
	public String getSearchBoxInputID() {
		return PropertiesCache.getInstance().getProperty("searchBoxInput");
	}
	public String getSearchResultsXpath(){
		return PropertiesCache.getInstance().getProperty("searchResultsXpath");
	}
	public String getSearchResultsPath() {
		return PropertiesCache.getInstance().getProperty("searchResults");
	}
	public String getSearchResultNamePath() {
		return PropertiesCache.getInstance().getProperty("searchResultName");
	}
	public String getHeaderTitlePath() {
		return PropertiesCache.getInstance().getProperty("headerTitle");
	}
	public String getpatientNamePatientChartPath() {
		return PropertiesCache.getInstance().getProperty("patientNamePatientChart");
	}
	public String getAllTabsLocatorXpath() {
		return PropertiesCache.getInstance().getProperty("allTabsXpath");
	}
	public String getPatientChartTitle() {
		return PropertiesCache.getInstance().getProperty("patientChartTitle");
	}
	public String getSearchHeaderNoStringText() {
		return PropertiesCache.getInstance().getProperty("searchHeaderNoStringText");
	}
	public String getSearchHeaderCss() {
		return PropertiesCache.getInstance().getProperty("searchHeader");
	}	
	public String getSearchHeaderText() {
		return PropertiesCache.getInstance().getProperty("searchHeaderText");
	}
	public String getSearchHeaderOneText() {
		return PropertiesCache.getInstance().getProperty("searchHeaderOneText");
	}
	public String getPatientNameList() {
		return PropertiesCache.getInstance().getProperty("patientNameList");
	}
	public String getListLoaderXpath() {
		return PropertiesCache.getInstance().getProperty("listLoader");
	}
}
