package com.apps.oneview.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import com.base.GenericVariable;

@SuppressWarnings("static-access")
public class HomePageCaller {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private static HomePageCaller PropertiesCache;
	private final static Properties configProp = new Properties();
	private static String Propertyfilename = "homepage.properties";

	public HomePageCaller setPropertyfilename(String Propertyfilename) {
		this.Propertyfilename = Propertyfilename;
		return this;
	}

	/***
	 * configcaller loads the property called in the .properties file
	 */

	public HomePageCaller() {
		// Private constructor to restrict new instances
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(Propertyfilename);
		LOGGER.info("Reading properties from file: " + Propertyfilename);
		try {
			configProp.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Bill Pugh Solution for singleton pattern

	/**
	 * Directive: Only use the static methods for testing the framework
	 * functionality. Write getters to access specific properties so that no input
	 * strings are hard coded in your tests.
	 */

	public static class ResourceLoader {
		private static final HomePageCaller INSTANCE = new HomePageCaller();
	}

	public static HomePageCaller getInstance() {
		return ResourceLoader.INSTANCE;
	}

	public static String getProperty(String key) {
		return configProp.getProperty(key);
	}

	public Set<String> getAllPropertyNames() {
		return configProp.stringPropertyNames();
	}

	public boolean containsKey(String key) {
		return configProp.containsKey(key);
	}

	public void setProperty(String key, String value) {
		configProp.setProperty(key, value);
	}

	/**
	 * adding all callers for environments this is where you call a specific
	 * environment please do not hardcode the in your code add a propertycaller for
	 * it under this segment.
	 */
	
	public String davitaLogoCss() {
		return PropertiesCache.getInstance().getProperty("logoCss");
	}

	public String appNameCss() {
		return PropertiesCache.getInstance().getProperty("appNameCss");
	}
	
	public String disagreeBtnXpath() {
		return PropertiesCache.getInstance().getProperty("disagreeBtnXpath");
	}
	
	public String agreeBtnXpath() {
		return PropertiesCache.getInstance().getProperty("agreeBtnXpath");
	}
	
	public String pendoCloseCss() {
		return PropertiesCache.getInstance().getProperty("pendoCloseCss");
	}
	
	public String pendoImageBadgeCss() {
		return PropertiesCache.getInstance().getProperty("pendoImageBadgeCss");
	}
	
	public String patientSearchButtonCss() {
		return PropertiesCache.getInstance().getProperty("patientSearchCss");
	}
	
	public String mainNavigationTaggname() {
		return PropertiesCache.getInstance().getProperty("mainNavTagname");
	}
	
	public String mainNavigationExpandedCss() {
		return PropertiesCache.getInstance().getProperty("mainNavExpandedCss");
	}
	
	public String commsHubComponentId() {
		return PropertiesCache.getInstance().getProperty("commsHubId");
	}
	
	public String mytasksComponentTagname() {
		return PropertiesCache.getInstance().getProperty("myTasksComponentTagname");
	}
	
	public String mytasksCardsCss() {
		return PropertiesCache.getInstance().getProperty("myTasksCardsCss");
	}
	
	public String mytasksCardsTagname() {
		return PropertiesCache.getInstance().getProperty("myTasksCardsTagname");
	}
	
	public String davitaAppsTagname() {
		return PropertiesCache.getInstance().getProperty("davitaApps");
	}

	public int mytasksCount() {
		return Integer.valueOf(PropertiesCache.getInstance().getProperty("taskCount")).intValue();
	}
	
	public String dpsUserInfoCss() {
		return PropertiesCache.getInstance().getProperty("userInfoCss");
	}
}
