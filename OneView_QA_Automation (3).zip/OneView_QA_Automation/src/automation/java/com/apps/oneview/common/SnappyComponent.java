package com.apps.oneview.common;

import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.common.EnvironmentCaller;
import com.apps.oneview.common.LoginComponent;
import com.apps.oneview.common.OrderCaller;
import com.apps.oneview.services.physPortalAPIComponent;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.GenericWebMethods;

import io.restassured.response.Response;

public class SnappyComponent {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private OrderCaller oc = new OrderCaller();
	private EnvironmentCaller ec = new EnvironmentCaller();
	GenericWebMethods gwm;
	WebElement orderTable;
	List<WebElement> allRows;

	public SnappyComponent(WebDriver wd) {
		// TODO Auto-generated constructor stub
		gwm = new GenericWebMethods(wd);
	}

	/**
	 * To click on snappy tab @ return : void
	 */
	public void Click_On_Snappy_Tab() {
		LOGGER.info("SnappyComponent.clickOnSnappyTab()");
		gwm.waitForElementToAppear(gwm.getBy("id", oc.homePageTaskId()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.homePageTaskId())));
		gwm.waitForElementToAppear(gwm.getBy("id", oc.homePageTaskOrdersId()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.homePageTaskOrdersId())));
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnSnappyTab()), (int) ec.getPageWaitTimeout());
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
				(int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSnappyTab())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
				(int) ec.getWaitTimeout());
	}

	/**
	 * TO read total snappy order count present at left bottom @ return: total
	 * snappy order count
	 */
	public int readTotalCount() {

		gwm.waitForTextToBePresentInElement(gwm.getWebElement(gwm.getBy("xpath", oc.totalCount())), "of",
				(int) ec.getWaitTimeout(), true);
		String Page_Count = gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.totalCount())));
		String[] arrSplit = Page_Count.split(" ");
		String Total_Count = arrSplit[4];
		return Integer.parseInt(Total_Count);
	}

	/**
	 * TO read total snappy order count present at left bottom and navigate upto
	 * last page using right arrow and checking the behavior of left and right
	 * arrow @ return: void
	 */
	public void GetTotalOrderCount() {
		gwm.waitForPageLoad();
		WebElement rightArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.rightArrowPagination()));
		String rightArrowData = rightArrow.getAttribute("class");
		WebElement leftArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.leftArrowPagination()));
		String classes = leftArrow.getAttribute("class");
		boolean isDisabledRightBtn;
		boolean isDisabledLeftBtn;
		int totalCount = readTotalCount();

		// Verify if the count is less than 20, then both the arrows are disabled
		if (totalCount < 20) {
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			// check for right button enable
			LOGGER.info("Checking for right arrow to be disable if total count is less than 20");
			isDisabledRightBtn = rightArrowData.contains("disabled");
			Assert.assertTrue(isDisabledRightBtn, "right arrow is enable");

			isDisabledLeftBtn = classes.contains("disabled");
			Assert.assertTrue(isDisabledLeftBtn, "Left arrow is enable");
			Assert.assertEquals(allRows.size(), totalCount,
					"No of orders doesn't match, Actual: " + allRows.size() + " Expected: " + totalCount);

		} else if (totalCount > 20) {
			// Check for left button disable
			LOGGER.info("Checking for left arrow to be disable if total count is greater than 20");

			isDisabledLeftBtn = classes.contains("disabled");
			Assert.assertTrue(isDisabledLeftBtn, "Left arrow is enable");
			// For navigating to next page and verify right arrow
			int noOfPages = totalCount / 20;
			int noOfOrdersLastPage = totalCount % 20;
			if (noOfOrdersLastPage != 0) {
				noOfPages = noOfPages + 1;
			}

			for (int i = 1; i < noOfPages; i++) {

				orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
				allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));

				Assert.assertEquals(allRows.size(), 20,
						"No of orders doesn't match, Actual: " + allRows.size() + " Expected: 20");

				rightArrow.click();
				gwm.waitForElementToAppear(gwm.getBy("xpath", oc.spinnerInsideOrder()), (int) ec.getPageWaitTimeout());
				GenericHelper.sleepSeconds(2); // 2 second wait is added because application takes time to load all 20
												// orders in a page
			}

			isDisabledRightBtn = rightArrowData.contains("disabled");
			Assert.assertFalse(isDisabledRightBtn, "right arrow is enable");
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			Assert.assertEquals(allRows.size(), noOfOrdersLastPage,
					"No of orders doesn't match, Actual: " + allRows.size() + " Expected: " + noOfOrdersLastPage);

		}

	}

	/**
	 * check whether total order badge count (available at upper left) is changed if
	 * we signed single order from snappy tab @ return: total snappy order count
	 */
	public void SignSingleOrderCountChanged() {
		// Read Order count from Snappy tab
		String SnappyTabCount = gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.snappyTabOrderCount())));

		// Select first snappy order
		boolean expanded = gwm.isElementVisible(gwm.getWebElement(gwm.getBy("id", oc.signSingleOrderModalID())));
		if (expanded) {
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.signSingleOrderModalID())));

			// sign the same order
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.signSingleOrderFromModalID())));
		} else {
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.signButtonSummaryExpanded("0"))));
		}

		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("classname", oc.pageLoader())),
				(int) ec.getWaitTimeout());

		// again read the count after signing one order
		String SnappyTabCountLatest = gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.snappyTabOrderCount())));

		Assert.assertEquals(Integer.parseInt(SnappyTabCountLatest), Integer.parseInt(SnappyTabCount) - 1,
				"Count of total order should be decrease by 1");

	}

	/**
	 * Match dps snappy count with physician portal count
	 * 
	 */
	public void Verify_PpCount_with_DPSCount(int ppCount, int dspCount) {

		Assert.assertEquals(dspCount, ppCount, "count should be same");
	}

	/**
	 * @description Fetch unsigned order count from PP
	 * @return SnappyOrderCount
	 */
	public int getUnsignedOrderCountPhysicainPortal() {
		int SnappyOrderCount = Integer.parseInt(gwm.readWebElementText(
				gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.snappyOrderBadgeCount())))));

		return SnappyOrderCount;
	}

	/**
	 * It will dispute first order available on snappy page and a Also check for
	 * total order count that should be reduced by 1
	 *
	 */
	public void DisputeSingleOrderCountChanged() {
		String Not_My_Patient_Reason = "Not My Patient";
		// Read Order count from Snappy tab
		int totalCountPre = readTotalCount();
		// Select first snappy order
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(0 + ""))));
		By by = gwm.getBy("xpath", oc.orderIDDetailPage());
		gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.disputeBtnOnDetailPage())));
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.selectDisputeReasonDropDownButton())));
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath",
				oc.selectReasonFromDisputeDropDown() + "[text()='" + Not_My_Patient_Reason + "']")));
		// Select dispute and its reason
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnDisputeButton())));// Click on dispute
																									// button
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.spinnerInsideOrder()), (int) ec.getPageWaitTimeout());
		// again read the count after dispute one order
		int totalCountPost = readTotalCount();
		Assert.assertEquals(totalCountPre, totalCountPost + 1, "Count of total order should be decrease by 1");
	}

	/**
	 * It will matched the Order badged count with the addition of snappy and cwow
	 * count (order badge count = cwow order count + snappy order count)
	 */
	public void MatchTotalOrderCount() {
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.orderCountRead(oc.orderBadgeCount())),
				(int) ec.getPageWaitTimeout());
		String OrderCount = gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.orderBadgeCount())))); // Read
																														// all
																														// order
																														// count
		LOGGER.info("Expected Order count" + OrderCount);

		// Read cwow order count
		// if cwow order count is not present,then take it as 0 count
		String CwowOrderCount;

		try {
			CwowOrderCount = gwm.readWebElementText(
					gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.cwowOrderBadgeCount()))));

		} catch (NoSuchElementException e) {
			LOGGER.info("Cwow order is not present" + e.getMessage());
			CwowOrderCount = "0";
		}

		String SnappyOrderCount = gwm.readWebElementText(
				gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.snappyOrderBadgeCount())))); // Read snappy
																										// order
		// count

		int CorrectCount = Integer.parseInt(CwowOrderCount) + Integer.parseInt(SnappyOrderCount);

		Assert.assertEquals(CorrectCount, Integer.parseInt(OrderCount),
				"Both actual and expected order count should be same");
	}

	/**
	 * Below function is to Select right order by passing order Id and Patient Name
	 */
	public int selectOrderUsingOrderIDandPatientName(String orderID, String strPname) {
		int rowCounter = -1;
		int totalCount = readTotalCount();
		boolean boolFound = false;
		WebElement rightArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.rightArrowPagination()));
		for (int pageCounter = 0; pageCounter < totalCount; pageCounter++) {
			GenericHelper.sleepSeconds(1);
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			for (rowCounter = 0; rowCounter < allRows.size(); rowCounter++) {
				String StrPatName = gwm.readWebElementText(gwm.getWebElement(
						gwm.getBy("xpath", String.format(oc.orderNavigation(), String.valueOf(rowCounter), "1"))));
				if (StrPatName.contains(strPname)) {
					gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowCounter + ""))));
					gwm.waitForElementToAppear(gwm.getBy("xpath", oc.orderIDDetailPage()), (int) ec.getWaitTimeout());
					GenericHelper.sleepSeconds(2);
					String screenOrderId = gwm
							.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.orderIDDetailPage())));
					gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())));
					GenericHelper.sleepSeconds(2);
					gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())),
							20);
					if (screenOrderId.equals(orderID)) {
						boolFound = true;
						break;
					}
				}
			}
			if (boolFound) {
				break;
			} else {
				rowCounter = -1;
			}
			pageCounter = pageCounter + allRows.size();
			// click on next page
			if (!rightArrow.getAttribute("class").contains("disabled")) {
				rightArrow.click();
				gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
						(int) ec.getWaitTimeout());
			}
		}
		return rowCounter;

	}

	/**
	 * 
	 * @param orderType   type to be searched
	 * @param orderStatus status to be searched
	 * @return row number with specific order type
	 */
	public int findOrderWithType(String orderType) {
		int rowCounter = -1;
		int totalCount = readTotalCount();
		boolean boolFound = false;
		WebElement rightArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.rightArrowPagination()));
		for (int pageCounter = 0; pageCounter < totalCount; pageCounter++) {
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			for (rowCounter = 0; rowCounter < allRows.size(); rowCounter++) {
				String ScreenOrderStatus = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowCounter + "", "6").toUpperCase())));
				String ScreenOrderText = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowCounter + "", "8").toUpperCase())));
				if (ScreenOrderText.startsWith(orderType.toUpperCase())) {
					boolFound = true;
					break;
				}
			}
			if (boolFound) {
				break;
			} else {
				rowCounter = -1;
			}
			pageCounter = pageCounter + allRows.size();
			// click on next page
			if (!rightArrow.getAttribute("class").contains("disabled")) {
				rightArrow.click();
				gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
						(int) ec.getWaitTimeout());
			}
		}
		return rowCounter;
	}

	/**
	 * Below function is to fetch hover text for particular row Note : Page
	 * navigation should be implemented prior If particular column doesn't contain
	 * hover text then its orignal value is taken
	 */
	public Map getToolTipTextAllColumn(int rowNumber) {
		/*
		 * keys for oder details Name Age DOB Gender FacilityCenter OrderType OrderId
		 * OrderStartdate OrderEndDate OrderStatus DiscontinuedDate Protien Sodium
		 * Potassium Phosphorus Calories Fluid CarbohydrateControlled
		 * PatientDiabeticStatus Additional Provider Collaborating_Physician EnteredOn
		 * NotedOn Justification TreatmentType Frequency Schedule TreatmentTime Dialyzer
		 * K+ Ca++ Bicarb Na Type StartNa EndNa InstructionsForUseNaModelling
		 * Temperature AutoFlow DFR BFR UFProfiling MaxUFRate
		 * InstructionsForUseUltaFiltration BolusLoad HourlyDose Stop TotalHeparinUnits
		 * Arterial Venous PrimaryAccess Concurrent ArterialLength ArterialGauge
		 * VenousLength VenousGauge NeedleTip Notes Source CodedBy CodedOn Access
		 * HeparinConcentration
		 * 
		 */

		Map dictOrderDetailPP = new HashMap();
		if (rowNumber >= 0) {

			String PatientColNum = "3";
			String FacilityColNum = "5";
			String StatusColNum = "6";
			String StartDateColNum = "7";
			String OrderColNum = "8";
			String JustificationColNum = "9";

			dictOrderDetailPP = new Hashtable();
			// Name
			gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", PatientColNum)));
			GenericHelper.sleepSeconds(3);
			String Name = "";
			String Age = "";
			String Gender;
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
				Name = gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
			} else {
				Name = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", PatientColNum))));
			}
			// Name
			String PatientName = Name.substring(0, Name.indexOf('(')).trim();
			PatientName = PatientName.trim();
			dictOrderDetailPP.put("Name", PatientName);
			Name = Name.replace(PatientName, "");
			LOGGER.info("Name " + PatientName);

			// Age
			Age = Name.substring(Name.indexOf("(") + 1, Name.indexOf(",")).trim();
			dictOrderDetailPP.put("Age", Age);
			LOGGER.info("Age " + Age);

			// Gender
			Gender = Name.substring(Name.indexOf(',') + 1, Name.indexOf(')')).trim();
			Gender = Gender.trim();
			dictOrderDetailPP.put("Gender", Gender);
			LOGGER.info("Gender " + Gender);

			// facility center
			String facilityCenter = "";
			gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", FacilityColNum)));
			GenericHelper.sleepSeconds(3);
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
				facilityCenter = gwm
						.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
			} else {
				facilityCenter = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", FacilityColNum))));
			}
			dictOrderDetailPP.put("FacilityCenter", "- " + facilityCenter.toUpperCase());
			LOGGER.info("FacilityCenter" + facilityCenter);

			// Status
			String OrderStatus;
			gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", StatusColNum)));
			GenericHelper.sleepSeconds(3);
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
				OrderStatus = gwm
						.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
			} else {
				OrderStatus = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", StatusColNum))));
			}

			if (OrderStatus.equals("DC"))
				OrderStatus = "D/C";
			dictOrderDetailPP.put("OrderStatus", OrderStatus);
			LOGGER.info("OrderStatus" + OrderStatus);

			// StartDate
			String startDate;
			gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", StartDateColNum)));
			GenericHelper.sleepSeconds(3);
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
				startDate = gwm
						.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
			} else {
				startDate = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", StartDateColNum))));
			}

			startDate = GenericHelper.dateFormat(startDate, oc.dateFormatPattern());
			dictOrderDetailPP.put("OrderStartdate", startDate);
			LOGGER.info("OrderStartdate" + startDate);

			// Justification is not for Diet order will be used for some other order
			// Justification
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", JustificationColNum)))) {
				gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", JustificationColNum)));
				String justification;
				GenericHelper.sleepSeconds(3);
				if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
					justification = gwm.readWebElementText(
							gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
				} else {
					justification = gwm.readWebElementText(gwm
							.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", JustificationColNum))));
				}
				justification = justification.replace("()", "");
				dictOrderDetailPP.put("Justification", justification);
				LOGGER.info("Justification" + justification);
			}

			// Order
			String hoverOrderText;
			gwm.mouse_Hover(gwm.getBy("xpath", oc.hoverSummaryScreen(rowNumber + "", OrderColNum)));
			GenericHelper.sleepSeconds(3);
			if (gwm.isElementPresent(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath()))) {
				hoverOrderText = gwm
						.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.mouseHoverTextUsingXpath())));
			} else {
				hoverOrderText = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowNumber + "", OrderColNum))));
			}
			String orderType = hoverOrderText.substring(0, hoverOrderText.indexOf(":")).trim();
			if (orderType.equals("Lab"))
				orderType = "Laboratory";
			dictOrderDetailPP.put("OrderType", orderType);
			LOGGER.info("Order Type " + orderType);
			hoverOrderText = hoverOrderText.substring(orderType.length() + 1).trim();
			if (hoverOrderText.startsWith("Medication")) {
				int pos = hoverOrderText.indexOf(":", hoverOrderText.indexOf(":") + 1);
				int pos2 = hoverOrderText.substring(0, pos).lastIndexOf(";");
				String startText = hoverOrderText.substring(0, hoverOrderText.indexOf(":")).trim();
				String startTextValue = hoverOrderText.substring(hoverOrderText.indexOf(":") + 1, pos2).trim();

				dictOrderDetailPP.put(startText, startTextValue);
				LOGGER.info(startText + startTextValue);
				hoverOrderText = hoverOrderText.substring(startText.length() + 1);
				hoverOrderText = hoverOrderText.substring(startTextValue.length() + 2).trim();
			}
			hoverOrderText = hoverOrderText.replaceAll("CVC Post Heparin Instillation:", "");
			hoverOrderText = hoverOrderText.replaceAll("Venous", ";Venous");
			String arrTemp[] = hoverOrderText.split(";");

			for (int orderTextInc = 0; orderTextInc < arrTemp.length; orderTextInc++) {
				if (arrTemp[orderTextInc].trim().startsWith("Needle: Arterial:")
						|| arrTemp[orderTextInc].trim().startsWith("Needle: Venous: ")) {
					arrTemp[orderTextInc] = arrTemp[orderTextInc].replaceAll("Needle:", "").trim();
				}

				String startText = "", startTextValue = "";
				if (arrTemp[orderTextInc].length() > 0) {
					startText = arrTemp[orderTextInc].substring(0, arrTemp[orderTextInc].indexOf(":")).trim();
					startTextValue = arrTemp[orderTextInc].substring(arrTemp[orderTextInc].indexOf(":") + 1).trim();
				}

				switch (startText) {
				case "Protein":
					dictOrderDetailPP.put("Protien", startTextValue);
					LOGGER.info("Protien " + startTextValue);
					break;

				case "Na+":
					dictOrderDetailPP.put("Sodium", startTextValue);
					LOGGER.info("Sodium " + startTextValue);
					break;

				case "K":
					dictOrderDetailPP.put("Potassium", startTextValue);
					LOGGER.info("Potassium " + startTextValue);
					break;

				case "P":
					dictOrderDetailPP.put("Phosphorus", startTextValue);
					LOGGER.info("Phosphorus " + startTextValue);
					break;

				case "Calories":
					dictOrderDetailPP.put("Calories", startTextValue);
					LOGGER.info("Calories " + startTextValue);
					break;

				case "Patient Diabetic Status":
					dictOrderDetailPP.put("PatientDiabeticStatus", startTextValue);
					LOGGER.info("PatientDiabeticStatus " + startTextValue);
					break;

				case "Fluid":
					dictOrderDetailPP.put("Fluid", startTextValue);
					LOGGER.info("Fluid " + startTextValue);
					break;

				case "Carbohydrate Controlled":
					if (startTextValue.equals("Yes"))
						startTextValue = "True";
					else
						startTextValue = "False";
					dictOrderDetailPP.put("CarbohydrateControlled", startTextValue);
					LOGGER.info("CarbohydrateControlled " + startTextValue);
					break;

				case "Additional":
					dictOrderDetailPP.put("Additional", startTextValue);
					LOGGER.info("Additional " + startTextValue);
					break;

				case "Provider":
					dictOrderDetailPP.put("Provider", startTextValue);
					LOGGER.info("Provider " + startTextValue);
					break;

				case "Collaborating Physician":
					dictOrderDetailPP.put("Collaborating_Physician", startTextValue);
					LOGGER.info("Collaborating_Physician " + startTextValue);
					break;

				case "Frequency":
					dictOrderDetailPP.put("Frequency", startTextValue);
					LOGGER.info("Frequency" + startTextValue);
					break;
				case "Treatment Time":
					dictOrderDetailPP.put("TreatmentTime", startTextValue);
					LOGGER.info("TreatmentTime" + startTextValue);
					break;
				case "Dialyzer":
					dictOrderDetailPP.put("Dialyzer", startTextValue);
					LOGGER.info("Dialyzer" + startTextValue);
					break;
				case "K+":
					dictOrderDetailPP.put("K+", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Ca++":
					dictOrderDetailPP.put("Ca++", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Bicarb":
					dictOrderDetailPP.put("Bicarb", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Na":
					dictOrderDetailPP.put("Na", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Temperature":
					dictOrderDetailPP.put("Temperature", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Heparin Hourly Dose":
					dictOrderDetailPP.put("HourlyDose", startTextValue);
					LOGGER.info(" HourlyDose" + startTextValue);
					break;
				case "Heparin Concentration":
					dictOrderDetailPP.put("HeparinConcentration", startTextValue);
					LOGGER.info("HeparinConcentration" + startTextValue);
					break;
				case "Total Heparin Units":
					dictOrderDetailPP.put("TotalHeparinUnits", startTextValue);
					LOGGER.info("TotalHeparinUnits" + startTextValue);
					break;
				case "Ultrafiltration":
					startTextValue = startTextValue.substring(startTextValue.indexOf(":") + 1).trim();
					dictOrderDetailPP.put("UFProfiling", startTextValue);
					LOGGER.info("UFProfiling " + startTextValue);
					break;
				case "Max UFR":
					dictOrderDetailPP.put("MaxUFRate", startTextValue);
					LOGGER.info("MaxUFRate" + startTextValue);
					break;
				case "Access":
					if (startTextValue.startsWith("AV Shunt Arm")) {
						startTextValue = startTextValue.replaceAll("AV Shunt Arm", "AV Shunt - Arm");
					}
					dictOrderDetailPP.put("Access", startTextValue);
					LOGGER.info("Access" + startTextValue);
					break;
				case "Concurrent":
					dictOrderDetailPP.put("Concurrent", startTextValue);
					LOGGER.info("Concurrent" + startTextValue);
					break;
				case "Needle Tip":
					dictOrderDetailPP.put("NeedleTip", startTextValue);
					LOGGER.info(" NeedleTip" + startTextValue);
					break;
				case "Order Source":
					dictOrderDetailPP.put("OrderSource", startTextValue);
					LOGGER.info("OrderSource" + startTextValue);
					break;
				case "Treatment Type":
					dictOrderDetailPP.put("TreatmentType", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Discontinued Date":
					startTextValue = GenericHelper.dateFormat(startTextValue, oc.dateFormatPattern());
					dictOrderDetailPP.put("DiscontinuedDate", startTextValue);
					LOGGER.info("DiscontinuedDate " + startTextValue);
					break;

				case "Schedule":
					dictOrderDetailPP.put("Schedule", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "TW":
					dictOrderDetailPP.put("TargetWeight", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Submodality":
					dictOrderDetailPP.put("Submodality", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Machine Type":
					dictOrderDetailPP.put("MachineType", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Auto Flow":
					if (startTextValue.contains(".0")) {
						startTextValue = startTextValue.replace(".0", "");
					}
					dictOrderDetailPP.put("AutoFlow", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "DFR":
					dictOrderDetailPP.put("DFR", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "BFR":
					dictOrderDetailPP.put("BFR", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "Target Weight":
					dictOrderDetailPP.put("TargetWeight", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;
				case "End Date":
					startTextValue = GenericHelper.dateFormat(startTextValue, oc.dateFormatPattern());
					dictOrderDetailPP.put("EndDate", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Discontinue Date":
					startTextValue = GenericHelper.dateFormat(startTextValue, oc.dateFormatPattern());
					dictOrderDetailPP.put("DiscontinuedDate", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Fills/Cycle":
					dictOrderDetailPP.put("Fills Per Cycle", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Dosing Instructions":
					dictOrderDetailPP.put("Instructions", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Protocol":
					dictOrderDetailPP.put("Protocol Name", startTextValue);
					LOGGER.info("Protocol Name" + startTextValue);
					break;

				case "Heparin Stop":
					dictOrderDetailPP.put("Stop", startTextValue);
					LOGGER.info("Protocol Name" + startTextValue);
					break;

				case "Heparin Bolus/Load":
					dictOrderDetailPP.put("Stop", startTextValue);
					LOGGER.info("Protocol Name" + startTextValue);
					break;

				case "Load/Hrly Dose Concen":
					dictOrderDetailPP.put("HeparinConcentration", startTextValue);
					LOGGER.info("Protocol Name" + startTextValue);
					break;

				case "Start Date":
					startTextValue = GenericHelper.dateFormat(startTextValue, oc.dateFormatPattern());
					dictOrderDetailPP.put("Start Date", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Written Date":
					startTextValue = GenericHelper.dateFormat(startTextValue, oc.dateFormatPattern());
					dictOrderDetailPP.put("Written Date", startTextValue);
					LOGGER.info(" " + startTextValue);
					break;

				case "Pharmacy Phone Number":
					dictOrderDetailPP.put("HeparinConcentration", startTextValue);
					LOGGER.info("Pharmacy Phone" + startTextValue);
					break;

				case "Pharmacy Fax Number":
					dictOrderDetailPP.put("HeparinConcentration", startTextValue);
					LOGGER.info("Pharmacy Fax" + startTextValue);
					break;

				case "Entered By":
					dictOrderDetailPP.put("EnteredBy", startTextValue);
					LOGGER.info("EnteredBy" + startTextValue);
					break;
				case "Dispense As Written":
					if (startTextValue.equalsIgnoreCase("No"))
						startTextValue = "false";
					else
						startTextValue = "true";
					dictOrderDetailPP.put("Dispense As Written", startTextValue);
					LOGGER.info("EnteredBy" + startTextValue);
					break;

				default:
					dictOrderDetailPP.put(startText, startTextValue);
					LOGGER.info("Add Code for : " + startText);
					break;
				}
			}
		}
		return dictOrderDetailPP;

	}

	/**
	 * Below function is to fetch Order detail for particular row Note : Page
	 * navigation should be implemented prior If particular column doesn't contain
	 * hover text then its orignal value is taken
	 */

	public Map fetchAllOrderDetail(int rowCounter) {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowCounter + ""))));
		By by = gwm.getBy("xpath", oc.orderIDDetailPage());
		gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());

		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.detailPageLoadingBar())),
				(int) ec.getPageWaitTimeout());
		WebElement objTemp;

		Map dictOrderDetailPP = new HashMap();

		// name
		objTemp = gwm.getWebElement(gwm.getBy("class", oc.patientNameClass()));
		dictOrderDetailPP.put("Name", objTemp.getText());
		LOGGER.info("Name " + objTemp.getText());

		// age
		objTemp = gwm.getWebElement(gwm.getBy("id", oc.patientAgeId()));
		dictOrderDetailPP.put("Age", objTemp.getText());
		LOGGER.info("Age " + objTemp.getText());

		// dob
		objTemp = gwm.getWebElement(gwm.getBy("id", oc.patientDOBId()));
		String temp1 = objTemp.getText();
		temp1 = GenericHelper.dateFormat(temp1, oc.dateFormatPattern());
		dictOrderDetailPP.put("DOB", temp1);
		LOGGER.info("DOB " + temp1);

		// gender
		objTemp = gwm.getWebElement(gwm.getBy("id", oc.patientGenderId()));
		dictOrderDetailPP.put("Gender", objTemp.getText());
		LOGGER.info("Gender " + objTemp.getText());

		// Facility
		objTemp = gwm.getWebElement(gwm.getBy("id", oc.patientFacilityId()));
		dictOrderDetailPP.put("FacilityCenter", "- " + objTemp.getText());
		LOGGER.info("FacilityCenter " + "- " + objTemp.getText());

		List<WebElement> list = gwm.getWebElements(gwm.getBy("class", oc.orderDetailPageAllFieldsClass()));
		List<WebElement> listLabel = gwm.getWebElements(gwm.getBy("class", oc.orderDetailPageAllFieldsLabelClass()));

		for (int listIterator = 0; listIterator < list.size(); listIterator++) {
			String temp = list.get(listIterator).getText();
			String tempLabel = listLabel.get(listIterator).getText();
			if (tempLabel.length() > 0) {
				if (tempLabel.charAt(0) == '(') {
					temp = temp + " " + tempLabel;
					tempLabel = "Justification";
				}
			}

			if (tempLabel.equalsIgnoreCase("")) {
				tempLabel = "Instructions";
			}
			boolean naFlag = false, ufFlag = false;
			if (temp.equals("End Na"))
				naFlag = true;

			if (temp.equals("UF Profiling"))
				ufFlag = true;
			switch (tempLabel) {
			case "Type":
				if (temp.equalsIgnoreCase("STEP") || temp.equalsIgnoreCase("LINEAR")
						|| temp.equalsIgnoreCase("EXPONENTIAL")) {
					dictOrderDetailPP.put("Type", temp);
					LOGGER.info(" " + temp);
				} else {
					if (temp.contains("PRN")) {
						temp = "PRN";
					}
					dictOrderDetailPP.put("OrderType", temp);
					LOGGER.info("OrderType " + temp);
				}
				break;

			case "ID":
				dictOrderDetailPP.put("OrderId", temp);
				LOGGER.info("OrderId " + temp);
				break;

			case "Start Date":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("OrderStartdate", temp);
				LOGGER.info("OrderStartdate " + temp);
				break;

			case "End Date":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("OrderEndDate", temp);
				LOGGER.info("OrderEndDate " + temp);
				break;

			case "Status":
				dictOrderDetailPP.put("OrderStatus", temp);
				LOGGER.info("OrderStatus " + temp);
				break;

			case "Discontinued Date":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("DiscontinuedDate", temp);
				LOGGER.info("DiscontinuedDate " + temp);
				break;

			case "Protein":
				dictOrderDetailPP.put("Protien", temp);
				LOGGER.info("Protien " + temp);
				break;

			case "Sodium":
				dictOrderDetailPP.put("Sodium", temp);
				LOGGER.info("Sodium " + temp);
				break;

			case "Potassium":
				dictOrderDetailPP.put("Potassium", temp);
				LOGGER.info("Potassium " + temp);
				break;

			case "Phosphorus":
				dictOrderDetailPP.put("Phosphorus", temp);
				LOGGER.info("Phosphorus " + temp);
				break;

			case "Calories":
				dictOrderDetailPP.put("Calories", temp);
				LOGGER.info("Calories " + temp);
				break;

			case "Fluid":
				dictOrderDetailPP.put("Fluid", temp);
				LOGGER.info("Fluid " + temp);
				break;

			case "Carbohydrate Controlled":
				dictOrderDetailPP.put("CarbohydrateControlled", temp);
				LOGGER.info("CarbohydrateControlled " + temp);
				break;

			case "Patient Diabetic Status":
				dictOrderDetailPP.put("PatientDiabeticStatus", temp);
				LOGGER.info("PatientDiabeticStatus " + temp);
				break;

			case "Additional":
				dictOrderDetailPP.put("Additional", temp);
				LOGGER.info("Additional " + temp);
				break;

			case "Provider":
				dictOrderDetailPP.put("Provider", temp);
				LOGGER.info("Provider " + temp);
				break;

			case "Collaborating Physician":
				dictOrderDetailPP.put("Collaborating_Physician", temp);
				LOGGER.info("Collaborating_Physician " + temp);
				break;

			case "Entered On":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("EnteredOn", temp);
				LOGGER.info("EnteredOn " + temp);
				break;

			case "Noted On":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("NotedOn", temp);
				LOGGER.info("NotedOn " + temp);
				break;

			case "Justification":
				temp = temp.replace("()", "");
				dictOrderDetailPP.put("Justification", temp);
				LOGGER.info(" " + temp);
				break;

			case "Treatment Type":
				dictOrderDetailPP.put("TreatmentType", temp);
				LOGGER.info(" " + temp);
				break;

			case "Frequency":
				dictOrderDetailPP.put("Frequency", temp);
				LOGGER.info(" " + temp);
				break;

			case "Schedule":
				dictOrderDetailPP.put("Schedule", temp);
				LOGGER.info(" " + temp);
				break;

			case "Treatment Time":
				dictOrderDetailPP.put("TreatmentTime", temp);
				LOGGER.info(" " + temp);
				break;

			case "Dialyzer":
				dictOrderDetailPP.put("Dialyzer", temp);
				LOGGER.info(" " + temp);
				break;

			case "K+":
				dictOrderDetailPP.put("K+", temp);
				LOGGER.info(" " + temp);
				break;

			case "Ca++":
				dictOrderDetailPP.put("Ca++", temp);
				LOGGER.info(" " + temp);
				break;

			case "Bicarb":
				dictOrderDetailPP.put("Bicarb", temp);
				LOGGER.info(" " + temp);
				break;

			case "Na":
				dictOrderDetailPP.put("Na", temp);
				LOGGER.info(" " + temp);
				break;

			case "Start Na":
				dictOrderDetailPP.put("StartNa", temp);
				LOGGER.info(" " + temp);
				break;

			case "End Na":
				dictOrderDetailPP.put("EndNa", temp);
				LOGGER.info(" " + temp);
				break;

			case "Temperature":
				dictOrderDetailPP.put("Temperature", temp);
				LOGGER.info(" " + temp);
				break;

			case "Auto Flow":
				dictOrderDetailPP.put("AutoFlow", temp);
				LOGGER.info(" " + temp);
				break;

			case "DFR":
				dictOrderDetailPP.put("DFR", temp);
				LOGGER.info(" " + temp);
				break;

			case "BFR":
				dictOrderDetailPP.put("BFR", temp);
				LOGGER.info(" " + temp);
				break;

			case "UF Profiling":
				dictOrderDetailPP.put("UFProfiling", temp);
				LOGGER.info(" " + temp);
				break;

			case "Max UF Rate":
				dictOrderDetailPP.put("MaxUFRate", temp);
				LOGGER.info(" " + temp);
				break;
			case "Instructions for Use":
				if (naFlag) {
					dictOrderDetailPP.put("InstructionsForUseNaModelling", temp);
					LOGGER.info(" " + temp);
				}
				if (ufFlag) {
					dictOrderDetailPP.put("InstructionsForUseUltaFiltration", temp);
					LOGGER.info(" " + temp);
				}
				break;

			case "Bolus/Load":
				dictOrderDetailPP.put("BolusLoad", temp);
				LOGGER.info(" " + temp);
				break;

			case "Hourly Dose":
				dictOrderDetailPP.put("HourlyDose", temp);
				LOGGER.info(" " + temp);
				break;

			case "Stop":
				dictOrderDetailPP.put("Stop", temp);
				LOGGER.info(" " + temp);
				break;

			case "Total Heparin Units":
				dictOrderDetailPP.put("TotalHeparinUnits", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial":
				dictOrderDetailPP.put("Arterial", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous":
				dictOrderDetailPP.put("Venous", temp);
				LOGGER.info(" " + temp);
				break;

			case "Primary Access":
				temp = temp.replaceAll("- ", "");
				dictOrderDetailPP.put("Access", temp);
				LOGGER.info(" " + temp);
				break;

			case "Concurrent":
				if (temp.trim().equals("False"))
					temp = "No";
				else
					temp = "Yes";
				dictOrderDetailPP.put("Concurrent", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial Length":
				dictOrderDetailPP.put("ArterialLength", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial Gauge":
				dictOrderDetailPP.put("ArterialGauge", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous Length":
				dictOrderDetailPP.put("VenousLength", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous Gauge":
				dictOrderDetailPP.put("VenousGauge", temp);
				LOGGER.info(" " + temp);
				break;

			case "Needle Tip":
				dictOrderDetailPP.put("NeedleTip", temp);
				LOGGER.info(" " + temp);
				break;

			case "Notes":
				dictOrderDetailPP.put("Notes", temp);
				LOGGER.info(" " + temp);
				break;

			case "Source":
				dictOrderDetailPP.put("Source", temp);
				LOGGER.info(" " + temp);
				break;

			case "Coded By":
				dictOrderDetailPP.put("CodedBy", temp);
				LOGGER.info(" " + temp);
				break;

			case "Coded On":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("CodedOn", temp);
				LOGGER.info(" " + temp);
				break;

			case "Target Weight":
				dictOrderDetailPP.put("TargetWeight", temp);
				LOGGER.info(" " + temp);
				break;

			case "Entered By":
				dictOrderDetailPP.put("EnteredBy", temp);
				LOGGER.info(" " + temp);
				break;

			case "Noted By":
				dictOrderDetailPP.put("NotedBy", temp);
				LOGGER.info(" " + temp);
				break;

			case "Total Fill in 24 hours":
				dictOrderDetailPP.put("Total Fill in 24 hrs", temp);
				LOGGER.info(" " + temp);
				break;

			case "Prescriber E-Signed On":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("Prescriber E-Signed On", temp);
				LOGGER.info(" " + temp);
				break;

			case "Order Source":
				dictOrderDetailPP.put("OrderSource", temp);
				LOGGER.info(" " + temp);
				break;

			case "Dosing Instructions":
				dictOrderDetailPP.put("Instructions", temp);
				LOGGER.info(" " + temp);
				break;

			case "Load/Hourly Dose Concentration":
				dictOrderDetailPP.put("HeparinConcentration", temp);
				LOGGER.info(" " + temp);
				break;

			case "Heparin Concentration":
				dictOrderDetailPP.put("HeparinConcentration", temp);
				LOGGER.info(" " + temp);
				break;

			case "Written Date":
				temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
				dictOrderDetailPP.put("Written Date", temp);
				LOGGER.info("OrderEndDate " + temp);
				break;

			default:
				dictOrderDetailPP.put(tempLabel, temp);
				LOGGER.info("Add case for :" + tempLabel);
				break;
			}
			LOGGER.info(tempLabel + ":" + temp);
		}
		return dictOrderDetailPP;
	}

	/**
	 * Below function is to compare order details between PP and DPs
	 * 
	 * @param srcList  DPs order list
	 * @param destList PP order list
	 */
	public void compareLists(Map srcList, Map destList) {

		if (srcList.isEmpty() && destList.isEmpty()) {
			Assert.assertEquals(false, true, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			String status = "";
			Set<Map.Entry> st = srcList.entrySet();
			for (Map.Entry iteartor : st) {
				Object srcKey = iteartor.getKey();
				String srcValue = srcList.get(srcKey) + "";
				if (srcValue.contains("None")) {
					srcValue = srcValue.replace("None", "");
					srcValue = srcValue.trim();
				}

				String destValue = destList.get(srcKey) + "";
				if (destValue.contains("None")) {
					destValue = destValue.replace("None", "");
					destValue = destValue.trim();
				}
				if (destValue.isEmpty()) {
					destValue = "";
				}
				if (srcKey.equals("MachineType")) {
					if ((destList.get("Dialyzer") + "").contains(srcValue)) {
						destValue = srcValue = "";
					} else {
						destValue = destList.get("Dialyzer") + "";
					}

				}

				if (srcKey.equals("Schedule")) {
					destValue = "";
					srcValue = "";
				}
				if (srcKey.equals("Therapy Volume")) {
					destValue = destValue.replaceAll(" ", "");
					srcValue = srcValue.replaceAll(" ", "");
				}
				if (srcKey.equals("TotalHeparinUnits")) {
					destValue = "";
					srcValue = "";
				}
				if (srcKey.equals("Justification") || srcKey.equals("EnteredBy") || srcKey.equals("Prescriber")) {
					destValue = destValue.replace(" ", "");
					destValue = destValue.replace("null", "");
					destValue = destValue.replace("E87.7", "E87.70");
					srcValue = srcValue.replace(" ", "");
				}
				if (srcKey.equals("HourlyDose")) {
					destValue = destValue.replace(" ", "");
					srcValue = srcValue.replace(" ", "");
				}

				if (srcKey.equals("Dialyzer") || srcKey.equals("Pharmacy Name") || srcKey.equals("Quantity")) {
					destValue = destValue.replace(" ", "");
					srcValue = srcValue.replace(" ", "");
					if (destValue.equals("NxStage170-C(1174)NxStage170-C")) {
						destValue = "NxStageCAR170-C(1174)";
					}
					if (destValue.equals("BAXTER170(911)")) {
						destValue = "BAXTERCAHP170(911)";
					}
					if (destValue.contains(srcValue)) {
						destValue = "";
						srcValue = "";
					}
				}
				if (srcKey.equals("TargetWeight")) {
					if (srcValue.indexOf(" ") > 0) {
						srcValue = srcValue.split(" ")[0];
					}
					if (destValue.indexOf(" ") > 0) {
						destValue = destValue.split(" ")[0];
					}
					if (srcValue.indexOf(".") > 0) {
						srcValue = srcValue.substring(0, srcValue.indexOf("."));
					}
					if (destValue.indexOf(".") > 0) {
						destValue = destValue.substring(0, destValue.indexOf("."));
					}
				}
				if (srcKey.equals("Machine Type") || srcKey.equals("Cartridge Type")) {
					if (destValue.equals("null")) {
						String strTemp = srcList.get("Dialyzer") + "";
						strTemp = strTemp.replaceAll(" ", "");
						srcValue = srcValue.replaceAll(" ", "");
						if (strTemp.contains(srcValue)) {
							srcValue = "N/A";
							destValue = "N/A";
						}
					}
				}
				if (destValue.contains(".00")) {
					destValue = destValue.replace(".00", "");
				}
				if (destValue.contains(".0")) {
					destValue = destValue.replace(".0", "");
					srcValue = srcValue.replace(".0", "");
				}
				if (destValue.contains(".10") || destValue.contains(".20") || destValue.contains(".30")
						|| destValue.contains(".40") || destValue.contains(".50") || destValue.contains(".60")
						|| destValue.contains(".70") || destValue.contains(".80") || destValue.contains(".90")) {
					destValue = destValue.replace(".10", ".1");
					destValue = destValue.replace(".20", ".2");
					destValue = destValue.replace(".30", ".3");
					destValue = destValue.replace(".40", ".4");
					destValue = destValue.replace(".50", ".5");
					destValue = destValue.replace(".60", ".6");
					destValue = destValue.replace(".70", ".7");
					destValue = destValue.replace(".80", ".8");
					destValue = destValue.replace(".90", ".9");
				}
				if (srcValue.equals("N/A") && destValue.equals("null")) {
					srcValue = "N/A";
					destValue = "N/A";
				}
				if (srcValue.equals("N/A") && destValue.equals("")) {
					srcValue = "N/A";
					destValue = "N/A";
				}
				if (srcValue.equals("No") && destValue.equals("null")) {
					srcValue = "N/A";
					destValue = "N/A";
				}
				if (srcValue.contains("mins")) {
					srcValue = srcValue.replace("mins", "min");
					destValue = destValue.replace("mins", "min");
				}
				if (srcValue.contains("Mins")) {
					srcValue = srcValue.replace("Mins", "min");
					destValue = destValue.replace("Mins", "min");
				}
				if (destValue.contains("minutes")) {
					srcValue = srcValue.replace("minutes", "min");
					destValue = destValue.replace("minutes", "min");
				}
				if (destValue.contains("hrs")) {
					destValue = destValue.replace("hrs", "hr");
					srcValue = srcValue.replace("hrs", "hr");
				}
				if (srcValue.equals("") || srcValue.equals("undefined")) {
					srcValue = "";
					destValue = "";
				}
				if (destValue.equals("GAMBRO17R(839)")) {
					srcValue = "GAMBROPOLYFLUX17R(839)";
					destValue = "GAMBROPOLYFLUX17R(839)";
				}
				if (destValue.equals("NxStage170(140)")) {
					srcValue = "NxStageCAR170(140)";
					destValue = "NxStageCAR170(140)";
				}
				if (srcKey.equals("Administrations") || srcKey.equals("HourlyDose") || srcKey.equals("Venous")
						|| srcKey.equals("Arterial") || srcKey.equals("NeedleTip")) {
					destValue = "";
					srcValue = "";
				}
				if (srcKey.equals("Weeks")) {
					destValue = destValue.replace(",", "");
					srcValue = srcValue.replace(",", "");
				}
				if (srcValue.equals("502 KT/V by UKM Panel")) {
					srcValue = "0" + srcValue;
				}
				if (srcValue.equals("Test Application User, Rody")) {
					srcValue = "MD Test Application User Rody";
				}
				if (srcValue.contains("before end of dialysis")) {
					srcValue = srcValue.replace("before end of dialysis", "before the end of dialysis");
				}

				if (srcKey.equals("OrderStatus")) {
					destValue = destValue.replaceAll("DC", "D/C");
					srcValue = srcValue.replaceAll("DC", "D/C");
				}

				if (srcKey.equals("Pharmacy Name")) {
					destValue = destValue.replaceAll("\n", "");
					srcValue = srcValue.replaceAll("\n", "");
				}
				if (srcKey.equals("Dispense As Written")) {
					destValue = destValue.toLowerCase();
					srcValue = srcValue.toLowerCase();
				}

				if (srcKey.equals("CodedBy") || srcKey.equals("NotedBy") || srcKey.equals("EnteredBy")
						|| srcKey.equals("Prescriber E-Signed By")) {
					boolean matchFlag = true;
					String[] ppName = destValue.split(" ");
					for (int ppNameIterator = 0; ppNameIterator < ppName.length; ppNameIterator++) {
						if (!srcValue.contains(ppName[ppNameIterator])) {
							matchFlag = false;
						}
					}

					if (matchFlag) {
						srcValue = destValue;
					}
				}
				LOGGER.info(srcKey + "---" + srcValue + "---" + destValue);
				if (!srcKey.equals("Application")) {
					if (!srcValue.trim().equals(destValue.trim())) {
						status = status + "Value Mismatch for : " + srcKey + " " + destList.get("Application") + "("
								+ destValue + ") " + srcList.get("Application") + " (" + srcValue + ")" + "\n";
					}
				}
			}
			Assert.assertEquals(status, "", status);
		}
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will dispute particular order from summary page
	 * @param rowNo
	 * @param orderType
	 */
	public void disputeOrderOnSummaryPage(String rowNo, String orderType) {
		if (rowNo.equals("-1")) {
			Assert.assertEquals(true, false, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt(rowNo));
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickSignOrDisputeModal(rowNo)),
					(int) ec.getWaitTimeout());
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickSignOrDisputeModal(rowNo))));
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnDisputeOption(rowNo)), (int) ec.getWaitTimeout());

			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.disputeButtonSummaryPage())));
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.selectDisputeReasonDropDownButton())));

			// waitTillElementAppear(getBy("xpath",
			// oc.select_reason_from_dispute_dropdown()+ "[text()='" +
			// GenericVariable.OrderDisputeReason[5] + "']"), 30);

			// verifying whether values are correct
			String strEquals = "";
			String objTemp = null;
			List<WebElement> list = gwm.getWebElements(gwm.getBy("xpath", oc.fetchDisputeReason()));
			for (int listIterator = 0; listIterator < 6; listIterator++) {
				objTemp = list.get(listIterator).getText().toUpperCase();
				boolean valueExists = GenericHelper.CheckInArray(GenericVariable.OrderDisputeReason, objTemp);
				if (!valueExists) {
					strEquals = strEquals + "\n" + objTemp + " is not present in the screen";
				}
			}
			Assert.assertEquals(strEquals, "", strEquals);

			gwm.waitForElementToAppear(gwm.getBy("xpath",
					oc.selectReasonFromDisputeDropDown() + "[text()='" + GenericVariable.DisputeOtherReason + "']"),
					30);
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.selectReasonFromDisputeDropDown()
					+ "[text()='" + GenericVariable.DisputeOtherReason + "']")));

			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.enterReasonForDispute()), (int) ec.getWaitTimeout());

			gwm.enterText(gwm.getWebElement(gwm.getBy("xpath", oc.enterReasonForDispute())),
					RandomStringUtils.random(6, "A-Z"), true);

			// fetching patient name and order id to check whether patient is removed or not
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnDisputeButton()), (int) ec.getWaitTimeout());

			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnDisputeButton())));// Click on dispute
																										// button
			gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
					(int) ec.getWaitTimeout());
			// check if disputed order is disappear or not
			int rowNum = selectOrderUsingOrderIDandPatientName(myList.get("OrderID") + "", myList.get("Name") + "");

			Assert.assertEquals(rowNum, -1, "Disputed order is not present on screen");
		}
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will fetch dispute reason and verify
	 * @param rowNo
	 */
	public void FetchDisputeReasonAndVerifyOnSummaryPage(String rowNo) {

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnDisputeOption(rowNo))));
		gwm.waitForElementToAppear(gwm.getBy("xpath",
				oc.selectReasonFromDisputeDropDown() + "[text()='" + GenericVariable.OrderDisputeReason[5] + "']"),
				30);

		// verifying whether values are correct
		String strEquals = "";
		String objTemp = null;
		List<WebElement> list = gwm.getWebElements(gwm.getBy("xpath", oc.fetchDisputeReason()));
		for (int listIterator = 0; listIterator < 6; listIterator++) {
			objTemp = list.get(listIterator).getText().toUpperCase();
			boolean valueExists = GenericHelper.CheckInArray(GenericVariable.OrderDisputeReason, objTemp);
			if (!valueExists) {
				strEquals = strEquals + "\n" + objTemp + " is not present in the screen";
			}
		}
		Assert.assertEquals(strEquals, "", strEquals);
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will dispute particular order from detail page
	 * @param rowNo
	 * @param orderType
	 */
	public void disputeOrderOnDetailPage(String rowNo, String orderType) {
		if (rowNo.equals("-1")) {
			Assert.assertEquals(true, false, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			// fetching patient name and order id to check whether patient is removed or not
			Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt(rowNo));
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowNo + ""))));
			By by = gwm.getBy("xpath", oc.orderIDDetailPage());
			gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.disputeBtnOnDetailPage())));
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.selectDisputeReasonDropDownButton())));
			// waitTillElementAppear(getBy("xpath",
			// oc.select_reason_from_dispute_dropdown()+ "[text()='" +
			// GenericVariable.OrderDisputeReason[5] + "']"), 30);

			// verifying dispute reasons
			String strEquals = "";
			String objTemp = null;
			List<WebElement> list = gwm.getWebElements(gwm.getBy("xpath", oc.fetchDisputeReason()));
			for (int listIterator = 0; listIterator < 6; listIterator++) {
				objTemp = list.get(listIterator).getText().toUpperCase();
				boolean valueExists = GenericHelper.CheckInArray(GenericVariable.OrderDisputeReason, objTemp);
				if (!valueExists) {
					strEquals = strEquals + "\n" + objTemp + " is not present in the screen";
				}
			}
			Assert.assertEquals(strEquals, "", strEquals);

			gwm.waitForElementToAppear(gwm.getBy("xpath",
					oc.selectReasonFromDisputeDropDown() + "[text()='" + GenericVariable.DisputeOtherReason + "']"),
					(int) ec.getWaitTimeout());
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.selectReasonFromDisputeDropDown()
					+ "[text()='" + GenericVariable.DisputeOtherReason + "']")));

			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.enterReasonForDispute()), (int) ec.getWaitTimeout());

			gwm.enterText(gwm.getWebElement(gwm.getBy("xpath", oc.enterReasonForDispute())),
					RandomStringUtils.random(6, "A-Z"), true);

			// fetching patient name and order id to check whether patient is removed or not
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnDisputeButton()), (int) ec.getWaitTimeout());

			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnDisputeButton())));// Click on dispute
																										// button
			gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
					(int) ec.getWaitTimeout());
			// check if disputed order is disappear or not
			int rowNum = selectOrderUsingOrderIDandPatientName(myList.get("OrderID") + "", myList.get("Name") + "");
			Assert.assertEquals(rowNum, -1, "Disputed order is not present on screen");
		}

	}

	/**
	 * @author Rakesh Gupta
	 * @description This will fetch dispute reason and verify on detail page
	 * @param rowNo
	 */
	public void FetchDisputeReasonAndVerifyOnDetailPage(String rowNo) {
		String strEquals = "";
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowNo + ""))));
		By by = gwm.getBy("xpath", oc.orderIDDetailPage());
		gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.disputeBtnOnDetailPage())));

		String objTemp = null;
		List<WebElement> list = gwm.getWebElements(gwm.getBy("class", oc.fetchDetailPageDisputeOptions()));
		for (int listIterator = 0; listIterator < 6; listIterator++) {
			objTemp = list.get(listIterator).getText().toUpperCase();
			boolean valueExists = GenericHelper.CheckInArray(GenericVariable.OrderDisputeReason, objTemp);
			if (!valueExists) {
				strEquals = strEquals + "\n" + objTemp + " is not present in the screen";
			}
		}
		Assert.assertEquals(strEquals, "", strEquals);
	}

	/**
	 * @author Rakesh Gupta
	 * @description return orderId and Patient name from order details page
	 * @return a list which contains orderId and Patient name
	 */
	public Dictionary FetchOrderIdAndPatientName(int rowNumber) {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowNumber + ""))));
		By by = gwm.getBy("xpath", oc.orderIDDetailPage());
		gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
		WebElement objTemp;
		Dictionary dictOrderDetailPP = new Hashtable();
		// name
		objTemp = gwm.getWebElement(gwm.getBy("class", oc.patientNameClass()));
		dictOrderDetailPP.put("Name", objTemp.getText());

		// ID
		objTemp = gwm.getWebElement(gwm.getBy("xpath", oc.orderIDDetailPage()));
		dictOrderDetailPP.put("OrderID", objTemp.getText());
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.orderDetailCloseButton()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())),
				(int) ec.getWaitTimeout());
		return dictOrderDetailPP;

	}

	/**
	 * @author Rakesh Gupta
	 * @description This will verify whether date are sorted in DPS
	 */
	public void VerifyDateAreSortedinDPS() {
		int rowCounter = 0;
		int totalCount = readTotalCount();
		int arrCounter = 0;
		String arrDate[] = new String[totalCount];
		WebElement rightArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.rightArrowPagination()));
		for (int pageCounter = 0; pageCounter < totalCount; pageCounter++) {
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			for (rowCounter = 0; rowCounter < allRows.size(); rowCounter++) {
				// StartDate
				String startDate = gwm.readWebElementText(
						gwm.getWebElement(gwm.getBy("xpath", oc.summaryColText(rowCounter + "", "6"))));
				arrDate[arrCounter] = startDate;
				arrCounter++;
			}
			pageCounter = pageCounter + allRows.size();
			// click on next page
			if (!rightArrow.getAttribute("class").contains("disabled")) {
				rightArrow.click();
				gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
						(int) ec.getWaitTimeout());
			}
		}

		boolean ascFlag = true;
		for (int iterator = 0; iterator < GenericHelper.arr.length - 1; iterator++) {
			Date d1 = new Date(GenericHelper.arr[iterator]);
			Date d2 = new Date(GenericHelper.arr[iterator + 1]);
			if (d1.compareTo(d2) >= 1) {
				ascFlag = false;
				break;
			}
		}
		Assert.assertEquals(ascFlag, true, "Date should be sorted by ascending order");
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign particular order from summary page
	 * @param rowNo
	 * @param orderType
	 */
	public void signSingleOrderOnSummaryPage(String rowNo, String orderType) {
		if (rowNo.equals("-1")) {
			Assert.assertEquals(true, false, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt(rowNo));
			GenericHelper.sleepSeconds(3);
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickSignOrDisputeModal(rowNo)),
					(int) ec.getWaitTimeout());
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickSignOrDisputeModal(rowNo))));
			gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnSignInOption(rowNo)), (int) ec.getWaitTimeout());

			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSignInOption(rowNo))));
			gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
					(int) ec.getWaitTimeout());
			// check if disputed order is disappear or not
			int rowNum = selectOrderUsingOrderIDandPatientName(myList.get("OrderID") + "", myList.get("Name") + "");

			Assert.assertEquals(rowNum, -1, "Signed order is not present on screen");
		}
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign first order from summary page
	 */
	public void signFirstOrderSummaryPage() {
		Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt("0"));
		int totalCountPre = readTotalCount();
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickSignOrDisputeModal("0")), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickSignOrDisputeModal("0"))));
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnSignInOption("0")), (int) ec.getWaitTimeout());

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSignInOption("0"))));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.pageLoader())),
				(int) ec.getWaitTimeout());
		int totalCountPost = readTotalCount();
		Assert.assertEquals(totalCountPre, totalCountPost + 1, "Signed order is not present on screen");
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign first order from detail page
	 */
	public void signFirstOrderOnDetailPage() {
		Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt("0"));
		int totalCountPre = readTotalCount();
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow("0" + ""))));
		By by = gwm.getBy("xpath", oc.orderIDDetailPage());
		gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSignDetailPage())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.pageLoader())),
				(int) ec.getWaitTimeout());
		int totalCountPost = readTotalCount();
		Assert.assertEquals(totalCountPre, totalCountPost + 1, "Signed order is not present on screen");
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign multiple order on summary page
	 */
	public void signMultipleOrderOnSummaryPage() {
		int totalCountPre = readTotalCount();
		// by default we are selecting 3 row , but if count is less than three then will
		// select -1 count

		int countSelected;
		if (totalCountPre > 3)
			countSelected = 3;
		else
			countSelected = totalCountPre - 1;

		for (int iterator = 0; iterator < countSelected; iterator++) {
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickCheckboxOnSnappyPage(iterator + ""))));
		}

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.signButtonFooter())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
				(int) ec.getWaitTimeout());
		int totalCountPost = readTotalCount();
		Assert.assertEquals(totalCountPre, totalCountPost + countSelected, "Signed order is not present on screen");
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign all order from summary page
	 */
	public void signAllOrderOnSummaryPage() {
		int totalCountPre = readTotalCount();
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.signButtonFooter())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
				(int) ec.getWaitTimeout());
		orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
		allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
		int totalCountPost = readTotalCount();
		Assert.assertEquals(totalCountPre, totalCountPost + allRows.size(), "Signed order is not present on screen");
	}

	/**
	 * @author Rakesh Gupta
	 * @description This will sign particular order from detail page
	 * @param rowNo
	 * @param orderType
	 */
	public void signSingleOrderOnDetailPage(String rowNo, String orderType) {
		if (rowNo.equals("-1")) {
			Assert.assertEquals(true, false, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			// fetching patient name and order id to check whether patient is removed or not
			Dictionary myList = FetchOrderIdAndPatientName(Integer.parseInt(rowNo));
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowNo + ""))));
			By by = gwm.getBy("xpath", oc.orderIDDetailPage());
			gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSignDetailPage())));
			gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("className", oc.pageLoader())),
					(int) ec.getWaitTimeout());

			// check if disputed order is disappear or not
			int rowNum = selectOrderUsingOrderIDandPatientName(myList.get("OrderID") + "", myList.get("Name") + "");
			Assert.assertEquals(rowNum, -1, "Signed order is not present on screen");
		}
	}

	/**
	 * Below function is to compare order details between PP and DPs
	 * 
	 * @param srcList  DPs order list
	 * @param destList PP order list
	 */
	public void compareListsCHG(Map srcList, String destList) {
		if (srcList.isEmpty()) {
			Assert.assertEquals(false, true, "Order Not Present Please Add Order and Execute Again!!!");
		} else {
			String status = "";
			Set<Map.Entry> st = srcList.entrySet();
			for (Map.Entry iteartor : st) {
				Object srcKey = iteartor.getKey();
				String srcValue = srcList.get(srcKey) + "";

				// below changes are done because data is not present in PP
				if (srcKey.equals("Justification") || srcKey.equals("Treatment") || srcKey.equals("Frequency")
						|| srcKey.equals("TreatmentType") || srcKey.equals("Lab Test")
						|| srcKey.equals("Medication/Ancillary") || srcKey.equals("Ancillary Service")
						|| srcKey.equals("Weeks") || srcKey.equals("Medication")) {
					srcValue = "";
				}
				if (srcKey.equals("TargetWeight") || srcKey.equals("Target Weight")) {
					if (srcValue.indexOf(" ") > 0) {
						srcValue = srcValue.split(" ")[0];
					}
					if (srcValue.indexOf(".") > 0) {
						srcValue = srcValue.substring(0, srcValue.indexOf("."));
					}
				}
				if (destList.contains(".00")) {
					destList = destList.replace(".00", "");
				}
				if (srcKey.equals("Hourly Dose")) {
					srcValue = srcValue.substring(0, srcValue.indexOf("(")).trim();
				}
				if (srcKey.equals("HourlyDose")) {
					srcValue = srcValue.replaceAll("hour", "hr");
				}
				if (!destList.contains(srcValue)) {
					status = status + "Value Mismatch for : " + srcKey + " " + "DPs " + "(" + srcValue + ")";
				}
			}
			Assert.assertEquals(status, "", status);
		}
	}

	/**
	 * Below Function fetch only the changed order property from detail page
	 * 
	 * @param rowCounter
	 * @return dictOrderDetailPP
	 */
	public Map fetchChgOrderDetail(int rowCounter) {

		Map dictOrderDetailPP = new HashMap();
		if (rowCounter > 0) {
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowCounter + ""))));
			By by = gwm.getBy("xpath", oc.orderIDDetailPage());
			gwm.waitForElementToAppear(by, (int) ec.getWaitTimeout());
			WebElement objTemp;
			List<WebElement> objTemp1 = gwm.getWebElements(
					gwm.getBy("xpath", "//div[@class='details-component__section' and @id='order-sections']"));
			int i = 0;
			String newOrderText;
			String arrNewOrder[] = null;
			for (i = 0; i < objTemp1.size(); i++) {
				newOrderText = objTemp1.get(i).getText();
				if (newOrderText.contains("New Order")) {
					arrNewOrder = newOrderText.split("\n");
					break;
				}
			}
			for (i = 1; i < arrNewOrder.length; i += 2) {
				if (arrNewOrder[i].equals("Order Start Date") || arrNewOrder[i].equals("Discontinued Date")
						|| arrNewOrder[i].equals("Start Date")) {
					String temp = arrNewOrder[i + 1];
					temp = GenericHelper.dateFormat(temp, oc.dateFormatPattern());
					arrNewOrder[i + 1] = temp;
				}
				dictOrderDetailPP.put(arrNewOrder[i], arrNewOrder[i + 1]);
			}
		}
		return dictOrderDetailPP;
	}

	/**
	 * Below function is to fetch row number from DPS for particular OrderId
	 * 
	 * @param OrderDetailPP
	 * @return
	 */
	public int getRowNumberChangedOrder(String OrderDetailPP) {
		int rowNumber = -1;
		if (OrderDetailPP.length() > 0) {
			String patName = OrderDetailPP.substring(OrderDetailPP.indexOf("NameStart") + 9,
					OrderDetailPP.indexOf("NameEnd"));
			String OrderId = OrderDetailPP.substring(OrderDetailPP.indexOf("orderIdStart") + 12,
					OrderDetailPP.indexOf("orderIdEnd"));
			String orderStatus = OrderDetailPP.substring(OrderDetailPP.indexOf("OrderStatusStart") + 16,
					OrderDetailPP.indexOf("OrderStatusEnd"));
			;
			String orderType = OrderDetailPP.substring(OrderDetailPP.indexOf("OrderTypeStart") + 14,
					OrderDetailPP.indexOf("OrderTypeEnd"));
			;
			if (orderStatus.equals("CHANGED")) {
				orderStatus = "CHG";
			}
			rowNumber = selectOrderUsingOrderID_Type_PatientName(OrderId, patName, orderType, orderStatus);
		}

		return rowNumber;
	}

	/**
	 * Below Function is to search particular id and fetch its summary data
	 * 
	 * @param orderDetailPP
	 * @return
	 */
	public Map SearchandgetToolTipTextAllColumn(Map orderDetailPP) {

		Map hoverTextDictDPs = new HashMap();
		if (!orderDetailPP.isEmpty()) {
			int rowNumber = selectOrderUsingOrderID_Type_PatientName(orderDetailPP.get("OrderId") + "",
					orderDetailPP.get("Name") + "", orderDetailPP.get("OrderType") + "",
					orderDetailPP.get("OrderStatus") + "");
			hoverTextDictDPs = getToolTipTextAllColumn(rowNumber);
			hoverTextDictDPs.put("Application", "DPs");
		}
		return hoverTextDictDPs;
	}

	/**
	 * Below Function is to search particular id and fetch its detail data
	 * 
	 * @param orderDetailPP
	 * @return
	 */
	public Map SearchAndfetchAllOrderDetail(Map orderDetailPP) {

		Map OrderDetailDictDPs = new HashMap();
		if (!orderDetailPP.isEmpty()) {
			int rowNumber = selectOrderUsingOrderID_Type_PatientName(orderDetailPP.get("OrderId") + "",
					orderDetailPP.get("Name") + "", orderDetailPP.get("OrderType") + "",
					orderDetailPP.get("OrderStatus") + "");
			OrderDetailDictDPs = fetchAllOrderDetail(rowNumber);
			OrderDetailDictDPs.put("Application", "DPs");
		}
		return OrderDetailDictDPs;
	}

	/**
	 * Below function is to Select right order by passing order Id , Patient Name
	 * and Order Type
	 */
	public int selectOrderUsingOrderID_Type_PatientName(String orderID, String strPname, String orderType,
			String orderStatus) {
		int rowCounter = -1;
		int totalCount = readTotalCount();
		boolean boolFound = false;
		if (orderType.equalsIgnoreCase("Laboratory")) {
			orderType = "Lab";
		}

		if (orderStatus.equals("D/C")) {
			orderStatus = "DC";
		}
		if (orderStatus.equals("CHANGED")) {
			orderStatus = "CHG";
		}
		WebElement rightArrow = gwm.getWebElement(gwm.getBy("cssSelector", oc.rightArrowPagination()));
		for (int pageCounter = 0; pageCounter < totalCount; pageCounter++) {
			GenericHelper.sleepSeconds(1);
			orderTable = gwm.getWebElement(gwm.getBy("cssSelector", oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			for (rowCounter = 0; rowCounter < allRows.size(); rowCounter++) {
				String StrPatName = gwm.readWebElementText(gwm.getWebElement(
						gwm.getBy("xpath", String.format(oc.orderNavigation(), String.valueOf(rowCounter), "1"))));
				String strOrderType = gwm.readWebElementText(gwm.getWebElement(
						gwm.getBy("xpath", String.format(oc.orderNavigation(), String.valueOf(rowCounter), "6"))));

				String strOrderStatus = gwm.readWebElementText(gwm.getWebElement(
						gwm.getBy("xpath", String.format(oc.orderNavigation(), String.valueOf(rowCounter), "4"))));

				if (StrPatName.contains(strPname)) {
					if (strOrderType.toLowerCase().startsWith(orderType.toLowerCase())) {
						if (strOrderStatus.equals(orderStatus)) {
							gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderRow(rowCounter + ""))));
							gwm.waitForElementToAppear(gwm.getBy("xpath", oc.orderIDDetailPage()),
									(int) ec.getWaitTimeout());
							String screenOrderId = gwm
									.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", oc.orderIDDetailPage())));
							gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())));
							gwm.waitForElementToDisappear(
									gwm.getWebElement(gwm.getBy("xpath", oc.orderDetailCloseButton())),
									(int) ec.getWaitTimeout());
							if (screenOrderId.equals(orderID)) {
								boolFound = true;
								break;
							}
						}
					}
				}
			}
			if (boolFound) {
				break;
			} else {
				rowCounter = -1;
			}
			pageCounter = pageCounter + allRows.size();
			// click on next page
			if (!rightArrow.getAttribute("class").contains("disabled")) {
				rightArrow.click();
				gwm.waitForElementToAppear(gwm.getBy("xpath", oc.spinnerInsideOrder()), (int) ec.getPageWaitTimeout());
			}
		}
		return rowCounter;

	}

	/***
	 * 
	 * @param snappyuser
	 * @param snappypassword
	 * @param keycloakid     Below function fetch License type and Clinical System
	 *                       from keycloak and verify same in dps order tab.
	 * @return
	 */
	public boolean fetchClinicalSystemandVerify(String clinicalSystem, String licenseType) {
		String keyCloakStatus = "";
		boolean screenStatus = false;

		// Assigning value to keyCloak status as per vale fetch from KeyCloak Attributes

		if (licenseType.equals("NP")) {
			keyCloakStatus = "CWOW";
		} else {
			if (clinicalSystem.equals("SNAPPY")) {
				keyCloakStatus = "SNAPPY";
			}
			if (clinicalSystem.equals("CWOW")) {
				keyCloakStatus = "CWOW";
			}
			if (clinicalSystem.equals("BOTH")) {
				keyCloakStatus = "BOTH";
			}
		}

		// fetching value from Screen
		boolean isSnappy = gwm.isElementPresent(gwm.getBy("xpath", oc.clickOnSnappyTab()));
		boolean isCwow = gwm.isElementPresent(gwm.getBy("xpath", oc.cwowTab()));
		String SnappyOrderCount = "0";
		if (gwm.isElementPresent(gwm.getBy("xpath", oc.orderCountRead(oc.cwowOrderBadgeCount()))))
			SnappyOrderCount = gwm.readWebElementText(
					gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.cwowOrderBadgeCount()))));

		String cwowOrderCount = "0";
		if (gwm.isElementPresent(gwm.getBy("xpath", oc.orderCountRead(oc.snappyOrderBadgeCount()))))
			cwowOrderCount = gwm.readWebElementText(
					gwm.getWebElement(gwm.getBy("xpath", oc.orderCountRead(oc.snappyOrderBadgeCount()))));
		// assert part

		switch (keyCloakStatus) {
		case "CWOW":
			if (Integer.parseInt(SnappyOrderCount) > 0) {
				if (isSnappy && isCwow) {
					screenStatus = true;
				}
			} else {
				if (isCwow && !isSnappy) {
					screenStatus = true;
				} else {
					screenStatus = false;
				}
			}

			break;

		case "SNAPPY":
			if (Integer.parseInt(cwowOrderCount) > 0) {
				if (isSnappy && isCwow) {
					screenStatus = true;
				}
			} else {
				if (!isCwow && isSnappy) {
					screenStatus = true;
				} else {
					screenStatus = false;
				}
			}
			break;

		case "BOTH":
			if (isCwow && isSnappy)
				screenStatus = true;
			break;

		default:
			screenStatus = false;
			break;
		}

		// calling assert
		return screenStatus;
	}

	/**
	 * To click on Task-->Order @ return : void
	 */
	public void clickOnOrders() {
		LOGGER.info("Enter SnappyComponent.Click_On_Orders()");
		gwm.waitForElementToAppear(gwm.getBy("id", oc.homePageTaskId()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.homePageTaskId())));
		gwm.waitForElementToAppear(gwm.getBy("id", oc.homePageTaskOrdersId()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", oc.homePageTaskOrdersId())));
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.clickOnSnappyTab()), (int) ec.getWaitTimeout());
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", oc.clickOnSnappyTab())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("cssSelector", oc.ghostLoaderCSS())), GenericVariable.intElementWaitTimeout);
	}

	/**
	 * To verify the Top panel data and Bottom panel data on Snappy
	 * orders-->Task-->Order-->Snappy @ return : void
	 */
	public void validateSnappyPanelData() {
		LOGGER.info("Enter SnappyComponent.validateSnappyPanelData()");
		String topPanelMessage = gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.getRecentOrdersHeaderTextCSS())));
		Assert.assertEquals(topPanelMessage.toUpperCase(), "ORDERS ENTERED WITHIN THE LAST 7 DAYS".toUpperCase());
		String bottomPanelMessage = gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.getAllOrdersHeaderTextCSS())));
		Assert.assertEquals(bottomPanelMessage.toUpperCase(), "ALL ORDERS".toUpperCase());
	}

	/**
	 * 
	 * @param username
	 * @param password
	 * @param clinicalSystem
	 * @param licenseType
	 * @param webDriver
	 * @Description : below function is to fetch and update value in key cloak to
	 *              test US FCA-4771
	 */
	public void keyCloakOnOffValidation(String username, String password, String clinicalSystem, String licenseType,
			WebDriver webDriver) {
		KeycloakAPIComponent kc = new KeycloakAPIComponent();
		JSONObject objUpdateJSON;
		String bearerToken = kc.getToken(GenericVariable.KeyCloakUsername,
				GenericVariable.KeyCloakPassword);
		String keyCloakUserId = kc.getKeycloakUserID(username, bearerToken);
		Response GetResponse = kc.getKeycloakUserAttributes(keyCloakUserId, bearerToken);

		// fetching existing value
		String currLicenseType = "";
		String currClinicalSystem = "";
		objUpdateJSON = new JSONObject(GetResponse.asString());

		try {
			currClinicalSystem = objUpdateJSON.getJSONObject("attributes").getJSONArray("clinicalSystems").get(0) + "";
		} catch (Exception e) {
			LOGGER.info("Clinical System attribute is not present");
		}

		try {
			currLicenseType = objUpdateJSON.getJSONObject("attributes").getJSONArray("licenseType").get(0) + "";
		} catch (Exception e) {
			LOGGER.info("License Type attribute is not present");
		}
		if (licenseType != "")
			objUpdateJSON.getJSONObject("attributes").put("licenseType", licenseType);
		if (clinicalSystem != "")
			objUpdateJSON.getJSONObject("attributes").put("clinicalSystems", clinicalSystem);

		kc.updateKeycloakUserAttributes(keyCloakUserId, bearerToken, objUpdateJSON);

		// Login to the application dps
		LOGGER.info("Login to dps");
		LoginComponent lgn = new LoginComponent(webDriver);
		lgn.login(username);
		clickOnOrders();
		boolean screenStatus = fetchClinicalSystemandVerify(clinicalSystem, licenseType);

		// updating old values
		GetResponse = kc.getKeycloakUserAttributes(keyCloakUserId, bearerToken);
		objUpdateJSON = new JSONObject(GetResponse.asString());
		if (currLicenseType != "")
			objUpdateJSON.getJSONObject("attributes").put("licenseType", currLicenseType);
		if (currClinicalSystem != "")
			objUpdateJSON.getJSONObject("attributes").put("clinicalSystems", currClinicalSystem);

		kc.updateKeycloakUserAttributes(keyCloakUserId, bearerToken, objUpdateJSON);
		Assert.assertTrue(screenStatus, "ON / OFF flag Check");
	}

	/**
	 * @description Fetch unsigned order count from PP
	 * @return SnappyOrderCount
	 */
	public int getSnappyOrderCount() {
		LOGGER.info("Entering into SnappyComponent.getSnappyOrderCount()");
		int snappyOrderCount = 0;
		gwm.waitForElementToAppear(gwm.getBy("xpath", oc.orderCountRead(oc.recentOrdersCountCSS())), GenericVariable.intElementWaitTimeout);
		List<WebElement> listOfElements = gwm
				.getWebElements(gwm.getBy("cssSelector", oc.snappyOrderBadgeCount()));
		if (listOfElements.size() > 0) {
			snappyOrderCount = Integer.parseInt(gwm
					.readWebElementText(
							gwm.getWebElement(gwm.getBy("cssSelector", oc.snappyOrderBadgeCount())))
					.trim());
		}
		LOGGER.info("Exiting from SnappyComponent.getSnappyOrderCount()");
		return snappyOrderCount;
	}

	/**
	 * @description Fetch unsigned order count from cwow
	 * @return cwowOrderCount
	 */
	public int getCwowOrderCount() {
		LOGGER.info("Entering into SnappyComponent.getCwowOrderCount()");
		int cwowOrderCount = 0;
		List<WebElement> listOfElements = gwm
				.getWebElements(gwm.getBy("cssSelector", oc.cwowOrderBadgeCount()));
		if (listOfElements.size() > 0) {
			cwowOrderCount = Integer
					.parseInt(gwm
							.readWebElementText(
									gwm.getWebElement(gwm.getBy("cssSelector", oc.cwowOrderBadgeCount())))
							.trim());
		}
		LOGGER.info("Exiting from SnappyComponent.getCwowOrderCount()");
		return cwowOrderCount;
	}

	/**
	 * @description Fetch total order count
	 * @return getTotalOrderCount
	 */
	public int getTotalOrderCount() {
		LOGGER.info("Entering into SnappyComponent.getTotalOrderCount()");
		gwm.waitForElementToAppear(gwm.getBy("cssSelector", oc.totalOrderCountRead()), GenericVariable.intElementWaitTimeout);
		int totalOrderCount = Integer.parseInt(
				gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.totalOrderCountRead())))
						.trim());
		LOGGER.info("Exiting from SnappyComponent.getTotalOrderCount()");
		return totalOrderCount;
	}

	/**
	 * It will matched the Order badged count with the addition of snappy and cwow
	 * count (order badge count = cwow order count + snappy order count)
	 */
	public void matchTotalOrderCountvsCwowAndSnappy() {
		LOGGER.info("Entering into SnappyComponent.matchTotalOrderCountvsCwowAndSnappy()");
		int cwowCount = getCwowOrderCount();
		int snappyCount = getSnappyOrderCount();
		int totalCount = getTotalOrderCount();
		int cwowAndSnappySum = cwowCount + snappyCount;
		Assert.assertEquals(totalCount, cwowAndSnappySum,
				"Both actual and expected order count should be same".toUpperCase());
	}
	
	/**
	 * @description To get recent unsigned order count from snappy API
	 * @return orderCount
	 * @throws Exception 
	 */
	public int getRecentUnsignedSnappyOrdersCountFromAPI(String username) throws Exception {
		LOGGER.info("Entering into SnappyComponent.getRecentUnsignedSnappyOrdersCountFromAPI()");
		physPortalAPIComponent snappyAPIComponent = new physPortalAPIComponent();
		int recentOrderCount = snappyAPIComponent.getRecentUnassignedOrderCount(username);
		return recentOrderCount;
	}

	/**
	 * @description To get total unsigned snappy orders count from snappy API
	 * @return orderCount
	 * @throws Exception 
	 */
	public int getTotalUnsignedSnappyOrdersCountFromAPI(String username) throws Exception {
		LOGGER.info("Entering into SnappyComponent.getTotalUnsignedSnappyOrdersCountFromAPI()"+username);
		physPortalAPIComponent snappyAPIComponent = new physPortalAPIComponent();
		int totalOrderCount = snappyAPIComponent.getUnassignedOrderCount(username);
		return totalOrderCount;
	}

	/**
	 * @description To get recent unsigned snappy orders count from UI
	 * @return orderCount
	 */
	public int getRecentUnsignedSnappyOrdersCountFromUIPanel() {
		LOGGER.info("Entering into SnappyComponent.getRecentUnsignedSnappyOrdersCountFromUIPanel()");
		gwm.waitForElementToAppear(gwm.getBy("cssSelector", oc.recentOrdersCountCSS()), GenericVariable.intElementWaitTimeout);
		int recentOrderCount = Integer.parseInt(
				gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.recentOrdersCountCSS()))).trim());
		return recentOrderCount;
	}

	/**
	 * @throws Exception 
	 * @description To match the recent snappy orders count from API with the recent snappy orders
	 *              count from UI
	 */
	public void recentSnappyOrdersCountVerificationFromAPIvsUIPanel(String username) throws Exception {
		LOGGER.info("Entering into SnappyComponent.recentSnappyOrdersCountVerificationFromAPIvsUIPanel()"+username);
		int recentSnappyOrdersCountFromAPI = getRecentUnsignedSnappyOrdersCountFromAPI(username);
		int recentSnappyOrdersCountFromUI = getRecentUnsignedSnappyOrdersCountFromUIPanel();
		Assert.assertEquals(recentSnappyOrdersCountFromAPI, recentSnappyOrdersCountFromUI,
						"Both actual and expected recent snappy order counts should be same");	
		}

	/**
	 * @throws Exception 
	 * @description To match the total snappy orders count from API with the total snappy orders
	 *              count from UI
	 */
	public void totalSnappyOrdersCountVerificationFromAPIvsUIPanel(String username) throws Exception {
		LOGGER.info("Entering into SnappyComponent.totalSnappyOrdersCountVerificationFromAPIvsUIPanel()");
		int totalSnappyOrdersCountFromAPI = getTotalUnsignedSnappyOrdersCountFromAPI(username);
		int totalSnappyOrdersCountFromUI = getSnappyOrderCount();
		Assert.assertEquals(totalSnappyOrdersCountFromAPI, totalSnappyOrdersCountFromUI,
					"Both actual and expected total snappy order counts should be same");
		}
}