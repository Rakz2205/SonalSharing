/**
 * Grace Tshihata
 * */

package com.apps.oneview.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.base.GenericWebMethods;

public class loginFactory {

	LoginCaller lc = new LoginCaller();
	private EnvironmentCaller ec = new EnvironmentCaller();
	GenericWebMethods aGm;

	WebDriver driver;

	By falconUserName = By.id(lc.username_Id());

	By falconpassword = By.id(lc.password_Id());

	By titleText = By.className(lc.titlle_class());
	By login = By.id(lc.login_submit_btn_id());

	public loginFactory(WebDriver driver) {

		this.driver = driver;

	}

	// Set user name in textbox

	public void setUserName(String strUserName) {

		driver.findElement(falconUserName).sendKeys(strUserName);

	}

	// Set password in password textbox

	public void setPassword(String strPassword) {

		driver.findElement(falconpassword).sendKeys(strPassword);

	}

	// Click on login button

	public void clickLogin() {

		driver.findElement(login).click();

	}

	// Get the title of Login Page

	public String getLoginTitle() {

		return driver.findElement(titleText).getText();

	}

	public String get_Page_Title() {
		return driver.getTitle();

	}

	/**
	 * 
	 * This POM method will be exposed in test case to login in the application
	 * 
	 * @param strUserName
	 * 
	 * @param strPasword
	 * 
	 * @return
	 * 
	 */

	public void loginToFalcon(String strUserName, String strPasword) {
		WebDriverWait wait = new WebDriverWait(driver, ec.getWaitTimeout());
		wait.until(ExpectedConditions.visibilityOfElementLocated(falconUserName));
		// Fill user name

		this.setUserName(strUserName);

		// Fill password

		this.setPassword(strPasword);

		// Click Login button

		this.clickLogin();


	}

	/**
	 * 
	 * All WebElements are identified by @FindBy annotation
	 * 
	 */

}
