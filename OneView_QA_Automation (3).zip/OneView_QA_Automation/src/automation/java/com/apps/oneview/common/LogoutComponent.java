package com.apps.oneview.common;

import java.util.logging.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import com.base.GenericVariable;
import com.base.GenericWebMethods;

public class LogoutComponent {
	WebDriver webdriver;
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private LogoutCaller logoutCaller = new LogoutCaller();
	private LoginCaller loginCaller= new LoginCaller();
	private GenericWebMethods gwm;

	// KWR: added a copy of the driver instance to genericmethods and had to add a
	// constructor
	public LogoutComponent(WebDriver wd) {
		webdriver=wd;
		gwm = new GenericWebMethods(wd);
		}

	@SuppressWarnings("static-access")
	public void logMe_Out() {
		LOGGER.info("Entering LogoutComponent.logMe_Out()");
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", logoutCaller.logout())));
		Assert.assertEquals(GenericVariable.LOGOUT_TITLE.toLowerCase(), gwm.get_Page_Title().toLowerCase());
	}
	
	public void logOut() {
		LOGGER.info("Entering LogoutComponent.logOut()");
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", logoutCaller.logout())));
	}
	
	public void verifyUserName(String username) {
		LOGGER.info("Entering LogoutComponent.verifyUserName with parameter(s) userName: "+username);
		gwm.getWebElement(gwm.getBy("id", loginCaller.username_Id()));
		Assert.assertEquals(gwm.getWebElement(gwm.getBy("id", loginCaller.username_Id())).getAttribute("value").toUpperCase(), username.toUpperCase());

}

}