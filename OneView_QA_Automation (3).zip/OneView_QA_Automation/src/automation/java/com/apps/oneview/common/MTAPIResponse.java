package com.apps.oneview.common;

import java.util.HashMap;
import java.util.logging.Logger;
import org.testng.Assert;
import org.testng.SkipException;

import com.apps.oneview.services.billingAPIComponent;
import com.apps.oneview.services.cwowAPIComponent;
import com.apps.oneview.services.patientsAPIComponent;
import com.apps.oneview.services.physPortalAPIComponent;
import com.base.GenericHelper;

// This class has a method getMapOfApiStatus which creates a map of API status, Ex:  key "cwowApiStatus", Value true
// apiNames ...(varargs) is a vararg datatype , it means an array of String
// inside for loop we need to build if else to hit the right API to get the status and add it to the map.
// Return type is a hash map which has all the keys as API status and values as boolean

public class MTAPIResponse {

	static HashMap<String, Boolean> apiStatusMap = new HashMap<String, Boolean>();
	String rptToken = null;

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	int responseCode;
	static boolean apiStatus;

	public MTAPIResponse(String rptToken) {
		this.rptToken = rptToken;
		System.out.println(this.rptToken+"in const");
	}

	/**
	 * This function creates a map of status code and status
	 * 
	 * @param apiNames
	 * @return apiStatusMap returns the map for status code and value in boolean
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, Boolean> getMapOfApiStatus(String... apiNames) throws Exception {
		LOGGER.info("Entering MTAPIResponse.getMapOfApiStatus: ");
		apiStatus = false;
		for (String apiName : apiNames) {
			LOGGER.info("For Loop MTAPIResponse..getMapOfApiStatus: ");

			if (apiName.equalsIgnoreCase("cwow")) {
				cwowAPIComponent cWOWAPIComponent = new cwowAPIComponent();
				responseCode = cWOWAPIComponent.getCWOWDisputeReasonsStatus(rptToken);
				updateMap(apiName, responseCode);

			} else if (apiName.equalsIgnoreCase("patientSearch")) {
				HashMap<String, String> patientMap = new HashMap<String, String>();
				patientsAPIComponent patientsAPIComponent = new patientsAPIComponent();
				patientMap = GenericHelper.fetchValueFromExcel("verifyPatientCharts");
				responseCode = patientsAPIComponent.searchPatientsStatus(rptToken, patientMap.get("mpi"));
				updateMap(apiName, responseCode);

			} else if (apiName.equalsIgnoreCase("phyportal")) {
				physPortalAPIComponent physPortalAPIComponent = new physPortalAPIComponent();
				responseCode = physPortalAPIComponent.getPhyPortalUnsignedOrdersStatus(rptToken);
				updateMap(apiName, responseCode);

			}else if (apiName.equalsIgnoreCase("login")) {
				if(rptToken!=null) {
					responseCode = 200;
				}else {
					responseCode = 500;
				}
				updateMap(apiName, responseCode);
				
			}else if (apiName.equalsIgnoreCase("billing")) {
				billingAPIComponent billingAPIComponent = new billingAPIComponent();
				responseCode = billingAPIComponent.getBillingAPIStatus(rptToken);
				updateMap(apiName, responseCode);
			}
		}
		return apiStatusMap;
	}

	/**
	 * 
	 * This function will check for the Cwow MT api status. 
	 * 
	 * return boolean
	 */
	public boolean isCwowUp() {
		LOGGER.info("Entering MTAPIResponse.isCwowUp: ");
		if (apiStatusMap.get("cwowApiStatus")==null || !apiStatusMap.get("cwowApiStatus")) {
			return false;		
		}
		return true;
	}

	/**
	 * 
	 * This function will check for the Snappy MT api status. 
	 * 
	 * @return boolean
	 */
	public boolean isSnappyUp() {
		LOGGER.info("Entering MTAPIResponse.isSnappyUp: ");
		if (apiStatusMap.get("phyportalApiStatus")==null || !apiStatusMap.get("phyportalApiStatus")) {
			return false;
		}
		return true;
	}

	/**
	 * This function will check for the patientSearch MT api status.
	 * 
	 * @return boolean
	 */
	public boolean isPatientSearchUp() {
		LOGGER.info("Entering MTAPIResponse.isPatientSearchUp: ");
		if (apiStatusMap.get("patientSearchApiStatus")==null || !apiStatusMap.get("patientSearchApiStatus")) {
			return false;
		}
		return true;
	}
	
	/**
	 * This function will check for keycloak's status. 
	 * 
	 * @return boolean
	 */
	public boolean isLoginUp() {
		LOGGER.info("Entering MTAPIResponse.isLoginUp: ");
		if (apiStatusMap.get("loginApiStatus")==null || !apiStatusMap.get("loginApiStatus")) {
			return false;
		}
		return true;
	}
	
	/**
	 * This function will check for the billing MT api status.
	 * 
	 * @return boolean
	 */
	public boolean isBillingUp() {
		LOGGER.info("Entering MTAPIResponse.isBillingUp: ");
		if (apiStatusMap.get("billingApiStatus")==null || !apiStatusMap.get("billingApiStatus")) {
			return false;
		}
		return true;
	}
	
	

	/**
	 * Updating the apicode and the status in a hashmap
	 * 
	 * @param apiName
	 * @param responseCode
	 */
	private static void updateMap(String apiName, int responseCode) {
		if (responseCode == 200) {
			apiStatus = true;
			apiStatusMap.put(apiName + "ApiStatus", apiStatus);
		} else {
			apiStatus = false;
			apiStatusMap.put(apiName + "ApiStatus", apiStatus);
			Assert.assertNotEquals(apiStatus, true,
					"Both actual and expected response are not same i.e Expected 200 and Actual is".toUpperCase()
							+ responseCode);
		}

	}

}
