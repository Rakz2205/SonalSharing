package com.apps.oneview.common;

import java.util.List;					  
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;									  
import org.testng.Assert;

import com.base.GenericWebMethods;
import com.base.TestBase;

public class PatientSearch {
	private SearchCaller searchCaller = new SearchCaller();
	private GenericWebMethods gwm;
	private com.apps.oneview.common.EnvironmentCaller ec = new EnvironmentCaller();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public PatientSearch(WebDriver wd) {
		gwm = new GenericWebMethods(wd);
	}
	/**
	 * Author - mrunmayeec
	 * Search the oneview application for the mentioned patient name
	 */
	public void searchPatient(String Name) {
		gwm.waitForPageLoad();
		// wait for search icon to be available
		gwm.waitForElementToBeVisbile(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchIconID())));
		// Click on search icon and verify the input box is visible
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchIconID())));
		// enter the search keyword
		gwm.enterText(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchBoxInputID())), Name, true);
		// wait for search results to appear
		gwm.waitForElementToAppear(gwm.getBy("xpath", searchCaller.getSearchResultsXpath()), (int) ec.getWaitTimeout());
		// name of the first search result stored to be compared later
		String name = gwm.readWebElementText(gwm.getWebElements(gwm.getBy("xpath", searchCaller.getSearchResultsPath())).get(0)
				.findElement(By.xpath(searchCaller.getSearchResultNamePath())));
		// click on patient name
		gwm.clickWebElement(gwm.getWebElements(gwm.getBy("xpath", searchCaller.getSearchResultsPath())).get(0)
				.findElement(By.xpath(searchCaller.getSearchResultNamePath())));
		// wait for patient charts to load data
		gwm.waitForElementToBeVisbile(gwm.getWebElement(gwm.getBy("cssSelector", searchCaller.getpatientNamePatientChartPath())));
		// Verify title for Patient charts
		Assert.assertEquals(gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", searchCaller.getHeaderTitlePath()))).toUpperCase(),
				searchCaller.getPatientChartTitle(), "Patient Chart page is not loaded after selecting a patient from search");

		// Verify that the name of patient in Search and Patient Chart is same
		Assert.assertEquals(gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", searchCaller.getpatientNamePatientChartPath()))),
				name, "Patient name searched and displayed in Patient chart doesn't match");
		// verify tab name for Labs tab in charts
		List<WebElement> tabNameList = gwm.getWebElements(gwm.getBy("xpath", searchCaller.getAllTabsLocatorXpath()));
		Assert.assertTrue(TestBase.patientChartTabNames.contains(tabNameList.get(0).getText().trim()), "Tab names for "
				+tabNameList.get(0).getText().trim()+ " do not match");
		// verify tab name for Treatment tab in charts
		Assert.assertTrue(TestBase.patientChartTabNames.contains(tabNameList.get(1).getText().trim()), "Tab names for "
				+tabNameList.get(1).getText().trim()+" do not match");
		// verify tab name for Clinical Summary tab in charts
		Assert.assertTrue(TestBase.patientChartTabNames.contains(tabNameList.get(2).getText().trim()), "Tab names for "
				+tabNameList.get(2).getText().trim()+" do not match");
		// verify tab name for Patient Profile tab in charts
		Assert.assertTrue(TestBase.patientChartTabNames.contains(tabNameList.get(3).getText().trim()), "Tab names for "
				+tabNameList.get(3).getText().trim()+" do not match");
	}
	
	/**
	 * Function will just search for String provided without any validation;
	 * 
	 * @author Prathamesh C
	 * @param Name
	 *            Pass Name of the patient which is to be searched
	 */	
	public void patientSearch(String Name) { 
		gwm.waitForPageLoad(); //Wait for page to load
		// wait for search icon to be available
		gwm.waitForElementToBeVisbile(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchIconID())));
		// Click on search icon and verify the input box is visible
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchIconID())));
		// enter the search keyword
		gwm.enterText(gwm.getWebElement(gwm.getBy("id", searchCaller.getSearchBoxInputID())), Name, true);
		// wait for search results to appear
		gwm.waitForElementToAppear(gwm.getBy("xpath", searchCaller.getListLoaderXpath()),
				(int) ec.getWaitTimeout());
	}
	
	/**
	 * Function will verify the header of Patient List displayed
	 * 
	 * @author Prathamesh C
	 * @param searchString
	 *            String searched - Character's of Patient Name
	 */	
	public void verifySearchHeader(String searchString) {
		String expectedSearchHeader = null;
		int searchNo = 0;
		
		String actualSearchHeader = gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector",
				searchCaller.getSearchHeaderCss())));
		//Verifying if the list exist
		if(actualSearchHeader.contains(searchCaller.getSearchHeaderNoStringText().replace("%s", searchString))) {
			expectedSearchHeader = searchCaller.getSearchHeaderNoStringText().replace("%s", searchString);
		}			
		else if(gwm.isElementPresent(gwm.getBy("xpath", searchCaller.getSearchResultsPath()))){
			searchNo = gwm.getWebElements(gwm.getBy("xpath", searchCaller.getSearchResultsPath())).size();
		}
		 
		//In Case There is 1 Matching Patient
		if (searchNo == 1) {
			expectedSearchHeader = searchCaller.getSearchHeaderOneText().replace("%s", searchString).replace("%d",
					String.valueOf(searchNo)); 
		//In Case There are more than 1 Matching Patient
		} else if (searchNo > 1) {
			expectedSearchHeader = searchCaller.getSearchHeaderText().replace("%s", searchString).replace("%d",
					String.valueOf(searchNo));
		}
		
		LOGGER.info("Expected Header for Search Result is "+expectedSearchHeader);
		Assert.assertEquals(actualSearchHeader.trim().toUpperCase(), expectedSearchHeader.toUpperCase(),
				"Search string result doesn't match for String: " + searchString);
	}
	
	/**
	 * Function will verify the  Patient List displayed
	 * 
	 * @author Prathamesh C
	 * @param searchString
	 *            String searched - Character's of Patient Name
	 */		
	public void verifyPatientList(String searchString) {
		boolean boolChkExist = false;
		List<WebElement> objPatientList = gwm.getWebElements(gwm.getBy("cssSelector", searchCaller.getPatientNameList()));
		for (WebElement objPatientName: objPatientList) {
			String tempString [] = gwm.readWebElementText(objPatientName).split(", ");
			if(tempString[0].toUpperCase().startsWith(searchString.toUpperCase()) 
					|| tempString[1].toUpperCase().startsWith(searchString.toUpperCase()))
			{
				boolChkExist = true;
			}
			else {
				boolChkExist = false;
				break;
			}
		}
		Assert.assertTrue(boolChkExist, "Search result doesn't conatins the Search String :"+ searchString);
	}
}