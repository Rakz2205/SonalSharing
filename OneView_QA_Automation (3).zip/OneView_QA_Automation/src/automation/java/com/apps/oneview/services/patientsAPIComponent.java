package com.apps.oneview.services;

import java.util.HashMap;
import java.util.logging.Logger;
import org.json.JSONObject;
import com.base.Drivers;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.RestAPI;
import com.base.TestBase;

import io.restassured.response.Response;

public class patientsAPIComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private static String patientSearchURL = GenericHelper.getBaseURL(TestBase.URL_Path.OneViewBase)
			+ GenericVariable.PATIENTS_MT_SUFFIX + GenericVariable.PATIENTS_SEARCH_SUFFIX;
	/**
	 * Function gets the patients from the search endpoint for a given search string
	 * 
	 * @param token  the RPT token requred by the MT service for authorization
	 * @param search characters you want to use for the patient search
	 * @return int
	 */
	public int searchPatientsStatus(String token, String search) {
		LOGGER.info("enter PatientsAPIComponent.searchPatients");
		// Set the endpoint
		String arrGetParam[] = { patientSearchURL, "" };
		// Add the query parameters
		HashMap<String, String> formParams = new HashMap<>();
		formParams.put("searchText", search);
		// Add the token
		HashMap<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + token);
		// this request doesn't have a body so pass a blank object
		JSONObject objGetJSON = new JSONObject();
		// Make the call
		Response getResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		// return the call status
		return getResponse.statusCode();
	}	 
}
