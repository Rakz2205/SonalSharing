package com.apps.oneview.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.json.*;

import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.GenericWebMethods;
import com.apps.oneview.common.CoveringRightsCaller;
import com.base.TestBase.App_Name;
import io.restassured.response.ResponseBody;

public class CoveringRightsComponent {
	protected final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	CoveringRightsCaller crc = new CoveringRightsCaller();
	private GenericWebMethods gwm;
	private String currentTab;
	private int gvWait = GenericVariable.intElementWaitTimeout;

	// KWR: added a copy of the driver instance to generic methods and had to add a
	// constructor
	public CoveringRightsComponent(WebDriver wd) {
		gwm = new GenericWebMethods(wd);
	}

	/**
	 * Function selects the CR menu option
	 * @return null
	 */
	public void navToCoveringRights() {
		LOGGER.info("enter CoveringRightsComponent.navToCoveringRights()");
		// Navigate to the Covering Rights application
		gwm.clickWebElement(gwm.getWebElement(By.id(crc.menuSettingsId())));
		gwm.clickWebElement(gwm.getWebElement(By.id(crc.menuSettingsCoveringRightsId())));
		//wait for text to be visible 
		String textToMatch = crc.crAppNameLabel();
		textToMatch = textToMatch.substring(0, textToMatch.indexOf(" "));
		gwm.waitForTextToBePresentInElement(gwm.getWebElement(By.id(crc.coveringRightsAppNameId())), 
											textToMatch, gvWait, true);

		
		Assert.assertTrue(gwm.getWebElement(By.id(crc.coveringRightsAppNameId()))
					.getText().toUpperCase().equals(crc.crAppNameLabel().toUpperCase()), 
					"Unable to navigate to the Covering Rights application");
	}
	
	/**
	 * Function validates the covering rights tabs appear as expected
	 * @return null
	 */
	public void validateTabs() {
		LOGGER.info("enter CoveringRightsComponent.validateTabs()");
		// get the tabs
		List<WebElement> crTabs = gwm.getWebElements(By.cssSelector(crc.coveringRightsTabsCss()));
		// validate the tab characteristics 
		for (WebElement aTab : crTabs) {
			Assert.assertTrue(((aTab.getText().trim().equals(crc.assignRightsTabLabel())))||
							 ((aTab.getText().trim().equals(crc.rightsAssignedTabLabel()))),
							 "Covering rights tab names do not match expectations");
		}
		Assert.assertEquals(crTabs.size(), crc.covRightsTabCount());

	}

	/**
	 * Function validates assign rights tab is active by default
	 * @return null
	 */
	public void validateDefaultTab() {
		LOGGER.info("enter CoveringRightsComponent.validateDefaultTab()");
		gwm.waitForElementToBeVisbile(gwm.getWebElement(By.cssSelector(crc.covRightsTabLink())));
		List<WebElement> crTabs = gwm.getWebElements(By.cssSelector(crc.covRightsTabLink()));
		String hexColor;
		for (WebElement aTab : crTabs) {
			if (aTab.getText().contains(crc.assignRightsTabLabel())) {
				currentTab = aTab.getText();
				hexColor = GenericHelper.convertRGBToHex(gwm.getCssValue(aTab, "border-bottom-color"));
				Assert.assertEquals(hexColor, "#82b20a");
				Assert.assertTrue(gwm.getTagAttribute(aTab, "class").contains(crc.tabActiveClass()));
			}
		}
	}
	
	/**
	 * Function validates the help text appears
	 * @return null
	 */
	public void validateHelpText() {
		LOGGER.info("enter CoveringRightsComponent.validateHelpText()");
		validateHelpText(currentTab);

	}
	
	public void validateHelpText(String tabLabel) {
		LOGGER.info("enter CoveringRightsComponent.validateHelpText()");
		// Validate the tool tip displays the right value
		gwm.mouse_Hover(By.cssSelector(crc.toolTipCss()));
		gwm.waitForTextToBePresentInElement(gwm.getWebElement(By.tagName(crc.toolTipTagName())), "provider", gvWait, false);
		String actualHelpText = gwm.readWebElementText(gwm.getWebElement(By.tagName(crc.toolTipTagName())));
		actualHelpText = actualHelpText.replace("\n", " ").replace("\r", " ").replace("  ", " ");
		String expectedHelpText = null;
		if (tabLabel.contains(crc.assignRightsTabLabel())) {
			expectedHelpText = crc.assignRightsTabHelpText();
		} else {
			expectedHelpText = crc.rightsAssignedTabHelpText();
		}

		Assert.assertEquals(actualHelpText.trim(), expectedHelpText, "Tool Tip text does not match expected tool tip message for tab: "+tabLabel);
	}	
	/**
	 * Function will return the physician with Covering Rights enabled;
	 * @return String - physician name
	 * @author Prathamesh C
	 */	
	public String getPhysicianWithCoveringRights() {
		LOGGER.info("enter CoveringRightsComponent.getPhysicianWithCoveringRights()");
		String physName = "";
		if (gwm.waitForElementToAppear(gwm.getBy("xpath", crc.getPhysNameWithRightsXpath()), gvWait)){
			physName = gwm.getWebElement(gwm.getBy("xpath", crc.getPhysNameWithRightsXpath())).getText();
		}
		else {
			physName = addCoveringRights();
		}
		Assert.assertTrue(physName!="", "Covering Rights are enabled for "+physName);
		return physName;
	}
	/**
	 * Function will add covering rights to physician and return the physician name;
	 * @return String - physician name
	 * @author Prathamesh C
	 */		
	public String addCoveringRights() {
		LOGGER.info("enter CoveringRightsComponent.addCoveringRights()");
		String physName = "";
		Boolean boolChkExist = false;
		if (gwm.waitForElementToAppear(gwm.getBy("xpath", crc.getPhysNameWithoutRightsXpath()), gvWait)){
			physName = gwm.getWebElement(gwm.getBy("xpath", crc.getPhysNameWithoutRightsXpath())).getText();
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", crc.getToggleForPhysRightsUnassignedXpath(physName))));
			gwm.waitForElementToBeClickable(gwm.getBy("xpath", crc.getSelectActiveCenterCheckboxXpath()), gvWait);
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("cssSelector", crc.getSelectAllCheckboxCss())));
			gwm.waitForElementToBeClickable(gwm.getBy("cssSelector", crc.getSaveAndCloseButtonCss()), gvWait);
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("cssSelector", crc.getSaveAndCloseButtonCss())));
			boolChkExist = gwm.waitForElementToAppear(gwm.getBy("xpath", crc.getToggleForPhysRightsAssignedXpath(physName))
					,gvWait);
		}
		Assert.assertTrue(boolChkExist, "Covering Rights are added for "+physName);
		return physName;
	}
	/**
	 * Function will click on enabled covering rights to make it disable;
	 * @return null
	 * @author Prathamesh C
	 */	
	public void clickToDisableCoveringRights(String physName) {
		LOGGER.info("enter CoveringRightsComponent.clickToDisableCoveringRights()");
		Boolean expectedResult = false;
		if(gwm.isElementVisible(gwm.getWebElement(gwm.getBy("xpath", crc.getToggleForPhysRightsAssignedXpath(physName))))){
			gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", crc.getToggleForPhysRightsAssignedXpath(physName))));
			expectedResult = gwm.waitForElementToAppear(gwm.getBy("xpath", 
					crc.getToggleForPhysRightsUnassignedXpath(physName)), gvWait);
		}
		Assert.assertTrue(expectedResult, "Covering Rights are disabled for "+physName);
	}

	/**
	 * Function will click on View History link and verify the modal should contain today's date;
	 * @return null
	 * @author Prathamesh C
	 */	
	public void verifyDateInViewHistoryModal(String physName) {
		LOGGER.info("enter CoveringRightsComponent.verifyDateInViewHistoryModal()");
		Boolean boolChkExist = false;
		String expectedDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date()).trim();
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", crc.getViewHistoryLinkForPhysXpath(physName))));
		gwm.waitForElementToAppear(gwm.getBy("cssSelector", crc.getViewHistoryDatesCss()), gvWait);
		WebElement prevDateObj = gwm.getWebElement(gwm.getBy("cssSelector", crc.getViewHistoryPreviousCss()
				+" "+crc.getViewHistoryDatesCss()));
		String actualDate = prevDateObj.getText().split(" - ")[1].trim();
		boolChkExist = actualDate.equals(expectedDate);
		String actualHeader = gwm.getWebElement(gwm.getBy("cssSelector", crc.getViewHistoryPreviousCss())).getText();
		String expectedHeader = crc.getPrevAssignedCRText().trim();
		Assert.assertTrue(actualHeader.contains(expectedHeader), "Verify Previously Assigned Covering Rights "
				+ "header is displayed inside modal popup");
		Assert.assertTrue(boolChkExist, "Verify today's date is displayed in Previously Assigned Covering Rights");
	}
	
	/**
	 * Function will verify EditFacilities link is displayed for particular physician;
	 * @return null
	 * @author Prathamesh C
	 */	
	public void verifyEditFacilitiesLinkForPhys(String physName) {
		LOGGER.info("enter CoveringRightsComponent.verifyEditFacilitiesLinkForPhys()");
		Boolean boolChkExist = gwm.isElementPresent(gwm.getBy("xpath", crc.getEditFacilitiesLinkXpath(physName)));
		Assert.assertTrue(boolChkExist, "Verify Edit Facilities Link is displayed for Physician "+physName);
	}
	
	/**
	 * Function will verify View History link is displayed for particular physician;
	 * @return null
	 * @author Prathamesh C
	 */	
	public void verifyViewHistoryLinkForPhys(String physName) {
		LOGGER.info("enter CoveringRightsComponent.verifyViewHistoryLinkForPhys()");
		Boolean boolChkExist = gwm.isElementPresent(gwm.getBy("xpath", crc.getViewHistoryLinkForPhysXpath(physName)));
		Assert.assertTrue(boolChkExist, "Verify View History link is displayed for Physician "+physName);
	}
}