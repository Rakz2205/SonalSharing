package com.apps.oneview.services;

import java.util.HashMap;
import java.util.logging.Logger;
import org.json.JSONObject;
import com.base.Drivers;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.RestAPI;
import com.base.TestBase;

import io.restassured.response.Response;

public class billingAPIComponent {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	/**
	 * Function makes a call to get the CWOW Dispute reasons response
	 * 
	 * @param bearerToken
	 * @return response
	 */
	public int getBillingAPIStatus(String bearerToken) {
		LOGGER.info("Entering billingAPIComponent.getBillingAPIStatus");
		HashMap<String, String> formParams = new HashMap<>();
		String arrGetParam[] = {
				GenericHelper.getBaseURL(TestBase.URL_Path.OneViewBase) + GenericVariable.BILLING_MT_SUFFIX, "" };
		HashMap<String, String> header = new HashMap<>();
		header.put("Accept", "application/json");
		header.put("Authorization", "Bearer " + bearerToken);
		JSONObject objGetJSON = new JSONObject();

		Response GetResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		return GetResponse.getStatusCode();
	}
}
