package com.apps.oneview.common;

import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.base.GenericHelper;
import com.base.GenericWebMethods;

public class PhysicianPortalComponent {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private PhysicianPortalCaller pp = new PhysicianPortalCaller();
	private OrderCaller oc = new OrderCaller();
	GenericWebMethods gwm;
	private SnappyComponent pc;

	public PhysicianPortalComponent(WebDriver wd) {
		// super(wd);
		gwm = new GenericWebMethods(wd);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @author Snehal Patil
	 * @description read the count of Unsigned order
	 * @return Unsigned Order Count
	 */
	public String getUnsignedOrderCount() {
		GenericHelper.sleepSeconds(10);
		// Wait till Unsigned order loads
		By by = gwm.getBy("xpath", pp.getAllOrderCountXpath("1"));
		gwm.waitForElementToAppear(by, 30);
		GenericHelper.sleepSeconds(5);

		String OrderCount = gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.getAllOrderCountXpath("1"))));
		LOGGER.info("Order count " + OrderCount);
		return OrderCount;
	}

	/**
	 * @author Snehal Patil
	 * @description Click on unsigned order
	 */
	public void Click_On_UnsignedOrder() {
		getUnsignedOrderCount();

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.getAllOrderCountXpath("1"))));

		// Wait for page loading-wait till order loads
		// By by = gwm.getBy("xpath", pp.Select_Order_No("1"));
		gwm.waitForElementToAppear(gwm.getBy("xpath", pp.Select_Order_No("1")), 30);
	}

	/**
	 * @author Snehal Patil
	 * @description Click on filter and select requied order type filter
	 * @param intOrder
	 *            row number which need to be click
	 */
	public void Apply_Filter_For_Order_Type(int intOrder) {

		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.OpenOrderTypeFilter())));// click on order type
		GenericHelper.sleepSeconds(1);
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Select_from_opened_Dropdown("1"))));// deselect all
																										// the value
		gwm.clickWebElement(
				gwm.getWebElement(gwm.getBy("xpath", pp.Select_from_opened_Dropdown(String.valueOf((intOrder))))));// select
																													// diet
																													// order
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Click_On_Apply_btn())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", pp.loadingIcon())), 30);
	}

	/**
	 * @author Rakesh Gupta
	 * @description apply filter for diet order
	 * @param orderType
	 *            filter to be selected
	 */
	public void Apply_PP_Filter(String orderType) {

		gwm.waitForElementToAppear(gwm.getBy("xpath", pp.Select_Order_No("1")), 30);
		switch (orderType.toUpperCase()) {
		case "DIET":
			Apply_Filter_For_Order_Type(3);
			break;
		case "TREATMENT HEMO":
			Apply_Filter_For_Order_Type(11);
			break;
		case "TREATMENT PD":
			Apply_Filter_For_Order_Type(12);
			break;
		case "LAB":
			Apply_Filter_For_Order_Type(6);
			break;
		case "TARGET WEIGHT":
			Apply_Filter_For_Order_Type(4);
			break;
		case "PRN":
			Apply_Filter_For_Order_Type(9);
			break;
		case "ANCILLARY":
			Apply_Filter_For_Order_Type(2);
			break;
		case "NON-BILLABLE SERVICE":
			Apply_Filter_For_Order_Type(8);
			break;
		case "MEDICATION":
			Apply_Filter_For_Order_Type(7);
			break;
		case "PROTOCOL":
			Apply_Filter_For_Order_Type(10);
			break;
		case "HOME MED":
			Apply_Filter_For_Order_Type(5);
			break;

		// will add other order type when required
		}
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", pp.loadingIcon())), 30);
	}

	/**
	 * @author Rakesh Gupta
	 * @description apply filter for order status
	 * @param StatusTypes
	 *            filter to be selected
	 */
	// apply filter for Order Status- new, changed , renewed
	public boolean Apply_PP_Filter_Order_Status(String StatusTypes) {

		gwm.waitForElementToAppear(gwm.getBy("xpath", pp.Select_Order_No("1")), 30);
		switch (StatusTypes.toUpperCase()) {
		case "NEW":
			Apply_Filter_For_Order_Status(2);
			break;
		case "CHG":
			Apply_Filter_For_Order_Status(3);
			break;
		case "RNW":
			Apply_Filter_For_Order_Status(5);
			break;
		case "DC":
			Apply_Filter_For_Order_Status(4);
			break;
		// will add other order type when required
		}
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", pp.loadingIcon())), 30);
		Boolean flag = gwm.isElementPresent(gwm.getBy("xpath", pp.Select_Order_No("1")));
		return flag;

	}

	/**
	 * @author Rakesh Gupta
	 * @description Click on filter and select requied order status filter
	 * @param intOrder
	 *            row number which need to be click
	 */
	// Click on filter and select required order filter
	public void Apply_Filter_For_Order_Status(int intOrder) {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Open_Order_Status_Filter())));// click on order type
		GenericHelper.sleepSeconds(1);
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Select_from_opened_Dropdown("1"))));// deselect all
																										// the value
		gwm.clickWebElement(
				gwm.getWebElement(gwm.getBy("xpath", pp.Select_from_opened_Dropdown(String.valueOf((intOrder))))));// select
																													// diet
																													// order
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Click_On_Apply_btn())));
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", pp.loadingIcon())), 30);
	}

	/**
	 * @author Rakesh Gupta
	 * @description Click on sort filter button
	 */
	public void Click_Filter_Button() {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("cssSelector", pp.Sort_Filter_dietOrder())));// click on filter
		gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", pp.loadingIcon())), 30);
	}

	/**
	 * @author Rakesh Gupta
	 * @description fetch only change order value
	 * @param orderType
	 * @return
	 */
	public String fetchOrderDetailCHGPP() {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Select_Order_No("1"))));
		gwm.waitForElementToAppear(gwm.getBy("xpath", pp.loadingIconDetailPage()), 20);
		String returnData = "";

		// Name
		String Name = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_NameValue()))));
		Name = Name.substring(0, Name.indexOf('('));
		Name = Name.trim();
		returnData = returnData + "NameStart" + Name + "NameEnd" + "\n";

		// Age
		String DobAgeGender = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_Dob_Age_Gender_Value()))));

		// OrderType
		String OrderTypeStaus = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_OrderTypeValue()))));

		OrderTypeStaus = OrderTypeStaus.replaceFirst("Order Type: ", "");

		String OrderType = OrderTypeStaus.substring(0, OrderTypeStaus.indexOf("("));
		OrderType = OrderType.trim();
		returnData = returnData + "OrderTypeStart" + OrderType + "OrderTypeEnd" + "\n";
		LOGGER.info("Order Type " + OrderType);

		// OrderStatus
		String OrderStatus = OrderTypeStaus.substring(OrderTypeStaus.indexOf("(") + 1, OrderTypeStaus.length() - 1);
		OrderStatus = OrderStatus.trim();
		returnData = returnData + "OrderStatusStart" + OrderStatus + "OrderStatusEnd" + "\n";
		LOGGER.info("OrderStatus" + OrderStatus);
		// modifying as per DPS requirement
		String arrTemp[] = DobAgeGender.split(",");
		arrTemp[1] = arrTemp[1].replaceAll("Age: ", "");
		arrTemp[2] = arrTemp[2].replaceAll("Gender: ", "");
		LOGGER.info("DobAgeGender" + DobAgeGender);

		String Age = arrTemp[1].trim();
		returnData = returnData + Age + "\n";
		LOGGER.info("Age" + Age);

		// DOB
		String DOB = arrTemp[0].replaceAll("DOB:", "");
		DOB = DOB.trim();
		returnData = returnData + DOB + "\n";
		LOGGER.info("DOB" + DOB);

		// Gender
		String Gender = arrTemp[2].trim();
		returnData = returnData + Gender + "\n";
		LOGGER.info("Gender" + Gender);

		// FacilityCenter
		String FacilityCenter = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_FacilityValue()))));
		// need to remove number
		FacilityCenter = FacilityCenter.substring(FacilityCenter.indexOf("-"), FacilityCenter.length());
		FacilityCenter = FacilityCenter.trim();
		returnData = returnData + FacilityCenter + "\n";
		LOGGER.info("FacilityCenter" + FacilityCenter);

		// OrderId
		String OrderId = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_OrderId()))));
		OrderId = OrderId.replace("Source System OrderId: ", "");
		returnData = returnData + "orderIdStart" + OrderId + "orderIdEnd" + "\n";
		LOGGER.info("OrderId" + OrderId);

		String strTemp = gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.changeOrderData())));

		returnData = returnData + strTemp + "\n";

		returnData = returnData.replace(".10", ".1");
		returnData = returnData.replace(".20", ".2");
		returnData = returnData.replace(".30", ".3");
		returnData = returnData.replace(".40", ".4");
		returnData = returnData.replace(".50", ".5");
		returnData = returnData.replace(".60", ".6");
		returnData = returnData.replace(".70", ".7");
		returnData = returnData.replace(".80", ".8");
		returnData = returnData.replace(".90", ".9");
		returnData = returnData.replace(".0 ", " ");
		returnData = returnData.replace("min", "mins");

		LOGGER.info("PP Data" + returnData);
		return returnData;
	}

	/**
	 * @author Rakesh Gupta
	 * @description return all order detail on from order details page
	 * @return a list which contains all order detail
	 */
	public Map fetchOrderDetailPP() {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Select_Order_No("1"))));
		gwm.waitForElementToAppear(gwm.getBy("xpath", pp.loadingIconDetailPage()), 20);

		Map dictOrderDetailPP = new HashMap();
		// Name
		String Name = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_NameValue()))));
		Name = Name.substring(0, Name.indexOf('('));
		Name = Name.trim();
		dictOrderDetailPP.put("Name", Name);
		LOGGER.info("Name " + Name);

		// Age
		String DobAgeGender = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_Dob_Age_Gender_Value()))));

		// modifying as per DPS requirement
		String arrTemp[] = DobAgeGender.split(",");
		arrTemp[1] = arrTemp[1].replaceAll("Age: ", "");
		arrTemp[2] = arrTemp[2].replaceAll("Gender:", "");
		LOGGER.info("DobAgeGender" + DobAgeGender);

		String Age = arrTemp[1].trim();
		dictOrderDetailPP.put("Age", Age);
		LOGGER.info("Age" + Age);

		// DOB
		String DOB = arrTemp[0].replaceAll("DOB:", "");
		DOB = DOB.trim();
		dictOrderDetailPP.put("DOB", DOB);
		LOGGER.info("DOB" + DOB);

		// Gender
		String Gender = arrTemp[2].trim();
		dictOrderDetailPP.put("Gender", Gender);
		LOGGER.info("Gender" + Gender);

		// FacilityCenter
		String FacilityCenter = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_FacilityValue()))));
		// need to remove number
		FacilityCenter = FacilityCenter.substring(FacilityCenter.indexOf("-"), FacilityCenter.length());
		FacilityCenter = FacilityCenter.trim();
		dictOrderDetailPP.put("FacilityCenter", FacilityCenter);
		LOGGER.info("FacilityCenter" + FacilityCenter);

		// OrderId
		String OrderId = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_OrderId()))));
		OrderId = OrderId.replace("Source System OrderId: ", "");
		dictOrderDetailPP.put("OrderId", OrderId);
		LOGGER.info("OrderId" + OrderId);

		// OrderStartdate
		String OrderStartdate = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_StartDateValue()))));
		OrderStartdate = OrderStartdate.replace("Start Date: ", "");
		dictOrderDetailPP.put("OrderStartdate", OrderStartdate);
		LOGGER.info("OrderStartdate" + OrderStartdate);

		// OrderEndDate
		String OrderEndDate = "None";
		dictOrderDetailPP.put("OrderEndDate", OrderEndDate);
		LOGGER.info("OrderEndDate" + OrderEndDate);

		// OrderType
		String OrderTypeStaus = (gwm
				.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_OrderTypeValue()))));
		LOGGER.info("OrderTypeStaus" + OrderTypeStaus);

		OrderTypeStaus = OrderTypeStaus.replaceFirst("Order Type: ", "");

		String OrderType = OrderTypeStaus.substring(0, OrderTypeStaus.indexOf("("));
		OrderType = OrderType.trim();
		dictOrderDetailPP.put("OrderType", OrderType);
		LOGGER.info("Order Type " + OrderType);

		// OrderStatus
		String OrderStatus = OrderTypeStaus.substring(OrderTypeStaus.indexOf("(") + 1, OrderTypeStaus.length() - 1);
		OrderStatus = OrderStatus.trim();
		dictOrderDetailPP.put("OrderStatus", OrderStatus);
		LOGGER.info("OrderStatus" + OrderStatus);

		// DiscontinuedDate

		String DiscontinuedDate = "";
		if (OrderType.equalsIgnoreCase("Protocol")) {
			List<WebElement> objTemp = gwm.getWebElements(gwm.getBy("xpath", pp.Start_End_Date()));
			DiscontinuedDate = objTemp.get(0).getText();
			DiscontinuedDate = DiscontinuedDate.substring(DiscontinuedDate.indexOf("-") + 1, DiscontinuedDate.length());
			DiscontinuedDate = DiscontinuedDate.trim();
			dictOrderDetailPP.put("DiscontinuedDate", DiscontinuedDate);

			if (DiscontinuedDate.length() > 0) {
				dictOrderDetailPP.put("EndDate", DiscontinuedDate);
				dictOrderDetailPP.put("OrderEndDate", DiscontinuedDate);
			}
			LOGGER.info("DiscontinuedDate" + DiscontinuedDate);

			String nameTemp = objTemp.get(1).getText();
			dictOrderDetailPP.put("Protocol Name", nameTemp);
			LOGGER.info("Protocol Name" + nameTemp);
		} else {
			DiscontinuedDate = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.Start_End_Date()))));
			DiscontinuedDate = DiscontinuedDate.substring(DiscontinuedDate.indexOf("-") + 1, DiscontinuedDate.length());
			DiscontinuedDate = DiscontinuedDate.trim();
			dictOrderDetailPP.put("DiscontinuedDate", DiscontinuedDate);

			if (DiscontinuedDate.length() > 0) {
				dictOrderDetailPP.put("EndDate", DiscontinuedDate);
				dictOrderDetailPP.put("OrderEndDate", DiscontinuedDate);
			}
			LOGGER.info("DiscontinuedDate" + DiscontinuedDate);
		}

		boolean naFlag = false, ufFlag = false, postHeparinFlag = false, needleFlag = false;

		List<WebElement> list = gwm.getWebElements(gwm.getBy("xpath", pp.Order_details_part1()));
		LOGGER.info("--------------PART 1--------------");
		boolean HomeMedsFlag = true;
		for (int listCounter = 5; listCounter < list.size(); listCounter++) {
			String temp = list.get(listCounter).getText();
			String tempLabel = "", tempValue = "";

			if (temp.contains("CCPD Treatment")) {
				dictOrderDetailPP.put("Treatment", "CCPD Treatment");
			}
			if (temp.indexOf("\n") > 0) {
				tempLabel = temp.substring(0, temp.indexOf("\n")).trim();
				tempLabel = tempLabel.replace(":", "");
				tempValue = temp.substring(temp.indexOf("\n") + 1).trim();
			} else {
				if (OrderType.equalsIgnoreCase("Home Med") && !temp.equals("") && HomeMedsFlag == true) {
					dictOrderDetailPP.put("Medication", temp.trim());
					HomeMedsFlag = false;
				} else {
					tempLabel = temp.trim();
					tempLabel = tempLabel.replace(":", "");
					tempValue = "";
				}
			}
			if (tempLabel.equals("End Na"))
				naFlag = true;

			if (tempLabel.equals("Therapy Parameters")) {
				String arrTemp1[] = tempValue.split("%");
				arrTemp1[0] = arrTemp1[0].trim();
				tempLabel = arrTemp1[0].substring(0, arrTemp1[0].indexOf(":"));
				tempValue = arrTemp1[0].substring(arrTemp1[0].indexOf(":") + 1) + "%";

				dictOrderDetailPP.put(tempLabel, tempValue);
				LOGGER.info(tempLabel + " : " + tempValue);

				arrTemp1[1] = arrTemp1[1].trim();
				tempLabel = arrTemp1[1].substring(0, arrTemp1[1].indexOf(":"));
				tempValue = arrTemp1[1].substring(arrTemp1[1].indexOf(":") + 1).trim();
				tempValue = tempValue.replaceAll(" ", "");

				dictOrderDetailPP.put(tempLabel, tempValue);
				LOGGER.info(tempLabel + " : " + tempValue);
			}
			if (tempLabel.equals("Ultrafiltration"))
				ufFlag = true;
			if (tempLabel.equals("Needle Gauge/Length/Tip"))
				needleFlag = true;
			if (tempLabel.equals("CVC Post Heparin Instillation"))
				postHeparinFlag = true;

			if (tempLabel.trim().equals("Heparin") || tempLabel.equals("Flow Rates") || tempLabel.equals("Access")
					|| tempLabel.equals("Ultrafiltration") || tempLabel.equals("Telephone")
					|| tempLabel.equals("Pharmacy Phone Number")) {
				if (tempLabel.equals("Access")) {
					if (!tempValue.startsWith("Concurrent")) {
						tempValue = "Access:" + tempValue;
						if (tempValue.contains("\n")) {
							tempValue = tempValue.replace("\n", ";Secondary Access:");
						}
					}
				}
				if (tempLabel.equals("Telephone")) {
					tempValue = "Telephone:" + tempValue;
					tempValue = tempValue.replace("Fax", ";Fax");
				}
				if (tempLabel.equals("Pharmacy Phone Number")) {
					tempValue = tempLabel + ":" + tempValue;
					tempValue = tempValue.replaceAll("Pharmacy Fax Number", ";Pharmacy Fax Number");
				}
				String arrTemp1[] = tempValue.split(";");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					if (strTemp.contains("Infusion")) {
						strTemp = strTemp.replace("Infusion", "Infusion:");
					}
					if (strTemp.contains("AV Graft -")) {
						strTemp = strTemp.replace("AV Graft -", "AV Graft");
						tempValue = strTemp;
					}
					if (strTemp.contains("AV Fistula -")) {
						strTemp = strTemp.replace("AV Fistula -", "AV Fistula");
					}
					if (strTemp.contains(":")) {
						tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
						tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();
					}

					tempLabel = returnListKey(tempLabel);

					dictOrderDetailPP.put(tempLabel, tempValue);

					LOGGER.info(tempLabel + " : " + tempValue);

				}

			}

			else if (tempLabel.equals("Dialysate") || tempLabel.equals("Quantity")
					|| tempLabel.equals("Dialysate/Sodium")) {
				if (tempLabel.equals("Quantity")) {
					tempValue = "Quantity:" + tempValue;
				}
				String arrTemp1[] = tempValue.split(",");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put(tempLabel, tempValue);

					LOGGER.info(tempLabel + " : " + tempValue);

				}

			}

			else if (tempLabel.equals("Coded")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("CodedBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("CodedBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("CodedOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("CodedOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("CodedOn", tempValue.trim());

						LOGGER.info("CodedOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("CodedBy", tempValue.trim());

						LOGGER.info("CodedBy" + " : " + tempValue.trim());
					}
				}

			} else if (tempLabel.equals("Noted")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("NotedBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("NotedBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("NotedOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("NotedOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("NotedOn", tempValue.trim());

						LOGGER.info("NotedOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("NotedBy", tempValue.trim());

						LOGGER.info("NotedBy" + " : " + tempValue.trim());
					}
				}

			} else if (tempLabel.equals("Prescriber E-signed")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("Prescriber E-Signed By",
							tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info(
							"Prescriber E-Signed By" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("Prescriber E-Signed On",
							tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info(
							"Prescriber E-Signed On" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("Prescriber E-Signed On", tempValue.trim());

						LOGGER.info("Prescriber E-Signed On" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("Prescriber E-Signed By", tempValue.trim());

						LOGGER.info("Prescriber E-Signed By" + " : " + tempValue.trim());
					}
				}

			}

			else if (tempLabel.equals("Entered by")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("EnteredBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("EnteredBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("EnteredOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("EnteredOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("EnteredOn", tempValue.trim());

						LOGGER.info("EnteredOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("EnteredBy", tempValue.trim());

						LOGGER.info("EnteredBy" + " : " + tempValue.trim());
					}
				}

			} else if (naFlag && tempLabel.equals("Instructions for Use")) {
				dictOrderDetailPP.put("InstructionsForUseNaModelling", tempValue);

				LOGGER.info("InstructionsForUseNaModelling" + " : " + tempValue);

				naFlag = false;
			} else if (ufFlag && tempLabel.equals("Instructions for Use")) {
				dictOrderDetailPP.put("InstructionsForUseUltaFiltration", tempValue);

				LOGGER.info("InstructionsForUseUltaFiltration" + " : " + tempValue);

				ufFlag = false;
			}

			else if (postHeparinFlag && tempLabel.equals("CVC Post Heparin Instillation")) {
				String arrTemp1[] = tempValue.split(",");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put("PostHeparin" + tempLabel, tempValue);

					LOGGER.info("PostHeparin" + tempLabel + " : " + tempValue);

				}
			}

			else if (needleFlag && tempLabel.equals("Needle Gauge/Length/Tip")) {
				String arrTemp1[] = tempValue.split(";");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					String arrStrTemp[] = strTemp.split("/");
					if (arrStrTemp.length == 3) {
						dictOrderDetailPP.put("NeedleTip", arrStrTemp[2].trim());
						strTemp = strTemp.replace("/ " + arrStrTemp[2].trim(), "");
					}

					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					if (arrStrTemp.length >= 2) {
						dictOrderDetailPP.put(tempLabel + "Gauge", arrStrTemp[0].trim());
						dictOrderDetailPP.put(tempLabel + "Length", arrStrTemp[1].trim());
					}
					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put("Needle" + tempLabel, tempValue);

					LOGGER.info("Needle" + tempLabel + " : " + tempValue);

				}
			} else if (tempLabel.equals("Treatment Type")) {
				if (tempValue.contains("(")) {
					dictOrderDetailPP.put("TreatmentType", tempValue.substring(0, tempValue.indexOf("(")).trim());

					LOGGER.info("TreatmentType" + " : " + tempValue.substring(0, tempValue.indexOf("(")).trim());

					dictOrderDetailPP.put("Submodality",
							tempValue.substring(tempValue.indexOf("(") + 1, tempValue.indexOf(")")).trim());

					LOGGER.info("Submodality" + " : "
							+ tempValue.substring(tempValue.indexOf("(") + 1, tempValue.indexOf(")")).trim());

				} else {
					dictOrderDetailPP.put("TreatmentType", tempValue.trim());

					LOGGER.info("TreatmentType" + " : " + tempValue.trim());

				}

			}

			else {
				tempLabel = returnListKey(tempLabel);
				dictOrderDetailPP.put(tempLabel, tempValue);
			}

			LOGGER.info(tempLabel + " : " + tempValue);

		}

		List<WebElement> list1 = gwm.getWebElements(gwm.getBy("xpath", pp.Order_details_part2()));
		LOGGER.info("--------------PART 2--------------");
		for (int listCounter = 1; listCounter < list1.size(); listCounter++) {
			String temp = list1.get(listCounter).getText();
			String tempLabel = "", tempValue = "";
			if (temp.contains("CCPD Treatment")) {
				dictOrderDetailPP.put("Treatment", "CCPD Treatment");
			}
			if (temp.indexOf("\n") > 0) {
				tempLabel = temp.substring(0, temp.indexOf("\n")).trim();
				tempLabel = tempLabel.replace(":", "");
				tempValue = temp.substring(temp.indexOf("\n") + 1).trim();
			} else {
				tempLabel = temp.trim();
				tempLabel = tempLabel.replace(":", "");
				tempValue = "";
			}

			if (tempLabel.equals("End Na"))
				naFlag = true;

			if (tempLabel.equals("Ultrafiltration"))
				ufFlag = true;
			if (tempLabel.equals("Needle Gauge/Length/Tip"))
				needleFlag = true;
			if (tempLabel.equals("CVC Post Heparin Instillation"))
				postHeparinFlag = true;
			if (tempLabel.equals("Therapy Parameters")) {
				String arrTemp1[] = tempValue.split("%");
				arrTemp1[0] = arrTemp1[0].trim();
				tempLabel = arrTemp1[0].substring(0, arrTemp1[0].indexOf(":"));
				tempValue = arrTemp1[0].substring(arrTemp1[0].indexOf(":") + 1) + "%";

				dictOrderDetailPP.put(tempLabel, tempValue);
				LOGGER.info(tempLabel + " : " + tempValue);

				arrTemp1[1] = arrTemp1[1].trim();
				tempLabel = arrTemp1[1].substring(0, arrTemp1[1].indexOf(":"));
				tempValue = arrTemp1[1].substring(arrTemp1[1].indexOf(":") + 1);

				dictOrderDetailPP.put(tempLabel, tempValue);
				LOGGER.info(tempLabel + " : " + tempValue);
			}
			if (tempLabel.trim().equals("Heparin") || tempLabel.equals("Flow Rates") || tempLabel.equals("Access")
					|| tempLabel.equals("Ultrafiltration") || tempLabel.equals("Telephone")
					|| tempLabel.equals("Pharmacy Phone Number")) {
				if (tempLabel.equals("Access")) {
					if (!tempValue.startsWith("Concurrent")) {
						tempValue = "Access:" + tempValue;
						if (tempValue.contains("\n")) {
							tempValue = tempValue.replace("\n", ";Secondary Access:");
						}
					}
				}
				if (tempLabel.equals("Telephone")) {
					tempValue = "Telephone:" + tempValue;
					tempValue = tempValue.replace("Fax", ";Fax");
				}

				if (tempLabel.equals("Pharmacy Phone Number")) {
					tempValue = tempLabel + ":" + tempValue;
					tempValue = tempValue.replaceAll("Pharmacy Fax Number", ";Pharmacy Fax Number");
				}
				String arrTemp1[] = tempValue.split(";");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					if (strTemp.contains("Infusion")) {
						strTemp = strTemp.replace("Infusion", "Infusion:");
					}
					if (strTemp.contains("AV Graft -")) {
						strTemp = strTemp.replace("AV Graft -", "AV Graft :");
					}
					if (strTemp.contains("AV Fistula -")) {
						strTemp = strTemp.replace("AV Fistula -", "AV Fistula");
					}
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put(tempLabel, tempValue);

					LOGGER.info(tempLabel + " : " + tempValue);

				}

			}

			else if (tempLabel.equals("Dialysate") || tempLabel.equals("Quantity")
					|| tempLabel.equals("Dialysate/Sodium")) {
				if (tempLabel.equals("Quantity")) {
					tempValue = "Quantity:" + tempValue;
				}
				String arrTemp1[] = tempValue.split(",");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put(tempLabel, tempValue);

					LOGGER.info(tempLabel + " : " + tempValue);

				}

			}

			else if (tempLabel.equals("Coded")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("CodedBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("CodedBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("CodedOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("CodedOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("CodedOn", tempValue.trim());

						LOGGER.info("CodedOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("CodedBy", tempValue.trim());

						LOGGER.info("CodedBy" + " : " + tempValue.trim());
					}
				}

			} else if (tempLabel.equals("Noted")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("NotedBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("NotedBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("NotedOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("NotedOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("NotedOn", tempValue.trim());

						LOGGER.info("NotedOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("NotedBy", tempValue.trim());

						LOGGER.info("NotedBy" + " : " + tempValue.trim());
					}
				}

			} else if (tempLabel.equals("Prescriber E-signed")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("Prescriber E-Signed By",
							tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info(
							"Prescriber E-Signed By" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("Prescriber E-Signed On",
							tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info(
							"Prescriber E-Signed On" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("Prescriber E-Signed On", tempValue.trim());

						LOGGER.info("Prescriber E-Signed On" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("Prescriber E-Signed By", tempValue.trim());

						LOGGER.info("Prescriber E-Signed By" + " : " + tempValue.trim());
					}
				}

			}

			else if (tempLabel.equals("Entered by")) {
				if (tempValue.contains("\n")) {
					dictOrderDetailPP.put("EnteredBy", tempValue.substring(0, tempValue.indexOf("\n")).trim());

					LOGGER.info("EnteredBy" + " : " + tempValue.substring(0, tempValue.indexOf("\n")).trim());

					dictOrderDetailPP.put("EnteredOn", tempValue.substring(tempValue.indexOf("\n") + 1).trim());

					LOGGER.info("EnteredOn" + " : " + tempValue.substring(tempValue.indexOf("\n") + 1).trim());
				} else {
					try {
						Date d = new Date(tempValue);
						dictOrderDetailPP.put("EnteredOn", tempValue.trim());

						LOGGER.info("EnteredOn" + " : " + tempValue.trim());
					} catch (Exception e) {
						dictOrderDetailPP.put("EnteredBy", tempValue.trim());

						LOGGER.info("EnteredBy" + " : " + tempValue.trim());
					}
				}

			} else if (naFlag && tempLabel.equals("Instructions for Use")) {
				dictOrderDetailPP.put("InstructionsForUseNaModelling", tempValue);

				LOGGER.info("InstructionsForUseNaModelling" + " : " + tempValue);

				naFlag = false;
			} else if (ufFlag && tempLabel.equals("Instructions for Use")) {
				dictOrderDetailPP.put("InstructionsForUseUltaFiltration", tempValue);

				LOGGER.info("InstructionsForUseUltaFiltration" + " : " + tempValue);

				ufFlag = false;
			} else if (postHeparinFlag && tempLabel.equals("CVC Post Heparin Instillation")) {
				String arrTemp1[] = tempValue.split(",");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put(tempLabel, tempValue);

					LOGGER.info(tempLabel + " : " + tempValue);

				}
			}

			else if (needleFlag && tempLabel.equals("Needle Gauge/Length/Tip")) {
				String arrTemp1[] = tempValue.split(";");
				for (int arrTemp1Inc = 0; arrTemp1Inc < arrTemp1.length; arrTemp1Inc++) {
					String strTemp = arrTemp1[arrTemp1Inc];

					String arrStrTemp[] = strTemp.split("/");
					if (arrStrTemp.length == 3) {
						dictOrderDetailPP.put("NeedleTip", arrStrTemp[2].trim());
						strTemp = strTemp.replace("/ " + arrStrTemp[2].trim(), "");
					}
					tempLabel = strTemp.substring(0, strTemp.indexOf(":")).trim();
					tempValue = strTemp.substring(strTemp.indexOf(":") + 1).trim();

					if (arrStrTemp.length >= 2) {
						arrStrTemp[0] = arrStrTemp[0].replace(tempLabel, "");
						arrStrTemp[0] = arrStrTemp[0].replace(":", "");
						dictOrderDetailPP.put(tempLabel + "Gauge", arrStrTemp[0].trim());
						dictOrderDetailPP.put(tempLabel + "Length", arrStrTemp[1].trim());
					}

					tempLabel = returnListKey(tempLabel);
					dictOrderDetailPP.put("Needle" + tempLabel, tempValue);

					LOGGER.info("Needle" + tempLabel + " : " + tempValue);

				}
			} else if (tempLabel.equals("Treatment Type")) {
				dictOrderDetailPP.put("TreatmentType", tempValue.substring(0, tempValue.indexOf("(")).trim());

				LOGGER.info("TreatmentType" + " : " + tempValue.substring(0, tempValue.indexOf("(")).trim());

				dictOrderDetailPP.put("Submodality",
						tempValue.substring(tempValue.indexOf("(") + 1, tempValue.indexOf(")")).trim());

				LOGGER.info("Submodality" + " : "
						+ tempValue.substring(tempValue.indexOf("(") + 1, tempValue.indexOf(")")).trim());

			}

			else {
				tempLabel = returnListKey(tempLabel);
				dictOrderDetailPP.put(tempLabel, tempValue);
			}

			LOGGER.info(tempLabel + " : " + tempValue);

		}

		return dictOrderDetailPP;
	}

	/**
	 * @author Rakesh Gupta
	 * @description mapped UI label with dictionary key
	 * @return string: key of dictionary
	 */
	public String returnListKey(String inputKey) {
		String listKey = inputKey;
		switch (inputKey) {
		case "Order Type":
			listKey = "OrderType";
			break;

		case "Order ID":
			listKey = "OrderId";
			break;

		case "Order Start Date":
			listKey = "OrderStartdate";
			break;

		case "Order End Date":
			listKey = "OrderEndDate";
			break;

		case "Order Status":
			listKey = "OrderStatus";
			break;

		case "Discontinued Date":
			listKey = "DiscontinuedDate";
			break;

		case "Protein":
			listKey = "Protien";
			break;

		case "Sodium":
			listKey = "Sodium";
			break;

		case "Potassium":
			listKey = "Potassium";
			break;

		case "Phosphorus":
			listKey = "Phosphorus";
			break;

		case "Calories":
			listKey = "Calories";
			break;

		case "Fluid":
			listKey = "Fluid";
			break;

		case "Carbohydrate Controlled":
			listKey = "CarbohydrateControlled";
			break;

		case "Patient Diabetic Status":
			listKey = "PatientDiabeticStatus";
			break;

		case "Additional":
			listKey = "Additional";
			break;

		case "Entered by":
			listKey = "EnteredBy";
			break;

		case "Entered By":
			listKey = "EnteredBy";
			break;

		case "Noted":
			listKey = "NotedOn";
			break;

		case "Justification":
			listKey = "Justification";
			break;

		case "Treatment Type":
			listKey = "TreatmentType";
			break;

		case "Frequency":
			listKey = "Frequency";
			break;

		case "Schedule":
			listKey = "Schedule";
			break;

		case "Treatment Time":
			listKey = "TreatmentTime";
			break;

		case "Dialyzer":
			listKey = "Dialyzer";
			break;

		case "K+":
			listKey = "K+";
			break;

		case "Ca++":
			listKey = "Ca++";
			break;

		case "Bicarb":
			listKey = "Bicarb";
			break;

		case "Na":
			listKey = "Na";
			break;

		case "Na+":
			listKey = "Na";
			break;

		case "Type":
			listKey = "Type";
			break;

		case "Start Na":
			listKey = "StartNa";
			break;

		case "End Na":
			listKey = "EndNa";
			break;

		case "Temperature":
			listKey = "Temperature";
			break;

		case "Auto Flow":
			listKey = "AutoFlow";
			break;

		case "DFR":
			listKey = "DFR";
			break;

		case "BFR":
			listKey = "BFR";
			break;

		case "UF Profiling":
			listKey = "UFProfiling";
			break;

		case "Max UF Rate":
			listKey = "MaxUFRate";
			break;

		case "Bolus/Load":
			listKey = "BolusLoad";
			break;

		case "Hourly Dose":
			listKey = "HourlyDose";
			break;

		case "Stop":
			listKey = "Stop";
			break;

		case "Total Heparin Units":
			listKey = "TotalHeparinUnits";
			break;

		case "Arterial":
			listKey = "Arterial";
			break;

		case "Venous":
			listKey = "Venous";
			break;

		case "Primary Access":
			listKey = "PrimaryAccess";
			break;

		case "Concurrent":
			listKey = "Concurrent";
			break;

		case "Arterial Length":
			listKey = "ArterialLength";
			break;

		case "Arterial Gauge":
			listKey = "ArterialGauge";
			break;

		case "Venous Length":
			listKey = "VenousLength";
			break;

		case "Venous Gauge":
			listKey = "VenousGauge";
			break;

		case "Needle Tip":
			listKey = "NeedleTip";
			break;

		case "Notes":
			listKey = "Notes";
			break;

		case "Order Source":
			listKey = "OrderSource";
			break;

		case "Coded By":
			listKey = "CodedBy";
			break;

		case "Coded On":
			listKey = "CodedOn";
			break;

		case "Prescriber E-signed":
			listKey = "prescriberESigned";
			break;
		case "Target Weight":
			listKey = "TargetWeight";
			break;

		case "Bolus/load":
			listKey = "BolusLoad";
			break;

		case "Infusion":
			listKey = "Infusion";
			break;

		case "Heparin Conc":
			listKey = "HeparinConcentration";
			break;

		case "key AV Graft":
			listKey = "keyAVGraft";
			break;

		case "PostHeparinArterial":
			listKey = "PostHeparinArterial";
			break;

		case "PostHeparinVenous":
			listKey = "PostHeparinVenous";
			break;
		case "NeedleVenous":
			listKey = "NeedleVenous";
			break;

		case "NeedleArterial":
			listKey = "NeedleArterial";
			break;
		case "AV Graft":
			listKey = "AVGraft";
			break;

		case "Total Fill in 24 hours":
			listKey = "Total Fill in 24 hrs";
			break;

		case "Cycle ":
			listKey = "Cycle";
			break;

		case "Fills/Cycle":
			listKey = "Fills Per Cycle";
			break;

		case "Any Additional cycles":
			listKey = "Additional Cycles/Exchanges";
			break;

		case "Dosing Instructions":
			listKey = "Instructions";
			break;

		case "# Doses":
			listKey = "Number of Doses";
			break;
		case "Load/Hrly Concen":
			listKey = "HeparinConcentration";
			break;

		case "Load":
			listKey = "BolusLoad";
			break;

		case "Instructions":
			listKey = "Sig";
			break;

		case "Quantity":
			listKey = "Quantity";
			break;

		case "Telephone":
			listKey = "Pharmacy Phone";
			break;

		case "Fax":
			listKey = "Pharmacy Fax";
			break;

		case "Pharmacy Phone Number":
			listKey = "Pharmacy Phone";
			break;

		case "Pharmacy Fax Number":
			listKey = "Pharmacy Fax";
			break;

		default:
			LOGGER.info("enter code for input key " + inputKey);
		}

		return listKey;

	}

	/**
	 * @author Rakesh Gupta
	 * @description return orderId and Patient name from order details page
	 * @return a list which contains orderId and Patient name
	 */
	public Dictionary FetchOrderIdAndPatientName() {
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("xpath", pp.Select_Order_No("1"))));
		GenericHelper.sleepSeconds(3);
		Dictionary dictOrderDetailPP = new Hashtable();
		// Name
		String Name = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_NameValue()))));
		Name = Name.substring(0, Name.indexOf('('));
		Name = Name.trim();
		dictOrderDetailPP.put("Name", Name);
		LOGGER.info("Name " + Name);

		// OrderId
		String OrderId = (gwm.readWebElementText(gwm.getWebElement(gwm.getBy("xpath", pp.orderDetail_OrderId()))));
		OrderId = OrderId.replace("Source System OrderId: ", "");
		dictOrderDetailPP.put("OrderId", OrderId);
		LOGGER.info("OrderId" + OrderId);
		return dictOrderDetailPP;
	}

	/**
	 * @author Rakesh Gupta
	 * @description Search and fetch order detail value
	 * @param orderName
	 * @param orderType
	 * @return
	 */
	public Map SearchandfetchOrderDetailPP(String orderName, String orderType) {
		Click_On_UnsignedOrder();
		Click_Filter_Button();
		Apply_PP_Filter(orderName);// Apply Filter for TargetWeight order
		Boolean orderPresent = Apply_PP_Filter_Order_Status(orderType); // Apply filter for order status

		Map OrderDetailPP = new HashMap();
		if (orderPresent) {
			OrderDetailPP = fetchOrderDetailPP();// Fetch TargetWeight order data
			OrderDetailPP.put("Application", "PP");
		}
		return OrderDetailPP;
	}

	/**
	 * @author Rakesh Gupta
	 * @description Search and fetch order detail value for Change order type
	 * @param orderName
	 * @param orderType
	 * @return
	 */
	public String SearchfetchOrderDetailCHGPP(String orderName, String orderType) {
		Click_On_UnsignedOrder();
		Click_Filter_Button();
		Apply_PP_Filter(orderName);// Apply Filter for diet order
		Boolean orderPresent = Apply_PP_Filter_Order_Status(orderType); // Apply filter for order status
		String OrderDetailPP = "";
		if (orderPresent) {
			OrderDetailPP = fetchOrderDetailCHGPP();
			OrderDetailPP = OrderDetailPP + orderName + orderType + "CHANGED" + "None";
		}

		return OrderDetailPP;
	}
}
