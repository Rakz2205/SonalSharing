package com.apps.oneview.common;

import java.util.List;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.apps.keycloak.KeycloakAPIComponent;
import com.apps.oneview.services.UsersAPIComponent;
import com.apps.pixit.PixitAPIComponent;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.GenericWebMethods;
import com.base.TestBase;

import io.restassured.response.Response;

public class HomePageComponent {
	WebDriver webdriver;
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private HomePageCaller hc = new HomePageCaller();
	private GenericWebMethods gwm;
	private Boolean hasInA = false;
	private Boolean hasMedCheck = false;
	private String clinicalSystems;
	public KeycloakAPIComponent kcAPI;
	private UsersAPIComponent usersServComp = new UsersAPIComponent();
	private String ovUserName, ovFirstName, ovLastName;

	public HomePageComponent(WebDriver wd, KeycloakAPIComponent kcAPI) {
		LOGGER.info("enter HomePageComponent constructor");
		gwm = new GenericWebMethods(wd);
		if (kcAPI != null) {
			this.kcAPI=kcAPI;
		} else {
			this.kcAPI = new KeycloakAPIComponent();
		}

	}

	/**
	 * Function gets the logged in user from keycloak based on the 
	 * 			the email assigned to the dps-user-info element
	 * 
	 * @param username
	 *            keycloak login username
	 * @return String the keycloak user name for the logged in OVBS user
	 */
	public String getUserFromKeyCloak() {
		LOGGER.info("enter HomePageComponent.getUserFromKeyCloak()");
		// get the user identifier to use as a search parameter
		WebElement anElement = gwm.getWebElement(By.cssSelector(hc.dpsUserInfoCss()));
		String email = gwm.getTagAttribute(anElement, "user-email");
		Response userSearch = kcAPI.getKeycloakUsers(email);
		JSONArray userArray = new JSONArray(userSearch.body().asString());
		if ((userSearch.getStatusCode() != 200) || (userArray.length() != 1 )) {
			Assert.fail("Could not get user list from KeyCloak");
		}
		return userArray.getJSONObject(0).getString("username");
	}
	
	/**
	 * Function determines if the user is MedCheck enabled
	 * 
	 * @param username
	 *            keycloak login username
	 * @return null
	 */
	public void getMedCheckStatus() {
		LOGGER.info("enter HomePageComponent.getMedCheckStatus()");
		// get the user name from the email address
		String userName = getUserFromKeyCloak();
		// get the keycloak admin token for the logged in user
		String password = TestBase.LOGIN_CREDS.get(userName);
		String adminToken = kcAPI.getToken(userName, password);
		//get the RPT token for the logged in user using the admin token
		String rptToken = kcAPI.getOVBSRPTToken(adminToken);
		hasMedCheck = usersServComp.isMedCheckEnabled(rptToken);
	}
	
	/**
	 * Function validates the InA status from the Pixitcomponent
	 * 
	 * @param username
	 *            keycloak login username
	 * @return null
	 */
	public void getInAStatus(String userName) {
		LOGGER.info("enter HomePageComponent.setInAStatus()");
		// get the activeDirectoryId from KeyCloak for the current user 
		Response kcResponse = kcAPI.getKeycloakUserAttributes(userName);
		// persist the user details
		JSONObject userJO = new JSONObject(kcResponse.body().asString());
		setOvUserName(userJO.getString("username"));
		setOvFirstName(userJO.getString("firstName"));
		setOvLastName(userJO.getString("lastName"));
		String activeDirectoryId = kcResponse.body().jsonPath().get("attributes.activeDirectoryId").toString();
		// remove the [] added for representation as json array
		activeDirectoryId = activeDirectoryId.substring(1, activeDirectoryId.length()-1);
		
		
		// make the call to the InA interface 
		PixitAPIComponent pac = new PixitAPIComponent();
		hasInA = pac.isInAEnabled(activeDirectoryId);
	}
	
	/**
	 * Function checks for the Pendo and TOS (Terms Of Service) modal windows
	 * 			and clears the windows so the tests aren't disrupted
	 * 
	 * @return null
	 */
	public void clearPendoTOSModals() {
		acceptTOS();
		closePendoModalWindow();
	}
	
	/**
	 * Function valdiates the home page app opens
	 * 
	 * @return null
	 */
	public void verifyHomePageOpens() {
		LOGGER.info("enter HomePageComponent.verifyHomePageOpens()");
		// validate the app name appears
		Assert.assertTrue(gwm.waitForTextInElement(gwm.getWebElement(By.cssSelector(hc.appNameCss())), 
				"HOME"), "Error: App name did not appear in the OVBS Header");
		gwm.isElementVisible(gwm.getWebElement(gwm.getBy("cssSelector", hc.appNameCss())));
		// validate the davita logo 
		WebElement anElement = gwm.getWebElement(gwm.getBy("cssSelector", hc.davitaLogoCss()));
		Assert.assertNotNull(anElement, "Davita Logo is not present");
		WebElement anImage = anElement.findElement(By.tagName("img"));
		String imgSource= anImage.getAttribute("src");
		Assert.assertEquals(imgSource, GenericHelper.getBaseURL(TestBase.URL_Path.OneViewBase)+GenericVariable.OV_LOGO_REL_PATH);
		// validate the Patient Search Button exits
		anElement = gwm.getWebElement(gwm.getBy("cssSelector", hc.patientSearchButtonCss()));
		WebElement aButton = anElement.findElement(By.tagName("button"));
		if (aButton == null || !aButton.isEnabled()) {
			Assert.fail("Patient Search Button is not enabled");
		}
		// validate the user name appears as expected
		anElement = gwm.getWebElement(gwm.getBy("cssSelector", hc.dpsUserInfoCss()));
		WebElement aHeader = anElement.findElement(By.tagName("h5"));
		Assert.assertEquals(aHeader.getText().trim(), getOvFirstName()+" "+getOvLastName().trim());
	}

	/**
	 * Function valdiates the main nav menu is displayed 
	 * 
	 * @return null
	 */
	public void verifyNavMenuDisplay() {
		LOGGER.info("enter HomePageComponent.verifyNavMenuDisplay()");
		Dimension viewPortDim = gwm.getViewportDims();
		LOGGER.info("View port Width: "+Integer.toString(viewPortDim.getWidth())
					+"	Height: "+Integer.toString(viewPortDim.getHeight()));
		WebElement topUl;
		WebElement mainNav = gwm.getWebElement(By.tagName(hc.mainNavigationTaggname()));
		Assert.assertTrue(viewPortDim.getWidth() >= 1280);
		Assert.assertNotNull(mainNav.findElement(By.cssSelector(hc.mainNavigationExpandedCss())));	
	}
	
	/**
	 * Function valdiates the comms hub component is displayed 
	 * 
	 * @return null
	 */
	public void verifyCommsHubDisplay() {
		LOGGER.info("enter HomePageComponent.verifyCommsHubDisplay()");
		WebElement commsComponent= gwm.getWebElement(By.id(hc.commsHubComponentId()));
		Assert.assertNotNull(commsComponent);
	}

	/**
	 * Function valdiates the myTasks component is displayed with the right number of cards
	 * 
	 * @return null
	 */
	public void verifyMyTasksComponents() {
		LOGGER.info("enter HomePageComponent.verifyMyTasksComponents()");
		getMedCheckStatus();
		// since all of the tasks are basically acync calls waiting for the long running Unsigned Orders task to load
		gwm.waitForTextToBePresentInElement(gwm.getWebElements(By.tagName(hc.mytasksCardsTagname())).get(0), 
				"Unsigned Orders", GenericVariable.intElementWaitTimeout, false);		
		List<WebElement> taskCards = gwm.getWebElements(By.cssSelector(hc.mytasksCardsCss()));
		
		if (hasInA) {
			if (hasMedCheck) {
				Assert.assertEquals(taskCards.size(), hc.mytasksCount());
			} else {
				Assert.assertEquals(taskCards.size(), hc.mytasksCount() - 1);
			}
			
		} else {
			Assert.assertEquals(taskCards.size(), hc.mytasksCount() - 2);
		}
	}
	
	/**
	 * Function valdiates the DaVita Aps component is displayed
	 * 
	 * @return null
	 */
	public void verifyDavitaAppsDisplay() {
		LOGGER.info("enter HomePageComponent.verifyDavitaAppsDisplay()");
		WebElement davitaApps= gwm.getWebElement(By.tagName(hc.davitaAppsTagname()));
		Assert.assertNotNull(davitaApps);
	}
	
	/**
	 * Function clears the Terms Of Service (TOS)
	 * 
	 * @return null
	 */
	public void acceptTOS() {
		if (gwm.isElementPresent(gwm.getBy("xpath", hc.disagreeBtnXpath()))) {
			gwm.scroll_To_Bottom_Of_Modal_Window();
			gwm.clickWebElement((gwm.getWebElement(gwm.getBy("xpath", hc.agreeBtnXpath()))));
		} 
	}

	/**
	 * Function clears the Pendo Guide
	 * 
	 * @return null
	 */
	public void closePendoModalWindow() {
		if (gwm.isElementPresent(gwm.getBy("cssSelector", hc.pendoCloseCss()))) {
			gwm.clickWebElement((gwm.getWebElement(gwm.getBy("cssSelector", hc.pendoCloseCss()))));
		}
	}
	public String getOvUserName() {
		return ovUserName;
	}

	public String getOvFirstName() {
		return ovFirstName;
	}

	public String getOvLastName() {
		return ovLastName;
	}	
	
	public void setOvUserName(String userName) {
		ovUserName = userName;
	}

	public void setOvFirstName(String firstName) {
		ovFirstName = firstName;
	}

	public void setOvLastName(String lastName) {
		ovLastName = lastName;
	}	
}
