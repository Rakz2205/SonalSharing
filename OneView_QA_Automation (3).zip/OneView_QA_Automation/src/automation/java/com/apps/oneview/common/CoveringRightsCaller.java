package com.apps.oneview.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import org.testng.Assert;

@SuppressWarnings("static-access")
public class CoveringRightsCaller {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private static CoveringRightsCaller PropertiesCache;
	private final static Properties configProp = new Properties();
	private static String Propertyfilename = "coveringRights.properties";

	public CoveringRightsCaller setPropertyfilename(String Propertyfilename) {
		this.Propertyfilename = Propertyfilename;
		return this;
	}

	/***
	 * configcaller loads the property called in the .properties file
	 */

	public CoveringRightsCaller() {
		// Private constructor to restrict new instances
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(Propertyfilename);
		LOGGER.info("Reading properties from file: " + Propertyfilename);
		try {
			configProp.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Bill Pugh Solution for singleton pattern

	/**
	 * Directive: Only use the static methods for testing the framework
	 * functionality. Write getters to access specific properties so that no input
	 * strings are hard coded in your tests.
	 */

	public static class ResourceLoader {
		private static final CoveringRightsCaller INSTANCE = new CoveringRightsCaller();
	}

	public static CoveringRightsCaller getInstance() {
		return ResourceLoader.INSTANCE;
	}

	public static String getProperty(String key) {
		return configProp.getProperty(key);
	}

	public Set<String> getAllPropertyNames() {
		return configProp.stringPropertyNames();
	}

	public boolean containsKey(String key) {
		return configProp.containsKey(key);
	}

	public void setProperty(String key, String value) {
		configProp.setProperty(key, value);
	}

	/**
	 * adding all callers for environments this is where you call a specific
	 * environment please do not hardcode the in your code add a propertycaller for
	 * it under this segment.
	 */
	
	// Sanity test locators
	public String menuSettingsId() {
		return PropertiesCache.getInstance().getProperty("menuSettingsId");
	}
	
	public String menuSettingsCoveringRightsId() {
		return PropertiesCache.getInstance().getProperty("menuSettingsCoveringRightsId");
	}

	public String coveringRightsAppNameId() {
		return PropertiesCache.getInstance().getProperty("crAppNameId");
	}
	
	public String crAppNameLabel() {
		return PropertiesCache.getInstance().getProperty("crAppNameLabel");
	}
	
	public String coveringRightsTabsCss() {
		return PropertiesCache.getInstance().getProperty("coveringRightsTabsCss");
	}
	
	public String assignRightsTabLabel() {
		return PropertiesCache.getInstance().getProperty("assignRightsTabLabel");
	}
	
	public String rightsAssignedTabLabel() {
		return PropertiesCache.getInstance().getProperty("rightsAssignedTabLabel");
	}
	
	public int covRightsTabCount() {
		return Integer.valueOf(PropertiesCache.getInstance().getProperty("covRightsTabCount"));
	}
	
	public String tabActiveBorderBottomColorChrome() {
		return PropertiesCache.getInstance().getProperty("tabActiveBorderBottomColorChrome");
	}
	
	public String tabActiveBorderBottomColorOthers() {
		return PropertiesCache.getInstance().getProperty("tabActiveBorderBottomColorOthers");
	}
	
	public String tabActiveClass() {
		return PropertiesCache.getInstance().getProperty("tabActiveClass");
	}
	
	public String covRightsContainerName() {
		return PropertiesCache.getInstance().getProperty("covRightsContainerName");
	}
	
	public String covRightsTabLink() {
		return PropertiesCache.getInstance().getProperty("covRightsTabLink");
	}
	
	public String assignRightsTabHelpText() {
		return PropertiesCache.getInstance().getProperty("assignRightsTabHelpTextValue0")+" "
				+PropertiesCache.getInstance().getProperty("assignRightsTabHelpTextValue1");
	}
	
	public String rightsAssignedTabHelpText() {
		return PropertiesCache.getInstance().getProperty("rightsAssignedTabHelpTextValue");
	}
	
	public String toolTipCss() {
		return PropertiesCache.getInstance().getProperty("toolTipCss");
	}
	
	public String toolTipTagName() {
		return PropertiesCache.getInstance().getProperty("toolTipTagName");
	}
	
	public String getAssignedToggleCss() {
		return PropertiesCache.getInstance().getProperty("listItemAssignedToggle");
	}
	
	public String getUnassignedToggleCss() {
		return PropertiesCache.getInstance().getProperty("listItemUnassignedToggle");
	}
	
	public String getPhysNameWithRightsXpath() {
		return PropertiesCache.getInstance().getProperty("physNameWithRightsXpath");
	}

	public String getPhysNameWithoutRightsXpath() {
		return PropertiesCache.getInstance().getProperty("physNameWithoutRightsXpath");
	}
	
	public String getSelectActiveCenterCheckboxXpath() {
		return PropertiesCache.getInstance().getProperty("activeCenterCheckboxXpath");
	}

	public String getSelectAllCheckboxCss() {
		return PropertiesCache.getInstance().getProperty("selectAllCheckboxCss");
	}
	
	public String getSaveAndCloseButtonCss() {
		return PropertiesCache.getInstance().getProperty("saveAndCloseButton");
	}

	public String getToggleForPhysRightsAssignedXpath(String physName) {
		return PropertiesCache.getInstance().getProperty("toggleForPhysRightsAssignedXpath").replace("%s", physName);
	}
	
	public String getToggleForPhysRightsUnassignedXpath(String physName) {
		return PropertiesCache.getInstance().getProperty("toggleForPhysRightsUnassignedXpath").replace("%s", physName);
	}
	
	public String getViewHistoryLinkForPhysXpath(String physName) {
		return PropertiesCache.getInstance().getProperty("viewHistoryForPhys").replace("%s", physName);
	}
	
	public String getEditFacilitiesLinkXpath(String physName) {
		return PropertiesCache.getInstance().getProperty("editFacilitiesForPhys").replace("%s", physName);
	}
	
	public String getViewHistoryDatesCss() {
		return PropertiesCache.getInstance().getProperty("viewHistoryDates");
	}
	
	public String getViewHistoryPreviousCss() {
		return PropertiesCache.getInstance().getProperty("viewHistoryPrevious");
	}
	
	public String getPrevAssignedCRText() {
		return PropertiesCache.getInstance().getProperty("prevAssignedCRText");
	}
}