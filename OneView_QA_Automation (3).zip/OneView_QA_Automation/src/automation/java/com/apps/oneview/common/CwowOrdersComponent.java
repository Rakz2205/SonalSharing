package com.apps.oneview.common;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.base.GenericHelper;
import com.base.GenericWebMethods;


public class CwowOrdersComponent {
	WebDriver webdriver;
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private OrderCaller oc = new OrderCaller();
	private EnvironmentCaller ec = new EnvironmentCaller();
	private GenericWebMethods gwm;
	private GenericHelper gh;
	List<WebElement> allRows;
	private WebElement orderTable;

	public CwowOrdersComponent(WebDriver wd) {
		LOGGER.info("enter HomePageComponent constructor");
		gwm = new GenericWebMethods(wd);
	}
	
	/***
	 * Function to navigate Task-->Order
	 * 
	 */
	public void navigateToOrderTab() 
	{
		LOGGER.info("enter OrdersComponent.NavigateToOrderTab()");
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id",oc.homePageTaskId())));
		
		gwm.clickWebElement(gwm.getWebElement(gwm.getBy("id",oc.homePageTaskOrdersId())));
		
	//	gwm.waitForElementToDisappear(gwm.getWebElement(gwm.getBy("xpath", oc.pageLoaderXpath())), (int)ec.getPageWaitTimeout());
		
	}
	
	/***
	 *  Function to verify Orders page opens after clicking Task-->Order
	 */
	public void verifyOrderPageOpens() {
		LOGGER.info("enter OrdersComponent.VerifyOrderPageOpens()");
		String strTemp=gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.ordersLabelHeaderCSS())));
		
		Assert.assertTrue(strTemp.toUpperCase().contains("ORDERS"), "Verify Order Screen is displayed");
	}
	
	/***
	 * Function to Verify Cwow Tab has default focus on Order page
	 */
	public void verifyCwowHasDefaultFocus() {
		LOGGER.info("enter OrdersComponent.verifyCwowHasDefaultFocus()");
		
		String strTemp=gwm.readWebElementText(gwm.getWebElement(gwm.getBy("cssSelector", oc.cwowActiveFocusCSS())));
		
		Assert.assertEquals(strTemp.toUpperCase().contains("CWOW ORDERS"), true, "Verify CWOW Order Tab has Default Focus");
		
	}
	
	/***
	 * Funtion to set window dimension and validate CWOW order view format
	 * @param portalSize : Screen dimension
	 */
	public void setSizeAndVerifyOrderView(String portalSize) {
		LOGGER.info("enter OrdersComponent.setSizeAndVerifyOrderView()");
		WebElement objTemp;
		switch (portalSize.toLowerCase())
		{
			case "medium":
				gwm.setBrowserSize(800, 600);
				objTemp = gwm.getWebElement(gwm.getBy("cssSelector", oc.cwowOrderTableViewCSS()));
				Assert.assertFalse(objTemp.isDisplayed(), "Verify CWOW Order is displayed as list view");
				break;
				
			case "big":
				gwm.setBrowserSize(1366, 768);
				objTemp = gwm.getWebElement(gwm.getBy("cssSelector", oc.cwowOrderTableViewCSS()));
				Assert.assertTrue(objTemp.isDisplayed(), "Verify CWOW Order is displayed as Table view");
				break;
		}
		
	}
	
	/**
	 * TO read total snappy order count present at left bottom @ return: total
	 * snappy order count
	 */
	public int readTotalCount() { // update without return_txt_xpath
		//waitTillElementDisappear(By.xpath(oc.PaginationNotAvaliable()),50);
		WebElement count = gwm.getWebElement(By.xpath(oc.totalCount()));
	    gwm.waitForTextToBePresentInElement(count , "of" , 10 , false);		
		String Page_Count = gwm.readWebElementText(count);
		String[] arrSplit = Page_Count.split(" ");
		String Total_Count = arrSplit[4];
		return Integer.parseInt(Total_Count);
	}
	
	/**
	 * 
	 * @param orderType type to be searched
	 * @param orderStatus staus to be searched
	 * @return row number with specific order type
	 */
	public int findOrderWithName(String orderType, String LastName, String gridType)
	{
		int rowCounter = -1;
		int totalCount = readTotalCount(); // created new to only see one grid* fix 
		boolean boolFound = false;
		orderTable = null;
		
		if ((gridType != null) && (gridType.equalsIgnoreCase("REFUTE"))) {
			orderTable = gwm.getWebElement(By.tagName(oc.getRefutedOrderGrid("name")));
		} else {
			orderTable = gwm.getWebElement(By.tagName(oc.getOrderGrid("name")));
		}
		WebElement rightArrow = gwm.getWebElement(By.cssSelector(oc.rightArrowPagination()));
		for (int pageCounter = 0; pageCounter < totalCount; pageCounter++) {
			orderTable = gwm.getWebElement(By.cssSelector(oc.getOrderGrid("css")));
			allRows = orderTable.findElements(By.cssSelector(oc.getCwowOrderGridRows()));
			for (rowCounter = 0; rowCounter < allRows.size(); rowCounter++) {
				WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowCounter + "","3")));
				WebElement ScreenText = gwm.getWebElement(By.xpath(oc.summaryColText(rowCounter + "","7")));
				String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
				String ScreenOrderText =  gwm.readWebElementText(ScreenText).toUpperCase();
				if (ScreenOrderText.startsWith(orderType.toUpperCase())&& ScreenOrderName.startsWith(LastName.toUpperCase()))
				{
					boolFound = true;
					break;
				}
			}
			if (boolFound) {
				break;
			}
			else
			{
				rowCounter=-1;
			}
			pageCounter = pageCounter + allRows.size();
			// click on next page
			if (!rightArrow.getAttribute("class").contains("disabled")) {
				rightArrow.click();
				gwm.waitForElementToDisappear(gwm.getWebElement(By.className(oc.pageLoader())), 10);
			}
		}
		return rowCounter;
	}
	
	/**
  	 * @param OrderType can be DNR, DIET, TX_ICHD  / LastName should be lastname patient  
  	 * @return Map of data to compare to api record  
  	 * Maps  Details page
  	 */
	
	public Map OrderDetailsList(String OrderType , String LastName) {
		// must match put names with api ... some will need logic to match 
		final int rowNo;
		rowNo = findOrderWithName(OrderType, LastName, null);	 // update for med/lab/tx orders
		gwm.clickWebElement(gwm.getWebElement(By.xpath(oc.orderRow(rowNo + ""))));
		Map dnrOrderDetails=new HashMap();
		WebElement objTemp;
		
		// name
		 
		gwm.waitForElementToAppear(By.className(oc.patientNameClass()), 15);
		objTemp = gwm.getWebElement(By.className(oc.patientNameClass()));
		dnrOrderDetails.put("patientName", objTemp.getText());
		LOGGER.info("Name " + objTemp.getText());
		
		// dob
		objTemp = gwm.getWebElement(By.id(oc.patientDOBId()));
		String temp1 = objTemp.getText();
		temp1 = gh.dateFormat(temp1, oc.dateFormatPattern());
		dnrOrderDetails.put("DOB", temp1);
		LOGGER.info("DOB " + temp1);
		
		// facility 
		gwm.waitForElementToAppear(By.id(oc.patientFacilityId()), 15);
		objTemp = gwm.getWebElement(By.id(oc.patientFacilityId()));
		dnrOrderDetails.put("facilityName", "- " + objTemp.getText());
		LOGGER.info("facilityName " + "- " + objTemp.getText());
		
		// mpi
		objTemp = gwm.getWebElement(By.id(oc.patientMPId()));
		dnrOrderDetails.put("mpi", objTemp.getText());
		LOGGER.info("mpi " + objTemp.getText());
		
		// dnr policy 
		if (OrderType.contains("DNR")) {
		objTemp = gwm.getWebElement(By.xpath(oc.dnrPolicyXpath()));
		dnrOrderDetails.put("acknowledgeText", objTemp.getText());
		LOGGER.info("dnrPolicy" + objTemp.getText());
		}
		
		List<WebElement> list = gwm.getWebElements(By.className(oc.orderDetailPageAllFieldsClass()));
		List<WebElement> listLabel = gwm.getWebElements(By.className(oc.orderDetailPageAllFieldsLabelClass()));

		for (int listIterator = 0; listIterator < list.size(); listIterator++) {
			String temp = list.get(listIterator).getText().trim();
			String tempLabel = listLabel.get(listIterator).getText().trim();
			if(tempLabel.length()>0)
			{
				if (tempLabel.charAt(0) == '(') {
					temp = temp + " " + tempLabel;
					tempLabel = "Justification";
				}
			}
			
			if(tempLabel.equalsIgnoreCase("")) { //dnr policy 
				tempLabel = "Instructions";
			}
			boolean naFlag = false, ufFlag = false;
			if (temp.equals("End Na"))
				naFlag = true;

			if (temp.equals("UF Profiling"))
				ufFlag = true;
			switch (tempLabel) {
			case "Type": //fix 
				if(temp.equalsIgnoreCase("STEP") || temp.equalsIgnoreCase("LINEAR") || temp.equalsIgnoreCase("EXPONENTIAL"))
				{
					dnrOrderDetails.put("orderType", temp);
					LOGGER.info(" " + temp);
				}
				else
				{
					if(temp.contains("PRN"))
					{
						temp="PRN";
					}
					dnrOrderDetails.put("orderType", temp);
					LOGGER.info("OrderType " + temp);
				}
				break;

			case "ID":
				dnrOrderDetails.put("orderNumber", temp);
				LOGGER.info("orderNumber " + temp);
				break;

			case "Start Date":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("orderStartDate", temp);
				LOGGER.info("orderStartDate " + temp);
				break;

			case "End Date":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("orderEndDate", temp);
				LOGGER.info("orderEndDate " + temp);
				break;

			case "Status":
				dnrOrderDetails.put("orderStatus", temp);
				LOGGER.info("OrderStatus " + temp);
				break;

			case "Discontinued Date":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("discontinuedDate", temp);
				LOGGER.info("discontinuedDate " + temp);
				break;

			case "Protein":
				dnrOrderDetails.put("protein", temp);
				LOGGER.info("Protien " + temp);
				break;

			case "Sodium":
				dnrOrderDetails.put("sodium", temp);
				LOGGER.info("Sodium " + temp);
				break;

			case "Potassium":
				dnrOrderDetails.put("potassium", temp);
				LOGGER.info("Potassium " + temp);
				break;
		
			case "Phosphorus":
				dnrOrderDetails.put("phosphorus", temp);
				LOGGER.info("Phosphorus " + temp);
				break;

			case "Calories":
				dnrOrderDetails.put("calories", temp);
				LOGGER.info("Calories " + temp);
				break;

			case "Fluid":
				dnrOrderDetails.put("fluid", temp);
				LOGGER.info("Fluid " + temp);
				break;

			case "Carbohydrate Controlled":
				dnrOrderDetails.put("carbohydrateControlled", temp);
				LOGGER.info("CarbohydrateControlled " + temp);
				break;

			case "Patient Diabetic Status":
				dnrOrderDetails.put("patientDiabeticStatus", temp);
				LOGGER.info("PatientDiabeticStatus " + temp);
				break;

			case "Additional":
				dnrOrderDetails.put("additional", temp);
				LOGGER.info("Additional " + temp);
				break;

			case "Provider":
				dnrOrderDetails.put("providerName", temp);
				LOGGER.info("Provider " + temp);
				break;

			case "Collaborating Physician":
				dnrOrderDetails.put("collaborating_Physician", temp);
				LOGGER.info("Collaborating_Physician " + temp);
				break;

			case "Entered On":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("orderEnterDate", temp);
				LOGGER.info("orderEnterDate " + temp);
				break;

			case "Noted On":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("notedOn", temp);
				LOGGER.info("NotedOn " + temp);
				break;

			case "Justifications":
				temp=temp.replace("()", "");
				dnrOrderDetails.put("justification", temp); //check
				LOGGER.info(" " + temp);
				break;

			case "Treatment Type":
				dnrOrderDetails.put("treatmentType", temp);
				LOGGER.info(" " + temp);
				break;

			case "Frequency":
				dnrOrderDetails.put("frequency", temp);
				LOGGER.info(" " + temp);
				break;

			case "Schedule":
				dnrOrderDetails.put("schedule", temp);
				LOGGER.info(" " + temp);
				break;

			case "Treatment Time":
				dnrOrderDetails.put("treatmentTime", temp);
				LOGGER.info(" " + temp);
				break;

			case "Dialyzer":
				dnrOrderDetails.put("dialyzer", temp);
				LOGGER.info(" " + temp);
				break;

			case "K+":
				dnrOrderDetails.put("K+", temp);
				LOGGER.info(" " + temp);
				break;

			case "Ca++":
				dnrOrderDetails.put("Ca++", temp);
				LOGGER.info(" " + temp);
				break;

			case "Bicarb":
				dnrOrderDetails.put("biCarb", temp);
				LOGGER.info(" " + temp);
				break;

			case "Na":
				dnrOrderDetails.put("Na", temp);
				LOGGER.info(" " + temp);
				break;

			case "Start Na":
				dnrOrderDetails.put("startNa", temp);
				LOGGER.info(" " + temp);
				break;

			case "End Na":
				dnrOrderDetails.put("endNa", temp);
				LOGGER.info(" " + temp);
				break;

			case "Temperature":
				dnrOrderDetails.put("temperature", temp);
				LOGGER.info(" " + temp);
				break;

			case "Auto Flow":
				dnrOrderDetails.put("autoFlow", temp);
				LOGGER.info(" " + temp);
				break;

			case "DFR":
				dnrOrderDetails.put("DFR", temp);
				LOGGER.info(" " + temp);
				break;

			case "BFR":
				dnrOrderDetails.put("BFR", temp);
				LOGGER.info(" " + temp);
				break;

			case "UF Profiling":
				dnrOrderDetails.put("UFProfiling", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "UFProfile":
				dnrOrderDetails.put("UFProfile", temp);	//profile on ui 
			    LOGGER.info(" " + temp);
			    break;
			    
			case "Max UF Rate":
				dnrOrderDetails.put("maxUFRate", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Instructions for Use":
				if (naFlag) {
					dnrOrderDetails.put("InstructionsForUseNaModelling", temp);
					LOGGER.info(" " + temp);
				}
				if (ufFlag) {
					dnrOrderDetails.put("InstructionsForUseUltaFiltration", temp);
					LOGGER.info(" " + temp);
				}
				break;

			case "Bolus/Load":
				dnrOrderDetails.put("BolusLoad", temp);
				LOGGER.info(" " + temp);
				break;

			case "Hourly Dose":
				dnrOrderDetails.put("hourlyDose", temp);
				LOGGER.info(" " + temp);
				break;

			case "Stop":
				dnrOrderDetails.put("stop", temp);
				LOGGER.info(" " + temp);
				break;

			case "Total Heparin Units":
				dnrOrderDetails.put("totalHeparinUnits", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial":
				dnrOrderDetails.put("arterial", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous":
				dnrOrderDetails.put("venous", temp);
				LOGGER.info(" " + temp);
				break;

			case "Primary Access":
				temp=temp.replaceAll("- ","");
				dnrOrderDetails.put("access", temp);
				LOGGER.info(" " + temp);
				break;

			case "Concurrent":
				if (temp.equals("False"))
					temp = "No";
				else
					temp = "Yes";
				dnrOrderDetails.put("concurrent", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial Length":
				dnrOrderDetails.put("arterialLength", temp);
				LOGGER.info(" " + temp);
				break;

			case "Arterial Gauge":
				dnrOrderDetails.put("arterialGauge", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous Length":
				dnrOrderDetails.put("venousLength", temp);
				LOGGER.info(" " + temp);
				break;

			case "Venous Gauge":
				dnrOrderDetails.put("venousGauge", temp);
				LOGGER.info(" " + temp);
				break;

			case "Needle Tip":
				dnrOrderDetails.put("veedleTip", temp);
				LOGGER.info(" " + temp);
				break;

			case "Notes":
				dnrOrderDetails.put("notes", temp);
				LOGGER.info(" " + temp);
				break;

			case "Source":
				dnrOrderDetails.put("source", temp);
				LOGGER.info(" " + temp);
				break;

			case "Coded By":
				dnrOrderDetails.put("codedBy", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Coded On":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("codedOn", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Target Weight":
				dnrOrderDetails.put("targetWeight", temp);
				LOGGER.info(" " + temp);
				break;
			
			case "Entered By":
				dnrOrderDetails.put("enteredBy", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Noted By":
				dnrOrderDetails.put("notedBy", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Total Fill in 24 hours":
				dnrOrderDetails.put("Total Fill in 24 hrs", temp);
				LOGGER.info(" " + temp);
				break;
			
			case "Prescriber E-Signed On":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("Prescriber E-Signed On", temp);
				LOGGER.info(" " + temp);
				break;
			
			case "Order Source":
				dnrOrderDetails.put("orderSource", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Dosing Instructions":
				dnrOrderDetails.put("instructions", temp);
				LOGGER.info(" " + temp);
				break;
			
			case "Load/Hourly Dose Concentration":
				dnrOrderDetails.put("heparinConcentration", temp);
				LOGGER.info(" " + temp);
				break;
			
			case "Heparin Concentration":
				dnrOrderDetails.put("heparinConcentration", temp);
				LOGGER.info(" " + temp);
				break;
				
			case "Written Date":
				temp = gh.dateFormat(temp, oc.dateFormatPattern());
				dnrOrderDetails.put("Written Date", temp);
				LOGGER.info("OrderEndDate " + temp);
				break;
				
			case "DNR Order Acknowledgement":
				dnrOrderDetails.put("isAcknowledge", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Physician Order for DNR":
				dnrOrderDetails.put("isPhysicianOrder", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Dietary Modifications":
				dnrOrderDetails.put("dietaryModifications", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Additional Modifications/Restrictions":
				dnrOrderDetails.put("additionalModifications", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Texture Modifications":
				dnrOrderDetails.put("textureModifications", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Weight":	
				dnrOrderDetails.put("weight", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Weight Used for Calculations":
				dnrOrderDetails.put("weightUsedForCalulations", temp);
			    LOGGER.info("" + temp);
			    break;
			    
			case "Sequential UF":
				dnrOrderDetails.put("sequentialUF", temp);
				LOGGER.info("" + temp);
				break;

			case "Sequential UF Time":
				dnrOrderDetails.put("sequentialUFTime", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Perform At":
				dnrOrderDetails.put("performAt", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Dialysate Bath":
				dnrOrderDetails.put("dialysateBath", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Bicarbonate":
				dnrOrderDetails.put("bicarbonate", temp.trim()); //check
				LOGGER.info("" + temp);
				break;
				
			case "Dialysate Temperature":
				dnrOrderDetails.put("dialysateTemperature", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Sodium Modeling":
				dnrOrderDetails.put("sodiumModeling", temp);
				LOGGER.info("" + temp);
				break;
		
			case "Perform With":
				 if(OrderType.contains("TX_ICHD"))
				 {
					 objTemp = gwm.getWebElement(By.xpath(oc.sodiumPerformWithXpath()));
					 dnrOrderDetails.put("sodPerformWith", objTemp.getText());
					LOGGER.info("sodperformWith" + objTemp.getText());
					
					objTemp = gwm.getWebElement(By.xpath(oc.ufPerformWithXpath()));
					dnrOrderDetails.put("ufPerformWith", objTemp.getText());
					LOGGER.info("ufperformWith" + objTemp.getText());
					 
				 }
				 else {
				dnrOrderDetails.put("performWith", temp);
				LOGGER.info("" + temp);}
				break;
				
				
			case "Profile":
				if (OrderType.contains("TX_ICHD")) {
					objTemp = gwm.getWebElement(By.xpath(oc.sodiumProfileXpath()));
					dnrOrderDetails.put("sodiumProfile", objTemp.getText());
					LOGGER.info("sodiumProfile" + objTemp.getText());
					
					objTemp = gwm.getWebElement(By.xpath(oc.ufProfileXpath()));
					dnrOrderDetails.put("ufProfile", objTemp.getText());
					LOGGER.info("ufProfile" + objTemp.getText());
					
				}
				
				else {
				dnrOrderDetails.put("profile", temp);
				LOGGER.info("" + temp);}
				break;
				
			case "Starting Na+":
				dnrOrderDetails.put("startingNa+", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Ending Na+":
				dnrOrderDetails.put("endingNa+", temp);
				LOGGER.info("" + temp);
				break;
				
			
			case "Provider PRN Instructions":
				if (OrderType.contains("TX_ICHD")) {
					objTemp = gwm.getWebElement(By.xpath(oc.sodiumPrnInstructionsXpath()));
					dnrOrderDetails.put("sodiumProviderPrnInstructions", objTemp.getText());
					LOGGER.info("sodiumProviderPrnInstructions" + objTemp.getText());
					
					objTemp = gwm.getWebElement(By.xpath(oc.ufPrnInstructionsXpath()));
					dnrOrderDetails.put("ufProviderPrnIntructions", objTemp.getText());
					LOGGER.info("ufproviderPrnIntructions" + objTemp.getText());
					
				}
				else {					
				dnrOrderDetails.put("providerPrnInstructions", temp);
				LOGGER.info("" + temp);}
				break;
				
				
			case "Base Sodium":
				dnrOrderDetails.put("baseSodium", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Blood Flow Rate":
				dnrOrderDetails.put("bloodFlowRate", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Auto Flow Rate":
				dnrOrderDetails.put("autoFlowRate", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Concurrent Access":
				dnrOrderDetails.put("concurrentAccess", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Arterial Access":
				dnrOrderDetails.put("arterialAccess", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Arterial Needle":
				dnrOrderDetails.put("arterialNeedle", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Venous Access":
				dnrOrderDetails.put("venousAccess", temp);
				LOGGER.info("" + temp);
				break;
			
			case "Venous Needle":
				dnrOrderDetails.put("venousNeedle", temp);
				LOGGER.info("" + temp);
				break;
			
			case "Is this lab order for the treatment of ESRD?":
				dnrOrderDetails.put("treatmentOfESRD", temp);
				LOGGER.info("" + temp);
				break;					
				
			case "Test":
				dnrOrderDetails.put("test", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Laboratory":
				dnrOrderDetails.put("laboratory", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Medication":
				dnrOrderDetails.put("medication", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Dose": 	
				dnrOrderDetails.put("dose", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Route":
				dnrOrderDetails.put("route", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Number of Administrations":
				dnrOrderDetails.put("Number of Administration", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Dispense As":
				dnrOrderDetails.put("dispense As", temp);
			    LOGGER.info("" + temp);
			    break;
			    
			case "Administered":
				dnrOrderDetails.put("administered", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Supplied By":
				dnrOrderDetails.put("supplied by", temp);
				LOGGER.info("" + temp);
				break;
				
			default:
				dnrOrderDetails.put(tempLabel, temp);
				LOGGER.info("Add case for :" + tempLabel);
				break;
			}
			LOGGER.info(tempLabel+":"+temp);
		}
	      //if(!OrderType.contains("TX_ICHD") || !OrderType.contains("MED")) {
          if (OrderType.contains("DNR") || OrderType.contains("DIET")) {
		
	          gwm.clickWebElement(gwm.getWebElement(By.id(oc.detailsPageExitId())));
	      }
	      
		return dnrOrderDetails;
	}
	
	/**
  	 * @param map of parent list from details page   
  	 * @return Map of data to compare to api record  
  	 * Maps  Details page
  	 */
	
	public Map subOrderDetailslist(Map dnrOrderDetails) {
		
		List<WebElement> list = gwm.getWebElements(By.className(oc.orderDetailPageAllFieldsSubClass()));
		List<WebElement> listLabel = gwm.getWebElements(By.className(oc.orderDetailPageAllFieldsSubLabelClass()));
		
		for (int listIterator = 0; listIterator < list.size(); listIterator++) {
			String temp = list.get(listIterator).getText().trim();
			String tempLabel = listLabel.get(listIterator).getText().trim();
			
			switch (tempLabel) {
			
			case "Potassium":
				dnrOrderDetails.put("potassium", temp);
				LOGGER.info("Potassium " + temp);
				break;
				
			case "Calcium":
				dnrOrderDetails.put("calcium", temp);
				LOGGER.info("" + temp);
				break;
			
			case "Concentrate Type":
				dnrOrderDetails.put("concentrateType", temp);
				LOGGER.info("" + temp);
				break;	
				
			case "Dialysate Flow Rate":
				dnrOrderDetails.put("dialysateFlowRate", temp);
				LOGGER.info("" + temp);
				break;	
				
			case "Use Single Dose Vial Only?":
				dnrOrderDetails.put("Use Single Dose Vial Only", temp);
				LOGGER.info("" + temp);
				break;
				
			case "Must Dispense as Written?":
				dnrOrderDetails.put("must Dispense as Written", temp);	
				LOGGER.info("" + temp);
				break;
				
			default:
				dnrOrderDetails.put(tempLabel, temp);
				LOGGER.info("Add case for :" + tempLabel);
				break;
			}
			LOGGER.info(tempLabel+":"+temp);
		}
		gwm.clickWebElement(gwm.getWebElement(By.id(oc.detailsPageExitId())));
		return dnrOrderDetails;
	}
	
	public Map OrderSummaryList (String OrderType, String LastName) {
		
		
		final int rowNo;
		rowNo = findOrderWithName(OrderType, LastName, null);
		Map dnrOrderSummary=new HashMap();
		
		if (OrderType.contains("DNR"))
		{
	    WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","3")));	
		String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
		dnrOrderSummary.put("patientNameSumDnr", ScreenOrderName);
		
		WebElement ScreenType = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7")));	
		String ScreenOrderType = gwm.readWebElementText(ScreenType).toUpperCase();
		dnrOrderSummary.put("orderType", ScreenOrderType);
		}
		
		if (OrderType.contains("DIET"))
		{
		WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","3")));	
		String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
		dnrOrderSummary.put("patientNameSumDiet", ScreenOrderName);
		
		//gwm.waitForTextToBePresentInElement(gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7"))), "ADDITIONAL COMMENTS" , 20 , false);
		WebElement ScreenType = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7")));	
		String ScreenOrderType = gwm.readWebElementText(ScreenType).toUpperCase();
		dnrOrderSummary.put("orderTypeDiet", ScreenOrderType);
		}
		
		if (OrderType.contains("TX_ICHD"))
		{
		WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","3")));	
		String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
		dnrOrderSummary.put("patientNameSumTx", ScreenOrderName);
		
		WebElement ScreenType = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7")));	
		String ScreenOrderType = gwm.readWebElementText(ScreenType).toUpperCase();
		dnrOrderSummary.put("orderTypeTx", ScreenOrderType);
		
		}
		
		if (OrderType.contains("LAB"))
		{
	    WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","3")));	
		String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
		dnrOrderSummary.put("patientNameSumLab", ScreenOrderName);
			
		WebElement ScreenType = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7")));	
		String ScreenOrderType = gwm.readWebElementText(ScreenType).toUpperCase();
		dnrOrderSummary.put("orderTypeLab", ScreenOrderType);	
		}
		
		if (OrderType.contains("MED"))
		{
		WebElement ScreenName = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","3")));	
		String ScreenOrderName = gwm.readWebElementText(ScreenName).toUpperCase();
		dnrOrderSummary.put("patientNameSumMed", ScreenOrderName);
				
		WebElement ScreenType = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","7")));	
		String ScreenOrderType = gwm.readWebElementText(ScreenType).toUpperCase();
		dnrOrderSummary.put("orderTypeMed", ScreenOrderType);	
		}
		 		
		WebElement ScreenDate = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","6")));	
		String ScreenOrderDate = gwm.readWebElementText(ScreenDate).toUpperCase();		
		dnrOrderSummary.put("orderEnterDate", ScreenOrderDate);
		WebElement ScreenFacility = gwm.getWebElement(By.xpath(oc.summaryColText(rowNo + "","4")));	
		String ScreenOrderFacility = gwm.readWebElementText(ScreenFacility).toUpperCase();
		dnrOrderSummary.put("facilityNameSum", ScreenOrderFacility);
		
		return dnrOrderSummary;
	}
}
