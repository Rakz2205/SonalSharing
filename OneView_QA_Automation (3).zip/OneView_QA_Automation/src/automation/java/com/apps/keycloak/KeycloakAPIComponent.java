package com.apps.keycloak;

import java.util.HashMap;
import java.util.logging.Logger;

import org.json.JSONObject;
import org.testng.Assert;

import com.base.Drivers;
import com.base.GenericVariable;
import com.base.GenericHelper;
import com.base.RestAPI;
import com.base.TestBase;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class KeycloakAPIComponent extends TestBase {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private JSONObject initUserAttribs;
	private String bearerToken;
	private String rptToken;
	private String activeDirectoryID;

	public KeycloakAPIComponent() {
		bearerToken = getToken(GenericVariable.OV_USER_1, GenericVariable.AUTOMATION_SANITY_PWD);
		rptToken = getOVBSRPTToken(bearerToken);

	}

	public String getActiveDirectoryID() {
		return activeDirectoryID;
	}

	public void setActiveDirectoryID(String activeDirectoryID) {
		this.activeDirectoryID = activeDirectoryID;
	}

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String token) {
		bearerToken = token;
	}

	public String getrptToken() {
		return rptToken;
	}

	public void setRptToken(String ovbsRptToken) {
		rptToken = ovbsRptToken;
	}

	/**
	 * Function to get keycloak token based on the user role
	 * 
	 * @param username keycloak login username
	 * @param password keycloak login password
	 * @param userRole Specifies the Keycloak user type For an admin user, value is
	 *                 master not an admin user, value is dps
	 * @return getToken for Authorization
	 */
	public String getToken(String username, String password) {
		
		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/x-www-form-urlencoded");
		
		HashMap<String, String> formParams = new HashMap<>();
		formParams.put("username", username);
		formParams.put("password", password);
		formParams.put("grant_type", "password");
		formParams.put("client_id", "dps-ui-app");

		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrParam[] = { endpointHost + "auth/realms/dps/protocol/openid-connect/token", "" };

		JSONObject objJSON = new JSONObject();
		Response postResponse = restapi.call("post", arrParam, objJSON, header, formParams, "");
		Assert.assertEquals(postResponse.statusCode(), 200, "KeyCloak - getToken error");
		JsonPath jsonPathEvaluator = postResponse.getBody().jsonPath();
		return jsonPathEvaluator.get("access_token").toString();

	}

	/**
	 * Function to get rpt token from OVBS
	 * 
	 * @param token Make call to getToken
	 * @return rpt Token
	 */

	public String getOVBSRPTToken(String token) {

		HashMap<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + token);
		header.put("Content-Type", "application/x-www-form-urlencoded");
		
		HashMap<String, String> formParams = new HashMap<>();		
		formParams.put("grant_type", "urn:ietf:params:oauth:grant-type:uma-ticket");
		formParams.put("audience", "dps-resource-server");
		
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrParam[] = { endpointHost + "auth/realms/dps/protocol/openid-connect/token", "" };

		JSONObject objJSON = new JSONObject();
		Response postResponse = restapi.call("post", arrParam, objJSON, header, formParams, "");
		Assert.assertEquals(postResponse.statusCode(), 200, "KeyCloak - getToken error");
		JsonPath jsonPathEvaluator = postResponse.getBody().jsonPath();
		return jsonPathEvaluator.get("access_token").toString();

	}

	/**
	 * Function to update keycloak user attributes
	 * 
	 * @param userID  ID of the user in Keycloak. Can be found in
	 *                keycloak->Users->Details->ID
	 * @param token   Make call to getToken
	 * @param objJSON the updated JSON content of the user attributes
	 * @return Response of the API call
	 */
	public Response updateKeycloakUserAttributes(String userID, String token, JSONObject objJSON) {

		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrUpdateParam[] = { endpointHost + GenericVariable.KeyCloakURLSuffix + userID, "" };

		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("Authorization", "Bearer " + token);

		Response UpdateResponse = restapi.call("put", arrUpdateParam, objJSON, header, formParams, "");
		return UpdateResponse;

	}

	/**
	 * Update keycloak user attributes without providing a token
	 * 
	 * @param userName OneView user name used to retrieve KC ID. Can be found in
	 *                 keycloak->Users->Details->ID
	 * @param objJSON  the updated JSON content of the user attributes
	 * 
	 * @return Response of the API call
	 */
	public Response updateKeycloakUserAttributes(String userName, JSONObject objJSON) {
		LOGGER.info("Calling method KeycloakAPIComponents.updateKeycloakUserAttributes");
		String aToken = this.getToken(GenericVariable.KeyCloakUsername, GenericVariable.KeyCloakPassword);
		String aUserId = this.getKeycloakUserID(userName, aToken);

		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrUpdateParam[] = { endpointHost + GenericVariable.KeyCloakURLSuffix + aUserId, "" };

		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("Authorization", "Bearer " + aToken);

		Response UpdateResponse = restapi.call("put", arrUpdateParam, objJSON, header, formParams, "");
		return UpdateResponse;

	}

	/**
	 * Get keycloak attributes by user name
	 * 
	 * @param userName the OneView user name
	 * 
	 * @return Response of the API call
	 */
	public Response getKeycloakUserAttributes(String userName) {
		String aToken = this.getToken(GenericVariable.KeyCloakUsername, GenericVariable.KeyCloakPassword);
		String aKcUserId = this.getKeycloakUserID(userName, aToken);
		return this.getKeycloakUserAttributes(aKcUserId, aToken);

	}

	/**
	 * Function to get attributes of users in keycloak
	 * 
	 * @param userID ID of the user in Keycloak. Can be found in
	 *               keycloak->Users->Details->ID
	 * @param token  Make call to getToken
	 * 
	 * @return Response of the API call
	 */
	public Response getKeycloakUserAttributes(String userID, String token) {

		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrGetParam[] = { endpointHost + GenericVariable.KeyCloakURLSuffix + userID, "" };

		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("Authorization", "Bearer " + token);
		JSONObject objGetJSON = new JSONObject();

		Response GetResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		return GetResponse;

	}

	/**
	 * Function will return ID of the user in keycloak
	 * 
	 * @param username username to be searched
	 * @param token    Make call to getToken
	 * 
	 * @return ID of the searched username in keycloak
	 */
	public String getKeycloakUserID(String username, String token) {

		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrGetParam[] = { endpointHost + GenericVariable.KeyCloakURLSuffix,
				"?first=0&max=20&search=" + username };

		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("Authorization", "Bearer " + token);

		JSONObject objGetJSON = new JSONObject();
		Response GetResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		JsonPath json = GetResponse.getBody().jsonPath();
		String id = json.get("id").toString();
		return id.substring(1, id.length() - 1);

	}

	/**
	 * Get keycloak search results by user name
	 * 
	 * @param userName the OneView user name
	 * 
	 * @return Response of the API call
	 */
	public Response getKeycloakUsers(String search) {
		String aToken = this.getToken(GenericVariable.KeyCloakUsername, GenericVariable.KeyCloakPassword);
		return this.getKeycloakUsers(search, aToken);

	}

	/**
	 * Function will return the ResponseBody of a keycloak user query
	 * 
	 * @param search search criteria that conforms to the specifications defined in
	 *               https://www.keycloak.org/docs-api/3.1/javadocs/org/keycloak/storage/user/UserQueryProvider.html
	 * @param token  Make call to getToken
	 * 
	 * @return ResponseBody containing the ID of the searched username in a keycloak
	 */
	public Response getKeycloakUsers(String search, String token) {

		HashMap<String, String> formParams = new HashMap<>();
		String endpointHost = GenericHelper.getBaseURL(URL_Path.OneViewBase);
		String arrGetParam[] = { endpointHost + GenericVariable.KeyCloakURLSuffix, "?first=0&max=20&search=" + search };

		HashMap<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");
		header.put("Authorization", "Bearer " + token);

		JSONObject objGetJSON = new JSONObject();
		Response GetResponse = restapi.call("get", arrGetParam, objGetJSON, header, formParams, "");
		return GetResponse;

	}

	/**
	 * Function will set the Keycloak attributes of a OVBS user id to a specific
	 * role as defined on the confluence page
	 * https://confluence.davita.com/display/ARC/NEW+Roles+-+2019
	 * 
	 * @param user    search criteria that conforms to the specifications defined in
	 *                https://www.keycloak.org/docs-api/3.1/javadocs/org/keycloak/storage/user/UserQueryProvider.html
	 * @param Profile Profile as defined on
	 *                https://confluence.davita.com/display/ARC/NEW+Roles+-+2019
	 * 
	 * @return Null
	 */
	public void setPhysAttrib(String user, String profile, String clinicalSystems, String activeDirectory) {
		LOGGER.info("Calling method KeycloakAPIComponents.setPhysRole");
		// Create JSONObject containing the attributes that define the Physician
		// Entitlement Profile
		JSONObject attribJO = null, userJO;
		Response aResp;
		String credType = "";
		String onePhysicianFlag = "";
		String eCredExpirationDate = "";
		// Get the whole user representation from keycloak since you have to have the
		// whole document to perform the put on the API
		aResp = getKeycloakUserAttributes(user);
		Assert.assertEquals(aResp.getStatusCode(), 200);
		userJO = new JSONObject(aResp.body().asString());
		// save the state the first time this method is called.
		if (initUserAttribs == null) {
			setInitUserAttribs(new JSONObject(userJO.get("attributes").toString()));
		}
		if (profile != null && clinicalSystems != null && activeDirectory != null) {
			if (profile != null) {
				attribJO = new JSONObject(userJO.get("attributes").toString());
				// get rid of the attributes that define the entitlement profile
				attribJO.remove("credType");
				attribJO.remove("onePhysicianFlag");
				attribJO.remove("eCredExpirationDate");
				// set the values for the required entitlement profile standards documented
				// here: https://confluence.davita.com/display/ARC/NEW+Roles+-+2019
				if (profile.equals("PHYS")) {
					credType = "PHYS";
					onePhysicianFlag = "Y";
					eCredExpirationDate = "01/01/2059";
				} else {
					Assert.fail("Profile not coded");
				}
				// add values to the json object
				attribJO.put("credType", credType);
				attribJO.put("onePhysicianFlag", onePhysicianFlag);
				attribJO.put("eCredExpirationDate", eCredExpirationDate);
				// Have to add the "attributes" tag back to attribJO so that keycloak will
				// accept the request
				attribJO = new JSONObject("{\"attributes\":" + attribJO + "}");
			}

			// set the values for the required entitlement profile standards for clinical
			// systems as documented
			// here: https://confluence.davita.com/display/ARC/NEW+Roles+-+2019
			if (clinicalSystems != null) {
				attribJO = new JSONObject(attribJO.get("attributes").toString());
				attribJO.remove("clinicalSystems");
				attribJO.put("clinicalSystems", clinicalSystems.toUpperCase());
				attribJO = new JSONObject("{\"attributes\":" + attribJO.toString() + "}");
			}

			// set the values for the required entitlement profile standards for
			// activeDirectory as documented
			// here: https://confluence.davita.com/display/ARC/NEW+Roles+-+2019
			if (activeDirectory != null) {
				attribJO = new JSONObject(attribJO.get("attributes").toString());
				attribJO.remove("activeDirectoryId");
				attribJO.put("activeDirectoryId", activeDirectory);
				attribJO = new JSONObject("{\"attributes\":" + attribJO.toString() + "}");
			}
		} else {
			Assert.fail("Values for attributes in keycloak can't be null");
		}

		// make the call to update keycloak
		aResp = updateKeycloakUserAttributes(user, attribJO);
		Assert.assertEquals(aResp.getStatusCode(), 204);
		// request the user json from keycloak again
		aResp = getKeycloakUserAttributes(user);
		// note expected values are stored in keycloak as a json array so added brackets
		// to the expected values to match the JSONObject representation
		if (profile != null) {
			Assert.assertEquals(aResp.jsonPath().get("attributes.credType").toString(), "[" + "PHYS" + "]");
			Assert.assertEquals(aResp.jsonPath().get("attributes.onePhysicianFlag").toString(), "[" + "Y" + "]");
			Assert.assertEquals(aResp.jsonPath().get("attributes.eCredExpirationDate").toString(),
					"[" + "01/01/2059" + "]");
			Assert.assertNotNull(aResp.jsonPath().get("attributes.NPI"), "NPI not configured in keycloak");
		}
		if (clinicalSystems != null) {
			Assert.assertEquals(aResp.jsonPath().get("attributes.clinicalSystems").toString(),
					"[" + clinicalSystems + "]");
		}
		if (activeDirectory != null) {
			String str = aResp.jsonPath().get("attributes.activeDirectoryId").toString();
			String newString = str.substring(str.indexOf("[") + 1, str.indexOf("]"));
			setActiveDirectoryID(newString);
			Assert.assertEquals(aResp.jsonPath().get("attributes.activeDirectoryId").toString(),
					"[" + activeDirectory + "]");
		}
	}

	/**
	 * Function will reset the user attributes to the original state
	 * 
	 * @param user search criteria that conforms to the specifications defined in
	 *             https://www.keycloak.org/docs-api/3.1/javadocs/org/keycloak/storage/user/UserQueryProvider.html
	 * 
	 * @return null
	 */
	public void resetUserAttributes(String user) {
		LOGGER.info("Calling method KeycloakAPIComponents.resetUserAttributes");
		JSONObject attribJO = new JSONObject("{\"attributes\":" + initUserAttribs.toString() + "}");
		Response aResp = updateKeycloakUserAttributes(user, attribJO);
		Assert.assertEquals(aResp.getStatusCode(), 204);
	}

	/**
	 * Function will get the user Init attributes
	 * 
	 * @return initUserAttribs
	 */
	public JSONObject getInitUserAttribs() {
		return initUserAttribs;
	}

	/**
	 * Function will set the user Init attributes
	 * 
	 * @param value
	 */
	public void setInitUserAttribs(JSONObject value) {
		initUserAttribs = value;
	}

}
