package com.apps.cwow;

import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import org.junit.Assert;
import com.base.GenericHelper;
import com.apps.oneview.common.OrderCaller;


public class CwowMappingComponents {
	private GenericHelper gh = new GenericHelper();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private OrderCaller oc = new OrderCaller();
	/**
	 * This function compares maps from rest api record to oneview display
	 *  @param 	 apiList api record list 
	 *  @param   ovList Oneview record list  
	 */
	//@SuppressWarnings("deprecation")
	public void compareList(Map apiList, Map ovList , String OrderType) {
		
		if(apiList.isEmpty() && ovList.isEmpty())
		{
			Assert.assertEquals("Order Not Present Please Add Order and Execute Again!!!", false, true);
			
		}
		
		else 
		{
			String status = "";
			Set <Map.Entry> st = apiList.entrySet();
			for (Map.Entry iteartor:st) {
				Object srcKey = iteartor.getKey();
				String apiValue = apiList.get(srcKey) + "";
				if (apiValue.contains("None")) {
					apiValue = apiValue.replace("None", "");
					apiValue = apiValue.trim();
				}				
				String ovValue = ovList.get(srcKey) + "";
				if (ovValue.contains("None")) {
					ovValue = ovValue.replace("None", "");
					ovValue = ovValue.trim();
				}				
				if (ovValue.isEmpty()) {
					ovValue = "";					
				}
				//dates *
				if (srcKey.equals("orderStartDate") || srcKey.equals("orderEndDate") || srcKey.equals("orderEnterDate") || srcKey.equals("discontinueDate"))
				{
					if(!apiValue.equals("null"))// needs work
					{
					String[] apiDate = apiValue.split("T");
					apiValue = apiDate[0];
					ovValue = gh.dateFormat(ovValue, oc.dateFormatPattern2());
					}
					
					if (srcKey.equals("orderEndDate") || srcKey.equals("End Date") || srcKey.equals("discontinueDate") || srcKey.equals("Discontinue Date"))
					{
						if(ovValue.equals("")) { // needs work
							ovValue.replace("", "null");
						}
					}
				}
				//dialysis center *
				if (srcKey.equals("facilityName"))
				{
					apiValue = apiValue.replaceAll("- ", "");
					ovValue = ovValue.replaceAll("- ", "");
					
					if(ovValue.contains(apiValue))
				{
						ovValue = apiValue;
				}
				}
				if (srcKey.equals("facilityNameSum"))
				{	
					apiValue = apiValue.toUpperCase();
					
					if(ovValue.contains(apiValue))
					{
							ovValue = apiValue;
					}
				}
				
				if (srcKey.equals("providerName"))
				{
					apiValue = apiValue.replace("M", "MD");
				}
				
				if (srcKey.equals("patientName"))
				{
					apiValue = apiValue.replace("," , ", ");
					if (OrderType.contains("DNR"))
					{
						apiValue = apiValue.replace(" QA-2", " S");
					}

					if (OrderType.contains("DIET"))
					{
					apiValue = apiValue.replace("QA-2", "");
					apiValue = apiValue.replace(" I", "I");
					}
				}
				
				if (srcKey.equals("patientNameSumDiet"))
				{
					String[] newName = ovValue.split("\\(");
					ovValue = newName[0].trim();
					apiValue = apiValue.replace(" I", "");
					apiValue = apiValue.replace("QA-2", "");
					apiValue = apiValue.replace("," , ", ").toUpperCase();
					
					
				}
				
				if (srcKey.equals("patientNameSumTx"))
				{
					String[] newName = ovValue.split("\\(");
					ovValue = newName[0].trim();
					apiValue = apiValue.replace("," , ", ").toUpperCase();
				}
								
				if (srcKey.equals("patientNameSumDnr"))
				{
					String[] newName = ovValue.split("\\(");
					ovValue = newName[0].trim();
					apiValue = apiValue.replace(" S", "");
					apiValue = apiValue.replace(" QA-2", "");
					apiValue = apiValue.replace("," , ", ").toUpperCase();					
				}
				
				if (srcKey.equals("patientNameSumLab"))
				{
					String[] newName = ovValue.split("\\(");
					ovValue = newName[0].trim();
					apiValue = apiValue.replace("," , ", ").toUpperCase();
				}
				
				if (srcKey.equals("patientNameSumMed"))
				{
					String[] newName = ovValue.split("\\(");
					ovValue = newName[0].trim();
					apiValue = apiValue.replace("," , ", ").toUpperCase();
				}
				
				if (srcKey.equals("justification"))
				{
					String[] newjust = ovValue.split(";");
					ovValue = newjust[0].trim();
					apiValue = apiValue.replace(";", "").trim();
					
				}
				
				if (srcKey.equals("dialysateTemperature"))
				{
					String[] temp = ovValue.split(" ");
					ovValue = temp[0].trim();
				}
				
				// MPI*
				if (srcKey.equals("mpi"))  
				{
					String[] newMpi = ovValue.split("#");
					ovValue = newMpi[1].trim();
				}
				// Type *
				if (!OrderType.contains("TX_ICHD"))
				{
				if (srcKey.equals("orderType"))
				{
					String[] apiType = apiValue.split(" "); 
					apiValue = apiType[0].trim();
				}
				}
				
				
				if (srcKey.equals("calories"))
				{
					String[] newCal = apiValue.split("/");
					apiValue = newCal[0].trim() + "/d";
				}
				// ID * 
								
				//Dnr Policy *
			
				// DNR ack / phy order 
				if (srcKey.equals("isAcknowledge") || srcKey.equals("isPhysicianOrder") || srcKey.equals("DNR Order Acknowledgement") || srcKey.equals("Physician Order for DNR") || srcKey.equals("sodiumModeling") || srcKey.equals("sequentialUF"))
				{
					apiValue = apiValue.toString();
					if (ovValue.contains("Yes"))
					{
						ovValue = ovValue.replace("Yes", "true");
					}
					if (ovValue.contains("No"))
					{
						ovValue = ovValue.replace("No", "false");
					}
					
					if(ovValue.contains(apiValue))
					{
						ovValue = apiValue;
					}
				}
				
				
				
				//order source *
				
				//enterBy*
				
		
				
				LOGGER.info(srcKey + "---" + apiValue + "---" + ovValue);
				if (!apiValue.trim().equals(ovValue.trim()))
				{
					status = status + "Value Mismatch for : "+ srcKey +"(" + ovValue + ") + (" + apiValue + ")"+ "\n"; 
					
				}				 
			}
			LOGGER.info("Assert :" + status);
			Assert.assertEquals(status, "", status);
		
		}
	}
	
}
