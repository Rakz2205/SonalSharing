
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "orderState",
    "provider",
    "isActiveFlag",
    "orderPatient",
    "facilityName",
    "id",
    "orderNumber",
    "facilityNumber",
    "masterPatientIdentifier",
    "orderSource",
    "orderStartDate",
    "orderEnterDate",
    "enterBy",
    "orderType",
    "weightUsedForCalculation",
    "calories",
    "potassium",
    "protein",
    "fluid",
    "phosphorus",
    "sodium",
    "modifications",
    "otherModifications",
    "calculatedCalories",
    "calculatedProtein"
})
public class DietMapper {

    @JsonProperty("orderState")
    private DietOrderState orderState;
    @JsonProperty("provider")
    private DietProvider provider;
    @JsonProperty("isActiveFlag")
    private Boolean isActiveFlag;
    @JsonProperty("orderPatient")
    private DietOrderPatient orderPatient;
    @JsonProperty("facilityName")
    private String facilityName;
    @JsonProperty("id")
    private String id;
    @JsonProperty("orderNumber")
    private Integer orderNumber;
    @JsonProperty("facilityNumber")
    private String facilityNumber;
    @JsonProperty("masterPatientIdentifier")
    private String masterPatientIdentifier;
    @JsonProperty("orderSource")
    private DietOrderSource orderSource;
    @JsonProperty("orderStartDate")
    private String orderStartDate;
    @JsonProperty("orderEnterDate")
    private String orderEnterDate;
    @JsonProperty("enterBy")
    private DietEnterBy enterBy;
    @JsonProperty("orderType")
    private DietOrderType orderType;
    @JsonProperty("weightUsedForCalculation")
    private DietWeightUsedForCalculation weightUsedForCalculation;
    @JsonProperty("calories")
    private DietCalories calories;
    @JsonProperty("potassium")
    private DietPotassium potassium;
    @JsonProperty("fluid")
    private DietFluid fluid;
    @JsonProperty("phosphorus")
    private DietPhosphorus phosphorus;
    @JsonProperty("sodium")
    private DietSodium sodium;
    @JsonProperty("modifications")
    private DietModifications modifications;
    @JsonProperty("otherModifications")
    private List<DietOtherModification> otherModifications = null;
    @JsonProperty("calculatedCalories")
    private Double calculatedCalories;
    @JsonProperty("calculatedProtein")
    private Double calculatedProtein;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("orderState")
    public DietOrderState getOrderState() {
        return orderState;
    }

    @JsonProperty("orderState")
    public void setOrderState(DietOrderState orderState) {
        this.orderState = orderState;
    }

    @JsonProperty("provider")
    public DietProvider getProvider() {
        return provider;
    }

    @JsonProperty("provider")
    public void setProvider(DietProvider provider) {
        this.provider = provider;
    }

    @JsonProperty("isActiveFlag")
    public Boolean getIsActiveFlag() {
        return isActiveFlag;
    }

    @JsonProperty("isActiveFlag")
    public void setIsActiveFlag(Boolean isActiveFlag) {
        this.isActiveFlag = isActiveFlag;
    }

    @JsonProperty("orderPatient")
    public DietOrderPatient getOrderPatient() {
        return orderPatient;
    }

    @JsonProperty("orderPatient")
    public void setOrderPatient(DietOrderPatient orderPatient) {
        this.orderPatient = orderPatient;
    }

    @JsonProperty("facilityName")
    public String getFacilityName() {
        return facilityName;
    }

    @JsonProperty("facilityName")
    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("orderNumber")
    public Integer getOrderNumber() {
        return orderNumber;
    }

    @JsonProperty("orderNumber")
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    @JsonProperty("facilityNumber")
    public String getFacilityNumber() {
        return facilityNumber;
    }

    @JsonProperty("facilityNumber")
    public void setFacilityNumber(String facilityNumber) {
        this.facilityNumber = facilityNumber;
    }

    @JsonProperty("masterPatientIdentifier")
    public String getMasterPatientIdentifier() {
        return masterPatientIdentifier;
    }

    @JsonProperty("masterPatientIdentifier")
    public void setMasterPatientIdentifier(String masterPatientIdentifier) {
        this.masterPatientIdentifier = masterPatientIdentifier;
    }

    @JsonProperty("orderSource")
    public DietOrderSource getOrderSource() {
        return orderSource;
    }

    @JsonProperty("orderSource")
    public void setOrderSource(DietOrderSource orderSource) {
        this.orderSource = orderSource;
    }

    @JsonProperty("orderStartDate")
    public String getOrderStartDate() {
        return orderStartDate;
    }

    @JsonProperty("orderStartDate")
    public void setOrderStartDate(String orderStartDate) {
        this.orderStartDate = orderStartDate;
    }

    @JsonProperty("orderEnterDate")
    public String getOrderEnterDate() {
        return orderEnterDate;
    }

    @JsonProperty("orderEnterDate")
    public void setOrderEnterDate(String orderEnterDate) {
        this.orderEnterDate = orderEnterDate;
    }

    @JsonProperty("enterBy")
    public DietEnterBy getEnterBy() {
        return enterBy;
    }

    @JsonProperty("enterBy")
    public void setEnterBy(DietEnterBy enterBy) {
        this.enterBy = enterBy;
    }

    @JsonProperty("orderType")
    public DietOrderType getOrderType() {
        return orderType;
    }

    @JsonProperty("orderType")
    public void setOrderType(DietOrderType orderType) {
        this.orderType = orderType;
    }

    @JsonProperty("weightUsedForCalculation")
    public DietWeightUsedForCalculation getWeightUsedForCalculation() {
        return weightUsedForCalculation;
    }

    @JsonProperty("weightUsedForCalculation")
    public void setWeightUsedForCalculation(DietWeightUsedForCalculation weightUsedForCalculation) {
        this.weightUsedForCalculation = weightUsedForCalculation;
    }

    @JsonProperty("calories")
    public DietCalories getCalories() {
        return calories;
    }

    @JsonProperty("calories")
    public void setCalories(DietCalories calories) {
        this.calories = calories;
    }

    @JsonProperty("potassium")
    public DietPotassium getPotassium() {
        return potassium;
    }

    @JsonProperty("potassium")
    public void setPotassium(DietPotassium potassium) {
        this.potassium = potassium;
    }

    @JsonProperty("fluid")
    public DietFluid getFluid() {
        return fluid;
    }

    @JsonProperty("fluid")
    public void setFluid(DietFluid fluid) {
        this.fluid = fluid;
    }

    @JsonProperty("phosphorus")
    public DietPhosphorus getPhosphorus() {
        return phosphorus;
    }

    @JsonProperty("phosphorus")
    public void setPhosphorus(DietPhosphorus phosphorus) {
        this.phosphorus = phosphorus;
    }

    @JsonProperty("sodium")
    public DietSodium getSodium() {
        return sodium;
    }

    @JsonProperty("sodium")
    public void setSodium(DietSodium sodium) {
        this.sodium = sodium;
    }

    @JsonProperty("modifications")
    public DietModifications getModifications() {
        return modifications;
    }

    @JsonProperty("modifications")
    public void setModifications(DietModifications modifications) {
        this.modifications = modifications;
    }

    @JsonProperty("otherModifications")
    public List<DietOtherModification> getOtherModifications() {
        return otherModifications;
    }

    @JsonProperty("otherModifications")
    public void setOtherModifications(List<DietOtherModification> otherModifications) {
        this.otherModifications = otherModifications;
    }

    @JsonProperty("calculatedCalories")
    public Double getCalculatedCalories() {
        return calculatedCalories;
    }

    @JsonProperty("calculatedCalories")
    public void setCalculatedCalories(Double calculatedCalories) {
        this.calculatedCalories = calculatedCalories;
    }

    @JsonProperty("calculatedProtein")
    public Double getCalculatedProtein() {
        return calculatedProtein;
    }

    @JsonProperty("calculatedProtein")
    public void setCalculatedProtein(Double calculatedProtein) {
        this.calculatedProtein = calculatedProtein;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
