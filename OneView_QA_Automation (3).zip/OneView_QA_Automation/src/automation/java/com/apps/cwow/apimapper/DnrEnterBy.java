
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "username",
    "firstName",
    "lastName",
    "idCorpClinic",
    "clinicName",
    "teammateId",
    "accessToken",
    "clinicalIndicator",
    "roles",
    "credential"
})
public class DnrEnterBy {

    @JsonProperty("username")
    private String username;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("idCorpClinic")
    private String idCorpClinic;
    @JsonProperty("clinicName")
    private String clinicName;
    @JsonProperty("teammateId")
    private String teammateId;
    @JsonProperty("accessToken")
    private String accessToken;
    @JsonProperty("clinicalIndicator")
    private Boolean clinicalIndicator;
    @JsonProperty("credential")
    private String credential;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    @JsonProperty("username")
    public void setUsername(String username) {
        this.username = username;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("idCorpClinic")
    public String getIdCorpClinic() {
        return idCorpClinic;
    }

    @JsonProperty("idCorpClinic")
    public void setIdCorpClinic(String idCorpClinic) {
        this.idCorpClinic = idCorpClinic;
    }

    @JsonProperty("clinicName")
    public String getClinicName() {
        return clinicName;
    }

    @JsonProperty("clinicName")
    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    @JsonProperty("teammateId")
    public String getTeammateId() {
        return teammateId;
    }

    @JsonProperty("teammateId")
    public void setTeammateId(String teammateId) {
        this.teammateId = teammateId;
    }

    @JsonProperty("accessToken")
    public String getAccessToken() {
        return accessToken;
    }

    @JsonProperty("accessToken")
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    @JsonProperty("clinicalIndicator")
    public Boolean getClinicalIndicator() {
        return clinicalIndicator;
    }

    @JsonProperty("clinicalIndicator")
    public void setClinicalIndicator(Boolean clinicalIndicator) {
        this.clinicalIndicator = clinicalIndicator;
    }

    @JsonProperty("credential")
    public String getCredential() {
        return credential;
    }

    @JsonProperty("credential")
    public void setCredential(String credential) {
        this.credential = credential;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
