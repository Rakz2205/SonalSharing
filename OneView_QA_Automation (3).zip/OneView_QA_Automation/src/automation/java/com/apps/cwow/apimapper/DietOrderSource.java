
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "itemId",
    "codeId",
    "displayName",
    "longDescription",
    "system",
    "url"
})
public class DietOrderSource {

    @JsonProperty("itemId")
    private String itemId;
    @JsonProperty("codeId")
    private String codeId;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("longDescription")
    private Object longDescription;
    @JsonProperty("system")
    private Object system;
    @JsonProperty("url")
    private Object url;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("itemId")
    public String getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    @JsonProperty("codeId")
    public String getCodeId() {
        return codeId;
    }

    @JsonProperty("codeId")
    public void setCodeId(String codeId) {
        this.codeId = codeId;
    }

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @JsonProperty("longDescription")
    public Object getLongDescription() {
        return longDescription;
    }

    @JsonProperty("longDescription")
    public void setLongDescription(Object longDescription) {
        this.longDescription = longDescription;
    }

    @JsonProperty("system")
    public Object getSystem() {
        return system;
    }

    @JsonProperty("system")
    public void setSystem(Object system) {
        this.system = system;
    }

    @JsonProperty("url")
    public Object getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(Object url) {
        this.url = url;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
