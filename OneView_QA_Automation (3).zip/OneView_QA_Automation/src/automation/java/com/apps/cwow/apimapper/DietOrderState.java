
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "orderId",
    "actionState",
    "codingState",
    "codedBy",
    "discontinueDate",
    "enterInErrorFlag",
    "enterInErrorReason"
})
public class DietOrderState {

    @JsonProperty("id")
    private String id;
    @JsonProperty("orderId")
    private String orderId;
    @JsonProperty("codedBy")
    private Object codedBy;
    @JsonProperty("discontinueDate")
    private Object discontinueDate;
    @JsonProperty("enterInErrorFlag")
    private Object enterInErrorFlag;
    @JsonProperty("enterInErrorReason")
    private Object enterInErrorReason;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("orderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("codedBy")
    public Object getCodedBy() {
        return codedBy;
    }

    @JsonProperty("codedBy")
    public void setCodedBy(Object codedBy) {
        this.codedBy = codedBy;
    }

    @JsonProperty("discontinueDate")
    public Object getDiscontinueDate() {
        return discontinueDate;
    }

    @JsonProperty("discontinueDate")
    public void setDiscontinueDate(Object discontinueDate) {
        this.discontinueDate = discontinueDate;
    }

    @JsonProperty("enterInErrorFlag")
    public Object getEnterInErrorFlag() {
        return enterInErrorFlag;
    }

    @JsonProperty("enterInErrorFlag")
    public void setEnterInErrorFlag(Object enterInErrorFlag) {
        this.enterInErrorFlag = enterInErrorFlag;
    }

    @JsonProperty("enterInErrorReason")
    public Object getEnterInErrorReason() {
        return enterInErrorReason;
    }

    @JsonProperty("enterInErrorReason")
    public void setEnterInErrorReason(Object enterInErrorReason) {
        this.enterInErrorReason = enterInErrorReason;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
