
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "orderId",
    "npi",
    "providerIdentifier",
    "providerRelationshipType",
    "startDateTime",
    "endDateTime",
    "firstName",
    "middleName",
    "lastName",
    "fullName",
    "providerCredentials",
    "contactNumber",
    "providerRelationship"
})
public class DnrProvider {

    @JsonProperty("orderId")
    private String orderId;
    @JsonProperty("npi")
    private String npi;
    @JsonProperty("providerIdentifier")
    private String providerIdentifier;
    @JsonProperty("startDateTime")
    private Object startDateTime;
    @JsonProperty("endDateTime")
    private Object endDateTime;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("middleName")
    private String middleName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("providerCredentials")
    private String providerCredentials;
    @JsonProperty("contactNumber")
    private Object contactNumber;
    @JsonProperty("providerRelationship")
    private String providerRelationship;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("orderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("npi")
    public String getNpi() {
        return npi;
    }

    @JsonProperty("npi")
    public void setNpi(String npi) {
        this.npi = npi;
    }

    @JsonProperty("providerIdentifier")
    public String getProviderIdentifier() {
        return providerIdentifier;
    }

    @JsonProperty("providerIdentifier")
    public void setProviderIdentifier(String providerIdentifier) {
        this.providerIdentifier = providerIdentifier;
    }

    @JsonProperty("startDateTime")
    public Object getStartDateTime() {
        return startDateTime;
    }

    @JsonProperty("startDateTime")
    public void setStartDateTime(Object startDateTime) {
        this.startDateTime = startDateTime;
    }

    @JsonProperty("endDateTime")
    public Object getEndDateTime() {
        return endDateTime;
    }

    @JsonProperty("endDateTime")
    public void setEndDateTime(Object endDateTime) {
        this.endDateTime = endDateTime;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("middleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @JsonProperty("providerCredentials")
    public String getProviderCredentials() {
        return providerCredentials;
    }

    @JsonProperty("providerCredentials")
    public void setProviderCredentials(String providerCredentials) {
        this.providerCredentials = providerCredentials;
    }

    @JsonProperty("contactNumber")
    public Object getContactNumber() {
        return contactNumber;
    }

    @JsonProperty("contactNumber")
    public void setContactNumber(Object contactNumber) {
        this.contactNumber = contactNumber;
    }

    @JsonProperty("providerRelationship")
    public String getProviderRelationship() {
        return providerRelationship;
    }

    @JsonProperty("providerRelationship")
    public void setProviderRelationship(String providerRelationship) {
        this.providerRelationship = providerRelationship;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
