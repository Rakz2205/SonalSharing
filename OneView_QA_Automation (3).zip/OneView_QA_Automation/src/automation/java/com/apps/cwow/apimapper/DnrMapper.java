
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "orderState",
    "provider",
    "isActiveFlag",
    "orderPatient",
    "facilityName",
    "id",
    "orderNumber",
    "facilityNumber",
    "masterPatientIdentifier",
    "orderSource",
    "orderStartDate",
    "recordVersion",
    "createDateTimeGmt",
    "createSessionTokenId",
    "orderEnterDate",
    "enterBy",
    "orderType",
    "acknowledgeText",
    "isAcknowledge",
    "isPhysicianOrder"
})
public class DnrMapper {

    @JsonProperty("orderState")
    private DnrOrderState orderState;
    @JsonProperty("provider")
    private DnrProvider provider;
    @JsonProperty("isActiveFlag")
    private Boolean isActiveFlag;
    @JsonProperty("orderPatient")
    private DnrOrderPatient orderPatient;
    @JsonProperty("facilityName")
    private String facilityName;
    @JsonProperty("id")
    private String id;
    @JsonProperty("orderNumber")
    private Integer orderNumber;
    @JsonProperty("facilityNumber")
    private String facilityNumber;
    @JsonProperty("masterPatientIdentifier")
    private String masterPatientIdentifier;
    @JsonProperty("orderSource")
    private DnrOrderSource orderSource;
    @JsonProperty("orderStartDate")
    private String orderStartDate;
    @JsonProperty("recordVersion")
    private Integer recordVersion;
    @JsonProperty("createDateTimeGmt")
    private String createDateTimeGmt;
    @JsonProperty("createSessionTokenId")
    private String createSessionTokenId;
    @JsonProperty("orderEnterDate")
    private String orderEnterDate;
    @JsonProperty("enterBy")
    private DnrEnterBy enterBy;
    @JsonProperty("orderType")
    private DnrOrderType orderType;
    @JsonProperty("acknowledgeText")
    private String acknowledgeText;
    @JsonProperty("isAcknowledge")
    private Boolean isAcknowledge;
    @JsonProperty("isPhysicianOrder")
    private Boolean isPhysicianOrder;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("orderState")
    public DnrOrderState getOrderState() {
        return orderState;
    }

    @JsonProperty("orderState")
    public void setOrderState(DnrOrderState orderState) {
        this.orderState = orderState;
    }

    @JsonProperty("provider")
    public DnrProvider getProvider() {
        return provider;
    }

    @JsonProperty("provider")
    public void setProvider(DnrProvider provider) {
        this.provider = provider;
    }

    @JsonProperty("isActiveFlag")
    public Boolean getIsActiveFlag() {
        return isActiveFlag;
    }

    @JsonProperty("isActiveFlag")
    public void setIsActiveFlag(Boolean isActiveFlag) {
        this.isActiveFlag = isActiveFlag;
    }

    @JsonProperty("orderPatient")
    public DnrOrderPatient getOrderPatient() {
        return orderPatient;
    }

    @JsonProperty("orderPatient")
    public void setOrderPatient(DnrOrderPatient orderPatient) {
        this.orderPatient = orderPatient;
    }

    @JsonProperty("facilityName")
    public String getFacilityName() {
        return facilityName;
    }

    @JsonProperty("facilityName")
    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("orderNumber")
    public Integer getOrderNumber() {
        return orderNumber;
    }

    @JsonProperty("orderNumber")
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    @JsonProperty("facilityNumber")
    public String getFacilityNumber() {
        return facilityNumber;
    }

    @JsonProperty("facilityNumber")
    public void setFacilityNumber(String facilityNumber) {
        this.facilityNumber = facilityNumber;
    }

    @JsonProperty("masterPatientIdentifier")
    public String getMasterPatientIdentifier() {
        return masterPatientIdentifier;
    }

    @JsonProperty("masterPatientIdentifier")
    public void setMasterPatientIdentifier(String masterPatientIdentifier) {
        this.masterPatientIdentifier = masterPatientIdentifier;
    }

    @JsonProperty("orderSource")
    public DnrOrderSource getOrderSource() {
        return orderSource;
    }

    @JsonProperty("orderSource")
    public void setOrderSource(DnrOrderSource orderSource) {
        this.orderSource = orderSource;
    }

    @JsonProperty("orderStartDate")
    public String getOrderStartDate() {
        return orderStartDate;
    }

    @JsonProperty("orderStartDate")
    public void setOrderStartDate(String orderStartDate) {
        this.orderStartDate = orderStartDate;
    }

    @JsonProperty("recordVersion")
    public Integer getRecordVersion() {
        return recordVersion;
    }

    @JsonProperty("recordVersion")
    public void setRecordVersion(Integer recordVersion) {
        this.recordVersion = recordVersion;
    }

    @JsonProperty("createDateTimeGmt")
    public String getCreateDateTimeGmt() {
        return createDateTimeGmt;
    }

    @JsonProperty("createDateTimeGmt")
    public void setCreateDateTimeGmt(String createDateTimeGmt) {
        this.createDateTimeGmt = createDateTimeGmt;
    }

    @JsonProperty("createSessionTokenId")
    public String getCreateSessionTokenId() {
        return createSessionTokenId;
    }

    @JsonProperty("createSessionTokenId")
    public void setCreateSessionTokenId(String createSessionTokenId) {
        this.createSessionTokenId = createSessionTokenId;
    }

    @JsonProperty("orderEnterDate")
    public String getOrderEnterDate() {
        return orderEnterDate;
    }

    @JsonProperty("orderEnterDate")
    public void setOrderEnterDate(String orderEnterDate) {
        this.orderEnterDate = orderEnterDate;
    }

    @JsonProperty("enterBy")
    public DnrEnterBy getEnterBy() {
        return enterBy;
    }

    @JsonProperty("enterBy")
    public void setEnterBy(DnrEnterBy enterBy) {
        this.enterBy = enterBy;
    }

    @JsonProperty("orderType")
    public DnrOrderType getOrderType() {
        return orderType;
    }

    @JsonProperty("orderType")
    public void setOrderType(DnrOrderType orderType) {
        this.orderType = orderType;
    }

    @JsonProperty("acknowledgeText")
    public String getAcknowledgeText() {
        return acknowledgeText;
    }

    @JsonProperty("acknowledgeText")
    public void setAcknowledgeText(String acknowledgeText) {
        this.acknowledgeText = acknowledgeText;
    }

    @JsonProperty("isAcknowledge")
    public Boolean getIsAcknowledge() {
        return isAcknowledge;
    }

    @JsonProperty("isAcknowledge")
    public void setIsAcknowledge(Boolean isAcknowledge) {
        this.isAcknowledge = isAcknowledge;
    }

    @JsonProperty("isPhysicianOrder")
    public Boolean getIsPhysicianOrder() {
        return isPhysicianOrder;
    }

    @JsonProperty("isPhysicianOrder")
    public void setIsPhysicianOrder(Boolean isPhysicianOrder) {
        this.isPhysicianOrder = isPhysicianOrder;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
