package com.apps.cwow;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import java.io.IOException;
import org.json.JSONObject;
import org.testng.Assert;
import com.base.RestAPI;
import com.base.Drivers;
import com.base.GenericHelper;
import com.base.GenericVariable;
import com.base.TestBase.URL_Path;
import com.apps.cwow.apimapper.DnrMapper;
import com.apps.cwow.apimapper.DietMapper;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class CwowAPIComponents {

	RestAPI restapi = new RestAPI();
	Drivers driver = new Drivers();
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
  
	  /**
	   * Checks patient for existing orders types can be DNR%20Order, Treatment%20Order, Diet%20Order
	   * @param orderType
	   * @param mpi
	   * @param facilityId
	   
	   */

	  public String checkForExistingOrder(String orderType , String mpi ) 
	  {
		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPISEARCH);
		  String path = (endpointHost + "_search/" + orderType  + "/active" + "?mpi=" + mpi + "&facilityId=" + GenericVariable.CwowfacilityId);
		  String arrUpdateParam[] = {path, ""};
	  	  
		  HashMap<String, String> header = new HashMap<>();
		  header.put("Content-Type", "application/json");
		  header.put("userName", GenericVariable.CwowApiUserName2);
	      header.put("Authorization", GenericVariable.CwowApiAuth);
		  header.put("facilityId", GenericVariable.CwowfacilityId);
		 
		  HashMap<String, String> formParams = new HashMap<>();
		  formParams.put("mpi", mpi);
		  formParams.put("facilityId", GenericVariable.CwowfacilityId );
		  
		  Response getdetails = restapi.call("get", arrUpdateParam, null, header, formParams, "");
		  Object healthCheck = getdetails.statusCode();
		  
		  if(  healthCheck.toString().contains("200") ) {
			  
			  String guid = getdetails.getBody().asString().replaceAll("\"","");;
			  LOGGER.info("if no record is found guid will be empty");
			  return guid; 
			  }
			  else {
				  LOGGER.info("Server is down");
				  return "";
			  }
		  }
	

	/**
	   * deletes record after creation 
	   * @param guid
	   * @parm entered in error file 
	   * @return response 
	   */

	  public Response enterInError( String guid, String errorFile) throws Exception {

		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPICOMMAND);
		  String arrUpdate[] = { endpointHost + guid + "/state", ""};
		  
		  HashMap<String , String> header = new HashMap<>();
			header.put("Content-Type", "application/json");
			header.put("userName", GenericVariable.CwowApiUserName1);
			header.put("Authorization", GenericVariable.CwowApiAuth);
			header.put("facilityId", GenericVariable.CwowfacilityId);
			
			String jsonbody = GenericHelper.readFileAsString(GenericVariable.AEFilePath + errorFile);
			Response errorResponse = restapi.call("put", arrUpdate, jsonbody, header);
			Assert.assertEquals(errorResponse.getStatusCode(), 200 ,"If 500 is returned server is down and test fails" );
			return errorResponse ;
	  }
	  
	  /**
	   * refutes cwow record after dispute action 
	   * @param guid
	   * @parm entered in error file 
	   * @return response 
	   */
	  public Response refuteCwowOrder(String guid, String refuteFile) throws Exception {
		
		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPICOMMAND);
		  String arrUpdate[] = {endpointHost + guid + "/state", ""};
		  
		  HashMap<String, String> header = new HashMap<>();
			header.put("Content-Type", "application/json");
			header.put("userName", GenericVariable.CwowApiUserName1);
			header.put("Authorization", GenericVariable.CwowApiAuth);
			header.put("facilityId", GenericVariable.CwowfacilityId);
			String jsonbody = GenericHelper.readFileAsString( GenericVariable.AEFilePath  + refuteFile);
			
			Response refuteResponse = restapi.call("put", arrUpdate, jsonbody, header);
			Assert.assertEquals(refuteResponse.getStatusCode(), 200, "If 500 is returned server is down and test fails");
			return refuteResponse;
	  }
	
	  /**
		 * @param guid
		 * @param order type can be treatment/hemo, diet , med , lab , dnr 
		 * @return order number used to validate record in oneview
		 * gets order number from api record
		 */
		
	  
	  public String getOrderNumber(String guid, String orderType) { 
		
		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPIQUERY);
		  String arrUpdateParam[] = {endpointHost + orderType +  "/"  + guid,  "" };
		  
		  HashMap<String, String> header = new HashMap<>();	  
		  header.put("Content-Type", "application/json");
		  header.put("Authorization", GenericVariable.CwowApiAuth);
		  header.put("userName", GenericVariable.CwowApiUserName2);
		  header.put("facilityId", GenericVariable.CwowfacilityId);
		  HashMap<String, String> formParams = new HashMap<>();
		  JSONObject objJSON = new JSONObject();
		  
		  Response getdetails = restapi.call("get", arrUpdateParam, objJSON, header, formParams, "");
		  Assert.assertEquals(getdetails.statusCode(), 200 , "If 500 is returned server is down and test fails");
		  
		  JsonPath jsonPathEvaluator = getdetails.getBody().jsonPath();
		  return jsonPathEvaluator.get("orderNumber").toString();
		  	  
	  }
	  
		/**
		 * @param order type can be treatment/hemo, diet , med , lab , dnr 
		 * @param order file should be local order files ex) DietOrder.txt , MedOrder.txt , LabOrder.txt ,DnrOrder.txt , TreatmentOrder.txt 
		 * @return id after order creation  
		 * Creates Cwow orders via api
		 * @throws Exception 
		 */
		
	  
	  public String createCwowOrders(String orderType, String orderFile) throws Exception {
		
		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPICOMMAND);
		  String arrUpdateParam[] = {endpointHost + orderType , ""};

		   HashMap<String, String> header = new HashMap<>();
			header.put("Content-Type", "application/json");
			header.put("userName", GenericVariable.CwowApiUserName2);
			header.put("Authorization", GenericVariable.CwowApiAuth);
			header.put("facilityId", GenericVariable.CwowfacilityId);
			
			String data = GenericHelper.readFileAsString( GenericVariable.AEFilePath + orderFile);
			String time = java.time.LocalDateTime.now().toString() + "Z";
		    String newData =  data.replaceAll("2019-07-25T20:51:02.842Z", time);		    			    
			LOGGER.info(newData);
			Response getGuid = restapi.call("post", arrUpdateParam, newData , header);
			Assert.assertEquals(getGuid.statusCode(), 200, "If 500 is returned server is down and test fails");
			JsonPath jsonPathEvaluator = getGuid.getBody().jsonPath();
			if (orderType.contains("dnr") || orderType.contains("diet") || orderType.contains("treatment/hemo") || orderType.contains("lab"))
			{
			String guid = getGuid.getBody().asString().replaceAll("\"","");
			return guid;
			}
			else {
			return jsonPathEvaluator.get("ids").toString().replaceAll("\\[", "").replaceAll("\\]", "");
			}						
	   		
	  }
	  
	  /**
	     * @param order type can be treatment/hemo, diet , med , lab , dnr
	 	 * @param guid
	 	 * @param Order can be tx , diet , med , lab , dnr  
	 	 * @return Map of data to compare to Summary page  
	 	 * Maps dnrOrder Summary page
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 	 */
	   
	   	public Map OrderListSummary(String guid, String orderType, String Order) throws JsonParseException, JsonMappingException, IOException {
	   		
	   
	   		  String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPIQUERY);
			  String arrUpdateParam[] = {endpointHost + orderType +  "/"  + guid,  "" };
			  
			  HashMap<String, String> header = new HashMap<>();	  
			  header.put("Content-Type", "application/json");
			  header.put("Authorization", GenericVariable.CwowApiAuth);
			  header.put("userName", GenericVariable.CwowApiUserName2);
			  header.put("facilityId", GenericVariable.CwowfacilityId);
			  HashMap<String, String> formParams = new HashMap<>();
			  JSONObject objJSON = new JSONObject();
			  
			  Response getdetails = restapi.call("get", arrUpdateParam, objJSON, header, formParams, "");
			  Assert.assertEquals(getdetails.statusCode(), 200, "If 500 is returned server is down and test fails");
			  
			  Map OrderList = new HashMap();
			  String record = getdetails.getBody().asString();
			  
			  
			  if (Order.contains("dnr"))
			  {

			  ObjectMapper dnrMapper = new ObjectMapper(); 
			  DnrMapper dnrOrder = dnrMapper.readValue(record, DnrMapper.class); 
			  OrderList.put("patientNameSumDnr", dnrOrder.getOrderPatient().getFullName());
			  OrderList.put("facilityNameSum", dnrOrder.getFacilityName());
			  OrderList.put("orderType", dnrOrder.getOrderType().getDisplayName());
			  OrderList.put("orderEnterDate", dnrOrder.getOrderEnterDate());
			  }
			  
			  if (Order.contains("diet"))
			  {
			  ObjectMapper dietMapper = new ObjectMapper(); 
			  DietMapper dietOrder = dietMapper.readValue(record, DietMapper.class);	
			  OrderList.put("patientNameSumDiet", dietOrder.getOrderPatient().getFullName());
			  OrderList.put("facilityNameSum", dietOrder.getFacilityName());
			  OrderList.put("orderEnterDate", dietOrder.getOrderEnterDate());
			  String orderTypeTitle = dietOrder.getOrderType().getDisplayName().toString().toUpperCase();
	   		  if (orderTypeTitle.contains("DIET ORDER"))
	   		  {
	   			  orderTypeTitle = orderTypeTitle.replace("DIET ORDER", "DIET");
	   		  }
	   		  String protein = dietOrder.getCalculatedProtein() + " GM/D";
			  String phoWeight1 = dietOrder.getPhosphorus().getValue().toString();
			  String phoWeight2 = dietOrder.getPhosphorus().getUom().getDisplayName().toString().toUpperCase();
			  String potWeight1 = dietOrder.getPotassium().getValue().toString();
			  String potWeight2 = dietOrder.getPotassium().getUom().getDisplayName().toString().toUpperCase();
			  String sodWeight1 = dietOrder.getSodium().getValue().toString();
			  String sodWeight2 = dietOrder.getSodium().getUom().getDisplayName().toString().toUpperCase();
			  String fluWeight1 = dietOrder.getFluid().getValue().toString();
			  String fluWeight2 = dietOrder.getFluid().getUom().getDisplayName().toString().toUpperCase();
			  String calWeight1 = dietOrder.getCalculatedCalories().toString();
			  String calWeight2 = dietOrder.getCalories().getUom().getDisplayName().toString().toUpperCase();
			  if (calWeight2.contains("KCAL/KG/(24.H)"))
			  {
				  calWeight2 = calWeight2.replace("KCAL/KG/(24.H)", "KCAL/D");
			  }	
			  String dietMod1 = dietOrder.getModifications().getDietaryModifications().get(0).getDisplayName().toUpperCase();
			  String dietMod2 = dietOrder.getModifications().getDietaryModifications().get(1).getDisplayName().toUpperCase();
			  String addMod1 = dietOrder.getModifications().getAdditionalModifications().get(0).getDisplayName().toUpperCase();
		      String addMod2 = dietOrder.getModifications().getAdditionalModifications().get(1).getDisplayName().toUpperCase();
			  String addMod3 = dietOrder.getOtherModifications().get(0).getOtherModification().replaceAll("\\[", "").replaceAll("\\]", "");
			  String textMod1 = dietOrder.getModifications().getTextureModifications().get(0).getDisplayName().toUpperCase();
			  String textMod2 = dietOrder.getModifications().getTextureModifications().get(1).getDisplayName().toUpperCase();
			  String weight1 = dietOrder.getWeightUsedForCalculation().getValue().toString();
			  String weight2 = dietOrder.getWeightUsedForCalculation().getUom().getDisplayName().toString().toUpperCase();
			  String weightCal = dietOrder.getWeightUsedForCalculation().getBodyWeightType().getDisplayName();
			  if (weightCal.contains("Standard Body Weight"))
			  {
				  weightCal = weightCal.replace("Standard Body Weight","STD BODY WT");			  
			  }
			  
			  OrderList.put("orderTypeDiet", orderTypeTitle + ":  PROTEIN: " + protein + ";  P: " + phoWeight1 + " " + phoWeight2 + ";  K: " + potWeight1 + " "+ potWeight2 +
			  ";  NA+: " + sodWeight1 + " " + sodWeight2 + ";  FLUID: "	+ fluWeight1 + " " + fluWeight2 + ";  CALORIES: " + calWeight1 + " " + calWeight2 + "; " + dietMod1 + ", " + dietMod2
			  + "; " + addMod1 + ", " + addMod2 + ", " + addMod3 + "; " + textMod1 + ", " + textMod2 + ";  ADDITIONAL COMMENTS: ;" + "  PT WT: " + weight1 + " " + weight2 + ";  WT USED FOR CALC: " + weightCal  );
			  
	   		  }
			   
			  
			  
			  return OrderList;
	   	}
	  
	  
	  /**
	 	 * @param guid
	 	 * @return Map of data to compare to details page  
	 	 * Maps dnrOrder Details page
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 	 */                                                 
	   public Map dnrOrderListDetails(String guid) throws JsonParseException, JsonMappingException, IOException {
		   
		
		      String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPIQUERY);
			  String arrUpdateParam[] = {endpointHost + "dnr/" + guid,  "" };
			  
			  HashMap<String, String> header = new HashMap<>();	  
			  header.put("Content-Type", "application/json");
			  header.put("Authorization", GenericVariable.CwowApiAuth);
			  header.put("userName", GenericVariable.CwowApiUserName2);
			  header.put("facilityId", GenericVariable.CwowfacilityId);
			  
			  HashMap<String, String> formParams = new HashMap<>();
			  JSONObject objJSON = new JSONObject();
			  
			  Response getdetails = restapi.call("get", arrUpdateParam, objJSON, header, formParams, "");
			  Assert.assertEquals(getdetails.statusCode(), 200 , "If 500 is returned server is down and test fails");
			  
			  Map dnrOrderList = new HashMap();
			  ObjectMapper dnrMapper = new ObjectMapper(); 
			  String record = getdetails.getBody().asString();
			  DnrMapper dnrOrder = dnrMapper.readValue(record, DnrMapper.class); 
			  
			  dnrOrderList.put("orderNumber", dnrOrder.getOrderNumber());
			  dnrOrderList.put("mpi", dnrOrder.getMasterPatientIdentifier());
			  dnrOrderList.put("DOB", dnrOrder.getOrderPatient().getDateOfBirth());
			  dnrOrderList.put("patientName", dnrOrder.getOrderPatient().getFullName());
			  dnrOrderList.put("providerName", dnrOrder.getProvider().getFullName());
			  dnrOrderList.put("facilityName", dnrOrder.getFacilityName());
			  dnrOrderList.put("orderSource", dnrOrder.getOrderSource().getDisplayName());
			  dnrOrderList.put("orderType", dnrOrder.getOrderType().getDisplayName());
			  dnrOrderList.put("orderStartDate", dnrOrder.getOrderStartDate());
			  dnrOrderList.put("discontinueDate", dnrOrder.getOrderState().getDiscontinueDate());
			  dnrOrderList.put("acknowledgeText", dnrOrder.getAcknowledgeText());
			  dnrOrderList.put("isAcknowledge", dnrOrder.getIsAcknowledge());
			  dnrOrderList.put("isPhysicianOrder", dnrOrder.getIsPhysicianOrder()); 
			  dnrOrderList.put("orderEnterDate", dnrOrder.getOrderEnterDate());	
			  String enterByFirst = dnrOrder.getEnterBy().getFirstName();
			  String enterByLast = dnrOrder.getEnterBy().getLastName();
			  String credential = dnrOrder.getEnterBy().getCredential();
			  dnrOrderList.put("enteredBy",  enterByLast +", " + enterByFirst + " " + credential);
 
			  return dnrOrderList;
	   }
	   
	   /**
	  	 * @param guid
	  	 * @return Map of data to compare to details page  
	  	 * Maps dietOrder Details page
	  	 */
	   	public Map dietOrderListDetails(String guid) throws JsonParseException, JsonMappingException, IOException  {
	   
	   		String endpointHost = GenericHelper.getBaseURL(URL_Path.CWOWAPIQUERY);
	   		String arrUpdateParam[] = {endpointHost + "diet/" + guid,  "" };
	   		
	   		HashMap<String, String> header = new HashMap<>();
	   		header.put("Content-Type", "application/json");
	   	    header.put("Authorization", GenericVariable.CwowApiAuth);
		    header.put("userName", GenericVariable.CwowApiUserName2);
		    header.put("facilityId", GenericVariable.CwowfacilityId);
	   		
	   		HashMap<String, String> formParams = new HashMap<>();
	   		JSONObject objJSON = new JSONObject();
	   		
	   		Response getdetails = restapi.call("get", arrUpdateParam, objJSON, header, formParams, "");
	   		Assert.assertEquals(getdetails.statusCode(), 200);
	   		
	   		Map dietOrderList = new HashMap();
	   		ObjectMapper dietMapper = new ObjectMapper(); 
			String record = getdetails.getBody().asString();
			DietMapper dietOrder = dietMapper.readValue(record, DietMapper.class); 
			
			dietOrderList.put("orderNumber",dietOrder.getOrderNumber());
			dietOrderList.put("mpi", dietOrder.getMasterPatientIdentifier());
			dietOrderList.put("DOB", dietOrder.getOrderPatient().getDateOfBirth());
			dietOrderList.put("patientName", dietOrder.getOrderPatient().getFullName() + " I");
			dietOrderList.put("providerName", dietOrder.getProvider().getFullName());
			dietOrderList.put("facilityName", dietOrder.getFacilityName());
			dietOrderList.put("orderSource", dietOrder.getOrderSource().getDisplayName());
			dietOrderList.put("orderType", dietOrder.getOrderType().getDisplayName());
			dietOrderList.put("orderStartDate", dietOrder.getOrderStartDate());
			dietOrderList.put("orderEnterDate", dietOrder.getOrderEnterDate());	
			dietOrderList.put("discontinueDate", dietOrder.getOrderState().getDiscontinueDate());
			dietOrderList.put("protein", dietOrder.getCalculatedProtein() + " gm/d");
			String phoWeight1 = dietOrder.getPhosphorus().getValue().toString();
			String phoWeight2 = dietOrder.getPhosphorus().getUom().getDisplayName();
			dietOrderList.put("phosphorus", phoWeight1 + " " + phoWeight2);
			String potWeight1 = dietOrder.getPotassium().getValue().toString();
			String potWeight2 = dietOrder.getPotassium().getUom().getDisplayName();
			dietOrderList.put("potassium", potWeight1 + " " + potWeight2);
			String sodWeight1 = dietOrder.getSodium().getValue().toString();
			String sodWeight2 = dietOrder.getSodium().getUom().getDisplayName();
			dietOrderList.put("sodium", sodWeight1 + " " + sodWeight2); 	
			String fluWeight1 = dietOrder.getFluid().getValue().toString();
			String fluWeight2 = dietOrder.getFluid().getUom().getDisplayName();
			dietOrderList.put("fluid", fluWeight1 + " " + fluWeight2);
			String calWeight1 = dietOrder.getCalculatedCalories().toString();
			String calWeight2 = dietOrder.getCalories().getUom().getDisplayName();
			dietOrderList.put("calories", calWeight1 + " " + calWeight2);
			String dietMod1 = dietOrder.getModifications().getDietaryModifications().get(0).getDisplayName();
			String dietMod2 = dietOrder.getModifications().getDietaryModifications().get(1).getDisplayName();
			dietOrderList.put("dietaryModifications", dietMod1 + ", " + dietMod2);
			String addMod1 = dietOrder.getModifications().getAdditionalModifications().get(0).getDisplayName();
			String addMod2 = dietOrder.getModifications().getAdditionalModifications().get(1).getDisplayName();
			String addMod3 = dietOrder.getOtherModifications().get(0).getOtherModification().replaceAll("\\[", "").replaceAll("\\]", "");
			dietOrderList.put("additionalModifications", addMod1 + ", " + addMod2 + ", " + addMod3);
			String textMod1 = dietOrder.getModifications().getTextureModifications().get(0).getDisplayName();
			String textMod2 = dietOrder.getModifications().getTextureModifications().get(1).getDisplayName();
			dietOrderList.put("textureModifications", textMod1 + ", " + textMod2);
			String weight1 = dietOrder.getWeightUsedForCalculation().getValue().toString();
			String weight2 = dietOrder.getWeightUsedForCalculation().getUom().getDisplayName();
			dietOrderList.put("weight", weight1 + " " + weight2);
			dietOrderList.put("weightUsedForCalulations", dietOrder.getWeightUsedForCalculation().getBodyWeightType().getDisplayName());
			String enterByFirst = dietOrder.getEnterBy().getFirstName();
			String enterByLast = dietOrder.getEnterBy().getLastName();
		    String credential = dietOrder.getEnterBy().getCredential();
		    dietOrderList.put("enteredBy",  enterByLast +", " + enterByFirst + " " + credential);
			
			
	   		return dietOrderList;
	   	}
}
