
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "value",
    "uom",
    "isNoRestriction"
})
public class DietSodium {

    @JsonProperty("value")
    private Integer value;
    @JsonProperty("uom")
    private DietSodiumUom uom;
    @JsonProperty("isNoRestriction")
    private Object isNoRestriction;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("value")
    public Integer getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(Integer value) {
        this.value = value;
    }

    @JsonProperty("uom")
    public DietSodiumUom getUom() {
        return uom;
    }

    @JsonProperty("uom")
    public void setUom(DietSodiumUom uom) {
        this.uom = uom;
    }

    @JsonProperty("isNoRestriction")
    public Object getIsNoRestriction() {
        return isNoRestriction;
    }

    @JsonProperty("isNoRestriction")
    public void setIsNoRestriction(Object isNoRestriction) {
        this.isNoRestriction = isNoRestriction;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
