
package com.apps.cwow.apimapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dietaryModifications",
    "textureModifications",
    "additionalModifications"
})
public class DietModifications {

    @JsonProperty("dietaryModifications")
    private List<DietDietaryModification> dietaryModifications = null;
    @JsonProperty("textureModifications")
    private List<DietTextureModification> textureModifications = null;
    @JsonProperty("additionalModifications")
    private List<DietAdditionalModification> additionalModifications = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dietaryModifications")
    public List<DietDietaryModification> getDietaryModifications() {
        return dietaryModifications;
    }

    @JsonProperty("dietaryModifications")
    public void setDietaryModifications(List<DietDietaryModification> dietaryModifications) {
        this.dietaryModifications = dietaryModifications;
    }

    @JsonProperty("textureModifications")
    public List<DietTextureModification> getTextureModifications() {
        return textureModifications;
    }

    @JsonProperty("textureModifications")
    public void setTextureModifications(List<DietTextureModification> textureModifications) {
        this.textureModifications = textureModifications;
    }

    @JsonProperty("additionalModifications")
    public List<DietAdditionalModification> getAdditionalModifications() {
        return additionalModifications;
    }

    @JsonProperty("additionalModifications")
    public void setAdditionalModifications(List<DietAdditionalModification> additionalModifications) {
        this.additionalModifications = additionalModifications;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
