
#Running test methods in parallel

TestNG provides multiple ways to execute the tests in a multi-threaded condition, 
one of them is executing each test method in a single thread. 
This mode reduces the execution time significantly because more tests are executed in parallel, 
hence reducing the total execution time.

#How to run a Test
You will see the following test result in the Console window:


#independentTest.java
TestNG also provides the flexibility to configure a test method to be run in a multi-threaded environment. 
This is achieved by configuring it while using the @Test annotation on a method.

The method is configured to run in multi-threaded mode by using the threadPoolSize attribute 
along with the Test annotation. The value of the threadPoolSize is set to 3; this configures 
the test method to be run in three different threads. The other two attributes, 
invocationCount and timeOut, configures the test to be invoked a multiple number of times 
and fail if the execution takes more time.


#ParallelMethodTest.java
TestNG provides multiple ways to execute the tests in a multi-threaded condition, 
one of them is executing each test method in a single thread. This mode reduces the execution 
time significantly because more tests are executed in parallel, hence reducing the total execution time.

#ParallelClassesTestTwo.java
each test class and its respective beforeClass and afterClass methods are executed in a different thread. 
This is identified by the id of the thread that is printed on the console.

#ParallelSuite.java
executing each test inside a suite in parallel, that is, each test that is part of the test suite execution 
will be executed in its own separate respective thread.


#how to
1. http://toolsqa.com/selenium-webdriver/testng-multi-browser-cross-browser/

#Setting Priority in TestNG

package TestNG;

@Test(priority=0)
method1()

@Test(priority=1)
method2()

@Test(priority=2)
method3()

Code Walkthrough

If a test script is composed of more than one test method, the execution priority and sequence 
can be set using TestNG annotation “@Test” and by setting a value for the “priority” parameter.

In the above code snippet, all the methods are annotated with the help @Test and the 
priorities are set to 0, 1 and 2. Thus the order of execution in which the test 
methods would be executed is:

Method1
Method2
Method3

##What retry does ?
####@Retention(RetentionPolicy.RUNTIME)
1. retry x time if test failed.. this is applied only to test with @RetryCountIfFailed(10)
Where 10 is the number of runtime.

####IRetryAnalyzer
1. Check if the Test method for which retry is called has RetryCountIfFailed annotation
2. Then compare current retry attempt with value of this annotation.


###Jenkins integration
https://www.guru99.com/maven-jenkins-with-selenium-complete-tutorial.html

###Run All test
mvn -Dtests=AllTests.xml test

###Furthermore it's possible to control which tests will run via the test property
mvn -Dtest=MyTest test
or
mvn -Dtest=MyTest,FirstTest,SecondTest test

###A more fine granular way to specify tests from command line
mvn -Dtest=MyTest#myMethod test
which run the method myMethod in the MyTest class.

##New comment by keith to test eclipse STS/git pull integration


###APPIUM
Note you need to get the .app of your project for it to work - not the .ipa

Appium Native iOS App Testing | WebDriver Appium is an open source, cross-platform test automation tool for native, hybrid and mobile web apps. Appium tests can be written in your favorite Webdriver-compatible language.

Requirements & installation

1| MAC OS X 10.7 (minimum version required) 2| Xcode updated version (prefer) 3| Node.js 4| Appium.app 5| Eclipse Kepler (prefer) 6| TestNG framework

Pre-Appium setup

iOS .app file is enough to inspect elements. In this example, I have used the project, 'InternationalMountains' from Apple DEV site.

1| Download the project, 'InternationalMountains' 2| Double click and extract it 3| Import it into Xcode by opening the Xcode file 4| Run the project 5| Make sure that the simulator is opened with the application 6| Open Terminal and move to the project folder 7| Run the following command to build the .app file

`xcodebuild -sdk iphonesimulator6.1`
8| It will build the app and generate the file, 'InternationalMountains.app' under /InternationalMountains/Build/Products/Release-iphonesimulator/

Appium iOS setup

1| Download & Install Node.js // npm represents that Node.js Package Manager  $ sudo npm install wd

2| Run the Appium server using node.js; There are couple of ways to do so..

1 Using Node.js

//install Appium  $ npm install -g appium (or) $ sudo npm install appium -g //start Appium server  $ appium &

2 Using the App

Download Appium, install and Run it

3| Now, the Appium server gets started in the

default port 4723 and IP Address 0.0.0.0
Appium inspector

Appium inspector is a record and playback tool just like Selenium IDE for web.

1| Open Appium

2| Change the default IP address to 127.0.0.1 and port 4725

3| Now, enable the check box, 'App path' 4| Click on the 'Choose' button and locate the .app local directory. i.e., InternationalMountains.app

5| Click on the 'Launch' button [Appium server launches now] 6| Now, a blue-colored icon found beside the 'Launch' button is enabled 

7| Clicking blue-colored icon open up the Appium inspector with Simulator 

8| Now, click the 'Record' button in Appium inspector 9| Every action will be generating a script at bottom of the Appium inspector


-----
Set up cisco vpn on mac to run automatically
https://www.maketecheasier.com/auto-connect-vpn-mac-startup 


