import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

public class AccountingEntriesValidator 
{
	public static Connection db_Connection = null;
	static String inputDataPath,outputDataPath;
	static DataFormatter dataFormatter = new DataFormatter();
	static HSSFWorkbook workbook;
	static HSSFSheet dbDataSheet;
	static HSSFSheet mainSheet;
	
	static int startRow,startCol;
	static int endRow,endCol;
	
	static String cHost;
	static String cSID;
	static String cUserName;
	static String sPassword;
	static String sPort;
	
	static String dbSheetName,mainSheetName;
	
	static String[][] arrQueryOut;
	
	static ArrayList<String> solId = new ArrayList<String>();
	static ArrayList<String> glNum = new ArrayList<String>(); 
	static ArrayList<String> tranType = new ArrayList<String>();
	static ArrayList<String> tranDate = new ArrayList<String>();
	static ArrayList<String> srcQuery = new ArrayList<String>();
	static FormulaEvaluator evaluator;
	static FileInputStream finput;
	
	public static void main(String[] args) throws IOException, SQLException 
	{
		// TODO Auto-generated method stub
		inputDataPath="C:\\Rakesh\\Office Stuff\\LMS\\Results\\Demo\\InputSheet.xls";
		
		
		//sheet name to be executed
		String arrSheetNames[]={"7,8,12","11"};
		//String arrSheetNames[]={"9","10","EachAcct","7,8,12","11"};
		
		
		String outFileName="Output"+"_"+getFileName();
		
		outputDataPath="C:\\Rakesh\\Office Stuff\\LMS\\Results\\Demo" +"\\"+outFileName+".xls";
		startRow=5;   // java starts cell from 0
		startCol=4;
		
		
		
		
		dbSheetName="DB Data";
		createExcelObject(inputDataPath);
		fetchDBConnectionData();
		create_database_connection_Oracle(cHost,sPort,cSID,cUserName,sPassword);
		
		for(int sheetInc=0;sheetInc<arrSheetNames.length;sheetInc++)
		{
			mainSheetName=arrSheetNames[sheetInc];
			mainSheet=workbook.getSheet(mainSheetName);
	    	endRow=mainSheet.getLastRowNum();
			fetchsolIdValue();
			fetchColValues();
			updateQueryWithColValues();
			executeQuerySolWise();
			updateCellWithComment();
			deleteListData();
		}
		
		saveAndCloseExcel();
		
	}
	private static void deleteListData() {
		solId.clear();
		glNum.clear(); 
		tranType.clear();
		tranDate.clear();
		srcQuery.clear();
		
	}
	private static void saveAndCloseExcel() throws IOException 
	{
		// TODO Auto-generated method stub
		finput.close();
		 
        FileOutputStream outputStream = new FileOutputStream(outputDataPath);
        workbook.write(outputStream);
       
        outputStream.close();
	}
	private static void updateCellWithComment() 
	{
		
		 CellStyle comparisionCellStylePass = workbook.createCellStyle();
	        
        comparisionCellStylePass.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
        comparisionCellStylePass.setFillPattern((short) 1);
        
        
        CellStyle comparisionCellStyleFail = workbook.createCellStyle();
        
        comparisionCellStyleFail.setFillForegroundColor(IndexedColors.RED.getIndex());
        comparisionCellStyleFail.setFillPattern((short) 1);
        
        
        CellStyle comparisionCellStyleError = workbook.createCellStyle();
        
        comparisionCellStyleError.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        comparisionCellStyleError.setFillPattern((short) 1);
		
		
		for(int solInc=0;solInc<solId.size();solInc++)
		{
			for(int queryInc=0;queryInc<srcQuery.size();queryInc++)
			{
		    	
				int excelRowNum=solInc+startRow;
				int excelColNum=queryInc+startCol;
				
				String excelValue=dataFormatter.formatCellValue(mainSheet.getRow(excelRowNum).getCell(excelColNum),evaluator);
				//get db value
				String dbValue=arrQueryOut[solInc][queryInc];
				
				
				 // Create a Row
		        Row resultRow = mainSheet.getRow(excelRowNum);
		        
		     // Create cells
		        Cell cell;
		        
		        if(excelValue=="")
		        {
		        	cell = resultRow.createCell(excelColNum);
		        }
		        else
		        {
		        	cell = resultRow.getCell(excelColNum);
		        }
		        
		        
				if(excelValue.equalsIgnoreCase(dbValue))
				{
					// pass green
	                cell.setCellStyle(comparisionCellStylePass);
				}
				else if(dbValue.equalsIgnoreCase("Error in executing query"))
				{
					// error yellow
					cell.setCellStyle(comparisionCellStyleError);
					addComment(excelRowNum,excelColNum,"","Error in Executing Query");
				}
				else
				{
					//fail red
					
					 if(excelValue=="")
			         {
			        	cell.setCellValue(dbValue);
			         }
			         else
			         {
			        	 cell.setCellStyle(comparisionCellStyleFail);
						addComment(excelRowNum,excelColNum,"","DB Value :"+dbValue);
			         }
					
					
				}
			}
		}
		
	}
	private static void executeQuerySolWise() throws SQLException 
	{
		arrQueryOut = new String[solId.size()+1][srcQuery.size()+1];
		
		for(int solInc=0;solInc<solId.size();solInc++)
		{
			String solTemp=solId.get(solInc);
			for(int queryInc=0;queryInc<srcQuery.size();queryInc++)
			{
				//fetch query and update with sol
				String queryTemp=srcQuery.get(queryInc);
				queryTemp=queryTemp.toUpperCase().replaceAll("%%SOL_ID", solTemp);
				
				String queryOut=getQueryOutput(queryTemp);
				
				arrQueryOut[solInc][queryInc]=queryOut;
				
			}
		}
		
		// printing for testing
		
		for(int solInc=0;solInc<solId.size();solInc++)
		{
			for(int queryInc=0;queryInc<srcQuery.size();queryInc++)
			{
				//System.out.print(arrQueryOut[solInc][queryInc]);
				//System.out.print("%%%");
			}
			System.out.println();
		}
		
	}
	private static void updateQueryWithColValues() 
	{
		// TODO Auto-generated method stub
		for(int queryInc1=0;queryInc1<srcQuery.size();queryInc1++)
		{
			String glCode=glNum.get(queryInc1);
			String tranTypeData=tranType.get(queryInc1);
			String tranDateData=tranDate.get(queryInc1);
			
			String sqlQuery=srcQuery.get(queryInc1);
			
			sqlQuery=sqlQuery.toUpperCase().replaceAll("%%GL_SUB_HEAD_CODE", glCode);
			sqlQuery=sqlQuery.toUpperCase().replaceAll("%%PART_TRAN_TYPE", tranTypeData);
			sqlQuery=sqlQuery.toUpperCase().replaceAll("%%TRAN_DATE", tranDateData);
			
			srcQuery.set(queryInc1, sqlQuery);
		}
		
	}
	
	private static void fetchColValues() 
	{
		HSSFCell cell;
    	for(int excelColInc=startCol;excelColInc<50;excelColInc++)
    	{
    		
    		String strTemp=dataFormatter.formatCellValue(mainSheet.getRow(0).getCell(excelColInc),evaluator);
    		if(strTemp=="")
    		{
    			endCol=excelColInc-1;
    			//System.out.println("End Column :"+endCol);
    			break;
    		}
    		else
    		{
    			//add into list
    			glNum.add(excelColInc-startCol,dataFormatter.formatCellValue(mainSheet.getRow(0).getCell(excelColInc),evaluator));
    			tranType.add(excelColInc-startCol,dataFormatter.formatCellValue(mainSheet.getRow(1).getCell(excelColInc),evaluator));
    			tranDate.add(excelColInc-startCol,dataFormatter.formatCellValue(mainSheet.getRow(2).getCell(excelColInc),evaluator));
    			srcQuery.add(excelColInc-startCol,dataFormatter.formatCellValue(mainSheet.getRow(3).getCell(excelColInc),evaluator));
    		}
    		
    	}
		
	}
	private static void fetchsolIdValue() 
	{
		// TODO Auto-generated method stub
		HSSFCell cell;
    	for(int excelInc=startRow;excelInc<=endRow;excelInc++)
    	{
    		solId.add(excelInc-startRow,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(0),evaluator));
    	}
		
	}
	public static void createExcelObject(String inputPath) throws IOException
    {
    	finput=new FileInputStream(inputPath);
    	workbook =new HSSFWorkbook(finput);
    	dbDataSheet=workbook.getSheet(dbSheetName);
    	evaluator = workbook.getCreationHelper().createFormulaEvaluator();
    }
	
	public static void fetchDBConnectionData()
    {
    	HSSFCell cell;
    	
    	 cHost = dataFormatter.formatCellValue(dbDataSheet.getRow(1).getCell(1));
    	 cSID = dataFormatter.formatCellValue(dbDataSheet.getRow(2).getCell(1));
    	 cUserName = dataFormatter.formatCellValue(dbDataSheet.getRow(3).getCell(1));
    	 sPassword = dataFormatter.formatCellValue(dbDataSheet.getRow(4).getCell(1));
    	 sPort = dataFormatter.formatCellValue(dbDataSheet.getRow(5).getCell(1));
    }
	
	public static void create_database_connection_Oracle(String host,String port, String SID, String username, String password) {
    	try {
        	
            Class.forName("oracle.jdbc.driver.OracleDriver");
            db_Connection = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+SID+"", ""+username+"", ""+password+"");
        } catch (Exception e) {
            throw new RuntimeException("Error while creating the DB connection", e);
        }
    }
	
	
	public static String getQueryOutput(String query) throws SQLException {
        ResultSet resultSet = null;
        try {
            Statement statement = db_Connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            resultSet = statement.executeQuery(query);
            resultSet.next();
            
            String returnTemp=resultSet.getObject(1)+"";
           
            return returnTemp;
        } catch (Exception e) {
        	//System.out.println(db_Connection.isClosed());
        	//System.out.println(query);
        	//System.out.println(e.getMessage());
            return "Error in executing query";
        }
        finally {
        	 resultSet.close();
        }
        
    }
	
	public static void addComment(int rowIdx, int colIdx, String author, String commentText) {
        CreationHelper factory = workbook.getCreationHelper();
        //get an existing cell or create it otherwise:
        
        // Create a Row
        Row headerRow = mainSheet.getRow(rowIdx);
        
     // Create cells
        Cell cell;
        cell = headerRow.getCell(colIdx);

        ClientAnchor anchor = factory.createClientAnchor();
        //i found it useful to show the comment box at the bottom right corner
        anchor.setCol1(cell.getColumnIndex() + 1); //the box of the comment starts at this given column...
        anchor.setCol2(cell.getColumnIndex() + 3); //...and ends at that given column
        anchor.setRow1(rowIdx + 1); //one row below the cell...
        anchor.setRow2(rowIdx + 5); //...and 4 rows high

        Drawing drawing = mainSheet.createDrawingPatriarch();
        Comment comment = drawing.createCellComment(anchor);
        //set the comment text and author
        comment.setString(factory.createRichTextString(commentText));
        comment.setAuthor(author);

        cell.setCellComment(comment);
    }
	
	public static String getFileName() {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
       
        timeStamp=timeStamp.replace(":", "_");
        timeStamp=timeStamp.replace("-", "_");
        return timeStamp;
    }
}
