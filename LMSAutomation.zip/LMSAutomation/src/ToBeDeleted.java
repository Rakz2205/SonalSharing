import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ToBeDeleted {
	
	static ArrayList<String> pdfFiles = new ArrayList<String>();
	static String inputFolderPath;
	static String folderPath;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//System.out.println("Hello");
		//inputFolderPath="C:\\Rakesh\\Office Stuff\\UPI\\Recurring Mandate\\Automation\\RecurrenceMandatePojoClass\\UpdateMandate";
		//getAllFileNames();
		
		folderPath="C:\\Rakesh\\Office Stuff\\UPI\\Recurring Mandate\\API Responses";
		
		createNotepadFileIfNotExist("test");
		appendDataInNotepad(folderPath+"\\"+"test"+".txt","Hello");
	}
	
	public static void createNotepadFileIfNotExist(String testname) throws IOException
	{
		File file = new File(folderPath+"\\"+testname+".txt");
		file.createNewFile(); 
	}
	
	
	public static void appendDataInNotepad(String txtFilePath,String dataToWrite) throws IOException
	{
		File f1 = new File(txtFilePath);
		System.out.println(txtFilePath);
		FileWriter fileWritter = new FileWriter(txtFilePath,true);
		
		// adding bifurcation 
		
		fileWritter.write("\n");
		fileWritter.write("**********************************************************************************");
		fileWritter.write("\n");
		fileWritter.write("*********************************START********************************************");
		fileWritter.write("\n");
		fileWritter.write("\n");
		fileWritter.write(dataToWrite);
		
		fileWritter.write("\n");
		fileWritter.write("**********************************************************************************");
		fileWritter.write("\n");
		fileWritter.write("*********************************END********************************************");
		fileWritter.write("\n");
		fileWritter.write("\n");
		fileWritter.close();
        System.out.println("Done");
	}
	
	public static void getAllFileNames()
	 {
		 File folder = new File(inputFolderPath);
		 File[] listOfFiles = folder.listFiles();

		 for (int i = 0; i < listOfFiles.length; i++) {
		   if (listOfFiles[i].isFile()) 
		   {
		     //System.out.println("File " + listOfFiles[i].getName());
		     String strTemp=listOfFiles[i].getName();
		     System.out.println(strTemp);
		    	 pdfFiles.add(strTemp);
		    	 
		   } 
		 }
	 }

}
