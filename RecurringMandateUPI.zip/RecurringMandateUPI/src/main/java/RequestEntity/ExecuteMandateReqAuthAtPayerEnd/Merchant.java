
package RequestEntity.ExecuteMandateReqAuthAtPayerEnd;


public class Merchant {

    private String sid;

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

}
