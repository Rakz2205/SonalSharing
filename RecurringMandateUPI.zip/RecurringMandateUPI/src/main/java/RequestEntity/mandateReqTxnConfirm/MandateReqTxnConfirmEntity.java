
package RequestEntity.mandateReqTxnConfirm;


public class MandateReqTxnConfirmEntity {

    private ApiResp apiResp;

    public ApiResp getApiResp() {
        return apiResp;
    }

    public void setApiResp(ApiResp apiResp) {
        this.apiResp = apiResp;
    }

}
