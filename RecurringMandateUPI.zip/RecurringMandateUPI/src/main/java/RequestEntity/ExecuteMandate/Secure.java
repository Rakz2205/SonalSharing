
package RequestEntity.ExecuteMandate;


public class Secure {


}
