package RequestEntity;

public class RequestInfo {
    public String getPspRefNo() {
        return pspRefNo;
    }

    public void setPspRefNo(String pspRefNo) {
        this.pspRefNo = pspRefNo;
    }

    private String pspRefNo;

}
