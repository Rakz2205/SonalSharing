package RequestEntity;

public class Amount {
    public Float getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(Float netAmount) {
        this.netAmount = netAmount;
    }

    private Float netAmount;

}
