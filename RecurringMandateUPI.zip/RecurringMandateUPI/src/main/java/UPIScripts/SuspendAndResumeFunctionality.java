package UPIScripts;

import Pages.*;
import base.AppUIBaseClass;
import com.utilities.mobileUtils.ActionsUtility;

public class SuspendAndResumeFunctionality extends AppUIBaseClass {

    public static PassbookPage passbookPage =new PassbookPage();
    public static HomePage homePage=new HomePage();
    public static TransactionSummaryPage transactionSummaryPage=new TransactionSummaryPage();
    public static SMSvalidationPage smSvalidationPage=new SMSvalidationPage();
    public static ManageMandatePage manageMandatePage=new ManageMandatePage();

    public void validateSuspendMandateFunctionality(String startDate,String endDate,String mpinNo,String mandateStatus){
        loopToNavigateBack();
        unloackDevice();
        passbookPage.navigateToPassbook();
        waitAndActionOnElement(passbookPage.manageMandate);
        unloackDevice();
        waitAndActionOnElement(passbookPage.mandateDetail);
        ActionsUtility.swipeUp(androidDriver);
        transactionSummaryPage.performeSuspend(startDate,endDate,mpinNo);
        smSvalidationPage.validateRevokeSMS();
        loopToNavigateBack();
        unloackDevice();
        passbookPage.navigateToPassbook();
        waitAndActionOnElement(passbookPage.manageMandate);
        manageMandatePage.validateMandateStatus(mandateStatus);

    }

    public void validateResumeMandateFunctionality(String mpinNo,String mandateStatus){
        loopToNavigateBack();
        unloackDevice();
        passbookPage.navigateToPassbook();
        waitAndActionOnElement(passbookPage.manageMandate);
        unloackDevice();
        waitAndActionOnElement(passbookPage.mandateDetail);
        ActionsUtility.swipeUp(androidDriver);
        transactionSummaryPage.performeResume(mpinNo);
        smSvalidationPage.validateRevokeSMS();
        loopToNavigateBack();
        unloackDevice();
        passbookPage.navigateToPassbook();
        waitAndActionOnElement(passbookPage.manageMandate);
        manageMandatePage.validateMandateStatus(mandateStatus);

    }



}
