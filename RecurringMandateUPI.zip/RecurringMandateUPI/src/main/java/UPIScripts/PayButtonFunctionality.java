package UPIScripts;

import Pages.*;
import base.AppUIBaseClass;
import com.utilities.webUtils.WaitUtility;
import org.apache.logging.log4j.LogManager;

import java.net.MalformedURLException;

public class PayButtonFunctionality extends AppUIBaseClass {

    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(PayButtonFunctionality.class);

    public static HomePage homePage=new HomePage();
    public static CollectPayRequestFromPage collectPayRequestFromPage=new CollectPayRequestFromPage();
    public static PayPage payPage=new PayPage();
    public static MPinPage mPinPage=new MPinPage();
    public static TransactionSummaryPage transactionSummaryPage=new TransactionSummaryPage();
    public static SendMoneyPage sendMoney = new SendMoneyPage();
    public static TransferringSendMoneyPage tf = new TransferringSendMoneyPage();


    public static void payButtonFunctionalityScript(String BankName) throws InterruptedException, MalformedURLException {
        homePage.selectUPITab();
        collectPayRequestFromPage.clickOnPayButton();
        //validate upi shield
        sendMoney.selectDebitBank(BankName);
        //click on proceed
        payPage.proceedButton();
        WaitUtility.averageWait();
        //click on confirm button
        tf.clickOnConfirmButton();
        WaitUtility.averageWait();
        mPinPage.enterMpin("2580");
        WaitUtility.maximumWait();
        log.info("pay money functionality");
        transactionSummaryPage.validateTransactionStatus();
        transactionSummaryPage.clickOnSahreReceipt();
        //validate receipt
        assertUtility.softAssert.assertAll();

    }


}
