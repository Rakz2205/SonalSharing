package ToBeDeleted;

import ApiAutomation.RecurringMandateByPayee;
import ComponentFile.ApiComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Random;

public class FirstProgram extends SetUp {

    ApiComponent apiComponent;
    CommonMethods commMethod;
    // sample with Browser list multi value
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Third", "BrowserList:Chrome:IE"})
    public void myTest(String browserName, HashMap myData) throws InterruptedException {
        Reporter.initiateTestReport(FirstProgram.class, (String) myData.get("TestDescription"));
        System.out.println("Helo");
        System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
        //GenericVariable.DPS_QA_HOST;
    }

    // sample with No Browser list
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Test"})
    public void myTest1(HashMap myData) throws InterruptedException {
        System.out.println("Helo");
        //System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
    }

    // sample with Single Browser list
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Test", "BrowserList:Chrome"})
    public void myTest2(String browserName, HashMap myData) throws InterruptedException {
        System.out.println("Helo");
        System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
    }

    public void writeToFile(String apiName, String responseVal,HashMap myData,String description) throws IOException {
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"\\ResponsePayload.txt", true)));
        BufferedWriter bw = new BufferedWriter(out);
        bw.write(apiName+'\n'+responseVal+  myData.get(description)+"******");
        bw.close();

    }


    @Test
    public String EndDate(){
        LocalDate today = LocalDate.now();
       String date=today.format(DateTimeFormatter.ofPattern("dd"));
        System.out.println(date+"current dtae");
        return date;
    }



}
