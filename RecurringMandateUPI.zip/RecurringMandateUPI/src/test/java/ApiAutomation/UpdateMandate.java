package ApiAutomation;

import ComponentFile.ApiComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;

public class UpdateMandate extends SetUp {
    ApiComponent apiComponent;
    CommonMethods commMethod;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Update", "API", "UpdateMandate", "PositiveScenario"})
    public void UpdateMandateTest(HashMap myData) throws MalformedURLException, InterruptedException {
        Reporter.initiateTestReport(UpdateMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        commMethod.getUmnNo(myData,"umnNo");
        Response response = apiComponent.getResponseUpdateMandate(myData, (String) myData.get("umnNo"));
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnIdForOtherMadate);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Success);
    }


    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Update", "API", "UpdateMandate", "PositiveScenario"})
    public void UpdateMandateTestWithoutCreateMandateCall(HashMap myData) throws IOException {
        Reporter.initiateTestReport(UpdateMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseUpdateMandate(myData, (String) myData.get("uniqueMandateNumber"));

        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnIdForOtherMadate);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        apiComponent.writeToNotepad(APIEndPoints.recMandateCheckStatus+getTxndId,"no request data",response.headers(),response.prettyPrint(),(String) myData.get("TestDescription"),"getResponseMandateCheckStatusGet");

        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Initiated);
    }


    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:UpdateMandate", "API", "UpdateMandate", "NegativeScenario"})
    public void UpdateMandateTestNegativeTest(HashMap myData) throws MalformedURLException, InterruptedException {
        Reporter.initiateTestReport(UpdateMandate.class, String.format((String) myData.get("TestDescription")));
        commMethod.getUmnNo(myData,"umnNo");
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseUpdateMandate(myData,(String) myData.get("umnNo"));
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnIdForOtherMadate);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Initiated);
    }
}
