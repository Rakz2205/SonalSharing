package ApiAutomation;

import ComponentFile.ApiComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.HashMap;

public class RevokeMandate extends SetUp {
    ApiComponent apiComponent;
    CommonMethods commMethod;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:RevokeMandate", "API", "RevokeMandate", "PositiveScenario"})
    public void RevokeMandateTest(HashMap myData) {
        Reporter.initiateTestReport(RevokeMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseRevokeMandate(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnIdForOtherMadate);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:RevokeMandate", "API", "RevokeMandate", "NegativeScenario"})
    public void RevokeMandateTestNegative(HashMap myData) {
        Reporter.initiateTestReport(RevokeMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseRevokeMandate(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseField(response,status_Json_Path, status_Success);
    }
}
