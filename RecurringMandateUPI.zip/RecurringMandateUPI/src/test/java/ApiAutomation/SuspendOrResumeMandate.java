package ApiAutomation;

import ComponentFile.ApiComponent;
import DataProvider.BrowserNameProvider;
import UPIScripts.PayButtonFunctionality;
import UPIScripts.SuspendAndResumeFunctionality;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import base.AppUIBaseClass;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;

public class SuspendOrResumeMandate extends SetUp {
    ApiComponent apiComponent;
    CommonMethods commMethod;
    PayButtonFunctionality payButtonFunctionality;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:SuspendResume", "API", "SuspendResume", "PositiveScenario"})
    public void SuspendOrResumeMandateTest(HashMap myData) {
        Reporter.initiateTestReport(SuspendOrResumeMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseSuspendResumeMandate(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnIdForOtherMadate);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:SuspendResume", "API", "SuspendResume", "NegativeScenario"})
    public void SuspendOrResumeMandateTestNegative(HashMap myData) {
        Reporter.initiateTestReport(SuspendOrResumeMandate.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseSuspendResumeMandate(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:ReccuringCreateMandate_Payee", "API", "RecurringMandate", "PositiveScenario"})
    public void RecurringMandateCreateByPayeeSuspendTest(HashMap myData) throws IOException, InterruptedException {
      //  AppUIBaseClass.launchAppium();
        Reporter.initiateTestReport(RecurringMandateByPayee.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseCreateByPayee(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseField(response,status_Json_Path, status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnId);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        apiComponent.writeToNotepad(APIEndPoints.recMandateCheckStatus+getTxndId,"no request data",response.headers(),response.prettyPrint(),(String) myData.get("TestDescription"),"getResponseMandateCheckStatusGet");
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Pending);
       /* payButtonFunctionality=new PayButtonFunctionality();
        payButtonFunctionality.payButtonFunctionalityScript("Jio Payments Bank limited");
        SuspendAndResumeFunctionality suspendAndResumeFunctionality=new SuspendAndResumeFunctionality();
        suspendAndResumeFunctionality.validateSuspendMandateFunctionality("07","09","123456","SUSPENDED");*/
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:ReccuringCreateMandate_Payee", "API", "RecurringMandate", "PositiveScenario"})
    public void RecurringMandateCreateByPayeeSuspendAndResumeTest(HashMap myData) throws IOException, InterruptedException {
       // AppUIBaseClass.launchAppium();
        Reporter.initiateTestReport(RecurringMandateByPayee.class, String.format((String) myData.get("TestDescription")));
        apiComponent = new ApiComponent();
        commMethod = new CommonMethods();
        Response response = apiComponent.getResponseCreateByPayee(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseField(response,status_Json_Path, status_Initiated);
        String getTxndId=commMethod.getValueFromResponse(response, txnId);
        response=apiComponent.getResponseMandateCheckStatusGet(null,getTxndId);
        apiComponent.writeToNotepad(APIEndPoints.recMandateCheckStatus+getTxndId,"no request data",response.headers(),response.prettyPrint(),(String) myData.get("TestDescription"),"getResponseMandateCheckStatusGet");
        commMethod.validateResponseField(response,mandatePayerstatus_Json_Path, status_Success);
        commMethod.validateResponseField(response,mandatePayeestatus_Json_Path, status_Pending);
       /* payButtonFunctionality=new PayButtonFunctionality();
        payButtonFunctionality.payButtonFunctionalityScript("Jio Payments Bank limited");
        SuspendAndResumeFunctionality suspendAndResumeFunctionality=new SuspendAndResumeFunctionality();
        suspendAndResumeFunctionality.validateSuspendMandateFunctionality("07","09","123456","SUSPENDED");
        suspendAndResumeFunctionality.validateResumeMandateFunctionality("123456","RESUMED");*/
    }

}
