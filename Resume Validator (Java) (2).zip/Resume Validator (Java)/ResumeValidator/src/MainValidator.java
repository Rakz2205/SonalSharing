import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//import org.apache.poi.h


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class MainValidator 
{
	static DataFormatter dataFormatter = new DataFormatter();
	static HSSFWorkbook workbook;
	static HSSFSheet mainSheet;
	
	static String inputFolderPath;
	static String outputFolderPath;
	static String includeString;  //split with \n
	static String excludeString;
	static String inputFileName ="InputSheet.xls";
	
	static String[] arrInclude;
	
	static String[] arrExclude;
	
	static ArrayList<String> pdfFiles = new ArrayList<String>();
	static ArrayList<String> docFiles = new ArrayList<String>(); 
	static ArrayList<String> docxFiles = new ArrayList<String>();
	static ArrayList<String> invalidFiles = new ArrayList<String>();
	
	//output list
	static ArrayList<String> eachFileName = new ArrayList<String>();
	static ArrayList<String> includeFound = new ArrayList<String>(); 
	static ArrayList<String> includeNotFound = new ArrayList<String>();
	static ArrayList<String> includePercentage = new ArrayList<String>();
	static ArrayList<String> excludeFound = new ArrayList<String>(); 
	static ArrayList<String> excludeNotFound = new ArrayList<String>();
	static ArrayList<String> excludePercentage = new ArrayList<String>();
	static ArrayList<String> comment = new ArrayList<String>();
	
	
	public static void main(String[] args) throws IOException 
	{
		//fetch input data
		createExcelObject("C:\\Rakesh\\Office Stuff\\Interviews\\Finder Utility");
		fetchInputData();
		getAllFileNames();
		
		arrInclude = includeString.split("\n");
		arrExclude = excludeString.split("\n");
		
		readPdfFile();
		readDocFile();
		readDocxFile();
		
		createOutputFile();

	}
	

	private static void createOutputFile() throws IOException {
		// TODO Auto-generated method stub
		//need to create an output excel and write data
		
		// also write invalid files at last
		
		String outFileName="Output"+"_"+getFileName();
		
		// Create a Workbook
        Workbook workbook = new HSSFWorkbook();
         // Create a Sheet
        Sheet outputSheet = workbook.createSheet("Resuls");
        
        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBoldweight((short) 1);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        
        
     // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        
     // Create a Row
        Row headerRow = outputSheet.createRow(0);
        
     // Create cells
        Cell cell;
        cell = headerRow.createCell(0);
        cell.setCellValue("SR NO");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(1);
        cell.setCellValue("File Name");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(2);
        cell.setCellValue("Include Found");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(3);
        cell.setCellValue("Include Not Found");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(4);
        cell.setCellValue("Include Percentage");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(5);
        cell.setCellValue("Exclude Found");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(6);
        cell.setCellValue("Exclude Not Found");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(7);
        cell.setCellValue("Exclude Percentage");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(8);
        cell.setCellValue("Comments");
        cell.setCellStyle(headerCellStyle);
        
        int rowCounter=1;
        
        for(int excelInc=0;excelInc<eachFileName.size();excelInc++)
    	{
        	Row row = outputSheet.createRow(excelInc+1);
        	rowCounter=rowCounter+1;
        	row.createCell(0).setCellValue(excelInc+1);
        	row.createCell(1).setCellValue(eachFileName.get(excelInc));
        	row.createCell(2).setCellValue(includeFound.get(excelInc));
        	row.createCell(3).setCellValue(includeNotFound.get(excelInc));
        	row.createCell(4).setCellValue(includePercentage.get(excelInc));
        	row.createCell(5).setCellValue(excludeFound.get(excelInc));
        	row.createCell(6).setCellValue(excludeNotFound.get(excelInc));
        	row.createCell(7).setCellValue(excludePercentage.get(excelInc));
        	row.createCell(8).setCellValue(comment.get(excelInc));
    	}
        
        for(int errorInc=0;errorInc<invalidFiles.size();errorInc++)
        {
        	Row row = outputSheet.createRow(rowCounter+errorInc);
        	row.createCell(0).setCellValue(rowCounter+errorInc);
        	row.createCell(1).setCellValue(invalidFiles.get(errorInc));
        	row.createCell(8).setCellValue("Invalid File type");
        }
        
     // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream(outputFolderPath +"/"+outFileName+".xls");
        workbook.write(fileOut);
        fileOut.close();
	}


	public static void createExcelObject(String inputPath) throws IOException
    {
    	FileInputStream finput=new FileInputStream(inputPath + "\\" + inputFileName);
    	workbook =new HSSFWorkbook(finput);
    	mainSheet=workbook.getSheet("Main");
    }
	
	 public static void fetchInputData()
	 {
    	HSSFCell cell;
    	inputFolderPath = dataFormatter.formatCellValue(mainSheet.getRow(2).getCell(3));
    	outputFolderPath = dataFormatter.formatCellValue(mainSheet.getRow(4).getCell(3));
    	includeString = dataFormatter.formatCellValue(mainSheet.getRow(6).getCell(3));
    	excludeString = dataFormatter.formatCellValue(mainSheet.getRow(8).getCell(3));
	 }
	 
	 public static void getAllFileNames()
	 {
		 File folder = new File(inputFolderPath);
		 File[] listOfFiles = folder.listFiles();

		 for (int i = 0; i < listOfFiles.length; i++) {
		   if (listOfFiles[i].isFile()) 
		   {
		     System.out.println("File " + listOfFiles[i].getName());
		     String strTemp=listOfFiles[i].getName();
		     if(strTemp.toUpperCase().endsWith(".PDF"))
		     {
		    	 pdfFiles.add(strTemp);
		     }
		     else if(strTemp.toUpperCase().endsWith(".DOC"))
		     {
		    	 docFiles.add(strTemp);
		     }
		     else if(strTemp.toUpperCase().endsWith(".DOCX"))
		     {
		    	 docxFiles.add(strTemp);
		     }
		     else
		     {
		    	 invalidFiles.add(strTemp);
		    	 System.out.println(strTemp + "Invalid file extension please check");
		     }
		     
		   } 
		 }
	 }
	 
	 
	 private static void readDocxFile() 
	 {
			// TODO Auto-generated method stub
			//need to add read code and call updateOutputList
		 System.out.println("============DOCX Start");
		 for(int docxInc=0;docxInc<docxFiles.size();docxInc++)
		 {
			 System.out.println(docxFiles.get(docxInc));
				
				
				try
				{
					File file = new File(inputFolderPath + "\\" +docxFiles.get(docxInc));
					
					FileInputStream fis = new FileInputStream(file);
					
					XWPFDocument  document = new XWPFDocument (fis);
		          
		           String myText="";
		           List<XWPFParagraph> fileData = document.getParagraphs();
				for (XWPFParagraph para : fileData)
		           {
		        	   myText= myText + para.getText();
		           }
				fis.close();
		           updateOutputList(docxFiles.get(docxInc),myText);
				}
				catch(Exception e)
				{
					updateOutputList(docxFiles.get(docxInc),"");
				}
		 }
	 }
	 
	 private static void readDocxFile1() 
	 {
			// TODO Auto-generated method stub
			//need to add read code and call updateOutputList
		 System.out.println("============DOCX Start");
		 for(int docxInc=0;docxInc<docxFiles.size();docxInc++)
		 {
			 System.out.println(docxFiles.get(docxInc));
				
				try
				{
					XWPFDocument docx = new XWPFDocument(new FileInputStream(inputFolderPath + "\\" +docxFiles.get(docxInc)));
					XWPFWordExtractor we = new XWPFWordExtractor(docx);
					
		           String myText=we.getText();
		           updateOutputList(docxFiles.get(docxInc),myText);
				}
				catch(Exception e)
				{
					updateOutputList(docxFiles.get(docxInc),"");
				}
		 }
	 }

	private static void readDocFile() 
	{
		// TODO Auto-generated method stub
		//need to add read code and call updateOutputList
		System.out.println("============DOC Start");
		for(int docInc=0;docInc<docFiles.size();docInc++)
		{
			System.out.println(docFiles.get(docInc));
			
			
			try
			{
				File file = new File(inputFolderPath + "\\" +docFiles.get(docInc));
				
				FileInputStream fis = new FileInputStream(file);
				
	           HWPFDocument document = new HWPFDocument(fis);
	           WordExtractor extractor = new WordExtractor(document);
	           String myText="";
	           String[] fileData = extractor.getParagraphText();
	           for (int dataInc = 0; dataInc < fileData.length; dataInc++)
	           {
	        	   myText= myText + fileData[dataInc];
	           }
	           
	           updateOutputList(docFiles.get(docInc),myText);
			}
			catch(Exception e)
			{
				updateOutputList(docFiles.get(docInc),"");
			}
			
			
		}
	}

	private static void readPdfFile() 
	{
		System.out.println("============");
		for(int pdfInc=0;pdfInc<pdfFiles.size();pdfInc++)
		{
			System.out.println(pdfFiles.get(pdfInc));
			File file = new File(inputFolderPath + "\\" +pdfFiles.get(pdfInc));
		    try {
		    	PdfReader reader = new PdfReader(inputFolderPath + "\\" +pdfFiles.get(pdfInc));
		    	int n = reader.getNumberOfPages(); 
		    	
		    	String myText="";
		    	for(int pdfPages=1;pdfPages<=n;pdfPages++)
		    	{
		    		myText = myText + PdfTextExtractor.getTextFromPage(reader, pdfPages);
		    	}
		        updateOutputList(pdfFiles.get(pdfInc),myText);
		        
		    } catch (Exception e) {
		    	
		    	updateOutputList(pdfFiles.get(pdfInc),"");
		    }
		}
		
	}
	
	public static void updateOutputList(String resumeName,String strData)
	{
		eachFileName.add(resumeName);
		
		
		if(strData=="")
		{
			comment.add("Please Check Manually!!!");
			includeFound.add("");
			includeNotFound.add("");
			includePercentage.add("");
			excludeFound.add("");
			excludeNotFound.add("");
			excludePercentage.add("");
		}
		else
		{
			//include execution
			String returnData=searchKeyword(strData,true);
			
			String[] addArrTemp = returnData.split("%%");
			
			includeFound.add(addArrTemp[0]);
			includeNotFound.add(addArrTemp[1]);
			includePercentage.add(addArrTemp[2]);
			
			//exclude execution
			returnData=searchKeyword(strData,false);
			
			addArrTemp = returnData.split("%%");
			
			excludeFound.add(addArrTemp[0]);
			excludeNotFound.add(addArrTemp[1]);
			
			if(excludeString=="")
			{
				excludePercentage.add("");
			}
			else
			{
				excludePercentage.add(addArrTemp[2]);
			}
			comment.add("");
		}
		
	}
	
	public static String searchKeyword(String strAll,boolean isInclude)
	{
		
		String strFind="",strNotFound="";
		Double percentageMatch;
		String[] arrTemp;
		if(isInclude)
		{
			arrTemp = arrInclude;
		}
		else
		{
			arrTemp = arrExclude;
		}
		
		double foundCount=0;
		for(int i=0;i<arrTemp.length;i++)
		{
			if(strAll.toLowerCase().contains(arrTemp[i].toLowerCase()))
			{
				strFind=strFind+arrTemp[i]+"\n";
				foundCount=foundCount+1;
			}
			else
			{
				strNotFound=strNotFound+arrTemp[i]+"\n";
			}
		}
		
		percentageMatch= (foundCount/arrTemp.length)*100;
		
		System.out.println(strFind +"%%" + strNotFound + "%%" + percentageMatch);
		return (strFind +"%%" + strNotFound + "%%" + percentageMatch);
		
	}
	
	 public static String getFileName() {
	        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
	       
	        timeStamp=timeStamp.replace(":", "_");
	        timeStamp=timeStamp.replace("-", "_");
	        return timeStamp;
	    }
	 
	 

}
