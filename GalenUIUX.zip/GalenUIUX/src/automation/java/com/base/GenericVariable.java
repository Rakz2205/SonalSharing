package com.base;

public class GenericVariable {
	public static final String AutoPracticeForm = "https://demoqa.com/automation-practice-form/";

}
