package com.base;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class GenericWebMethod 
{
	
	/**
	 * Set the size of the browser window so that small, medium and large browser specifications
	 * an be measured
	 * 
	 * @author Rakesh Gupta
	 * 
	 * @param width and height
	 * 
	 */
	public void setBrowserSize(WebDriver driver,int setWidth,int setHeight) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		Dimension window_size=new Dimension(
				((Number) js.executeScript("return window.outerWidth - window.innerWidth +"+setWidth)).intValue(),
				((Number) js.executeScript("return window.outerWidth - window.innerWidth +"+setHeight)).intValue());
		driver.manage().window().setSize(window_size);
	}
}
