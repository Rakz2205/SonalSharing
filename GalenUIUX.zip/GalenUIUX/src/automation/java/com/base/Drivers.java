package com.base;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Drivers 
{
	
	public WebDriver driver;
	
	public WebDriver launchURL(String browserName, String urlToLaunch) {
		// TODO Auto-generated method stub
		if(browserName.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", new File("src/automation/java/com/webDriver/chromedriver.exe").getAbsolutePath());
			driver=(WebDriver) new ChromeDriver();
			driver.get(urlToLaunch);
			return driver;
		}
		else
		{
			return null;
		}
		
	}
	
}
