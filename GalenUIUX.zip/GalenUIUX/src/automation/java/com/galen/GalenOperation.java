package com.galen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.galenframework.api.Galen;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.HtmlReportBuilder;
import com.galenframework.reports.model.LayoutReport;

public class GalenOperation 
{

	public int executeGalenSpec(WebDriver driver, String specFilePath, String onScreenName, String resultFileName) throws IOException {
		//Create a layoutReport object
        //checkLayout function checks the layout and returns a LayoutReport object
		LayoutReport objLayoutReport =Galen.checkLayout(driver, specFilePath, Arrays.asList(onScreenName));
		
		
		//Create a galen test info list
		 List<GalenTestInfo> objGalentestsList	= new LinkedList<GalenTestInfo>();
		 
		//Create a GalenTestInfo object
	      GalenTestInfo objSingleGalenTest = GalenTestInfo.fromString(onScreenName+" main title here");
	      
	    //Get layoutReport and assign to test object
	       objSingleGalenTest.getReport().layout(objLayoutReport, onScreenName+" single test");
	       
	     //Add test object to the tests list
	      objGalentestsList.add(objSingleGalenTest);
	      
	    //Create a htmlReportBuilder object
	    HtmlReportBuilder htmlReportBuilder = new HtmlReportBuilder();
	    
	    //Create a report under specified folder based on tests list
        htmlReportBuilder.build(objGalentestsList, "ReportFolder_"+resultFileName);
		
        return objLayoutReport.errors();
	}

	public int executeGalenSpec(WebDriver driver, String specFilePath, List<String> allOnLists , String resultFileName) throws IOException {
		//Create a layoutReport object
        //checkLayout function checks the layout and returns a LayoutReport object
		LayoutReport objLayoutReport =Galen.checkLayout(driver, specFilePath, allOnLists);
		
		
		//Create a galen test info list
		 List<GalenTestInfo> objGalentestsList	= new LinkedList<GalenTestInfo>();
		 
		//Create a GalenTestInfo object
	      GalenTestInfo objSingleGalenTest = GalenTestInfo.fromString(resultFileName+" main title here");
	      
	    //Get layoutReport and assign to test object
	       objSingleGalenTest.getReport().layout(objLayoutReport, resultFileName + " Test");
	       
	     //Add test object to the tests list
	      objGalentestsList.add(objSingleGalenTest);
	      
	    //Create a htmlReportBuilder object
	    HtmlReportBuilder htmlReportBuilder = new HtmlReportBuilder();
	    
	    //Create a report under specified folder based on tests list
        htmlReportBuilder.build(objGalentestsList, "ReportFolder_"+resultFileName);
		
        return objLayoutReport.errors();
	}
		
}
