package com.galenAutomation;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.base.Drivers;
import com.base.GenericVariable;
import com.base.GenericWebMethod;
import com.galen.GalenOperation;


public class GalenConditionStatementTest {

	public String urlToLaunch=GenericVariable.AutoPracticeForm;
	public WebDriver driver;
	
	public GenericWebMethod gwm;
	
	@BeforeMethod
	public void setup() throws Exception {
		Drivers d=new Drivers();
		driver=d.launchURL("Chrome",urlToLaunch);
		gwm=new GenericWebMethod();
	}
	
	@AfterMethod
	public void setupEnd() throws Exception {
		driver.quit();
	}
	
	@Test(enabled = false)
	public void GalenConditonStatementSpecs() throws IOException
	{
		gwm.setBrowserSize(driver, 1600, 1200);
		String specFilePath="GalenSpecsDefinationFiles/GalenConditonStatementSpecs.gspec";
		GalenOperation galenOpt=new GalenOperation();
		int errorCount=galenOpt.executeGalenSpec(driver,specFilePath,"Conditional","GalenConditonStatementSpecsTest");
        //If layoutReport has errors Assert Fail
        if (errorCount > 0)
        {
        	System.out.println("Layout test failed for GalenConditonStatementSpecsTest");
            Assert.fail();
        }
        System.out.println("Layout test PASSED for GalenConditonStatementSpecsTest");
	}

}
