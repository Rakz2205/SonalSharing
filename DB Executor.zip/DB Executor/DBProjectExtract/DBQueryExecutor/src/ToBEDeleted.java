
public class ToBEDeleted {

	public static void main(String[] args) 
	{
		int abc=0;
		// TODO Auto-generated method stub
		try
		{
			abc=5/0;
		}
		catch(Exception e)
		{
			
		}
		
		System.out.println(abc);
		abc=10;
		System.out.println(abc);
	}

}
