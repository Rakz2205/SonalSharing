// need to replace all throws with try catch
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class DbConnectivity {
	public static Connection db_Connection = null;
	
	static DataFormatter dataFormatter = new DataFormatter();
	static HSSFWorkbook workbook;
	static HSSFSheet dbDataSheet;
	static HSSFSheet mainSheet;
	static String cHost;
	static String cSID;
	static String cUserName;
	static String sPassword;
	static String sPort;
	
	static String outputFolderPath,inputDataPath;
	//creating 7 list to store all values
	static ArrayList<String> scenario = new ArrayList<String>();
	static ArrayList<String> executeFlag = new ArrayList<String>(); 
	static ArrayList<String> srcQuery = new ArrayList<String>();
	static ArrayList<String> srcOutput = new ArrayList<String>();
	static ArrayList<String> destQuery = new ArrayList<String>();
	static ArrayList<String> destOutput = new ArrayList<String>();
	static ArrayList<String> comparisionOutput = new ArrayList<String>();
	static ArrayList<String> comments = new ArrayList<String>();
	
	
	public static void main(String[] args) throws IOException, SQLException 
	{
		// TODO Auto-generated method stub
		
		
		
		inputDataPath="C:\\Rakesh\\Office Stuff\\DB Executor\\InputSheet.xls";
		outputFolderPath="C:\\Rakesh\\Office Stuff\\DB Executor\\Results";
		
		createExcelObject(inputDataPath);
		fetchDBConnectionData();
		create_database_connection_Oracle(cHost,sPort,cSID,cUserName,sPassword);
		readAllQuery();
		executeSourceQuery();
		updateDestQuery();
		executeDestQuery();
		compareResult();
		
		createOutputFile();
		
		
		//String myQuery="select SOL_ID from custom.city_pin_mapper where PIN_CODE='125063'";
		
		
		
		
		/*ResultSet objTemp = execute_select_statement(myQuery);
		objTemp.next();
		//System.out.println(objTemp.getString("SOL_ID"));
		db_Connection.close();*/
	}
	
	private static void createOutputFile() throws IOException 
	{
		String outFileName="Output"+"_"+getFileName();
		
		// Create a Workbook
        Workbook workbook = new HSSFWorkbook();
         // Create a Sheet
        Sheet outputSheet = workbook.createSheet("Results");
        
        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBoldweight((short) 1);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        
        
     // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        
     // Create a Row
        Row headerRow = outputSheet.createRow(0);
        
     // Create cells
        Cell cell;
        cell = headerRow.createCell(0);
        cell.setCellValue("SR NO");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(1);
        cell.setCellValue("Scenario");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(2);
        cell.setCellValue("Execute Flag (Y/N)");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(3);
        cell.setCellValue("Source Query");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(4);
        cell.setCellValue("Source Query Output");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(5);
        cell.setCellValue("Destination Query");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(6);
        cell.setCellValue("Destination Query Output / Expected Value");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(7);
        cell.setCellValue("Comparision");
        cell.setCellStyle(headerCellStyle);
        
        cell = headerRow.createCell(8);
        cell.setCellValue("Comments");
        cell.setCellStyle(headerCellStyle);
        
        
        // entering all value
        
        CellStyle comparisionCellStylePass = workbook.createCellStyle();
        
        comparisionCellStylePass.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
        comparisionCellStylePass.setFillPattern((short) 1);
        
        
        CellStyle comparisionCellStyleFail = workbook.createCellStyle();
        
        comparisionCellStyleFail.setFillForegroundColor(IndexedColors.RED.getIndex());
        comparisionCellStyleFail.setFillPattern((short) 1);
        
        
        CellStyle comparisionCellStyleError = workbook.createCellStyle();
        
        comparisionCellStyleError.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        comparisionCellStyleError.setFillPattern((short) 1);
        
        for(int excelInc=0;excelInc<executeFlag.size();excelInc++)
    	{
        	Row row = outputSheet.createRow(excelInc+1);
        	
        	row.createCell(0).setCellValue(excelInc+1);
        	row.createCell(1).setCellValue(scenario.get(excelInc));
        	row.createCell(2).setCellValue(executeFlag.get(excelInc));
        	row.createCell(3).setCellValue(srcQuery.get(excelInc));
        	row.createCell(4).setCellValue(srcOutput.get(excelInc));
        	row.createCell(5).setCellValue(destQuery.get(excelInc));
        	row.createCell(6).setCellValue(destOutput.get(excelInc));
        	
        	String compareTempValue=comparisionOutput.get(excelInc);
        	if(compareTempValue.equalsIgnoreCase("PASS"))
        	{
        		cell = row.createCell(7);
                cell.setCellValue(compareTempValue);
                cell.setCellStyle(comparisionCellStylePass);
        	}
        	else if(compareTempValue.equalsIgnoreCase("FAIL"))
        	{
        		cell = row.createCell(7);
                cell.setCellValue(compareTempValue);
                cell.setCellStyle(comparisionCellStyleFail);
        	}
        	else if(compareTempValue.equalsIgnoreCase("ERROR"))
        	{
        		cell = row.createCell(7);
                cell.setCellValue(compareTempValue);
                cell.setCellStyle(comparisionCellStyleError);
        	}
        	else
        	{
        		row.createCell(7).setCellValue(compareTempValue);
        	}
        	
        	
        	
        	row.createCell(8).setCellValue(comments.get(excelInc));
        	
    	}
        
     // Resize all columns to fit the content size
        for(int i = 0; i < 9; i++) {
        	outputSheet.autoSizeColumn(i);
        	
        }
        
        
     // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream(outputFolderPath +"/"+outFileName+".xls");
        workbook.write(fileOut);
        fileOut.close();
        
	}

	private static void compareResult() 
	{
		for(int excelInc=0;excelInc<executeFlag.size();excelInc++)
    	{
			String exeFlag=executeFlag.get(excelInc);
			if(exeFlag.equalsIgnoreCase("Y"))
			{
				String srcOut=srcOutput.get(excelInc);
				String destOut=destOutput.get(excelInc);
				
				String commMessage=comments.get(excelInc);
				
				if(commMessage=="")
				{
					if(srcOut.equalsIgnoreCase(destOut))
					{
						comparisionOutput.set(excelInc, "PASS");
					}
					else
					{
						comparisionOutput.set(excelInc, "FAIL");
					}
				}
				else
				{
					comparisionOutput.set(excelInc, "ERROR");
				}
				
				
			}
    	}
		
	}

	private static void executeDestQuery()
	{
		for(int excelInc=0;excelInc<executeFlag.size();excelInc++)
    	{
			
			String exeFlag=executeFlag.get(excelInc);
			if(exeFlag.equalsIgnoreCase("Y"))
			{
				String destQueryTemp=destQuery.get(excelInc);
				
				if(destQueryTemp.length()>0)
				{
					//System.out.println(destQueryTemp);
					try
					{
						ResultSet objTemp = execute_select_statement(destQueryTemp);
						objTemp.next();
						
						// adding result in list
						//System.out.println(objTemp.getObject(1)+"");
						destOutput.set(excelInc,(objTemp.getObject(1)+""));
						objTemp.close();
					}
					catch(Exception e)
					{
						comments.set(excelInc, e.getMessage());
					}
					
				}
				
				
			}
			
    	}
		
	}

	private static void updateDestQuery() {
		//System.out.println("Before upadte function");
		for(int excelInc=0;excelInc<executeFlag.size();excelInc++)
    	{
			
			//System.out.println(destQuery.get(excelInc));
			String exeFlag=executeFlag.get(excelInc);
			if(exeFlag.equalsIgnoreCase("Y"))
			{
				String strTemp=destQuery.get(excelInc);
				////System.out.println("DEST preupdated :---------"+strTemp);
				if(strTemp.toUpperCase().contains("%%SRCOUT"))
				{
					strTemp=strTemp.replaceAll("%%SRCOUT", srcOutput.get(excelInc));
					////System.out.println("DEST Updated :---------"+strTemp);
					destQuery.set(excelInc, strTemp);
				}
				
			}
			
    	}
		
	}

	private static void executeSourceQuery() 
	{
		for(int excelInc=0;excelInc<executeFlag.size();excelInc++)
    	{
			
			String exeFlag=executeFlag.get(excelInc);
			if(exeFlag.equalsIgnoreCase("Y"))
			{
				
				
				try
				{
					//System.out.println(srcQuery.get(excelInc));
					ResultSet objTemp = execute_select_statement(srcQuery.get(excelInc));
					objTemp.next();
					
					// adding result in list
					//System.out.println(objTemp.getObject(1)+"");
					srcOutput.set(excelInc,(objTemp.getObject(1)+""));
				}
				catch(Exception e)
				{
					comments.set(excelInc, e.getMessage());
				}
				
				
			}
			
    	}
		
	}

	public static ResultSet execute_select_statement(String query) {
        ResultSet resultSet = null;
        try {
            Statement statement = db_Connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            resultSet = statement.executeQuery(query);

           // //System.out.println(query);
        } catch (Exception e) {
            throw new RuntimeException("Error while executing the select query.");
        }
        return resultSet;
    }
	
	/**
     * Method to create the Oracle database connection
     */
    public static void create_database_connection_Oracle(String host,String port, String SID, String username, String password) {
    	try {
        	
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //System.out.println("jdbc:oracle:thin:@"+host+":"+port+":"+SID+""+ ""+username+""+ ""+password+"");
            db_Connection = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+SID+"", ""+username+"", ""+password+"");
        } catch (Exception e) {
            throw new RuntimeException("Error while creating the DB connection", e);
        }
    	
    	
    }
    
    public static void createExcelObject(String inputPath) throws IOException
    {
    	FileInputStream finput=new FileInputStream(inputPath);
    	workbook =new HSSFWorkbook(finput);
    	dbDataSheet=workbook.getSheet("DB Data");
    	mainSheet=workbook.getSheet("Main");
    }
    
    public static void fetchDBConnectionData()
    {
    	HSSFCell cell;
    	
    	 cHost = dataFormatter.formatCellValue(dbDataSheet.getRow(1).getCell(1));
    	 cSID = dataFormatter.formatCellValue(dbDataSheet.getRow(2).getCell(1));
    	 cUserName = dataFormatter.formatCellValue(dbDataSheet.getRow(3).getCell(1));
    	 sPassword = dataFormatter.formatCellValue(dbDataSheet.getRow(4).getCell(1));
    	 sPort = dataFormatter.formatCellValue(dbDataSheet.getRow(5).getCell(1));
    	
    	
    	//System.out.println(cHost +"----" + sPort);
    }
    
    
    public static void readAllQuery()
    {
    	HSSFCell cell;
    	
    	FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
    	
    	int lastRowCount=mainSheet.getLastRowNum();
    	
    	for(int excelInc=1;excelInc<=lastRowCount;excelInc++)
    	{
    		scenario.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(1),evaluator));
    		executeFlag.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(2),evaluator));
			srcQuery.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(3),evaluator));
			srcOutput.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(4),evaluator));
			destQuery.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(5),evaluator));
			destOutput.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(6),evaluator));
			comparisionOutput.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(7),evaluator));
			comments.add(excelInc-1,dataFormatter.formatCellValue(mainSheet.getRow(excelInc).getCell(8),evaluator));
    	}
    	
    }
    
    public static String getFileName() {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
       
        timeStamp=timeStamp.replace(":", "_");
        timeStamp=timeStamp.replace("-", "_");
        return timeStamp;
    }
   
}
