package enach.finacle;

import com.utilities.connectionUtils.DataBaseUtility;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Rough {

    public static void main(String args[]) throws Exception {
        String accountNo="30000000043456";
        String cbsquery = "select Clr_bal_amt from TBAADM.GAM where foracid ='" + accountNo + "' ";

        DataBaseUtility.createOracleDatabaseConnection("10.144.109.133", "1521", "DBII", "dbread", "dbread");
        int cbsAmount=0,thresholdAmount=0,reqAmount=0;
        ResultSet resultSet = DataBaseUtility.executeSelectStatement(cbsquery);

        if (DataBaseUtility.getRowCount(resultSet) == 0)
            throw new Exception("No records found in CBS table for Account Number:"+accountNo);

        if (resultSet.next()) {
            cbsAmount = Integer.parseInt(resultSet.getString("CLR_BAL_AMT"));

        }
        System.out.println("CBS Amount: "+cbsAmount);


        String autoTopUpquery = "select THRESHOLD_AMOUNT/100 AS THRESHOLD_AMOUNT from JPB_AUTOTOPUP_MANDATE where ACCOUNT_NUMBER='" + accountNo + "' and STATUS='5' order by CREATED_AT desc";

        DataBaseUtility.createOracleDatabaseConnection("10.144.109.129", "1535", "nach", "SI_AUTOP_RO", "Dji1#Mls");

        ResultSet resultSet2 = DataBaseUtility.executeSelectStatement(autoTopUpquery);

        if (DataBaseUtility.getRowCount(resultSet2) == 0)
            throw new Exception("No records found in AutoTopUp table for Account Number:"+accountNo);

        if (resultSet2.next()) {
            thresholdAmount = Integer.parseInt(resultSet2.getString("THRESHOLD_AMOUNT"));

        }
        System.out.println("Threshold Amount: "+thresholdAmount);

        if(cbsAmount<thresholdAmount)
        {
            reqAmount=1;
        }
        else {
            int diff = cbsAmount - thresholdAmount;
            reqAmount = Math.abs(diff)+1;

        }

        System.out.println(reqAmount);


    }

}
