package enach.finacle;


import base.BaseClass;
import com.utilities.fileUtils.ExcelUtility;
import com.utilities.reportUtils.ExtentUtility;
import enach.listeners.TestExtentListener;
import org.testng.annotations.*;
import testUtilities.ConnectionSetUp;
import testUtilities.SetUpTest;

import java.util.Map;

import static base.BaseClass.configProperties;
import static base.ConstantsER.CHROME;
import finacleDebitActivity.FinaclePages;


@Listeners(TestExtentListener.class)
public class FinacleDebitActivity extends SetUpTest {


    public static int testCounter = 0;

    @Test(dataProvider = "TestDataProvider")
    public void testFinacle(Map<Object, Object> testData) throws Exception {

        FinaclePages finaclePages= new FinaclePages();

        finaclePages.initializeURL();

        finaclePages.loginInToFinacle();

        finaclePages.tapNEFTRTGSButton();

        finaclePages.enterDebitDetails(testData);

        Thread.sleep(10000);






    }


    @BeforeMethod
    public void beforeSetup() {
        if (!testName.equalsIgnoreCase(this.getClass().getSimpleName())) {
            testName = this.getClass().getSimpleName();
            extentTest = ExtentUtility.createTestNode(extentReports, this.getClass().getSimpleName());
        }
        BaseClass.extentTestChildNode = ExtentUtility.createTestSuitNode(extentTest, "ENACH_TC_" + testCounter++);
        BaseClass.webProperties = configProperties;
        BaseClass.launchApplication(configProperties,CHROME);
    }

    @AfterMethod
    public void afterSetup() {

        BaseClass.extentTestChildNode = null;
        BaseClass.closeApplication();



    }



    /**
     * Data provider provides the test data, here you need to mention the test data
     * sheet path, test data sheet name and test case name
     */
    @DataProvider(name = "TestDataProvider")
    public Object[][] testDataProvider() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "eNachRegistrationDestBank", "eNachRegistration");
    }
}
