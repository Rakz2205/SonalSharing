package enach.simulator;


import com.utilities.fileUtils.ExcelUtility;
import com.utilities.reportUtils.ExtentUtility;
import enach.listeners.TestExtentListener;

import testUtilities.ConnectionSetUp;
import testUtilities.SetUpTest;
import org.testng.annotations.*;
import base.BaseClass;
import pages.JioPaymentBankPage;
import pages.SimulatorPage;

import java.util.Map;

import static base.BaseClass.*;
import static base.ConstantsER.CHROME;


@Listeners(TestExtentListener.class)
public class eMandateRegistration extends SetUpTest {


    public static int testCounter = 0;

    @Test(dataProvider = "TestDataProvider")
    public void testMandateRegistration(Map<Object, Object> testData) throws Exception {


        SimulatorPage simulatorPage = new SimulatorPage();

        JioPaymentBankPage jioPaymentBankPage = new JioPaymentBankPage();

        simulatorPage.printCaseScenarioName(testData);

        simulatorPage.initializeURL();

        simulatorPage.loginInToSimulator();

        simulatorPage.tapAutoFillFormButton();

        simulatorPage.enterCustomerDetails(testData);

        jioPaymentBankPage.enterJioCredentials(testData);

        jioPaymentBankPage.reviewDetails((String) testData.get("ApproveORReject"));

        jioPaymentBankPage.enterOTPDetails(testData);

        jioPaymentBankPage.verifySummaryPage(testData);

        jioPaymentBankPage.clickDoneButton();

        System.out.println("Reached");


    }


    @BeforeMethod
    public void beforeSetup() {
        if (!testName.equalsIgnoreCase(this.getClass().getSimpleName())) {
            testName = this.getClass().getSimpleName();
            extentTest = ExtentUtility.createTestNode(extentReports, this.getClass().getSimpleName());
        }
        BaseClass.extentTestChildNode = ExtentUtility.createTestSuitNode(extentTest, "ENACH_TC_" + testCounter++);
        BaseClass.webProperties = configProperties;
        BaseClass.launchApplication(configProperties,CHROME);
    }

    @AfterMethod
    public void afterSetup() {
        //ConnectionSetUp.closeTestConnections();

        BaseClass.extentTestChildNode = null;
        BaseClass.closeApplication();



    }



    /**
     * Data provider provides the test data, here you need to mention the test data
     * sheet path, test data sheet name and test case name
     */
    @DataProvider(name = "TestDataProvider")
    public Object[][] testDataProvider() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "eNachRegistrationDestBank", "eNachRegistration");
    }
}
