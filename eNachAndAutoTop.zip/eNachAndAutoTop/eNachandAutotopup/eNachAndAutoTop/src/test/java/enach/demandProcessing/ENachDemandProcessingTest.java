package enach.demandProcessing;

import base.BaseClass;
import com.utilities.fileUtils.ExcelUtility;
import demandProcessingUtils.GenerateINWFile;
import demandProcessingUtils.TriggerFileProcess;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static demandProcessingUtils.UploadToSFTPServer.uploadINWFile;

public class ENachDemandProcessingTest extends BaseClass {

    @DataProvider
    public Object[][] testDataProvider()
    {
        return ExcelUtility.getDataFromExcel(System.getProperty("user.dir")+"\\TestData\\ENACH_DR_TestData.xlsx","eNachDemandProcessing","eNachDemandProcessing");
    }

    GenerateINWFile generateINWFile;
    public static Logger log = LogManager.getLogger(ENachDemandProcessingTest.class);

    @BeforeClass
    public void setUp()
    {
        generateINWFile = new GenerateINWFile();
        totalDebitAmount = 0;
    }

    @Test(dataProvider = "testDataProvider")
    public void VerifyAllScenariosDataFlow(HashMap testDataMap) {
        try
        {
            log.info("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n Demand Registration Scenario: "+testDataMap.get("TestdataType")+ "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            log.info(testDataMap);
            String scenarios = GenerateINWFile.formScenariosString(testDataMap);
            ArrayList<Map<String, String>> fileInputList = GenerateINWFile.formListHashMapOfDBRecords(configProperties.getProperty("ColumnNames"),scenarios);
            GenerateINWFile.writingReplacedValuesToFile(fileInputList, configProperties.getProperty("TestInputTemplate"));
            GenerateINWFile.runFileGeneratorJar(configProperties.getProperty("FileGeneratorUtilityPath"),"1");
            uploadINWFile();
            boolean missingRecordsFound = TriggerFileProcess.performFileProcessValidations(fileInputList);
            GenerateINWFile.addAccountNumbersAndCBSAmountAfterDebit();
            GenerateINWFile.compareCBSAmounts(missingRecordsFound);
            log.info("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n End of Test: "+testDataMap.get("TestdataType")+ "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");

        } catch (Exception e) {
            log.info("Assertion Exception: "+e.getMessage());
            throw new RuntimeException("Exception in VerifyAllScenariosDataFlow(): "+e.getMessage());
        }

    }

    @BeforeMethod
    public void beforeSetup() {
        softAssert = new SoftAssert();
        deleteXMLAndTextFiles();
    }

    @AfterMethod
    public void afterSetup() {
        extentTestChildNode = null;
    }
}
