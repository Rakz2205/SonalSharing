package enach.app;


import base.BaseClass;
import com.utilities.fileUtils.ExcelUtility;
import com.utilities.reportUtils.ExtentUtility;
import enach.listeners.TestExtentListener;
import mobilepages.AutoTopUpPage;
import mobilepages.MyJioHome;
import mobilepages.NetBankingPortalPage;
import mobilepages.SummaryPage;
import testUtilities.SetUpTest;
import static base.BaseClass.*;
import static base.ConstantsER.MOBILE;

import org.apache.logging.log4j.LogManager;
import org.testng.annotations.*;

import java.util.Map;


@Listeners(TestExtentListener.class)
public class AutoTopUpRegistration extends SetUpTest {


    public static int testCounter = 0;

    @Test(dataProvider = "TestDataProvider")
    public void testMobileTransaction(Map<Object, Object> testData) throws Exception {

        LogManager.getLogger(AutoTopUpRegistration.class).info("Hello Sample Test Case.");

        MyJioHome myJioHome= new MyJioHome();
        AutoTopUpPage autoTopUpPage = new AutoTopUpPage();
        NetBankingPortalPage netBankingPortalPage =new NetBankingPortalPage();
        SummaryPage summaryPage = new SummaryPage();

        myJioHome.clickOnMoreOption();

        myJioHome.clickOnFinanceOption();

        myJioHome.scrollandClickAutoTopUp();

        autoTopUpPage.setAutoTopUp(testData);

        autoTopUpPage.enterBankAccountDetails(testData);

        netBankingPortalPage.netBankingPortal();

        summaryPage.verifySummaryPage();




    }


    @BeforeMethod
    public void beforeSetup() {
      //  ConnectionSetUp.createTestConnections();
        if (!testName.equalsIgnoreCase(this.getClass().getSimpleName())) {
            testName = this.getClass().getSimpleName();
          //  extentTest = ExtentUtility.createTestNode(extentReports, this.getClass().getSimpleName());
        }
     //   BaseClass.extentTestChildNode = ExtentUtility.createTestSuitNode(extentTest, "AutoTopUp_TC_" + testCounter++);
        BaseClass.launchApplication(configProperties,MOBILE);
    }

    @AfterMethod
    public void afterSetup() {
     //   ConnectionSetUp.closeTestConnections();
      //  BaseClass.extentTestChildNode = null;
        BaseClass.closeApplication();
    }

    /**
     * Data provider provides the test data, here you need to mention the test data
     * sheet path, test data sheet name and test case name
     */
    @DataProvider(name = "TestDataProvider")
    public Object[][] testDataProvider() {
        return ExcelUtility.getDataFromExcel(testDataSheetPath, "AutoTopUpSponsorBank", "AutoTopUpRegistration");
    }
}
