package finacleDebitActivity;


import base.BaseClass;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.reportUtils.ExtentUtility;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import java.sql.ResultSet;
import java.util.Map;

import static demandProcessingUtils.GetCBSAmount.getAmountFromCBS;


public class FinaclePages extends BaseClass {


    public FinaclePages()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 10), this);
    }



    @FindBy(xpath = "//input[@id='username']")
    public WebElement txtBoxUserName;


    @FindBy(xpath = "//input[@id='password']")
    public WebElement txtBoxPassword;


    @FindBy(xpath = "//button[@id='login']")
    public WebElement btnLogin;




    public  void initializeURL() {
        String webURL;
        try {
            webURL = webProperties.getProperty("FinacleURL");

            driver.get(webURL);
            LogManager.getLogger(FinaclePages.class).info("successfully launched the Finacle URL : " + webURL);

        } catch (Exception e) {
            LogManager.getLogger(FinaclePages.class).error("error while launching the Finacle url.\n" + e.getMessage());

            throw new RuntimeException("error while launching the Finacle url.", e);
        }
    }



    public void loginInToFinacle() {

        try {

              String  userName = webProperties.getProperty("FinacleUserID");
              String  password = webProperties.getProperty("FinaclePassword");

            txtBoxUserName.sendKeys(userName);

            txtBoxPassword.sendKeys(password);
            btnLogin.click();

            LogManager.getLogger(FinaclePages.class).info("login into Finacle portal.");
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "login into Finacle portal", driver);

        } catch (Exception e) {

            LogManager.getLogger(FinaclePages.class).error("error while login into the Finacle portal.");
            ExtentUtility.logExtent(extentTestChildNode, "Fail", "error while login into the Finacle portal.", driver);
            throw new RuntimeException("Error while login into the application.", e);
        }
    }


    public void tapNEFTRTGSButton() {
        try {
            driver.findElement(By.xpath("//button[contains(text(),'NEFT/RTGS')]")).click();
            LogManager.getLogger(FinaclePages.class).info("Clicked on NEFT/RTGS button.");
            Thread.sleep(3000);

        } catch (Exception e) {

            LogManager.getLogger(FinaclePages.class).error("Unable to tap on the NEFT/RTGS button.\n " + e.getMessage());
            throw new RuntimeException(
                    "tapNEFTRTGSButton || Tap on NEFT/RTGS button on Finacle page."
                            + e.getMessage(), e);
        }
    }



    public void enterDebitDetails(Map<Object, Object> map)
    {
        try {

            String amtToBeEntered=getAmountToBeDebited("30000000043456");

            System.out.println("Amount to be Entered "+amtToBeEntered);

            driver.findElement(By.xpath("//input[@placeholder='Remitter Account number']")).sendKeys("1234567890");

            driver.findElement(By.xpath("//input[@placeholder='AMOUNT']")).sendKeys(amtToBeEntered);

            driver.findElement(By.xpath("//button[@id='paynow']")).click();

            Thread.sleep(3000);
            String expResponse=driver.findElement(By.xpath("//strong[contains(text(),'Posted Successfully...')]")).getText();

            Assert.assertEquals(expResponse,"Posted Successfully...");

        }
        catch (Exception e) {

            LogManager.getLogger(FinaclePages.class).error("Error while entering debit details in Finacle's Page.\n " + e.getMessage());
            throw new RuntimeException(
                    "FinaclePage : enterCustomerDetails || Error while entering debit details in Finacle's Page."
                            + e.getMessage(), e);
        }
    }


    public String getAmountToBeDebited(String accountNo)
    {
        String reqAmt="";

        try {
          //  String accountNo="30000000043456";
            String cbsquery = "select Clr_bal_amt from TBAADM.GAM where foracid ='" + accountNo + "' ";

            DataBaseUtility.createOracleDatabaseConnection("10.144.109.133", "1521", "DBII", "dbread", "dbread");

            int cbsAmount=0,thresholdAmount=0,reqAmount=0;

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(cbsquery);

            if (DataBaseUtility.getRowCount(resultSet) == 0)
                throw new Exception("No records found in CBS table for Account Number:"+accountNo);

            if (resultSet.next()) {
                cbsAmount = Integer.parseInt(resultSet.getString("CLR_BAL_AMT"));

            }
            System.out.println("CBS Amount: "+cbsAmount);


            String autoTopUpquery = "select THRESHOLD_AMOUNT/100 AS THRESHOLD_AMOUNT from JPB_AUTOTOPUP_MANDATE where ACCOUNT_NUMBER='" + accountNo + "' and STATUS='5' order by CREATED_AT desc";

            DataBaseUtility.createOracleDatabaseConnection("10.144.109.129", "1535", "nach", "SI_AUTOP_RO", "Dji1#Mls");

            ResultSet resultSet2 = DataBaseUtility.executeSelectStatement(autoTopUpquery);

            if (DataBaseUtility.getRowCount(resultSet2) == 0)
                throw new Exception("No records found in AutoTopUp table for Account Number:"+accountNo);

            if (resultSet2.next()) {
                thresholdAmount = Integer.parseInt(resultSet2.getString("THRESHOLD_AMOUNT"));

            }
            System.out.println("Threshold Amount: "+thresholdAmount);

            if(cbsAmount<thresholdAmount)
            {
                reqAmount=1;
            }
            else {
                int diff = cbsAmount - thresholdAmount;
                reqAmount = Math.abs(diff)+1;

            }

            System.out.println(reqAmount);
            reqAmt=String.valueOf(reqAmount);


        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return reqAmt;
    }





}
