package testUtilities;

import base.BaseClass;
import com.utilities.connectionUtils.DataBaseUtility;

public class ConnectionSetUp extends BaseClass {

    public static void createTestConnections() {
        try {
            //  Create database connection
            if (configProperties.getProperty("Environment").equalsIgnoreCase("PP")) {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty("PP_DB_UserHost"), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            } else {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty("SIT_DB_UserHost"), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            }

        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void createCBSConnection(String instanceType) {
        try {
            String instance = "SIT_CBS_INS_"+instanceType;
            //  Create database connection
            if (configProperties.getProperty("Environment").equalsIgnoreCase("PP")) {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty(instance), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            } else {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty(instance), configProperties.getProperty("SIT_CBS_USERNAME"), configProperties.getProperty("SIT_CBS_PASSWORD"));
            }

        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void closeTestConnections() {
        try {
            //  disconnecting database
            DataBaseUtility.dbConnection.close();

            //  disconnect unix connection
       //     UnixUtility.session.disconnect();
        } catch (Exception e) {
            throw new RuntimeException("error while closing the test connections.", e);
        }
    }
}
