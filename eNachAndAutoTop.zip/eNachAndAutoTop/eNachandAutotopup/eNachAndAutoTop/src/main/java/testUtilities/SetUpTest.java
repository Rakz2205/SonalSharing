package testUtilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utilities.fileUtils.PropertiesUtility;
import com.utilities.reportUtils.ExtentUtility;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.util.Properties;

public class SetUpTest {
    public static String testDataSheetPath;
    public static Properties properties;
    public static ExtentReports extentReports;
    public static ExtentTest extentTest;
    public static String testName = "";

    @BeforeTest
    public void SetUp() {
        try {
            //  get config properties
            properties = PropertiesUtility.getApplicationProperties("config.properties");

            //  get test data file name
            testDataSheetPath = System.getProperty("user.dir") + "\\TestData\\" + properties.getProperty("TestDataSheetName");


            extentReports = ExtentUtility.createReport(properties.getProperty("ExtentTestName")+"_"+System.currentTimeMillis());
        } catch (Exception e) {
            throw new RuntimeException(
                    "SetUpTest : SetUp || Error while setting up the test environment.\n" + e.getMessage(), e);
        }
    }

    @AfterTest
    public void CleanUp()  {
        //  to create extent report
        extentReports.flush();
    }

    public static void ImplicitWait()
    {

    }
}
