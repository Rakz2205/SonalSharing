package base;

public interface Constants {

    int THRESHOLD_TIME=120;
    int DEBIT_AMOUNT_IN_PAISE =100; //enter in paise

    String INWARD_FILE_PROCESS="INWARDFILEPROCESS";
    String JPB_DEBIT_FILE_PROCESS="JPBDEBITFILEPROCESS";
    String RETURN_FILE_PROCESS="RETURNFILEPROCESS";

    //Negative Scenarios
    String ALL_SCENARIOS="RECEIVED_STATUS|ACCEPTED_STATUS|REJECTED_STATUS|TOKEN_AF_STATUS|AMOUNT_GREATER_MAX|INCORRECT_UMRN_NUMBER|INCORRECT_ACCOUNT_NUMBER|INCORRECT_SP_BANK_CODE|INCORRECT_DEST_BANK_CODE|INACTIVE_ACCOUNT|FREEZE_ACCOUNT|DORMANT_ACCOUNT|CLOSED_ACCOUNT|";

    //Invalid eMandate Status Scenarios
    String RECEIVED_STATUS = "RECEIVED_STATUS";
    String ACCEPTED_STATUS = "ACCEPTED_STATUS";
    String REJECTED_STATUS = "REJECTED_STATUS";
    String TOKEN_AF_STATUS = "TOKEN_AF_STATUS";

    //Missing Value Scenarios
    String MISSING_UMRN_NUMBER="MISSING_UMRN_NUMBER";
    String MISSING_DEST_BANK_CODE="MISSING_DEST_BANK_CODE";
    String MISSING_SP_BANK_CODE="MISSING_SP_BANK_CODE";
    String MISSING_RECORD_MESSAGE_ID="MISSING_RECORD_MESSAGE_ID";
    String MISSING_ACCOUNT_NUMBER="MISSING_ACCOUNT_NUMBER";

    //Incorrect Value Scenarios
    String INCORRECT_UMRN_NUMBER="INCORRECT_UMRN_NUMBER";
    String INCORRECT_ACCOUNT_NUMBER="INCORRECT_ACCOUNT_NUMBER";
    String INCORRECT_SP_BANK_CODE="INCORRECT_SP_BANK_CODE";
    String INCORRECT_DEST_BANK_CODE="INCORRECT_DEST_BANK_CODE";
    String INCORRECT_CORP_CODE="INCORRECT_CORP_CODE";
    String AMOUNT_GREATER_MAX="AMOUNT_GREATER_MAX";
    String AMOUNT_GREATER_CBS_BAL = "AMOUNT_GREATER_CBS_BAL";
    String DUPLICATE_RECORD_ID = "DUPLICATE_RECORD_ID";
    String BEFORE_MANDATE_START_DATE="BEFORE_MANDATE_START_DATE";
    String AFTER_MANDATE_END_DATE ="AFTER_MANDATE_END_DATE";
    String INCORRECT_FILE_NAME="INCORRECT_FILE_NAME";

    //Invalid Account State Scenarios
    String INACTIVE_ACCOUNT="INACTIVE_ACCOUNT";
    String FREEZE_ACCOUNT="FREEZE_ACCOUNT";
    String DORMANT_ACCOUNT="DORMANT_ACCOUNT";
    String CLOSED_ACCOUNT="CLOSED_ACCOUNT";

    String GREATER_SETTLEMENT_DATE="GREATER_SETTLEMENT_DATE";
    String MISSING_AMOUNT="MISSING_AMOUNT";
    String MISSING_ACH_SEQUENCE_NUMBER="MISSING_ACH_SEQUENCE_NUMBER";

    //Missing Parameters State Reason Code
    String FILE_HEADER_FORMAT_VALIDATION = "FILE_HEADER_FORMAT_VALIDATION";
    String FILE_RECORD_FORMAT_VALIDATION = "FILE_RECORD_FORMAT_VALIDATION";
    String FILE_NAME_FAILURE="FILE_NAME_FAILURE";

    //Missing Parameters Remarks
    String AMOUNT_GREATER_MAX_REMARKS = "File Created";
    String MISSING_UMRN_NUMBER_REMARKS = "UMRN ERROR-Oops!! Received inward file with record having invalid UMRN number";
    String MISSING_SP_BANK_CODE_REMARKS = "Oops!! Received inward file with incorrect with record having invalid value of sponsor bank code";
    //JIOP7010812200000009-Oops!! Received inward file with incorrect with record having invalid value of
    String MISSING_DEST_BANK_CODE_REMARKS = "Oops!! Received inward file with wrong header having invalid Header destination bank code";
    //Oops!! Received inward file with header having invalid value of ISO mandatory param
    String MISSING_RECORD_MESSAGE_ID_REMARKS = "Oops!! Received inward file with incorrect with record having invalid value of headerRecord Transact";
    //JIOP7010812200000009-Oops!! Received inward file with incorrect with record having invalid value of
    String MISSING_ACCOUNT_NUMBER_REMARKS = "Oops!! Received inward file with incorrect with record having invalid value of  beneficiary account";
    //JIOP7010812200000009-Oops!! Received inward file with incorrect with record having invalid value of
    String MISSING_AMOUNT_REMARKS = "Oops!! Received inward file with incorrect with record having invalid value of  beneficiary account";
    String MISSING_ACH_SEQUENCE_NUMBER_REMARKS = "Oops!! Received inward file with record having invalid ACH sequence number";
    String FILE_NAME_FAILURE_REMARKS="File Name Validation Failure";
    //Validations
    String VALIDATION_COMPLETED="VALIDATION_COMPLETED";
    String FILE_CREATED_REMARKS="File Created";
    String SCHEDULED_SRC="SCHEDULED";
    String SUCCESS_SRC="230010";
    String SUCCESS_REMARKS="Debit Successful";
    //Debit Successful
    String MANDATE_NOT_RECEIVED_SRC="230005";
    String MANDATE_NOT_RECEIVED_REMARKS="Mandate not received";
    String AMOUNT_MISMATCH_SRC="230006";
    String AMOUNT_MISMATCH_REMARKS="Amount mismatch between mandate and Transaction";
    String INVALID_IFSC_SRC="230009";
    String INVALID_IFSC_REMARKS="Invalid IFSC";
    String GENERIC_ERROR_CODE_SRC ="230000";
    String GENERIC_ERROR_CODE_REMARKS ="Generic Error code";
    String ACCOUNT_FREEZE_SRC ="30523";
    String ACCOUNT_FREEZE_REMARKS ="Account either freezed or invalid account details";
    String ACCOUNT_INACTIVE_DORMANT_SRC ="30528";
    String ACCOUNT_INACTIVE_DORMANT_REMARKS ="Account is Inactive/Dormant";
    String ACCOUNT_CLOSED_SRC ="30527";
    String ACCOUNT_CLOSED_REMARKS ="Account is closed";
    String INCORRECT_ACCOUNT_NUMBER_SRC ="30524";
    String INCORRECT_ACCOUNT_NUMBER_REMARKS ="Invalid account details";
    String INSUFFICIENT_FUNDS_SRC ="21004";
    String INSUFFICIENT_FUNDS_REMARKS ="Insufficient Funds";
    String MANDATE_EXPIRED_SRC="230004";
    String MANDATE_EXPIRED_REMARKS="Mandate Expired";
    String DUPLICATE_RECORD_ID_SRC="230003";
    String DUPLICATE_RECORD_ID_REMARKS="Duplicate Transaction";
    String GENERATED_RETURN_FILE="GENERATED_RETURN_FILE";

    //Assertion Messages
    String AMOUNT_NOT_TALLIED = "Amount not Tallied";

    String REMOVE_PREVAILING_ZEROS = "^0+(?!$)";
    long MAX_WAIT_TIME=30000;
    long MIN_WAIT_TIME=20000;

    //DB Column Names
    String ACH_DEST_INWARD_FILE_SRC="ACH_DEST_INWARD_FILE_SRC";
    String ACH_DEST_INWARD_FILE_REMARKS="ACH_DEST_INWARD_FILE_REMARKS";
    String ACH_DEST_TRANSACTION_INW_SRC="ACH_DEST_TRANSACTION_INW_SRC";
    String ACH_DEST_TRANSACTION_INW_REMARKS="ACH_DEST_TRANSACTION_INW_REMARKS";
    String ACH_DEST_TRANSACTION_DEBIT_SRC="ACH_DEST_TRANSACTION_DEBIT_SRC";
    String ACH_DEST_TRANSACTION_DEBIT_REMARKS="ACH_DEST_TRANSACTION_DEBIT_REMARKS";
    String ACH_DEST_TRANSACTION_RTN_SRC="ACH_DEST_TRANSACTION_RTN_SRC";
    String ACH_DEST_TRANSACTION_RTN_REMARKS="ACH_DEST_TRANSACTION_RTN_REMARKS";
    String CHECK_DEST_TRANSACTION="CHECK_DEST_TRANSACTION";
}
