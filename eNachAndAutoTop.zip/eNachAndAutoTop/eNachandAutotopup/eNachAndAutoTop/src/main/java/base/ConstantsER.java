package base;

public interface ConstantsER {

    String CHROME="CHROME";
    String MOBILE="MOBILE";
    String BANK_ID="JIOP";
    String NETBANKING="NetBanking";
    String REJECT_BY_CUSTOMER=" Rejected as per customer confirmation.";
    String ACCOUNT_INOPERATIVE=" Account Inoperative.";
    String ACCOUNT_FROZEN=" Account frozen.";
    String PPI_ACCOUNT=" No such account.";
    String ACCOUNT_CLOSED=" Account closed.";

    String INVALID_OTP="100000";
    String INVALID_MPIN="0000";

    String MISMATCH_MOBILE="9920393324";
    String MISMATCH_MPIN="7460";



}
