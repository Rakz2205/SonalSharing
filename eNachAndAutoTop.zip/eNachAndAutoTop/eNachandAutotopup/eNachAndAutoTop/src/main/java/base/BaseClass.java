package base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.fileUtils.PropertiesUtility;
import com.utilities.reportUtils.ExtentUtility;
import com.utilities.webUtils.LaunchApplication;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.io.*;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static base.Constants.DUPLICATE_RECORD_ID;

public class BaseClass
{
    public static WebDriver driver = null;
    public static ExtentTest extentTestChildNode;
    public static WebDriverWait wait = null;
    public static Properties webProperties = null;
    public static String timeStamp = null;
    public static Properties configProperties = null;
    public static Properties writeProperties = null;
    public static ExtentReports extentReports;
    public static ExtentTest extentTest;
    public static String testName = "";
    public static int dBRecordsSize = 1;
    public static SoftAssert softAssert;
    public static int mandateAmount;
    public static int debitAmount = 0;
    public static int totalDebitAmount = 0;
    public static String fileMessageId = "DNF22072020183538";
    public static String cbsAccountNumber;
    public static String duplicateRecordId;
    public static String recordMessageId="67898989";
    public static String mandateStartDate;
    public static String mandateEndDate;
    public static int cbsAmountBeforeDebit;
    public static boolean incorrectFileName = false;
    public static OutputStream outputStream;


    public BaseClass() {
        try {
            //get config properties
            configProperties = PropertiesUtility.getApplicationProperties("config.properties");
            //getDuplicateRecordIdProp = PropertiesUtility.getApplicationProperties("duplicateRecordId.properties");
            extentReports = ExtentUtility.createReport(configProperties.getProperty("ExtentTestName") + "_" + System.currentTimeMillis());
            softAssert = new SoftAssert();
			
			 //  get test data file name
            testDataSheetPath = System.getProperty("user.dir") + "\\TestData\\" + configProperties.getProperty("TestDataSheetName");
			
        } catch (Exception e) {
            throw new RuntimeException(
                    "BaseClass : constructor || Error while setting up the test environment.\n" + e.getMessage(), e);
        }
    }

    public static void writeDuplicateRecordId(String scenario)
    {
        try{
            if(!scenario.equalsIgnoreCase(DUPLICATE_RECORD_ID))
            {
                outputStream = new FileOutputStream("C:\\eNachAndAutoTop_Local\\eNachAndAutoTop\\duplicateRecordId.properties");
                writeProperties = new Properties();
                System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                duplicateRecordId = recordMessageId;
                writeProperties.setProperty("duplicateRecordId", recordMessageId);
                writeProperties.store(outputStream, "Duplicate Record Id");
                System.out.println("Written to file");
                outputStream.close();
            }
        } catch (IOException e) {
            throw new RuntimeException("Exception in writeDuplicateRecordId(): "+e.getMessage());
        }

    }

    public static void launchApplication(Properties properties) {
        try {
            LogManager.getLogger(BaseClass.class).info("\n******************** Test Started ***************************\n");
            driver = LaunchApplication.launchApplication(properties, "CHROME", true);
            wait = new WebDriverWait(driver, 30);
            LogManager.getLogger(BaseClass.class).info("Web application open successfully.");
        } catch (Exception e) {

            LogManager.getLogger(BaseClass.class).error("Error while opening the application.");

            throw new RuntimeException(
                    "MobileUtility : launch_application || Error while opening the application.\n"
                            + e.getMessage(), e);
        }
    }

    public static void createENACHConnections() {
        try {
            //  Create database connection
            if (configProperties.getProperty("Environment").equalsIgnoreCase("PP")) {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty("PP_DB_UserHost"), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            } else {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty("SIT_DB_UserHost"), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            }

        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void closeTestConnections() {
        try {
            //  disconnecting database
            DataBaseUtility.dbConnection.close();
        } catch (Exception e) {
            throw new RuntimeException("error while closing the test connections.", e);
        }
    }

    public static void closeApplication() {
        try {
            if (driver != null) {
                driver.quit();
                driver = null;
            } else
                LogManager.getLogger(BaseClass.class).info("\n******************** End Test ***************************\n");
        } catch (Exception e) {

            throw new RuntimeException(
                    "close_application || Error while closing the application.\n"
                            + e.getMessage(), e);
        }
    }


    public static void ImplicitWait(WebDriver driver, int timeInSecs) {
        driver.manage().timeouts().implicitlyWait(timeInSecs, TimeUnit.SECONDS);
    }


    public static void ExplicitWait(WebDriver driver, WebElement element, int timeInSecs) {
        (new WebDriverWait(driver, timeInSecs)).until(ExpectedConditions.visibilityOf(element));
    }


    public String getRequiredString(String fulltext, String beginIndexString, int number) {
        String requiredText = fulltext.substring(fulltext.lastIndexOf(beginIndexString) + number);
        System.out.println(requiredText);

        return requiredText;
    }

    public static String enachOTP() {
        String mobileOTP;
        String number = "9653334997";
        String query = "select OTP from JFS_OTP \n" +
                "where mobile_number =" + number + "\n" +
                "order by EXPIRES_AT desc";


        DataBaseUtility.createOracleDatabaseConnectionServiceName("10.144.109.101", "1521", "STBLRWAL", "SI_PSPAUTH", "auth_123");


        ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);

        try {
            if (resultSet != null && resultSet.next())
                mobileOTP = resultSet.getString("OTP");
            else
                throw new AssertionError("OTP not present in eNach Database");

            System.out.println(mobileOTP);

            resultSet.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return mobileOTP;
    }


    public void setOtp(String otp) {
        try {
            int i = 1;
            char[] otpCharArray = otp.toCharArray();
            for (char digit : otpCharArray) {
                driver.findElement(By.xpath("(//input[@type='password'])[" + i + "]")).sendKeys(String.valueOf(digit));
                i++;
            }
        } catch (Exception e) {
            throw new RuntimeException("Error while entering otp " + e.getMessage());
        }
    }

    public static String agentOTP() {
        String mobileOTP;
        String query = "select Otp,FIELD_VALUES,R_CRE_TIME from otp_live where FIELD_VALUES like '%%' order by R_CRE_TIME desc";

        DataBaseUtility.createOracleDatabaseConnection("10.140.139.116", "1521", "FIDCS", "FDCMAWPD", "fdcmawpd");

        ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);
        try {
            if (resultSet != null && resultSet.next())
                mobileOTP = resultSet.getString("OTP");
            else
                throw new AssertionError("OTP not present in FDC Database");
            resultSet.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return mobileOTP;
    }

    //To delete TestInput and INW xml Files
    public static void deleteFileIfExists(String filepathWithName, String extn) {
        try {
            File dir = new File(filepathWithName);
            FileFilter fileFilter = new WildcardFileFilter("*." + extn);
            File[] files = dir.listFiles(fileFilter);
            if (files.length > 0) {
                for (int i = 0; i < files.length; i++) {
                    if (extn == "txt" && files[i].getName().contains("TestInput")) {
                        files[i].delete();
                    } else if (extn == "xml" && files[i].getName().contains("INW")) {
                        files[i].delete();
                    }
                }
            }
            LogManager.getLogger(BaseClass.class).info("Files deleted successfully..!!!");
        } catch (Exception ex) {
            throw new RuntimeException("Error in deleteFileIfExists(String filepathWithName,String extn): " + ex.getMessage());
        }
    }

    public static void deleteXMLAndTextFiles() {
        deleteFileIfExists(configProperties.getProperty("FileGeneratorUtilityPath"), "txt");
        deleteFileIfExists(configProperties.getProperty("FileGeneratorUtilityPath"), "xml");
    }

    public static String getINWFileName(String filePath, String ext) {
        try {
            File theNewestFile = null;
            File dir = new File(filePath);
            FileFilter fileFilter = new WildcardFileFilter("*." + ext);
            File[] files = dir.listFiles(fileFilter);
            if (files.length > 0) {
                Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                theNewestFile = files[0];
            }
            String fileName = theNewestFile.getName();
            return fileName;
        } catch (Exception ex) {
            throw new RuntimeException("Error in getINWFileName(): " + ex.getMessage());
        }
    }

    public static String addDaysInProvidedDate(int numberOfDays, String providedDate, String oldDateFormat, String newDateFormat) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(oldDateFormat);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(simpleDateFormat.parse(providedDate));
            simpleDateFormat = new SimpleDateFormat(newDateFormat);
            calendar.add(Calendar.DATE, numberOfDays);
            return simpleDateFormat.format(calendar.getTime());

        } catch (Exception e) {
            throw new RuntimeException("DateUtility | addDaysInCurrentDate : Error while adding the days in current date time.");
        }
    }

}
