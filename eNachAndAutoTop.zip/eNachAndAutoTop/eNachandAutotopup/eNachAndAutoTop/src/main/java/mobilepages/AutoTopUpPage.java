package mobilepages;

import base.BaseClass;
import com.utilities.reportUtils.ExtentUtility;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.Map;

import static com.utilities.mobileUtils.ActionsUtility.swipeUp;
import static com.utilities.webUtils.JavascriptExecutorUtility.scrollTillElementFound;

public class AutoTopUpPage extends BaseClass {


    public AutoTopUpPage()
    {
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }


// Auto reload page


    @FindBy(xpath = "//*[@label='Link your bank account using account number']//following-sibling::span[@class='jsx-3173151916 checkmark']")
    public WebElement chkAccountNo;


    @FindBy(xpath = "//input[@label='Name']")
    public WebElement txtName;

    @FindBy(xpath = "//div[@data-testid='ifsc-field']")
    public WebElement drpSelectBank;

    @FindBy(xpath = "//input[@label='Bank account number']")
    public WebElement txtBankAccountNo;


    @FindBy(xpath = "//div[@data-testid='account-type-field']")
    public WebElement drpSelectAccountType;


    @FindBy(xpath = "//span[@class='css-1u7pje1']")
    public WebElement chkAcceptTermsConditions;

    @FindBy(xpath = "//button[@data-testid='common-button']")
    public WebElement btnProceed;


    // NetBanking Portal Page

    @FindBy(xpath = "//a[@class='nav-link']")
    public WebElement btnBankResptoNPCI;

    @FindBy(xpath = "//input[@id='respXml']//following-sibling::span[@class='circle']")
    public WebElement chkRespXml;

    @FindBy(xpath = "//button[contains(text(),'Auto Fill Form')]")
    public WebElement btnAutoFillForm;


    @FindBy(xpath = "//input[@id='submit_btn']")
    public WebElement btnSubmit;




    public void setAutoTopUp(Map<Object,Object> map) throws InterruptedException {

        driver.findElement(By.xpath("(//android.widget.Button[contains(@text,'"+(String) map.get("AutoTopUpAmt")+"')])[1]")).click();
        driver.findElement(By.xpath("//android.widget.Button[contains(@text,'"+(String) map.get("ThresholdAmt")+"')]")).click();
        swipeUp(driver);
        ((AppiumDriver) driver).context("WEBVIEW_com.jio.myjio");
        driver.findElement(By.xpath("//span[@data-testid='term-box-style']")).click();

        LogManager.getLogger(AutoTopUpPage.class).info("Set AutoTop Up Page.");
        ExtentUtility.logExtent(extentTestChildNode, "Pass", "Set AutoTop Up Page. ", driver);
        btnProceed.click();

        Thread.sleep(3000);
    }

    // Auto reload Page


    public void enterBankAccountDetails(Map<Object,Object> map) throws InterruptedException {
        try {

            chkAccountNo.click();
            txtName.sendKeys((String) map.get("Name"));
            ((AppiumDriver) driver).hideKeyboard();
            drpSelectBank.click();
            selectBank((String) map.get("BankName"));

            txtBankAccountNo.sendKeys((String) map.get("BankAccountNo"));
            ((AppiumDriver) driver).hideKeyboard();

            drpSelectAccountType.click();
            driver.findElement(By.xpath("//span[contains(text(),'Savings')]")).click();

            chkAcceptTermsConditions.click();

            LogManager.getLogger(AutoTopUpPage.class).info("Link By Account Number Details Page.");
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "Link By Account Number Details  Page. ", driver);

            btnProceed.click();

            Thread.sleep(3000);

            btnProceed.click();

            Thread.sleep(7000);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void  selectBank(String bankName){
        try{

            driver.findElement(By.xpath("//div[contains(text(),'"+bankName+"')]")).click();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }

}
