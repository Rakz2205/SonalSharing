package mobilepages;

import base.BaseClass;
import com.utilities.reportUtils.ExtentUtility;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import static com.utilities.webUtils.JavascriptExecutorUtility.scrollTillElementFound;

public class SummaryPage extends BaseClass {


    public SummaryPage()
    {
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }


    // Summary Page

    @FindBy(xpath = "//div[@data-testid='dt-status-message']")
    public WebElement lblTitleValue;

    @FindBy(xpath = "//div[@data-testid='dt-list-item-6']")
    public WebElement lblTransactionIDValue;

    @FindBy(xpath = "//div[@data-testid='dt-list-item-7']")
    public WebElement lblDateTimeValue;

    @FindBy(xpath = "//div[@data-testid='dt-list-item-0']")
    public WebElement lblAutoReloadAmtValue;

    @FindBy(xpath = "//div[@data-testid='dt-list-item-1']")
    public WebElement lblThresholdAmtValue;


    @FindBy(xpath = "//input[@id='submit_btn']")
    public WebElement btnSubmit;





// Summary Page

    public void verifySummaryPage()
    {
        try{

            String txtTitle=lblTitleValue.getText();
            Assert.assertEquals(txtTitle,"Auto top-up registration successful");

            String txtTransactionId=lblTransactionIDValue.getText();
            System.out.println("Transaction ID is : "+txtTransactionId);

            String txtDateTime=lblDateTimeValue.getText();
            System.out.println("Date Time is : "+txtDateTime);

            String txtAutoReloadAmt=lblAutoReloadAmtValue.getText();
            System.out.println("Auto Reload Amount is : "+txtAutoReloadAmt);

            String txtThresholdAmt=lblThresholdAmtValue.getText();
            System.out.println("Threshold Amount is : "+txtThresholdAmt);

            LogManager.getLogger(SummaryPage.class).info("Link By Account Number Details Page.");
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "Link By Account Number Details  Page. ", driver);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }



}
