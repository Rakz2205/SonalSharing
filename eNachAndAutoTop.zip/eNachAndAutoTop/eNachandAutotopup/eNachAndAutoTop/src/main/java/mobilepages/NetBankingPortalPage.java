package mobilepages;

import base.BaseClass;
import com.utilities.reportUtils.ExtentUtility;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.utilities.mobileUtils.ActionsUtility.swipeUp;
import static com.utilities.webUtils.JavascriptExecutorUtility.scrollTillElementFound;

public class NetBankingPortalPage extends BaseClass {


    public NetBankingPortalPage()
    {
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }


    // NetBanking Portal Page

    @FindBy(xpath = "//a[@class='nav-link']")
    public WebElement btnBankResptoNPCI;

    @FindBy(xpath = "//input[@id='respXml']//following-sibling::span[@class='circle']")
    public WebElement chkRespXml;

    @FindBy(xpath = "//button[contains(text(),'Auto Fill Form')]")
    public WebElement btnAutoFillForm;


    @FindBy(xpath = "//input[@id='submit_btn']")
    public WebElement btnSubmit;





// NetBanking Portal Page

    public void netBankingPortal()
    {
        try{

            btnBankResptoNPCI.click();
            chkRespXml.click();
            btnAutoFillForm.click();
            scrollTillElementFound(driver,btnSubmit);
            LogManager.getLogger(NetBankingPortalPage.class).info("NetBanking Portal Page.");
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "NetBanking Portal Page. ", driver);
            btnSubmit.click();
            Thread.sleep(6000);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }



}
