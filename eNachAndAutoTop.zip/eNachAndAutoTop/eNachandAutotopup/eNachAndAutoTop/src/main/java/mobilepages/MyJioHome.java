package mobilepages;

import base.BaseClass;
import com.utilities.reportUtils.ExtentUtility;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.utilities.mobileUtils.ActionsUtility.swipeUp;
import static com.utilities.webUtils.JavascriptExecutorUtility.scrollTillElementFound;

public class MyJioHome extends BaseClass {


    public MyJioHome()
    {
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'MORE')]")
    public WebElement optMore;


    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Finance')]")
    public WebElement optFinance;




    public void clickOnMoreOption() throws InterruptedException {

        optMore.click();
        LogManager.getLogger(MyJioHome.class).info("Clicked on More Option.");
        Thread.sleep(3000);
    }


    public void clickOnFinanceOption() throws InterruptedException {

        optFinance.click();
        LogManager.getLogger(MyJioHome.class).info("Clicked on Finance Tab.");
        ExtentUtility.logExtent(extentTestChildNode, "Pass", "Clicked on Finance Tab. ", driver);
        Thread.sleep(3000);
    }



    public void scrollandClickAutoTopUp() throws InterruptedException {
        MobileElement element = (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator(
                "new UiScrollable(new UiSelector().resourceId(\"com.jio.myjio:id/jpb_banner_my_money_card_pager\")).setAsHorizontalList().scrollIntoView("
                        + "new UiSelector().textContains(\"Auto Topup\"))"));

        element.click();
        LogManager.getLogger(MyJioHome.class).info("Clicked on AutoTopUp Icon.");
        ExtentUtility.logExtent(extentTestChildNode, "Pass", "Clicked on AutoTopUp Icon. ", driver);
        Thread.sleep(8000);
    }




}
