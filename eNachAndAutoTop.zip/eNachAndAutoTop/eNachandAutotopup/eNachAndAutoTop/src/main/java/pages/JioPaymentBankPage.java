package pages;


import base.BaseClass;
import com.utilities.connectionUtils.DataBaseUtility;
import com.utilities.reportUtils.ExtentUtility;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import static base.ConstantsER.*;
import static com.utilities.webUtils.JavascriptExecutorUtility.scrollTillElementFound;

public class JioPaymentBankPage extends BaseClass {

    private static String mandateIDR;
    public JioPaymentBankPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 10), this);
    }



    @FindBy(xpath = "//div[contains(text(),'Proceed')]")
    public WebElement btnProceed;

    @FindBy(xpath = "//a[@id='netHrefSubmit']")
    public WebElement btnContinue;



    @FindBy(xpath = "//input[@type='text']")
    public WebElement txtMobileNo;

    @FindBy(xpath = "//input[@type='password']")
    public WebElement txtMpin;

    @FindBy(xpath = "//div[contains(text(),'DONE')]")
    public WebElement btnDone;


    @FindBy(xpath = "//div[contains(text(),'eMandate Setup')]")
    public WebElement lblTitle;

    @FindBy(xpath = "//span[@class='css-901oao css-16my406 r-11t4n93 r-1qd0xha r-1gkfh8e r-b88u0q r-1cwl3u0']")
    public WebElement lblFailureReason;

    @FindBy(xpath = "//div[contains(text(),'JPB')]")
    public WebElement lblMandateId;

    @FindBy(xpath = "//div[contains(text(),'Your E-Mandate registration is rejected due to')]//following-sibling::span")
    public WebElement lblRejectionReason;

    @FindBy(xpath = "//div[contains(text(),'Welcome')]")
    public WebElement lblReview;

    @FindBy(xpath = "//div[contains(text(),'Mandate Id')]//following-sibling::div")
    public WebElement lblMandateIdReviewPage;




    public void enterJioCredentials(Map<Object, Object> map) {
        try {


            txtMobileNo.sendKeys((String) map.get("CustomersMobileNumber"));
            txtMpin.sendKeys((String) map.get("mPIN"));
            btnProceed.click();

            LogManager.getLogger(JioPaymentBankPage.class).info("Entered Jio Details.");

        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while Entering Jio Credentials.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while Entering Jio Credentials. "
                            + e.getMessage(), e);
        }
    }



    public void reviewDetails(String approveReject)
    {
        try {

            if(lblReview.isDisplayed())
            {
                ExtentUtility.logExtent(extentTestChildNode, "Pass", "Review Page Appeared Successfully. ", driver);
                LogManager.getLogger(JioPaymentBankPage.class).info("Review Page Appeared Successfully. ");
            }
            else
            {
                ExtentUtility.logExtent(extentTestChildNode, "Fail", "Review Page Failed to Load ", driver);
                LogManager.getLogger(JioPaymentBankPage.class).info("Review Page Failed to Load");
                throw new RuntimeException(
                        " Review Page Failed to Load");
            }

            mandateIDR=lblMandateIdReviewPage.getText();

            System.out.println("Review Page Mandate ID : "+mandateIDR);

            ExtentUtility.logExtent(extentTestChildNode, "Pass", "Review Details Page ", driver);

            driver.findElement(By.xpath("(//div[@class='css-901oao r-5vjb3g r-kb43wt r-1x35g6 r-1it3c9n'])[1]")).click();
            driver.findElement(By.xpath("(//div[@class='css-901oao r-5vjb3g r-kb43wt r-1x35g6 r-1it3c9n'])[2]")).click();
            driver.findElement(By.xpath("(//div[@class='css-901oao r-5vjb3g r-kb43wt r-1x35g6 r-1it3c9n'])[3]")).click();

            if(approveReject.contains("Approve"))
            {
                WebElement ele=driver.findElement(By.xpath("//div[contains(text(),'Approve')]"));
                scrollTillElementFound(driver,ele);
                driver.findElement(By.xpath("//div[contains(text(),'Approve')]")).click();
            }
            else if(approveReject.contains("Reject"))
            {
                WebElement ele=driver.findElement(By.xpath("//div[contains(text(),'Reject')]"));
                scrollTillElementFound(driver,ele);
                driver.findElement(By.xpath("//div[contains(text(),'Reject')]")).click();
            }
        }
        catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while in Review Details \n " + e.getMessage());
            throw new RuntimeException(
                    " Error while in Review Details."
                            + e.getMessage(), e);
        }
    }



    public void enterOTPDetails(Map<Object, Object> map)
    {
        try {
            if( ((String) map.get("ApproveORReject")).equalsIgnoreCase("Approve")) {
                Thread.sleep(4000);
                String otp = enachOTP((String) map.get("CustomersMobileNumber"));
                setOtp(otp);
                driver.findElement(By.xpath("//div[contains(text(),'Verify OTP')]")).click();

            }

        }
        catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while entering OTP \n " + e.getMessage());
            throw new RuntimeException(
                    " Error while entering OTP."
                            + e.getMessage(), e);
        }
    }


    public void verifySummaryPage(Map<Object, Object> map) {
        try {

            String title = lblTitle.getText();

            if( ((String) map.get("ApproveORReject")).equalsIgnoreCase("Approve")) {

                Assert.assertEquals(title, "eMandate Setup successful");
                String mandateId=lblMandateId.getText();
                LogManager.getLogger(JioPaymentBankPage.class).info("Verified Success Summary Page. Mandate ID : "+mandateId);
            }

            else if(((String) map.get("ApproveORReject")).equalsIgnoreCase("Reject")) {

                Assert.assertEquals(title, "eMandate Setup failed");
                String rejectionReason=lblRejectionReason.getText();
                Assert.assertEquals(rejectionReason, REJECT_BY_CUSTOMER);
                LogManager.getLogger(JioPaymentBankPage.class).info("Verified Failure Summary Page.");
            }
             verifyDBStatus(mandateIDR,(String) map.get("ApproveORReject"));


        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while  verifying Success Summary Page.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while  verifying Success Summary Page "
                            + e.getMessage(), e);
        }
    }


    public void verifyDBStatus(String mandateId,String approveOrreject)
    {
        try {
            String query = "select * from SI_NACH_OWNER.jpb_mandate_management where JPB_MANDATE_ID='" + mandateId + "' ";

            DataBaseUtility.createOracleDatabaseConnection("10.144.109.129", "1535", "nach", "SI_NACH_RO", "Dji1#Mls");

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);
            if (resultSet.next()) {
                String statusMandate = resultSet.getString("STATUS");

                switch (approveOrreject) {
                    case "Approve":
                        if(statusMandate.equalsIgnoreCase("ACCEPTED")) {
                            LogManager.getLogger(JioPaymentBankPage.class).info("DB Status Verification Successful. DB Status is : " + statusMandate);
                        }
                        else {
                            LogManager.getLogger(JioPaymentBankPage.class).info("DB Status Verification Failed. DB Status is : " + statusMandate);
                        }
                        break;

                    case "Reject":
                        if(statusMandate.equalsIgnoreCase("REJECTED")) {
                            LogManager.getLogger(JioPaymentBankPage.class).info("DB Status Verification Successful. DB Status is : " + statusMandate);
                        }
                        else {
                            LogManager.getLogger(JioPaymentBankPage.class).error("DB Status Verification Failed. DB Status is : " + statusMandate);
                        }
                        break;

                    default:
                        throw new Exception("InValid Status.");
                }

            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }



    public void verifyNegAccntStatusFailure(Map<Object, Object> map) {
        try {
            String title=lblTitle.getText();
            Assert.assertEquals(title,"eMandate Setup failed");
            LogManager.getLogger(JioPaymentBankPage.class).info("Verified Failure Summary Page.");

            String rejectionReason=lblRejectionReason.getText();

        String expRejectionReason="";
            switch ((String) map.get("ScenarioName"))
            {
                case "SavingsAccount_Dormant":
                case "SavingsAccount_Inactive":
                    expRejectionReason=ACCOUNT_INOPERATIVE;
                    break;


                case "SavingsAccount_TotalFreeze":
                case "SavingsAccount_DebitFreeze":
                case "SavingsAccount_CreditFreeze":
                    expRejectionReason=ACCOUNT_FROZEN;
                    break;

                case "SavingsAccount_PPIAccount":
                    expRejectionReason=PPI_ACCOUNT;
                    break;

                case "SavingsAccount_ClosedAccount":
                    expRejectionReason=ACCOUNT_CLOSED;
                    break;

                default:
                    throw new Exception("Invalid Scenario name.");


            }
            Assert.assertEquals(rejectionReason,expRejectionReason);
            LogManager.getLogger(JioPaymentBankPage.class).info("Verified Rejection Reason in Summary Page.");


        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while  verifying Failure Summary Page.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while  verifying Failure Summary Page "
                            + e.getMessage(), e);
        }
    }




    public void clickDoneButton() {
        try {
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "Summary Page ", driver);
            btnDone.click();
            LogManager.getLogger(JioPaymentBankPage.class).info("Clicked on Done button.");
            Thread.sleep(2000);
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "Bank Response Page ", driver);

            LogManager.getLogger(JioPaymentBankPage.class).info("Bank Response Page ");
            Thread.sleep(3000);

            List<WebElement> npciRefId = driver.findElements(By.xpath("//label[contains(text(),'NPCI Reference Id')]"));
            if(npciRefId.size()>0)
            {
                ExtentUtility.logExtent(extentTestChildNode, "Pass", "Redirected to Merchant Portal Page ", driver);
                LogManager.getLogger(JioPaymentBankPage.class).info("Redirected to Merchant Portal Page ");
            }
            else
            {
                ExtentUtility.logExtent(extentTestChildNode, "Fail", "Redirection to Merchant Portal Page Failed ", driver);
                LogManager.getLogger(JioPaymentBankPage.class).info("Redirection to Merchant Portal Page Failed");
            }

        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Unable to tap on the Done button.\n " + e.getMessage());
            throw new RuntimeException(
                    "Tap on Continue button "
                            + e.getMessage(), e);
        }
    }



    public void enterInvalidOTP()
    {
        try {
          //  Thread.sleep(4000);
            String otp=INVALID_OTP;
            setOtp(otp);
            Thread.sleep(4000);

            for(int invalidAttemptCount=0;invalidAttemptCount<3;invalidAttemptCount++)
            {
                driver.findElement(By.xpath("//div[contains(text(),'Verify OTP')]")).click();
                Thread.sleep(3000);
            }


        }
        catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while entering Invalid OTP \n " + e.getMessage());
            throw new RuntimeException(
                    " Error while entering Invalid OTP."
                            + e.getMessage(), e);
        }
    }


    public void verifyAuthFailed(Map<Object, Object> map) {
        try {

            String title=lblTitle.getText();
            Assert.assertEquals(title,"eMandate Setup failed");

            String rejectionReason=lblRejectionReason.getText();

            String expRejectionReason="";
            switch ((String) map.get("ScenarioName")) {

                case "InvalidOTP":
                    expRejectionReason = " Authentication Failed -  Incorrect OTP.";
                    break;

                case "InvalidMPIN":
                    expRejectionReason = " Incorrect Credential.";
                    break;

                case "MismatchEntries":
                    expRejectionReason = " Invalid User Credentials.";
                    break;

                default:
                    System.out.println("Invalid Scenario name.");

            }

            Assert.assertEquals(rejectionReason,expRejectionReason);
            LogManager.getLogger(JioPaymentBankPage.class).info("Verified Authentication Failure Summary Page.");


        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while  verifying Authentication Failure Summary Page.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while  verifying Authentication Failure Summary Page "
                            + e.getMessage(), e);
        }
    }


    public void invalidMPIN(Map<Object, Object> map) {
        try {

            for(int invalidAttemptCount=0;invalidAttemptCount<3;invalidAttemptCount++) {

                txtMobileNo.sendKeys((String) map.get("CustomersMobileNumber"));

                txtMpin.sendKeys(INVALID_MPIN);
                btnProceed.click();
                Thread.sleep(4000);

                if(invalidAttemptCount==2)
                {
                    break;
                }
                else {
                    driver.switchTo().alert().accept();
                }
                System.out.println(invalidAttemptCount);
            }

            LogManager.getLogger(JioPaymentBankPage.class).info("Entered Jio Details with Invalid MPIN.");
            Thread.sleep(3000);

        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while Entering Jio Credentials with Invalid MPIN.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while Entering Jio Credentials  with Invalid MPIN. "
                            + e.getMessage(), e);
        }
    }



    public void mismatchEntries(Map<Object, Object> map) {
        try {

            txtMobileNo.sendKeys(MISMATCH_MOBILE);

            txtMpin.sendKeys(MISMATCH_MPIN);

            btnProceed.click();

            LogManager.getLogger(JioPaymentBankPage.class).info("Entered Jio Details with Mismatch Entries.");


        } catch (Exception e) {

            LogManager.getLogger(JioPaymentBankPage.class).error("Error while Entering Jio Credentials with with Mismatch Entries.\n " + e.getMessage());
            throw new RuntimeException(
                    "Error while Entering Jio Credentials with Mismatch Entries. "
                            + e.getMessage(), e);
        }
    }






}
