package pages;


import base.BaseClass;
import com.utilities.reportUtils.ExtentUtility;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import java.util.Map;

import static base.ConstantsER.BANK_ID;
import static base.ConstantsER.NETBANKING;


public class SimulatorPage extends BaseClass {


    public SimulatorPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 10), this);
    }



    @FindBy(xpath = "//input[@name='userName']")
    public WebElement txtBoxUserName;

    @FindBy(xpath = "//input[@name='password']")
    public WebElement txtBoxPassword;

    @FindBy(xpath = "//button[@class='btn btn-primary']")
    public WebElement btnLogin;

    @FindBy(xpath = "//button[@onclick='autoFillFunction()']")
    public WebElement btnAutoFillForm;

    @FindBy(xpath = "//button[@onclick='genXml();']")
    public WebElement btnGenerateXml;

    @FindBy(xpath = "//button[@onclick='sendXmlForSign();']")
    public WebElement btnSignXml;

    @FindBy(xpath = "//button[@onclick='sendJSONToNPCI()']")
    public WebElement btnSubmitToNPCI;


    @FindBy(xpath = "//input[@list='BankID']")
    public WebElement txtBankID;

    @FindBy(xpath = "//input[@list='AuthModes']")
    public WebElement txtAuthModes;

    @FindBy(xpath = "//input[@name='Mobile']")
    public WebElement txtMobileNo;

    @FindBy(xpath = "//input[@name='DebtAccNO']")
    public WebElement txtDebtAccNo;

    @FindBy(xpath = "//input[@id='MaxAmtCheck']")
    public WebElement chkMaxAmt;

    @FindBy(xpath = "//input[@id='ColltnAmtCheck']")
    public WebElement chkColltnAmt;

    @FindBy(xpath = "//input[@id='FnlColltnDtCheck']")
    public WebElement chkFnlColltDate;


    public  void initializeURL() {
        String webURL;
        try {
            webURL = webProperties.getProperty("SimulatorURL");

            driver.get(webURL);
            LogManager.getLogger(SimulatorPage.class).info("successfully launched the Simulator URL : " + webURL);
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "successfully launched the url. <br />" + webURL, driver);

        } catch (Exception e) {
            LogManager.getLogger(SimulatorPage.class).error("error while launching the application url.\n" + e.getMessage());
            ExtentUtility.logExtent(extentTestChildNode, "Fail", "error while launching the application url.", driver);

            throw new RuntimeException("error while launching the application url.", e);
        }
    }



    public void loginInToSimulator() {

        try {

              String  userName = webProperties.getProperty("SimulatorUserID");
              String  password = webProperties.getProperty("SimulatorPassword");

            txtBoxUserName.sendKeys(userName);

            txtBoxPassword.sendKeys(password);
            btnLogin.click();

            LogManager.getLogger(SimulatorPage.class).info("login into Simulator portal.");
            ExtentUtility.logExtent(extentTestChildNode, "Pass", "login into Simulator portal", driver);

        } catch (Exception e) {

            LogManager.getLogger(SimulatorPage.class).error("error while login into the Simulator portal.");
            ExtentUtility.logExtent(extentTestChildNode, "Fail", "error while login into the Simulator portal.", driver);
            throw new RuntimeException("Error while login into the application.", e);
        }
    }


    public void tapAutoFillFormButton() {
        try {
            btnAutoFillForm.click();
            LogManager.getLogger(SimulatorPage.class).info("Clicked on AutoFillForm button.");
            Thread.sleep(3000);

        } catch (Exception e) {

            LogManager.getLogger(SimulatorPage.class).error("Unable to tap on the AutoFillForm button.\n " + e.getMessage());
            throw new RuntimeException(
                    "tapAutoFillFormButton || Tap on AutoFillForm button on Simulator page."
                            + e.getMessage(), e);
        }
    }



    public void enterCustomerDetails(Map<Object, Object> map)
    {
        try {

            txtBankID.clear();
            txtBankID.sendKeys(BANK_ID);
            txtBankID.sendKeys(Keys.TAB);

            Thread.sleep(2000);
            txtMobileNo.clear();
            txtMobileNo.sendKeys("+91-"+(String) map.get("CustomersMobileNumber")+"");


            txtDebtAccNo.clear();
            txtDebtAccNo.sendKeys((String) map.get("CustomersAccountNumber"));

        // Ticking on FnlColltDate Checkbox
            Thread.sleep(2000);
            chkFnlColltDate.click();

            if( (((String) map.get("ColltnAmtORMaxAmt")).equalsIgnoreCase("ColltnAmt")) )
            {
                chkMaxAmt.click();
            }
            else if( (((String) map.get("ColltnAmtORMaxAmt")).equalsIgnoreCase("MaxAmt")) )
            {
                chkColltnAmt.click();
            }

            Thread.sleep(2000);
            btnGenerateXml.click();

            Thread.sleep(2000);
            btnSignXml.click();

            // Changes due to new field AuthMode 16/07/2020
            Thread.sleep(2000);
            txtAuthModes.sendKeys(NETBANKING);

            btnSubmitToNPCI.click();

        }
        catch (Exception e) {

            LogManager.getLogger(SimulatorPage.class).error("Error while entering customer details in Simulator's Page.\n " + e.getMessage());
            throw new RuntimeException(
                    "SimulatorPage : enterCustomerDetails || Error while entering customer details in Simulator's Page."
                            + e.getMessage(), e);
        }
    }

    public void printCaseScenarioName(Map<Object, Object> map) {
        try{

            LogManager.getLogger(SimulatorPage.class).info("Scenario Name: "+(String) map.get("ScenarioName") +"   Mobile Number:  "+(String) map.get("CustomersMobileNumber"));
            ExtentUtility.logExtent(extentTestChildNode, "Pass", (String) map.get("ScenarioName") +"  Mobile Number:  "+(String) map.get("CustomersMobileNumber"), null);

        }
        catch(Exception e)
        {
            LogManager.getLogger(SimulatorPage.class).error("Error while printing CaseScenarioName.");
        }
    }




}
