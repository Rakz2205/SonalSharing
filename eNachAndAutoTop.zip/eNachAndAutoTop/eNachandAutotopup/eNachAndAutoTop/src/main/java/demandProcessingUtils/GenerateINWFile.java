package demandProcessingUtils;
/**
 * Class to create TestInput2.txt
 *
 * @author Sneha.Dasari
 */

import base.BaseClass;
import com.utilities.fileUtils.FileUtility;
import com.utilities.javaUtils.DateUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.*;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static base.Constants.*;

public class GenerateINWFile extends BaseClass {
    public static String[] searchString;
    public static String[] scenarios;
    public static String[] line;
    public static String columnHeader;
    public static HashMap<String, Integer> columnNamesMap;
    public static HashMap<String, Integer> accountNumberAndCBSBalanceCopy = null;
    public static HashMap<String, Integer> accountNumberAndCBSBalance = null;
    public static HashMap<String, Integer> accountNumberAndAfterDebit;
    public static Logger log = LogManager.getLogger(GenerateINWFile.class);
    public static int accountNumberCount = 0;

    /**
     * Method to fetch multiple records from DB and save them in Multidimensional Collection
     *
     * @param searchStringArg Parameters to be replaced
     * @param scenariosArg Scenarios to form TestInput.txt File
     */
    @Step("Forming List of HashMaps of records fetched")
    public static ArrayList<Map<String, String>> formListHashMapOfDBRecords(String searchStringArg, String scenariosArg) {
        log.info("Forming List of HashMaps of the records from resultSet");
        log.info("******************* DB Records *********************");
        debitAmount = 0;
        totalDebitAmount = 0;
        accountNumberCount = 0;
        ArrayList<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
        try {

            //Splitting the searchString
            searchString = searchStringArg.split("\\|");

            //Splitting scenarios
            scenarios = scenariosArg.split("\\|");

            accountNumberAndCBSBalance = new HashMap<>();
            accountNumberAndCBSBalanceCopy = new HashMap<>();
            accountNumberAndAfterDebit = new HashMap<>();

            //Checking if Multiple Valid Records Case
            int scenarioLength = scenarios.length;
            log.info("Scenarios Length: " + scenarioLength);

            int resultListIndex = 0;

            fileMessageId = RandomGeneratorUtils.generateFileMessageID();

            for (resultListIndex = 0; resultListIndex < scenarioLength; resultListIndex++)
            {
                //Fetching the query as per the Scenario
                String query = getQueryToFetchRecords(scenarios[resultListIndex]);

                //Allocation of DB Values to Search String Columns
                Map<String, String> resultMap = allocateSearchStringValues(query, resultListIndex);

                resultList.add(resultListIndex, resultMap);

                //Fetching CBS Amount for account Numbers
                addAccountNumbersAndCBSAmount(resultMap);

                //Performing Negative Scenarios
                resultList = GetDatabaseRecords.performNegativeScenarios(resultList, scenarios[resultListIndex], resultListIndex);
            }
            log.info("Total Debit Amount: " + totalDebitAmount);


            //Printing number of records fetched from database
            dBRecordsSize = resultList.size();
            for (int i = 0; i < resultList.size(); i++) {
                log.info(resultList.get(i) +" : "+resultList.get(i).size());
            }

            //Printing the AccountNumber and CBS Amount
            log.info(accountNumberAndCBSBalance);

            log.info("Number of Records in List: " + dBRecordsSize);
        } catch (Exception ex) {
            log.info("Error in getRecordsToCreateINWFile(): " + ex.getMessage());
        }
        return resultList;
    }

    /**
     * Method to form scenarios String by excel rows
     *
     * @param excelDataMap contains one row from the excelsheet
     */
    public static String formScenariosString(HashMap excelDataMap)
    {
        String scenarios="";
        HashMap<String,String> testDataMap = excelDataMap;
        System.out.println(excelDataMap);
        for (Map.Entry testDataEachMap:testDataMap.entrySet()) {
            if(!testDataEachMap.getKey().equals("TestCaseName") && !testDataEachMap.getKey().equals("TestdataType") && !testDataEachMap.getKey().equals("TestDescription") && !testDataEachMap.getKey().equals("ExecutionCheck"))
            {
                int noOfRecords = Integer.parseInt(testDataEachMap.getValue().toString());
                for(int index=0;index<noOfRecords;index++)
                {
                    if(scenarios.equalsIgnoreCase(""))
                    {
                        scenarios= (String) testDataEachMap.getKey();
                    }
                    else
                    {
                        scenarios = scenarios+"|"+testDataEachMap.getKey();
                    }

                }

            }
        }
        System.out.println(scenarios);
        return scenarios;
    }

    /**
     * Method to return query as per the scenario
     *
     * @param scenario contains the Scenario Name
     */
    @Step("Getting query to fetch records")
    public static String getQueryToFetchRecords(String scenario) {
        String query;
        switch (scenario) {
            case RECEIVED_STATUS:
                query = configProperties.getProperty("receivedStatusQuery");
                break;
            case ACCEPTED_STATUS:
                query = configProperties.getProperty("acceptedStatusQuery");
                break;
            case REJECTED_STATUS:
                query = configProperties.getProperty("rejectedStatusQuery");
                break;
            case TOKEN_AF_STATUS:
                query = configProperties.getProperty("tokenAFStatusQuery");
                break;
            case FREEZE_ACCOUNT:
                query = configProperties.getProperty("freezeAccountQuery");
                break;
            case DORMANT_ACCOUNT:
                query = configProperties.getProperty("dormantAccountQuery");
                break;
            case CLOSED_ACCOUNT:
                query = configProperties.getProperty("closedAccountQuery");
                break;
            case INACTIVE_ACCOUNT:
                query = configProperties.getProperty("inactiveAccountQuery");
                break;
            default:
                query = configProperties.getProperty("activatedStatusQuery");
                accountNumberCount++;
                break;
        }
        return query;

    }


    /**
     * Method to allocate DB values to search String columns
     *
     * @param query will be used to fetch records from DB
     * @param resultListIndex points to the map at that index in the List
     */
    public static Map<String, String> allocateSearchStringValues(String query, int resultListIndex) {
        try {
            createENACHConnections();
            Map<String, String> resultMap = new HashMap<>();
            ResultSet resultSet = GetDatabaseRecords.fetchRecordsFromDB(query);
            while (resultSet.next()) {
                for (int searchStringIndex = 0; searchStringIndex < searchString.length; searchStringIndex++) {
                    switch (searchString[searchStringIndex]) {
                        case "FILE_MESSAGE_ID":
                            resultMap.put("FILE_MESSAGE_ID", fileMessageId);
                            break;
                        case "RECORD_MESSAGE_ID":
                            recordMessageId = RandomGeneratorUtils.generateRecordMessageID();
                            resultMap.put("RECORD_MESSAGE_ID", recordMessageId);
                            addValidationParameters(resultMap);
                            break;
                        case "AMOUNT":
                            mandateAmount = Integer.parseInt(RandomGeneratorUtils.removeLeadingZeroes(resultSet.getString("AMOUNT")));
                            debitAmount = getAmountForMap(resultSet, resultMap);
                            totalDebitAmount = totalDebitAmount + debitAmount;
                            break;
                        case "ACCOUNT_NUMBER":
                            cbsAccountNumber = resultSet.getString("ACCOUNT_NO");
                            resultMap.put(searchString[searchStringIndex], resultSet.getString("ACCOUNT_NO"));
                            break;
                        case "SETTLEMENT_DATE":
                            mandateStartDate = resultSet.getString("MNDT_START_DATE");
                            System.out.println("Mandate Start Date: "+mandateStartDate);
                            mandateEndDate = resultSet.getString("MNDT_END_DATE");
                            resultMap.put(searchString[searchStringIndex], DateUtility.getCurrentDateTime("yyyy-MM-dd"));
                            break;
                        default:
                            resultMap.put(searchString[searchStringIndex], resultSet.getString(searchString[searchStringIndex]));
                            break;
                    }
                }
            }
            closeTestConnections();
            return resultMap;
        } catch (Exception ex) {
            throw new RuntimeException("Exception in allocateSearchStringValues(): " + ex.getMessage());
        }
    }

    /**
     * Method to add Unique Account Numbers and corresponding CBS Balance to the Map
     *
     * @param resultMap Parameters to be replaced
     */
    public static void addAccountNumbersAndCBSAmount(Map<String, String> resultMap) {
        try {
            System.out.println(resultMap.size());

            String accountNumber = resultMap.get("ACCOUNT_NUMBER");
            System.out.println(accountNumber);
            if (accountNumberAndCBSBalance == null) {
                accountNumberAndCBSBalance.put(accountNumber, GetCBSAmount.getAmountFromCBS("TWO", accountNumber));
                accountNumberAndCBSBalanceCopy.put(accountNumber, accountNumberAndCBSBalance.get(accountNumber));
            } else {
                if (!accountNumberAndCBSBalance.containsKey(accountNumber)) {
                    accountNumberAndCBSBalance.put(accountNumber, GetCBSAmount.getAmountFromCBS("TWO", accountNumber));
                    accountNumberAndCBSBalanceCopy.put(accountNumber, accountNumberAndCBSBalance.get(accountNumber));
                }
            }

        } catch (Exception ex) {
            throw new RuntimeException("Exception in getAccountNumbersAndCBSAmount(): " + ex.getMessage());
        }
    }

    /**
     * Method to add Account Numbers and CBS Balance after Debit to the Map
     *
     */
    public static void addAccountNumbersAndCBSAmountAfterDebit() {
        try {
            System.out.println(accountNumberAndCBSBalance.size());

            for (Map.Entry<String, Integer> cbsAccountNumbers : accountNumberAndCBSBalance.entrySet()) {
                String accountNumber = cbsAccountNumbers.getKey();
                accountNumberAndAfterDebit.put(accountNumber, GetCBSAmount.getAmountFromCBS("TWO", accountNumber));
            }

        } catch (Exception ex) {
            throw new RuntimeException("Exception in addAccountNumbersAndCBSAmountAfterDebit(): " + ex.getMessage());
        }
    }

    /**
     * Method to compare CBS Amounts before and after the Debit is performed
     *
     * @param missingRecordsFound contains the flag to denote if missing records are present or not
     */
    public static void compareCBSAmounts(boolean missingRecordsFound) {
        HashMap<String, Integer> expectedCBSAmount = new HashMap<>();
        HashMap<String, Integer> actualCBSAmount = new HashMap<>();

        if (missingRecordsFound) {
            expectedCBSAmount = accountNumberAndCBSBalanceCopy;
        } else {
            expectedCBSAmount = accountNumberAndCBSBalance;
        }
        actualCBSAmount = accountNumberAndAfterDebit;

        for (Map.Entry<String, Integer> expectedCBSAmountValue : expectedCBSAmount.entrySet()) {

            for (Map.Entry<String, Integer> actualCBSAmountValue : actualCBSAmount.entrySet()) {
                if (expectedCBSAmountValue.getKey().equals(actualCBSAmountValue.getKey())) {
                    log.info(expectedCBSAmountValue.getValue() + " : " + actualCBSAmountValue.getValue());
                    softAssert.assertEquals(expectedCBSAmountValue.getValue(), actualCBSAmountValue.getValue(), AMOUNT_NOT_TALLIED);
                }
            }

        }
        softAssert.assertAll();
    }

    /**
     * Method to add default values to the Trigger Process Validations
     *
     * @param resultMap contains the map to add validations
     */
    public static void addValidationParameters(Map<String, String> resultMap) {
        resultMap.put(ACH_DEST_INWARD_FILE_SRC, VALIDATION_COMPLETED);
        resultMap.put(ACH_DEST_INWARD_FILE_REMARKS, FILE_CREATED_REMARKS);
        resultMap.put(ACH_DEST_TRANSACTION_INW_SRC, SCHEDULED_SRC);
        resultMap.put(ACH_DEST_TRANSACTION_INW_REMARKS, null);
        resultMap.put(ACH_DEST_TRANSACTION_DEBIT_SRC, SUCCESS_SRC);
        resultMap.put(ACH_DEST_TRANSACTION_DEBIT_REMARKS, SUCCESS_REMARKS);
        resultMap.put(ACH_DEST_TRANSACTION_RTN_SRC, GENERATED_RETURN_FILE);
        resultMap.put(ACH_DEST_TRANSACTION_RTN_REMARKS, SUCCESS_REMARKS);
        resultMap.put(CHECK_DEST_TRANSACTION, "true");
    }

    /**
     * Method to return Amount w.r.t., IS_MAX_AMT flag
     *
     * @param resultSet contains the resultSet it is currently pointing to
     * @param resultMap contains the Map of searchString and Validations
     */
    public static int getAmountForMap(ResultSet resultSet, Map<String, String> resultMap) {
        try {
            if (resultSet.getString("IS_MAX_AMT").equals("Y")) {
                if (accountNumberCount > 0) {
                    debitAmount = DEBIT_AMOUNT_IN_PAISE + ((accountNumberCount - 1) * 100);
                } else {
                    debitAmount = DEBIT_AMOUNT_IN_PAISE;
                }
                log.info("Debit Amount: " + debitAmount);
            } else {
                //debitAmount = Integer.parseInt(RandomGeneratorUtils.removeLeadingZeroes(resultSet.getString("AMOUNT")));
                debitAmount = mandateAmount;
            }
            String amount = String.valueOf(debitAmount);
            resultMap.put("AMOUNT", amount);
            return debitAmount;
        } catch (Exception ex) {
            throw new RuntimeException("Exception in getAmountForMap(): " + ex.getMessage());
        }
    }

    /**
     * Method to write replaced line in TestInput File
     *
     * @param newData to replace values in line with the values in MAP
     */
    @Step("Replacing values of template file with Map values and writing into TestInput.txt")
    public static void writingReplacedValuesToFile(List<Map<String, String>> newData, String testFileName) {
        try {
            log.info("Writing Replaced Values in Line to TestInput File");
            //Fetching the Contents from the Template file
            String[] contents = getContentsFromTestFile(testFileName);

            //Splitting the first line in the file
            columnHeader = contents[0];
            String[] columnNames = columnHeader.split("\\|");

            //Splitting the searchString
            searchString = configProperties.getProperty("ColumnNames").split("\\|");

            //Getting indexes of the parameters to be replaced
            columnNamesMap = getColumnIndex(columnNames);


            //Writing Column Headers into TestInput.txt File
            FileUtility.createTextFile(configProperties.getProperty("TestInputCopied"), columnHeader);
            log.info("Before replacing and writing into file: " + newData.size());
            for (int k = 0; k < newData.size(); k++) {
                //Splitting the second line
                line = contents[1].split("\\|");
                String newLine = replacingValues(line, newData.get(k), columnNamesMap);
                log.info("New Line: " + newLine);
                FileUtility.createTextFile(configProperties.getProperty("TestInputCopied"), newLine);
            }
            //Thread.sleep(10000);
        } catch (Exception ex) {
            log.info("Exception in writingToFiles(): " + ex.getMessage());
        }
    }

    public static void appendToFile(String fileName, String newLine, boolean isFirstLine) {
        try {
            File file = new File(fileName);
            FileWriter fr = new FileWriter(file, true);
            BufferedWriter br = new BufferedWriter(fr);
            if (isFirstLine) {
                br.write(newLine);
            } else {
                br.write("\n" + newLine);
            }

            log.info("Append Successful");

            br.close();
            fr.close();
        } catch (Exception ex) {
            throw new RuntimeException("Error in appendToFile(): " + ex.getMessage());
        }
    }

    /**
     * Method to replace the values in line array as per the index positions and column names
     *
     * @param line        contains the array of line 2 from the template file
     * @param newValues   contains Map where key = Column Names from DB and value = Column Values
     * @param columnNames contains Map where key = Column Names that are to be replaced and value = Index positions
     */
    @Step("Performing Replacing values operation")
    public static String replacingValues(String[] line, Map<String, String> newValues, HashMap<String, Integer> columnNames) {
        String reformedLine = "";
        try {
            log.info("ColumnNames Size: " + columnNames.size());
            log.info("newValues Size: " + newValues.size());
            for (int index = 0; index < newValues.size(); index++) {
                for (Map.Entry<String, String> entry : newValues.entrySet()) {

                    for (Map.Entry<String, Integer> columnIndex : columnNames.entrySet()) {
                        if (entry.getKey().equals(columnIndex.getKey())) {
                            line[columnIndex.getValue()] = entry.getValue();
                            break;
                        }
                    }

                }
            }
            reformedLine = reformedLine + line[0];
            for (int index = 1; index < line.length; index++) {
                reformedLine = reformedLine + "|" + line[index];
            }
            log.info("Reformed Line: " + reformedLine);
        } catch (Exception ex) {
            throw new RuntimeException("Error in replacingValues(): " + ex.getMessage());
        }
        return reformedLine;
    }

    /**
     * Method to get the index from the Column Headers Array
     *
     * @param columnNames Array contains All the Names from the Line 1 of the Template file
     */
    @Step("Fetching Header Indexes from Header Names")
    public static HashMap<String, Integer> getColumnIndex(String[] columnNames) {
        HashMap<String, Integer> columnNamesMap = new HashMap<String, Integer>();
        try {
            for (int index = 0; index < columnNames.length; index++) {
                //log.info(columnNames[index] +" : "+ index);
                columnNamesMap.put(columnNames[index], index);
            }

        } catch (Exception ex) {
            throw new RuntimeException("Error in getColumnIndex(): " + ex.getMessage());
        }
        return columnNamesMap;
    }

    /**
     * Method to return Contents into a String Array
     *
     * @param testFileName String contains the location of the Template file
     */
    @Step("Getting contents from TestInput Template file")
    public static String[] getContentsFromTestFile(String testFileName) {
        String[] contents = new String[24];
        try {
            File testFile = new File(testFileName);
            FileReader fileReader = new FileReader(testFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            int lineNumber = 0;
            while ((line = bufferedReader.readLine()) != null) {
                log.info("New Line: " + line);
                contents[lineNumber] = line;
                log.info("Line " + lineNumber + " : " + contents[lineNumber]);
                lineNumber++;
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in getContentsFromTestFile(): " + ex.getMessage());
        }
        return contents;
    }

    /**
     * Method to run FileUtilityGenerator Jar
     * @param fileGeneratorPath contains Path of TestInput.txt file
     * @param fileOption contains whether to perform INW file operation or RTN file operation
     */
    @Step("Running File Generator Utility Jar")
    public static void runFileGeneratorJar(String fileGeneratorPath, String fileOption) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder();
            processBuilder.command("cmd", "/c", "java -jar FileGeneratorUtility-jar-with-dependencies.jar TestInput.txt\"");
            processBuilder.directory(new File(fileGeneratorPath));
            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));

            String line = "";
            while ((line = reader.readLine()) != null) {
                log.info(line);
                if (line.contains("Please select one of the two options above, enter 1 or 2"))
                    break;
            }
            writer.write(fileOption);
            writer.close();
            String line2 = "";
            while ((line2 = reader.readLine()) != null) {
                log.info(line2);
            }
            reader.close();
            process.waitFor(MAX_WAIT_TIME, TimeUnit.SECONDS);
            log.info("After process.waitFor()");

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
