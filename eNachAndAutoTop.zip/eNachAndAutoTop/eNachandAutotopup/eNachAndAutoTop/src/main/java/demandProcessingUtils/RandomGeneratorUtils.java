package demandProcessingUtils;

import com.utilities.javaUtils.DateUtility;

import static base.Constants.REMOVE_PREVAILING_ZEROS;

public class RandomGeneratorUtils
{
    public static String generateFileMessageID()
    {
        return "DNF"+DateUtility.getCurrentDateTime("ddMMyyyyHHmmss");
    }

    public static String generateRecordMessageID()
    {
        String randomInt="";
        for (int i = 0; i < 14; i++) {
            randomInt += String.valueOf((int)(Math.random()*10));
        }
        return randomInt;
    }

    public static String removeLeadingZeroes(String str) {
        String strPattern = REMOVE_PREVAILING_ZEROS;
        str = str.replaceAll(strPattern, "");
        if(str.contains("."))
        {
            System.out.println("here");
            str = str.replace(".","");
            System.out.println(str);
        }
        return str;
    }

}
