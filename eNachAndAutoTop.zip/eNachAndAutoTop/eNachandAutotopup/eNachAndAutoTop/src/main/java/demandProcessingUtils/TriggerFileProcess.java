package demandProcessingUtils;

import base.BaseClass;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.yandex.qatools.allure.annotations.Step;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static base.Constants.*;

public class TriggerFileProcess extends BaseClass {
    public static Logger log = LogManager.getLogger(TriggerFileProcess.class);

    @Step("Performing Inward File Process, Checking inwStateReasonCode: {0} and remarks: {1}")
    public static void performFileTriggerProcess(String inwStateReasonCode, String remarks) {
        try
        {
            log.info("Performing Inward File Process");
            String inwFileName = getINWFileName(configProperties.getProperty("FileGeneratorUtilityPath"),"xml");
            log.info("FileName: "+inwFileName);
            performFileProcess(configProperties.getProperty("inwardApiURL"), configProperties.getProperty("inwardFileProcessMsg"));
            Thread.sleep(MAX_WAIT_TIME);
            TriggerFileProcess.checkStatusReasonCode(inwFileName, inwStateReasonCode,remarks);
        } catch (Exception ex) {
            throw new RuntimeException("Exception in performFileTriggerProcess(): " + ex.getMessage());
        }
    }

    /**
     * Method to perform File Process
     *
     * @param apiUrl     passes url of api to be triggered
     * @param triggerMsg passes message to be validated
     */
    @Step("Performing File Process for api Url: {0} and trigger Message: {1}")
    public static void performFileProcess(String apiUrl, String triggerMsg) {
        Response response = RestUtil.getByUrl(apiUrl);
        softAssert.assertEquals(response.asString(), triggerMsg);
    }

    /**
     * Method to Validate StateReasonCode in ACH_DEST_INWARD_FILE SCHEMA
     *
     * @param inwFileName        contains the INW xml File
     * @param inwStateReasonCode contains validation Message for STATE_REASON_CODE
     */
    @Step("Checking Status Reason Code for inwFileName: {0}, inwStateReasonCode: {1} and remarks: {2}")
    public static void checkStatusReasonCode(String inwFileName, String inwStateReasonCode, String remarks) {
        try {
            int thresholdTime = 0;
            ResultSet resultSet = DataBaseUtility.executeSelectStatement("select * from SI_NACH_OWNER.ACH_DEST_INWARD_FILE where FILE_NAME='" + inwFileName + "'");
            while (thresholdTime < 30) {
                System.out.println("Inside checkStatusReasonCode while(): "+thresholdTime);
                resultSet = DataBaseUtility.executeSelectStatement("select * from SI_NACH_OWNER.ACH_DEST_INWARD_FILE where FILE_NAME='" + inwFileName + "'");
                if (resultSet.next() && resultSet.getString("STATE_REASON_CODE").equals(inwStateReasonCode))
                    break;
                else
                    thresholdTime++;
                Thread.sleep(MIN_WAIT_TIME);

            }
            softAssert.assertEquals(resultSet.getString("STATE_REASON_CODE"), inwStateReasonCode,inwFileName+": State reason code mismatch");
            softAssert.assertEquals(resultSet.getString("REMARKS"),remarks,inwFileName+": Remarks mismatch");
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkStatusReasonCode(): " + ex.getMessage());
        }
    }

    /**
     * Method to Validate StateReasonCode in ACH_DEST_TRANSACTION SCHEMA
     *
     * @param stateReasonCode contains validation Message for STATE_REASON_CODE
     * @param remarks         contains validation Message for REMARKS
     */
    @Step("Performing Check Status Reason code in ACH_DEST_TRANSACTION for file message id: {0}, state reason code: {1} and remarks: {2} for {3} number of records")
    public static void checkStatusReasonCodeinTransaction(String stateReasonCode, String remarks,String recordMessageId, String checkDestTransaction) {
        try {
            ResultSet resultSet = DataBaseUtility.executeSelectStatement("select * from SI_NACH_OWNER.ACH_DEST_TRANSACTION where RECORD_MESSAGE_ID='" + recordMessageId + "'");
            if(checkDestTransaction.equals("true"))
            {
                softAssert.assertTrue(DataBaseUtility.getRowCount(resultSet) == 1, "Number of records MisMatch");
                while (resultSet.next()) {
                    LogManager.getLogger().info("RECORD_MESSAGE_ID: " + resultSet.getString("RECORD_MESSAGE_ID"));
                    log.info("STATE REASON CODE: " + resultSet.getString("STATE_REASON_CODE"));
                    softAssert.assertEquals(resultSet.getString("STATE_REASON_CODE"), stateReasonCode, resultSet.getString("RECORD_MESSAGE_ID")+": State Reason code not matched");
                    log.info("REMARKS: " + resultSet.getString("REMARKS"));
                    softAssert.assertEquals(resultSet.getString("REMARKS"), remarks, resultSet.getString("RECORD_MESSAGE_ID")+": Remarks mismatch");
                    cbsAccountNumber = resultSet.getString("ACCOUNT_NUMBER");
                }
            }
            else
            {
                while (resultSet.next())
                {
                    softAssert.assertTrue(DataBaseUtility.getRowCount(resultSet) == 0, resultSet.getString("RECORD_MESSAGE_ID")+": Number of records MisMatch");
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkStatusReasonCodeinTransaction(): " + ex.getMessage());
        }
    }

    public static int missingRecordsPresent(ArrayList<Map<String, String>> fileInputList)
    {
        int foundMissingRecords=0;
        for (int loop = 0; loop < fileInputList.size(); loop++) {

            Map<String,String> fileInputMap = fileInputList.get(loop);
            if(fileInputMap.get(ACH_DEST_INWARD_FILE_SRC).equalsIgnoreCase(FILE_HEADER_FORMAT_VALIDATION) || fileInputMap.get(ACH_DEST_INWARD_FILE_SRC).equalsIgnoreCase(FILE_RECORD_FORMAT_VALIDATION) || fileInputMap.get(ACH_DEST_INWARD_FILE_SRC).equalsIgnoreCase(FILE_NAME_FAILURE))
            {
                foundMissingRecords = loop+1;
                break;
            }
        }
        return foundMissingRecords;

    }

    public static boolean performFileProcessValidations(ArrayList<Map<String, String>> fileInputList)
    {
        boolean missingRecordsFound;
        createENACHConnections();
        try
        {
            int missingRecordsCount = missingRecordsPresent(fileInputList);
            if(missingRecordsCount == 0)
            {
                performFileProcess(INWARD_FILE_PROCESS,fileInputList);
                performFileProcess(JPB_DEBIT_FILE_PROCESS,fileInputList);
                performFileProcess(RETURN_FILE_PROCESS,fileInputList);
                missingRecordsFound = false;
            }
            else
            {
                Map<String,String> fileInputMap = fileInputList.get(missingRecordsCount-1);
                log.info("Performing Inward File Process");
                performFileTriggerProcess(fileInputMap.get(ACH_DEST_INWARD_FILE_SRC),fileInputMap.get(ACH_DEST_INWARD_FILE_REMARKS));
                for (int loop = 0; loop < fileInputList.size(); loop++)
                {
                    Map<String,String> fileInputEachMap = fileInputList.get(loop);
                    checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_INW_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_INW_REMARKS),fileInputEachMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                }

                performFileProcess(configProperties.getProperty("debitApiURL"), configProperties.getProperty("jpbDebitProcessMsg"));
                log.info("Performing JPB Debit File Process");
                Thread.sleep(MAX_WAIT_TIME);
                for (int loop = 0; loop < fileInputList.size(); loop++)
                {
                    Map<String,String> fileInputEachMap = fileInputList.get(loop);
                    checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_DEBIT_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_DEBIT_REMARKS),fileInputEachMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                }

                performFileProcess(configProperties.getProperty("returnApiURL"), configProperties.getProperty("returnFileProcessMsg"));
                log.info("Performing Return File Process");
                Thread.sleep(MAX_WAIT_TIME);
                for (int loop = 0; loop < fileInputList.size(); loop++)
                {
                    Map<String,String> fileInputEachMap = fileInputList.get(loop);
                    checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_RTN_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_RTN_REMARKS),fileInputEachMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                }
                missingRecordsFound = true;
            }
            return missingRecordsFound;

        }
        catch (Exception ex)
        {
            throw new RuntimeException("Exception in performFileProcessValidations(): "+ex.getMessage());
        }
        finally {
            closeTestConnections();
        }
    }

    public static void performFileProcess(String triggerProcess,List<Map<String,String>> fileInputList)
    {
        try
        {
            switch (triggerProcess)
            {
                case INWARD_FILE_PROCESS:
                    performFileTriggerProcess(VALIDATION_COMPLETED,FILE_CREATED_REMARKS);
                    Thread.sleep(MAX_WAIT_TIME);
                    for (int loop = 0; loop < fileInputList.size(); loop++)
                    {
                        Map<String,String> fileInputMap = fileInputList.get(loop);
                        checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_INW_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_INW_REMARKS),fileInputMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                    }
                    break;
                case JPB_DEBIT_FILE_PROCESS:
                    performFileProcess(configProperties.getProperty("debitApiURL"), configProperties.getProperty("jpbDebitProcessMsg"));
                    Thread.sleep(MAX_WAIT_TIME);
                    for (int loop = 0; loop < fileInputList.size(); loop++)
                    {
                        Map<String,String> fileInputMap = fileInputList.get(loop);
                        checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_DEBIT_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_DEBIT_REMARKS),fileInputMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                    }
                    break;
                case RETURN_FILE_PROCESS:
                    performFileProcess(configProperties.getProperty("returnApiURL"), configProperties.getProperty("returnFileProcessMsg"));
                    Thread.sleep(MAX_WAIT_TIME);
                    for (int loop = 0; loop < fileInputList.size(); loop++)
                    {
                        Map<String,String> fileInputMap = fileInputList.get(loop);
                        checkStatusReasonCodeinTransaction(fileInputMap.get(ACH_DEST_TRANSACTION_RTN_SRC),fileInputMap.get(ACH_DEST_TRANSACTION_RTN_REMARKS),fileInputMap.get("RECORD_MESSAGE_ID"),fileInputMap.get("CHECK_DEST_TRANSACTION"));
                    }
                    break;
            }

        }
        catch (Exception ex)
        {
            throw new RuntimeException("Exception in performInwFileProcess(): "+ex.getMessage());
        }
    }
}
