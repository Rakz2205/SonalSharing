package demandProcessingUtils;

import base.BaseClass;
import com.utilities.connectionUtils.DataBaseUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.*;

import static base.BaseClass.writeDuplicateRecordId;
import static base.Constants.*;
import static demandProcessingUtils.GetCBSAmount.getAmountFromCBS;

public class GetDatabaseRecords extends BaseClass {
    public static Logger log = LogManager.getLogger(GetDatabaseRecords.class);

    public static ResultSet fetchRecordsFromDB(String query)
    {
        try
        {
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);

            int rowCount = DataBaseUtility.getRowCount(resultSet);

            if (rowCount == 0)
                throw new Exception("zero records found in jpb_mandate_management table query.");
            else {
                return resultSet;
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in TestDemandProcessing(): "+ex.getMessage());
        }
    }

    public static ArrayList<Map<String, String>> getAllColFromJPBMandateManagement(String query) {
        ArrayList<Map<String, String>> jpbMMList = new ArrayList();

        try {
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);
            ResultSetMetaData md = resultSet.getMetaData();
            int columns = md.getColumnCount();

            while (resultSet.next()) {
                HashMap<String, String> row = new HashMap(columns);
                for (int i = 1; i <= columns; ++i) {
                    row.put(md.getColumnName(i), resultSet.getString(i));
                }
                jpbMMList.add(row);
            }


            for (Map.Entry e : jpbMMList.get(0).entrySet()
            ) {
                System.out.println(e.getKey() + " : " + e.getValue());

            }
        } catch (Exception ex) {
            log.info("Exception in getAllColFromJPBMandateManagement(): " + ex.getMessage());
        }
        return jpbMMList;

    }

    public static ArrayList<Map<String, String>> performNegativeScenarios(ArrayList<Map<String, String>> jpbMMList, String scenario,int listIndex) {
        String accountNumber = jpbMMList.get(listIndex).get("ACCOUNT_NUMBER");
        int cbsAccountBalance = GenerateINWFile.accountNumberAndCBSBalance.get(accountNumber);
        writeDuplicateRecordId(scenario);
        switch (scenario) {
            case AMOUNT_GREATER_MAX:
                int amount = mandateAmount;
                log.info("Amount from Map: " + amount);
                amount = amount + 100;
                log.info("Amount after Adding 1: " + amount);
                jpbMMList.get(listIndex).replace("AMOUNT", String.valueOf(amount));
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,AMOUNT_MISMATCH_SRC,AMOUNT_MISMATCH_REMARKS,GENERATED_RETURN_FILE,AMOUNT_MISMATCH_REMARKS,"true");
                break;
            case MISSING_UMRN_NUMBER:
                jpbMMList.get(listIndex).replace("UMRN", "");
                addValidations(jpbMMList.get(listIndex),FILE_RECORD_FORMAT_VALIDATION,MISSING_UMRN_NUMBER_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_DEST_BANK_CODE:
                jpbMMList.get(listIndex).put("DESTINATION_BANK_CODE", "");
                addValidations(jpbMMList.get(listIndex),FILE_HEADER_FORMAT_VALIDATION,MISSING_DEST_BANK_CODE_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_SP_BANK_CODE:
                jpbMMList.get(listIndex).put("SP_BANK_CODE", "");
                addValidations(jpbMMList.get(listIndex),FILE_RECORD_FORMAT_VALIDATION,MISSING_SP_BANK_CODE_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_RECORD_MESSAGE_ID:
                jpbMMList.get(listIndex).replace("RECORD_MESSAGE_ID", "");
                addValidations(jpbMMList.get(listIndex),FILE_RECORD_FORMAT_VALIDATION,MISSING_RECORD_MESSAGE_ID_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_ACCOUNT_NUMBER:
                jpbMMList.get(listIndex).replace("ACCOUNT_NUMBER", "");
                addValidations(jpbMMList.get(listIndex),FILE_RECORD_FORMAT_VALIDATION,MISSING_ACCOUNT_NUMBER_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_ACH_SEQUENCE_NUMBER:
                jpbMMList.get(listIndex).put("ACH_SEQUENCE_NUMBER", "");
                addValidations(jpbMMList.get(listIndex),FILE_HEADER_FORMAT_VALIDATION,MISSING_DEST_BANK_CODE_REMARKS,null,null,null,null,null,null,"false");
                break;
            case MISSING_AMOUNT:
                jpbMMList.get(listIndex).replace("AMOUNT", "");
                addValidations(jpbMMList.get(listIndex),FILE_HEADER_FORMAT_VALIDATION,MISSING_DEST_BANK_CODE_REMARKS,null,null,null,null,null,null,"false");
                break;
            case INCORRECT_UMRN_NUMBER:
                jpbMMList.get(listIndex).replace("UMRN", "JIOP0000000000000000");
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,MANDATE_NOT_RECEIVED_SRC,MANDATE_NOT_RECEIVED_REMARKS,GENERATED_RETURN_FILE,MANDATE_NOT_RECEIVED_REMARKS,"true");
                break;
            case INCORRECT_ACCOUNT_NUMBER:
                jpbMMList.get(listIndex).replace("ACCOUNT_NUMBER", "30000000000000");
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null, INCORRECT_ACCOUNT_NUMBER_SRC, INCORRECT_ACCOUNT_NUMBER_REMARKS,GENERATED_RETURN_FILE, INCORRECT_ACCOUNT_NUMBER_REMARKS,"true");
                break;
            case INCORRECT_SP_BANK_CODE:
                jpbMMList.get(listIndex).put("SP_BANK_CODE", "HDFC0121212");
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,INVALID_IFSC_SRC,INVALID_IFSC_REMARKS,GENERATED_RETURN_FILE,INVALID_IFSC_REMARKS,"true");
                break;
            case INCORRECT_DEST_BANK_CODE:
                jpbMMList.get(listIndex).put("DESTINATION_BANK_CODE", "JIOP1234567");
                addValidations(jpbMMList.get(listIndex),FILE_HEADER_FORMAT_VALIDATION,MISSING_DEST_BANK_CODE_REMARKS,null,null,null,null,null,null,"false");
                break;
            case INCORRECT_CORP_CODE:
                jpbMMList.get(listIndex).put("CORP_CODE", "NACH00000000000000");
                //validations to be changed
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,GENERIC_ERROR_CODE_SRC,GENERIC_ERROR_CODE_REMARKS,GENERATED_RETURN_FILE,GENERIC_ERROR_CODE_REMARKS,"true");
                break;
            case GREATER_SETTLEMENT_DATE:
                jpbMMList.get(listIndex).put("SETTLEMENT_DATE","2020-08-01");
                //validations to be changed
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,GENERIC_ERROR_CODE_SRC,GENERIC_ERROR_CODE_REMARKS,GENERATED_RETURN_FILE,GENERIC_ERROR_CODE_REMARKS,"true");
                break;
            case DUPLICATE_RECORD_ID:
                duplicateRecordId = writeProperties.getProperty("duplicateRecordId");
                System.out.println(duplicateRecordId);
                jpbMMList.get(listIndex).replace("RECORD_MESSAGE_ID",duplicateRecordId);
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,DUPLICATE_RECORD_ID_SRC,DUPLICATE_RECORD_ID_REMARKS,GENERATED_RETURN_FILE,DUPLICATE_RECORD_ID_REMARKS,"true");
                break;
            case AMOUNT_GREATER_CBS_BAL:
                int insuffAmount = getAmountFromCBS("TWO",accountNumber) + 100000;
                jpbMMList.get(listIndex).replace("AMOUNT",String.valueOf(insuffAmount));
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,INSUFFICIENT_FUNDS_SRC,INSUFFICIENT_FUNDS_REMARKS,GENERATED_RETURN_FILE,INSUFFICIENT_FUNDS_REMARKS,"true");
                break;
            case RECEIVED_STATUS:
            case TOKEN_AF_STATUS:
            case ACCEPTED_STATUS:
            case REJECTED_STATUS:
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,MANDATE_NOT_RECEIVED_SRC,MANDATE_NOT_RECEIVED_REMARKS,GENERATED_RETURN_FILE,MANDATE_NOT_RECEIVED_REMARKS,"true");
                break;
            case FREEZE_ACCOUNT:
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,ACCOUNT_FREEZE_SRC,ACCOUNT_FREEZE_REMARKS,GENERATED_RETURN_FILE,ACCOUNT_FREEZE_REMARKS,"true");
                break;
            case DORMANT_ACCOUNT:
            case INACTIVE_ACCOUNT:
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,ACCOUNT_INACTIVE_DORMANT_SRC,ACCOUNT_INACTIVE_DORMANT_REMARKS,GENERATED_RETURN_FILE,ACCOUNT_INACTIVE_DORMANT_REMARKS,"true");
                break;
            case CLOSED_ACCOUNT:
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,ACCOUNT_CLOSED_SRC,ACCOUNT_CLOSED_REMARKS,GENERATED_RETURN_FILE,ACCOUNT_CLOSED_REMARKS,"true");
                break;
            case AFTER_MANDATE_END_DATE:
                jpbMMList.get(listIndex).replace("SETTLEMENT_DATE",addDaysInProvidedDate(1,mandateEndDate,"yyyy-MM-dd hh:mm:ss.s","yyyy-MM-dd"));
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,MANDATE_EXPIRED_SRC,MANDATE_EXPIRED_REMARKS,GENERATED_RETURN_FILE,MANDATE_EXPIRED_REMARKS,"true");
                break;
            case BEFORE_MANDATE_START_DATE:
                jpbMMList.get(listIndex).replace("SETTLEMENT_DATE",addDaysInProvidedDate(-1,mandateStartDate,"yyyy-MM-dd hh:mm:ss.s","yyyy-MM-dd"));
                addValidations(jpbMMList.get(listIndex),VALIDATION_COMPLETED,FILE_CREATED_REMARKS,SCHEDULED_SRC,null,MANDATE_EXPIRED_SRC,MANDATE_EXPIRED_REMARKS,GENERATED_RETURN_FILE,MANDATE_EXPIRED_REMARKS,"true");
                break;
            case INCORRECT_FILE_NAME:
                incorrectFileName = true;
                addValidations(jpbMMList.get(listIndex),FILE_NAME_FAILURE,FILE_NAME_FAILURE_REMARKS,null,null,null,null,null,null,"false");
                break;
            default:
                System.out.println("In debit");
                int debitedAmount = Integer.parseInt(jpbMMList.get(listIndex).get("AMOUNT"));
                GenerateINWFile.accountNumberAndCBSBalance.replace(accountNumber,cbsAccountBalance-debitedAmount);
        }
        return jpbMMList;
    }

    public static void addValidations(Map<String,String> resultMap,String inwFileSRC,String inwFileRemarks,String inwProcessSRC,String inwProcessRemarks, String jpbDebitSRC, String jpbDebitRemarks, String returnSRC, String returnRemarks, String checkDestTransactions)
    {
        totalDebitAmount = totalDebitAmount - Integer.parseInt(resultMap.get("AMOUNT"));
        resultMap.replace(ACH_DEST_INWARD_FILE_SRC,inwFileSRC);
        resultMap.replace(ACH_DEST_INWARD_FILE_REMARKS,inwFileRemarks);
        resultMap.replace(ACH_DEST_TRANSACTION_INW_SRC,inwProcessSRC);
        resultMap.replace(ACH_DEST_TRANSACTION_INW_REMARKS,inwProcessRemarks);
        resultMap.replace(ACH_DEST_TRANSACTION_DEBIT_SRC,jpbDebitSRC);
        resultMap.replace(ACH_DEST_TRANSACTION_DEBIT_REMARKS,jpbDebitRemarks);
        resultMap.replace(ACH_DEST_TRANSACTION_RTN_SRC,returnSRC);
        resultMap.replace(ACH_DEST_TRANSACTION_RTN_REMARKS,returnRemarks);
        resultMap.replace(CHECK_DEST_TRANSACTION,checkDestTransactions);
    }

}
