package demandProcessingUtils;

import base.BaseClass;
import com.utilities.connectionUtils.DataBaseUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.yandex.qatools.allure.annotations.Step;

import java.sql.ResultSet;

public class GetCBSAmount extends BaseClass
{
    public static Logger log = LogManager.getLogger(GetCBSAmount.class);
    public static int getAmountFromCBS(String instance,String accountNumber)
    {
        try
        {
            String cbsQuery = "Select CLR_BAL_AMT from tbaadm.gam where FORACID='"+accountNumber+"'";
            createCBSConnection(instance);
            log.info("CBS Query: "+cbsQuery);
            ResultSet resultSet = DataBaseUtility.executeSelectStatement(cbsQuery);
            int cbsAmount=0;
            if(resultSet.next())
            {
                cbsAmount = (int)(Double.parseDouble(resultSet.getString("CLR_BAL_AMT"))*100);
                log.info(cbsAmount);
            }

            return (cbsAmount);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Exception in getAmountFromCBS(): "+ex.getMessage());
        }
        finally {
            closeTestConnections();
        }
    }

    @Step("Validating CBS Amount")
    public static void validateCBSAmount(int expectedAmount, String cbsQuery, String errorMessage)
    {
        try
        {
            int cbsAfterDebit = getAmountFromCBS("TWO",cbsQuery);
            log.info("CBS Balance after Debit: "+cbsAfterDebit);
            softAssert.assertTrue(expectedAmount == cbsAfterDebit,errorMessage);
            softAssert.assertAll();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Exception in validateCBSAmount(): "+ex.getMessage());
        }
    }

    public static void createCBSConnection(String instanceType) {
        try {
            String instance = "SIT_CBS_INS_"+instanceType;
            //  Create database connection
            if (configProperties.getProperty("Environment").equalsIgnoreCase("PP")) {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty(instance), configProperties.getProperty("DB_Username"), configProperties.getProperty("DB_Password"));
            } else {
                DataBaseUtility.createOracleDatabaseConnection(configProperties.getProperty(instance), configProperties.getProperty("SIT_CBS_USERNAME"), configProperties.getProperty("SIT_CBS_PASSWORD"));
            }

        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void closeTestConnections() {
        try {
            //  disconnecting database
            DataBaseUtility.dbConnection.close();

            //  disconnect unix connection
            //UnixUtility.session.disconnect();
        } catch (Exception e) {
            throw new RuntimeException("error while closing the test connections.", e);
        }
    }
}
