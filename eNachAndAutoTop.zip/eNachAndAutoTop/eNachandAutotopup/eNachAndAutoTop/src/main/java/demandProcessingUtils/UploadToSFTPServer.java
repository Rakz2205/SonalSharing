package demandProcessingUtils;


import base.BaseClass;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.utilities.connectionUtils.UnixUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.yandex.qatools.allure.annotations.Step;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static base.Constants.THRESHOLD_TIME;
import static com.utilities.fileUtils.FileUtility.copyFile;

public class UploadToSFTPServer extends BaseClass
{
    public static String fileName;
    public static Logger log = LogManager.getLogger(UploadToSFTPServer.class);

    /**
     * Method to upload INW File to SFTP Server
     */
    @Step("Uploading INW.xml file generated to SFTP Server")
    public static void uploadINWFile()
    {
        try
        {
            if(incorrectFileName)
            {
                renameFileName();
                incorrectFileName = false;
            }
            log.info("Uploading to SFTP Server");
            UnixUtility.createUnixConnection(configProperties.getProperty("SFTP_HOSTNAME"),configProperties.getProperty("SFTP_USERNAME"),configProperties.getProperty("SFTP_PASSWORD"),Integer.parseInt(configProperties.getProperty("SFTP_PORT")));
            fileName = getINWFileName(configProperties.getProperty("FileGeneratorUtilityPath"),"xml");
            UnixUtility.uploadFileOverSftp(configProperties.getProperty("remoteSFTPDirectoryPath"),configProperties.getProperty("FileGeneratorUtilityPath"),fileName);
            LogManager.getLogger(UploadToSFTPServer.class).info("File Uploaded successfully");

            //Checking if file is uploaded to App Server
            UploadToSFTPServer.checkINWFilePresent();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Exception in uploadINWFile(): "+ex.getMessage());
        }
    }

    /**
     * Method to check if INW file is moved to Main Server
     */
    @Step("Checking If INW.xml file is moved to App Server")
    public static void checkINWFilePresent()
    {
        log.info("Checking if file is uploaded to App Server");
        String remoteSFTPDirectory = configProperties.getProperty("remoteSFTPDirectoryPath");
        UnixUtility.createUnixConnection(configProperties.getProperty("SFTP_HOSTNAME"),configProperties.getProperty("SFTP_USERNAME"),configProperties.getProperty("SFTP_PASSWORD"),Integer.parseInt(configProperties.getProperty("SFTP_PORT")));
        int thresholdTime=0;
        while (checkFileOverSFTP(remoteSFTPDirectory,fileName) && thresholdTime<THRESHOLD_TIME)
        {
            if(!checkFileOverSFTP(remoteSFTPDirectory, fileName))
            {
                break;
            }
            thresholdTime++;

        }
    }

    /**
     * Method to rename INW File Name
     */
    public static void renameFileName()
    {
        fileName = getINWFileName(configProperties.getProperty("FileGeneratorUtilityPath"),"xml");
        copyFile(configProperties.getProperty("FileGeneratorUtilityPath")+fileName,configProperties.getProperty("FileGeneratorUtilityPath")+"IncorrectTestName.xml");
        File f = new File(configProperties.getProperty("FileGeneratorUtilityPath")+fileName);
        f.delete();
    }

    /**
     * move file from remote to local directory
     *
     * @param remoteDirectory remote directory path in string
     * @param fileName        file name in string
     */
    @Step("Getting contents from TestInput Template file")
    public static boolean checkFileOverSFTP(String remoteDirectory, String fileName) {
        System.out.println("In CheckFileOverSFTP");
        Channel channel = null;
        try {
            channel = UnixUtility.session.openChannel("sftp");
            channel.connect();

            ChannelSftp channelSftp = (ChannelSftp) channel;
            channelSftp.cd(remoteDirectory);
            
            channelSftp.get(fileName).available();
            return true;

        } catch (Exception e) {
            return false;
        } finally {
            channel.disconnect();
        }
    }

}
