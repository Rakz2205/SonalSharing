package ToBeDeleted;

import DataProvider.BrowserNameProvider;
import Utils.Reporter;
import base.SetUp;
import org.testng.annotations.Test;

import java.util.HashMap;

public class FirstProgram extends SetUp {
    // sample with Browser list multi value
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Third", "BrowserList:Chrome:IE","TsetId:1234"})
    public void myTest_123456(String browserName, HashMap myData) throws InterruptedException {
        Reporter.initiateTestReport(FirstProgram.class, (String) myData.get("TestDescription"));
        System.out.println("Helo");
        System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
        //GenericVariable.DPS_QA_HOST;
    }

    // sample with No Browser list
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Test"})
    public void myTest1(HashMap myData) throws InterruptedException {
        Reporter.initiateTestReport(FirstProgram.class, (String) myData.get("TestDescription"));
        System.out.println("Helo");
        //System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
    }

    // sample with Single Browser list
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Test", "BrowserList:Chrome"})
    public void myTest2(String browserName, HashMap myData) throws InterruptedException {
        Reporter.initiateTestReport(FirstProgram.class, (String) myData.get("TestDescription"));
        System.out.println("Helo");
        System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
    }

    // sample with no test data and no browser list data provider not required
    @Test
    public void myTest5() throws InterruptedException {

        System.out.println("Helo");
        //System.out.println(browserName);

        // WebDriver myDriver = LaunchApplication.launchApplication(null, "chrome", true);
        // myDriver.get("http://ppcafapproval.rjil.ril.com:9443/Uniserve-Web/LogInAction.do");
        // Thread.sleep(1000);

        // myDriver.close();

        // myDriver = LaunchApplication.launchApplication(null, "IE", true);
        // myDriver.get("http://ppcafapproval.rjil.ril.com:9443/Uniserve-Web/LogInAction.do");
        // Thread.sleep(1000);

        // myDriver.close();


        // need to create a dataprovider same as done in QA Automation project CT
    }
}
