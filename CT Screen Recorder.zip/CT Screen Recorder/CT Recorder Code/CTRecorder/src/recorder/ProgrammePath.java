package recorder;

public class ProgrammePath{

	public String workingDir(){
		// TODO Auto-generated method stub
		
		 String workingDir = System.getProperty("user.dir");	
		 //System.out.println(workingDir);
		   return workingDir;		
	}
}