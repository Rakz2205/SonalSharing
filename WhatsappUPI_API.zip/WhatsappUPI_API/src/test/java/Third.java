import DataProvider.BrowserNameProvider;
import Utils.Reporter;
import org.testng.annotations.Test;

import java.util.HashMap;

public class Third
{
    @Test()
    public void myTest() throws InterruptedException {
       //Reporter.initiateTestReport(FirstProgram.class, (String) myData.get("TestDescription"));
        System.out.println("Helo");
        //System.out.println(browserName);
       // System.out.println(myData.get("Metadata"));
        //GenericVariable.DPS_QA_HOST;
    }
    // sample with No Browser list
    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Test"})
    public void myTest1(HashMap myData) throws InterruptedException {
        Reporter.initiateTestReport(Third.class, "test");
        System.out.println("Helo");
        //System.out.println(browserName);
        System.out.println(myData.get("Metadata"));
    }

}
