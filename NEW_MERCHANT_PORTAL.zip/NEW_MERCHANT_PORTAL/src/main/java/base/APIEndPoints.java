package base;

public class APIEndPoints extends SetUp {
    public static final String Authenticate_EndPoint = "http://10.144.108.106:3006/jfs/v1/authenticate";

    public static final String public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnDSqH8nSZfSILO/AWRRxgUxgXsJGr2eVo5h8ZdHZ86YAUQ5cCWYTQ48VSceUw9kutqEagEzQDoK4UbkGzqzLN+Hqp2Mu2M4Dzpecm3wlPSgfdnRZFSXIbSPJ3QrV4R8mumShYuYHKK/nn0JmzlQIQCLf9CtIGqFBBquqyGg75MTX1AA92mO6CUxJ9hpN5hseki6MfPTViMIKc5cMCXP6kBh3t1b69diKovvADMQZxiyHIJX5mta30/+SQv0R6BEfg6F769vZD+td79+qELp/iYWCrUmeNe7HJjy3FgZ5UQxHOhS3s1TjX0S/H/+yOWg9MzHgd6+OhV/8LeblAj203QIDAQAB";

    public static final String AES_Key = "691A7E7C417D9BB953BB28C10933B1A2";

    public static final String Authenticate_ChangeCredential_EndPoint ="http://10.144.108.106:3006/jfs/v1/authenticate/credentials/change";



    public static final String Authenticate_ResetCredential_EndPoint ="http://10.144.108.106:3006/jfs/v1/authenticate/credentials/reset";

    public static final String MMS_GetMerchantConfig_EndPoint = "http://10.144.108.106:7007/jfs/v1/merchant/getMerchantConfig";

    public static final String MMS_GetMerchantUserInterface_EndPoint = "http://10.144.108.106:7007/jfs/v1/merchant/getUserInterface";

    public static final String MMS_GetCardsMerchant_EndPoint = "http://10.144.108.106:7007/jfs/v1/merchant/getCards";

    public static final String MMS_SearchMerchant_EndPoint = "http://10.144.108.106:7007/jfs/v1/merchant/searchMerchant";


    public static final String MMS_GetMerchantConfigList_EndPoint = "http://10.144.108.106:7007/jfs/v1/merchant/getMerchantConfigList";

    public static final String GST_GetGSTInvoices_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/gstinvoices/";

    public static final String GST_GetColumns_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/transactions/columns";

    public static final String GST_DownloadGSTInvoice_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/gstinvoices/";

    public static final String Transaction_GetTransaction_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/transactions";

    public static final String Transaction_GetTransactionById_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/transaction/31120020200312322393";

    public static final String Settlement_GetSettlements_EndPoint = "http://10.144.108.106:7010/jfs/v1/merchant/settlements";

    public static final String Settlement_GenerateSettlementReport_EndPoint = "http://10.144.108.106:7010/jfs/v1/merchant/generateSettlementReport";

    public static final String Settlement_GetSettlementsFile_EndPoint = "http://10.144.108.106:7010/jfs/v1/merchant/getSettlementsFile/";

    public static final String InitiateRefund_EndPoint = "http://10.144.108.106:3007/jfs/v1/merchant/refunds";

}
