package base;

public class GenericVariable extends SetUp
{
    public static final String DPS_QA_HOST = "https://qa.oneviewdps.davita.com/";
}
