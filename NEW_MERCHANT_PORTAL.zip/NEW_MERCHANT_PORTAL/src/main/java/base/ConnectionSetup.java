package base;

import com.utilities.connectionUtils.DataBaseUtility;

public class ConnectionSetup extends SetUp {

    public static void createTestConnections() {
        try {
            //  Create database connection
            if (properties.getProperty("Environment").equalsIgnoreCase("PP")) {
                dbMerchant = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty(""), properties.getProperty(""), properties.getProperty(""));
            } else {
                dbMerchant = DataBaseUtility.createOracleDatabaseConnection(properties.getProperty("SIT_DB_Merchant_UserHost"),
                        properties.getProperty("DB_Merchant_Username"), properties.getProperty("DB_Merchant_Password"));
            }
        } catch (Exception e) {
            throw new RuntimeException("error while creating the test connections.", e);
        }
    }

    public static void closeTestConnections() {
        try {
            dbMerchant.close();
        } catch (Exception e) {
            throw new RuntimeException("error while closing the test connections.", e);
        }
    }
}
