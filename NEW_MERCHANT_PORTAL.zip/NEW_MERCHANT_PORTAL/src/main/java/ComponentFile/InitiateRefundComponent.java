package ComponentFile;

import ResponseEntity.CardsMerchantDataList;
import ResponseEntity.ConfigResponseEntity;
import ResponseEntity.ConfigValueList;
import ResponseEntity.MMSResponseEntity.GetCardsMerchantResponseEntity;
import ResponseEntity.MMSResponseEntity.GetConfigResponseEntity;
import ResponseEntity.MMSResponseEntity.GetMerchantConfigListResponseEntity;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.ConfigParams;
import entity.Data;
import entity.InitiateRefundEntity.InitiateRefundEntity;
import entity.InputFilter;
import entity.MMSEntity.*;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import java.sql.ResultSet;
import java.util.*;

public class InitiateRefundComponent extends SetUp
{
    Gson request = new Gson();
    CommonMethods commMethod;
    public InitiateRefundComponent() {
        commMethod = new CommonMethods();
    }

    public Response getResponseInitiateRefund(HashMap myData)
    {
        try {
            Response response = null;
            String payload = createInitiateRefundPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));

            response = RestUtil.postByJson(payload, APIEndPoints.InitiateRefund_EndPoint, request);
            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Initiate Refund response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Initiate Refund response.", e);
            throw new RuntimeException("error while creating the Initiate Refund response.", e);
        }
    }

    private String createInitiateRefundPayload(HashMap myData)
    {
        try {

            InitiateRefundEntity parent = new InitiateRefundEntity();

            parent.setMid((String) myData.get("mid"));
            parent.setOriginalId((String) myData.get("originalId"));
            parent.setSource((String) myData.get("source"));
            parent.setRrn((String) myData.get("rrn"));
            parent.setTerminalId((String) myData.get("terminalId"));
            parent.setLivemode(Boolean.parseBoolean((String) myData.get("livemode")));
            parent.setInvoice((String) myData.get("invoice"));
            parent.setAcquiringInstId((String) myData.get("acquiringInstId"));
            parent.setTransactionTime((String) myData.get("transactionTime"));
            parent.setCurrency(Integer.parseInt(myData.get("currency").toString()));
            parent.setAcquiringInstCountryCode(Integer.parseInt(myData.get("acquiringInstCountryCode").toString()));
            parent.setAmount(Double.parseDouble(myData.get("amount").toString()));

            String payload = request.toJson(parent);

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Initiate Refund payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Initiate Refund payload.", e);
            throw new RuntimeException("error while creating the Initiate Refund payload.", e);
        }
    }
}
