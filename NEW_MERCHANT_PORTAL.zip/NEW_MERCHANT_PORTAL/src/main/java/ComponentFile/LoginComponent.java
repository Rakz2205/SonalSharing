package ComponentFile;

import Utils.Reporter;
import base.SetUp;
import com.utilities.fileUtils.PropertiesUtility;

import java.util.Properties;

public class LoginComponent  extends SetUp
{
    public static Properties loginProp;

    public LoginComponent()
    {
        loginProp = PropertiesUtility.getApplicationProperties("\\src\\main\\java\\PropertiesFile\\environment.properties");
        System.out.println("Inside constructor");
        System.out.println(loginProp.getProperty("Environment"));
    }

    public void tryProp()
    {
        System.out.println("Inside try propr" + loginProp.getProperty("Environment"));
        Reporter.logReport(LoginComponent.class, log_Type_Pass,"GetAccount payload has been created. Payload : ", null);
    }
}
