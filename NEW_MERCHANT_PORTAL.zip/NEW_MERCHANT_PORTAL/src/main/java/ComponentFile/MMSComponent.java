package ComponentFile;

import ResponseEntity.CardsMerchantDataList;
import ResponseEntity.ConfigResponseEntity;
import ResponseEntity.ConfigValueList;
import ResponseEntity.ConfigValues;
import ResponseEntity.MMSResponseEntity.GetCardsMerchantResponseEntity;
import ResponseEntity.MMSResponseEntity.GetConfigResponseEntity;
import ResponseEntity.MMSResponseEntity.GetMerchantConfigListResponseEntity;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.ConfigParams;
import entity.Data;
import entity.InputFilter;
import entity.MMSEntity.*;
import io.restassured.response.Response;
import org.openqa.selenium.remote.server.handler.DeleteSession;
import org.testng.Assert;

import java.sql.ResultSet;
import java.util.*;

public class MMSComponent extends SetUp {
    Gson request = new Gson();
    CommonMethods commMethod;

    public MMSComponent() {
        commMethod = new CommonMethods();
    }

    public Response getResponseGetMerchantConfig(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetMerchantConfigPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));
            

            response = RestUtil.postByJson(payload, APIEndPoints.MMS_GetMerchantConfig_EndPoint, request);

            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Get Merchant Config response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Get Merchant Config response.", e);
            throw new RuntimeException("error while creating the Get Merchant Config response.", e);
        }
    }

    private String createGetMerchantConfigPayload(HashMap myData) {
        try {
            GetMerchantConfigEntity getMerchantConfig = new GetMerchantConfigEntity();
            getMerchantConfig.setMid((String) myData.get("mid"));
            getMerchantConfig.setConfigType((String) myData.get("configType"));
            getMerchantConfig.setStatus((String) myData.get("status"));

            String payload = request.toJson(getMerchantConfig);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Merchant Config payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the the Get Merchant Config payload.", e);
            throw new RuntimeException("error while creating the the Get Merchant Config payload.", e);
        }

    }

    public void validateMerchantConfigResponseBody(Response response, HashMap myData) {
        try {

            ResultSet resultSet = getMerchantConfigDB(myData);

            String dbValueToJson = convertConfigResultSetToJson(resultSet, myData);

            String responseBody = response.getBody().asString();
            ObjectMapper mapper = new ObjectMapper();

            Assert.assertEquals(mapper.readTree(dbValueToJson), mapper.readTree(responseBody), "Get Merchant Config resonse body matches with DB");

            // comparing result set with response is pending

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Merchant Config response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while validating Get Merchant Config response body.", e);
            throw new RuntimeException("error while validating Get Merchant Config response body.", e);
        }
    }

    private String convertConfigResultSetToJson(ResultSet resultSet, HashMap myData) {
        String responsePayload = "";
        try {
            GetConfigResponseEntity getConfigResponseEntity = new GetConfigResponseEntity();
            ConfigResponseEntity configResponseEntity = new ConfigResponseEntity();
            Gson dbRequest = new Gson();

            getConfigResponseEntity.setStatus(status_Success);

            configResponseEntity.setMid((String) myData.get("mid"));
            configResponseEntity.setConfigType((String) myData.get("configType"));
            configResponseEntity.setStatus((String) myData.get("status"));

            //fetch value from result set and enter into list
            ArrayList<ConfigValues> tempList = new ArrayList<ConfigValues>();

            while (resultSet.next()) {
                ConfigValues ConfigValues = new ConfigValues();
                String strKey = resultSet.getString("KEY");
                String strValue = resultSet.getString("VALUE");
                ConfigValues.setKey(strKey);
                ConfigValues.setValue(strValue);
                tempList.add(ConfigValues);
            }
            configResponseEntity.setConfigValues(tempList);
            getConfigResponseEntity.setResponse(configResponseEntity);

            responsePayload = dbRequest.toJson(getConfigResponseEntity);
        } catch (Exception e) {
            throw new RuntimeException("error while converting db values into json.", e);
        }
        return responsePayload;
    }

    private ResultSet getMerchantConfigDB(HashMap myData) {
        ResultSet resultSet;
        String query;
        try {
            String inputStatus = (String) myData.get("status");
            if (inputStatus.equalsIgnoreCase("ALL")) {
                query = "Select Key,value from Merchant_config where Merchant_id=(Select MERCHANT_ID from Merchant where MID='" + (String) myData.get("mid") + "') and CONFIG_TYPE='" + (String) myData.get("configType") + "'";
            } else {
                query = "Select Key,value from Merchant_config where Merchant_id=(Select MERCHANT_ID from Merchant where MID='" + (String) myData.get("mid") + "') and CONFIG_TYPE='" + (String) myData.get("configType") + "' and STATUS='" + (String) myData.get("status") + "'";
            }

            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "DB Value fetched for Merchant Config", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while fetching data from DB for Merchant Config.", e);
            throw new RuntimeException("error while fetching data from DB for Merchant Config.", e);
        }


    }

    public Response getResponseMerchantUserInterface(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetMerchantUserInterfacePayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.MMS_GetMerchantUserInterface_EndPoint, request);
            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Get Merchant User Interface response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Get Merchant User Interface response.", e);
            throw new RuntimeException("error while creating the Get Merchant User Interface response.", e);
        }
    }

    private String createGetMerchantUserInterfacePayload(HashMap myData) {
        try {
            GetMerchantUserInterfaceEntity parentBody = new GetMerchantUserInterfaceEntity();
            parentBody.setMid((String) myData.get("mid"));
            parentBody.setTemplateId((String) myData.get("templateId"));

            ConfigParams configParameters = new ConfigParams();
            configParameters.setMediaType((String) myData.get("configParams_MediaType"));

            parentBody.setConfigParams(configParameters);

            String payload = request.toJson(parentBody);

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Merchant User Interface payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the the Get Merchant User Interface payload.", e);
            throw new RuntimeException("error while creating the the Get Merchant User Interface payload.", e);
        }
    }

    public void validateMerchantUserInterfaceResponseBody(Response response, HashMap myData) {
        try {
            ResultSet resultSet = getMerchantUserInterfaceDB(myData);

            resultSet.next();
            String mercantLogoDB = resultSet.getString("Merchant_logo_path");
            commMethod.validateResponseContainsMessage(response, mercantLogoDB);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Merchant User Interface response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while validating Get Merchant User Interface response body.", e);
            throw new RuntimeException("error while validating Get Merchant User Interface response body.", e);
        }
    }

    private ResultSet getMerchantUserInterfaceDB(HashMap myData) {
        ResultSet resultSet;
        String query;
        try {
            String inputStatus = (String) myData.get("status");

            query = "Select Merchant_logo_path from Merchant_User_Interface where Merchant_id=(Select MERCHANT_ID from Merchant where MID='" + (String) myData.get("mid") + "') and template_id='" + (String) myData.get("templateId") + "'";

            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "DB Value fetched for Merchant User Interface", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while fetching data from DB for Merchant User Interface.", e);
            throw new RuntimeException("error while fetching data from DB for Merchant User Interface.", e);
        }


    }

    public Response getResponseCardsMerchant(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetCardsMerchantPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.MMS_GetCardsMerchant_EndPoint, request);
            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Get Cards Merchant response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Get Cards Merchant response.", e);
            throw new RuntimeException("error while creating the Get Cards Merchant response.", e);
        }
    }

    private String createGetCardsMerchantPayload(HashMap myData) {
        try {

            GetCardsMerchantEntity getCardMerchant = new GetCardsMerchantEntity();
            getCardMerchant.setMid((String) myData.get("mid"));

            String payload = request.toJson(getCardMerchant);

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Cards Merchant payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the the Get Cards Merchant payload.", e);
            throw new RuntimeException("error while creating the the Get Cards Merchant payload.", e);
        }
    }

    public void validateGetCardsMerchantResponseBody(Response response, HashMap myData) {
        try {
            ResultSet resultSet = getCardsMerchantDB(myData);
            String dbValueToJson = convertCardsMerchantResultSetToJson(resultSet, myData);
            String responseBody = response.getBody().asString();

            ObjectMapper mapper = new ObjectMapper();

            Assert.assertEquals(mapper.readTree(dbValueToJson), mapper.readTree(responseBody), "Get Cards Merchant resonse body matches with DB");

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Cards Merchant response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while validating Get Cards Merchant response body.", e);
            throw new RuntimeException("error while validating Get Cards Merchant  response body.", e);
        }
    }

    private String convertCardsMerchantResultSetToJson(ResultSet resultSet, HashMap myData) {
        String responsePayload = "";
        try {
            GetCardsMerchantResponseEntity parentBody = new GetCardsMerchantResponseEntity();
            parentBody.setStatus(status_Success);
            Gson dbRequest = new Gson();

            CardsMerchantDataList innerArray = new CardsMerchantDataList();
            ArrayList<CardsMerchantDataList> tempList = new ArrayList<CardsMerchantDataList>();

            while (resultSet.next()) {
                CardsMerchantDataList cardDataList = new CardsMerchantDataList();
                int nId = resultSet.getInt("ID");
                String strCardType = resultSet.getString("CARD_TYPE");
                String strScheme = resultSet.getString("SCHEME");
                String strMerchantId = resultSet.getString("MERCHANT_ID");
                String isPremium = resultSet.getString("IS_PREMIUM");
                String strIntAllowed = resultSet.getString("IS_INTERNATIONAL_ALLOWED");
                String strDomesticAllowed = resultSet.getString("IS_DOMESTIC_ALLOWED");

                cardDataList.setCardType(strCardType);
                cardDataList.setIsDomesticAllowed(strDomesticAllowed);
                cardDataList.setIsInternationalAllowed(strIntAllowed);
                cardDataList.setIsPremium(isPremium);
                cardDataList.setScheme(strScheme);
                tempList.add(cardDataList);
            }

            parentBody.setData(tempList);

            responsePayload = dbRequest.toJson(parentBody);

        } catch (Exception e) {
            throw new RuntimeException("error while converting db values into json.", e);
        }
        return responsePayload;
    }

    private ResultSet getCardsMerchantDB(HashMap myData) {
        ResultSet resultSet;
        String query;
        try {
            query = "select ID,CARD_TYPE,SCHEME,MERCHANT_ID,IS_PREMIUM,IS_INTERNATIONAL_ALLOWED,IS_DOMESTIC_ALLOWED from card_config where Merchant_id=(Select MERCHANT_ID from Merchant where MID='" + (String) myData.get("mid") + "')";
            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "DB Value fetched for Get Cards Merchant", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while fetching data from DB for Get Cards Merchant.", e);
            throw new RuntimeException("error while fetching data from DB for Get Cards Merchant.", e);
        }
    }

    public Response getResponseSearchMerchant(HashMap myData) {
        try {
            Response response = null;
            String payload = createSearchMerchantPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.MMS_SearchMerchant_EndPoint, request);
            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Search Merchant response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Search Merchant response.", e);
            throw new RuntimeException("error while creating the Search Merchant response.", e);
        }
    }

    private String createSearchMerchantPayload(HashMap myData) {
        try {

            SearchMerchantEntity parentBody = new SearchMerchantEntity();

            InputFilter firstParam = new InputFilter();

            String testDataType = (String) myData.get("TestdataType");

            if (testDataType.equalsIgnoreCase("SEARCH_USING_MID")) {
                firstParam.setMid((String) myData.get("mid"));
            } else {
                firstParam.setUserID((String) myData.get("userId"));
            }
            parentBody.setInputFilter(firstParam);


            // creating an list
            String strTemp = (String) myData.get("OutputDomains");
            String[] arrTemp = strTemp.split("%%");

            List<String> secondParam = Arrays.asList(arrTemp);

            parentBody.setOutputDomains(secondParam);

            ConfigParams thirdParam = new ConfigParams();
            thirdParam.setMediaType((String) myData.get("configParams_MediaType"));

            parentBody.setConfigParams(thirdParam);

            String payload = request.toJson(parentBody);

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Search Merchant payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the the Search Merchant payload.", e);
            throw new RuntimeException("error while creating the the Search Merchant payload.", e);
        }
    }

    public Response getResponseMerchantConfigList(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetMerchantConfigListPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.MMS_GetMerchantConfigList_EndPoint, request);
            Reporter.logReport(MMSComponent.class, log_Type_Pass, "Get Merchant Config List response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the Get Merchant Config List response.", e);
            throw new RuntimeException("error while creating the Get Merchant Config List response.", e);
        }

    }

    private String createGetMerchantConfigListPayload(HashMap myData) {

        try {

            GetMerchantConfigList getMerchantConfigList = new GetMerchantConfigList();
            getMerchantConfigList.setMid((String) myData.get("mid"));

            String payload = request.toJson(getMerchantConfigList);

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Merchant Config List payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while creating the the Get Merchant Config List payload.", e);
            throw new RuntimeException("error while creating the the Get Merchant Config List payload.", e);
        }
    }

    public void validateGetMerchantConfigListResponseBody(Response response, HashMap myData) {
        try {
            ResultSet resultSet = getMerchantConfigListDB(myData);
            String dbValueToJson = convertMerchantConfigListResultSetToJson(resultSet, myData);
            String responseBody = response.getBody().asString();

            ObjectMapper mapper = new ObjectMapper();

            Assert.assertEquals(mapper.readTree(dbValueToJson), mapper.readTree(responseBody), "Get Cards Merchant resonse body matches with DB");

            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "Get Cards Merchant response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while validating Get Merchant Config List response body.", e);
            throw new RuntimeException("error while validating Get Merchant Config List  response body.", e);
        }
    }

    private String convertMerchantConfigListResultSetToJson(ResultSet resultSet, HashMap myData) {
        String responsePayload = "";
        try {
            GetMerchantConfigListResponseEntity parentBody = new GetMerchantConfigListResponseEntity();
            parentBody.setStatus(status_Success);
            Gson dbRequest = new Gson();

            Data data = new Data();
            data.setMid((String) myData.get("mid"));

            ConfigValueList innerArray = new ConfigValueList();
            ArrayList<ConfigValueList> tempList = new ArrayList<ConfigValueList>();

            while (resultSet.next()) {
                ConfigValueList merchantConfigList = new ConfigValueList();
                int nId = resultSet.getInt("ID");
                String strKey = resultSet.getString("KEY");
                String strValue = resultSet.getString("VALUE");
                merchantConfigList.setId(nId);
                merchantConfigList.setKey(strKey);
                merchantConfigList.setValue(strValue);
                tempList.add(merchantConfigList);
            }

            data.setConfigValues(tempList);
            parentBody.setData(data);
            responsePayload = dbRequest.toJson(parentBody);

        } catch (Exception e) {
            throw new RuntimeException("error while converting db values into json.", e);
        }
        return responsePayload;
    }

    private ResultSet getMerchantConfigListDB(HashMap myData) {

        ResultSet resultSet;
        String query;
        try {
            query = "select id,key,value from MERCHANT_CONFIG_LIST where Merchant_id=(Select MERCHANT_ID from Merchant where MID='" + (String) myData.get("mid") + "')";
            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(MMSComponent.class, log_Type_Pass,
                    "DB Value fetched for Get Merchant Config List", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(MMSComponent.class, log_Type_Fail, "error while fetching data from DB for Get Merchant Config List.", e);
            throw new RuntimeException("error while fetching data from DB for Get Merchant Config List.", e);
        }
    }
}
