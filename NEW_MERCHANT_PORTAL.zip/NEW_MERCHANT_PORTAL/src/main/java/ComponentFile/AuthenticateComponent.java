package ComponentFile;

import Utils.CommonMethods;
import Utils.CryptoUtil;
import Utils.Reporter;
import base.APIEndPoints;
import base.Constants;
import base.SetUp;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import entity.AuthenticateList;
import entity.MobileEntity;
import entity.User;
import entity.Validation;
import entity.authenticationEntity.AutheticateEntity;
import entity.authenticationEntity.ChangeCredentailsEntity;
import entity.authenticationEntity.GenerateOTPEntity;
import io.restassured.response.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static base.APIEndPoints.*;

public class AuthenticateComponent extends SetUp {
    Gson request = new Gson();
    CommonMethods commMethod = new CommonMethods();
    public AuthenticateComponent() {

    }

    public String createOTPPayload(HashMap myData) {
        try {
            GenerateOTPEntity genOTPEntity = new GenerateOTPEntity();
            User user = new User();
            AuthenticateList authList = new AuthenticateList();
            String type = (String) myData.get("TestdataType");
            if ("OTP_Using_Mobile".equals(type)) {
                MobileEntity mobileEntity = new MobileEntity();
                mobileEntity.setCountryCode((String) myData.get("countryCode"));
                mobileEntity.setNumber((String) myData.get("mobileNumber"));

                user.setMobile(mobileEntity);
            } else if ("OTP_Using_UserId".equals(type)) {
                user.setBankuserId((String) myData.get("userId"));
            }

            genOTPEntity.setUser(user);
            authList.setAction((String) myData.get("Authentication_action"));
            authList.setMode((String) myData.get("Authentication_mode"));
            authList.setValue("");

            ArrayList<AuthenticateList> tempList = new ArrayList<AuthenticateList>();
            tempList.add(authList);
            genOTPEntity.setAuthenticateList(tempList);

            genOTPEntity.setScope((String) myData.get("Scope"));

            String payload = request.toJson(genOTPEntity);


            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass,
                    "Generate OTP payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate OTP payload.", e);
            throw new RuntimeException("error while creating the Generate OTP payload.", e);
        }

    }

    public Response getResponseGenOTP(HashMap myData) {

        try {
            Response response = null;
            String payload = createOTPPayload(myData);
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            //request.put("x-channel-id", "3133");
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));

            response = RestUtil.postByJson(payload, APIEndPoints.Authenticate_EndPoint, request);
            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass, "Generate OTP response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate OTP response.", e);
            throw new RuntimeException("error while creating the Generate OTP response.", e);
        }
    }

    public String createAutheticationPayloadWithAES(HashMap myData) {
        try {
            AutheticateEntity autheticateEntity = new AutheticateEntity();
            User user = new User();
            AuthenticateList authList = new AuthenticateList();
            MobileEntity mobileEntity = new MobileEntity();

            if((String) myData.get("userId")!=""){user.setBankuserId((String) myData.get("userId"));}
            if((String) myData.get("countryCode")!=""){mobileEntity.setCountryCode((String) myData.get("countryCode"));}
            if((String) myData.get("mobileNumber")!=""){ mobileEntity.setNumber((String) myData.get("mobileNumber"));}
            user.setMobile(mobileEntity);
            if((String) myData.get("emailAddress")!=""){user.setEmailAddress((String) myData.get("emailAddress"));}
            autheticateEntity.setUser(user);

            if((String) myData.get("Authentication_action")!=""){authList.setAction((String) myData.get("Authentication_action"));}
            if((String) myData.get("Authentication_mode")!=""){authList.setMode((String) myData.get("Authentication_mode"));}
            if((String) myData.get("Authentication_value")!="")
            {
                authList.setValue(CryptoUtil.encryptAES((String) myData.get("Authentication_value"), AES_Key, "AES/ECB/PKCS5PADDING"));
            }

            ArrayList<AuthenticateList> tempAuthList = new ArrayList<AuthenticateList>();
            tempAuthList.add(authList);
            autheticateEntity.setAuthenticateList(tempAuthList);

            if((String) myData.get("Scope")!=""){autheticateEntity.setScope((String) myData.get("Scope"));}
            if((String) myData.get("EncryptionKey")!=""){autheticateEntity.setEncryptionKey(CryptoUtil.encryptRSA((String) myData.get("EncryptionKey"), public_key, "RSA/ECB/PKCS1PADDING"));}

            String payload = request.toJson(autheticateEntity);

            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass,
                    "Generate authetication payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate authetication payload.", e);
            throw new RuntimeException("error while creating the Generate authetication payload.", e);
        }
    }

    public String createAutheticationPayload(HashMap myData) {
        try {
            AutheticateEntity autheticateEntity = new AutheticateEntity();
            User user = new User();
            AuthenticateList authList = new AuthenticateList();
            MobileEntity mobileEntity = new MobileEntity();

            if((String) myData.get("userId")!=""){user.setBankuserId((String) myData.get("userId"));}
            if((String) myData.get("countryCode")!=""){mobileEntity.setCountryCode((String) myData.get("countryCode"));}
            if((String) myData.get("mobileNumber")!=""){ mobileEntity.setNumber((String) myData.get("mobileNumber"));}
            user.setMobile(mobileEntity);
            if((String) myData.get("emailAddress")!=""){user.setEmailAddress((String) myData.get("emailAddress"));}
            autheticateEntity.setUser(user);

            if((String) myData.get("Authentication_action")!=""){authList.setAction((String) myData.get("Authentication_action"));}
            if((String) myData.get("Authentication_mode")!=""){authList.setMode((String) myData.get("Authentication_mode"));}
            if((String) myData.get("Authentication_value")!="")
            {
                authList.setValue((String) myData.get("Authentication_value"));
            }

            ArrayList<AuthenticateList> tempAuthList = new ArrayList<AuthenticateList>();
            tempAuthList.add(authList);
            autheticateEntity.setAuthenticateList(tempAuthList);

            if((String) myData.get("Scope")!=""){autheticateEntity.setScope((String) myData.get("Scope"));}
            if((String) myData.get("EncryptionKey")!=""){autheticateEntity.setEncryptionKey((String) myData.get("EncryptionKey"));}

            String payload = request.toJson(autheticateEntity);

            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass,
                    "Generate authetication payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate authetication payload.", e);
            throw new RuntimeException("error while creating the Generate authetication payload.", e);
        }
    }

    public Response getResponseAuthenticate(HashMap myData) {

        try {
            Response response = null;
            String payload = createAutheticationPayload(myData);
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));

            response = RestUtil.postByJson(payload, APIEndPoints.Authenticate_EndPoint, request);
            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass, "Generate authenticate response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate authenticate response.", e);
            throw new RuntimeException("error while creating the Generate OTP response.", e);
        }
    }

    public Response getResponseChangeCredential(HashMap myData) {

        try {
            Response response = null;
            String payload = createChangeCredentialPayload(myData,"","Change Credential");
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));

            response = RestUtil.postByJson(payload, APIEndPoints.Authenticate_ChangeCredential_EndPoint, request);
            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass, "Generate change credentials response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the change credentials authenticate response.", e);
            throw new RuntimeException("error while creating the change credentials OTP response.", e);
        }
    }

    public String createChangeCredentialPayloadWithAES(HashMap myData, String otpRecieved,String executionMessage) {
        try {
            ChangeCredentailsEntity changeCredentailsEntity = new ChangeCredentailsEntity();
            User user = new User();
            Validation validation = new Validation();
            MobileEntity mobileEntity = new MobileEntity();

            if((String) myData.get("userId")!=""){user.setBankuserId((String) myData.get("userId"));}
            if((String) myData.get("mobileNumber")!=""){mobileEntity.setNumber((String) myData.get("mobileNumber"));}
            if((String) myData.get("countryCode")!=""){mobileEntity.setCountryCode((String) myData.get("countryCode"));}
            user.setMobile(mobileEntity);

            if((String) myData.get("emailAddress")!=""){user.setEmailAddress((String) myData.get("emailAddress"));}
            changeCredentailsEntity.setUser(user);


            if((String) myData.get("Validation_type")!=""){validation.setType(Integer.parseInt(myData.get("Validation_type").toString()));}
            if((String) myData.get("Validation_dateOfBirth")!=""){validation.setDateOfBirth((String) myData.get("Validation_dateOfBirth"));}
            if(otpRecieved!=""){validation.setOtp(otpRecieved);}

            changeCredentailsEntity.setValidation(validation);

            if((String) myData.get("CredentialType")!=""){changeCredentailsEntity.setCredentialType(Integer.parseInt(myData.get("CredentialType").toString()));}
            if((String) myData.get("credentialValue")!=""){
                changeCredentailsEntity.setCredentialValue(CryptoUtil.encryptAES((String) myData.get("credentialValue"), AES_Key, "AES/ECB/PKCS5PADDING"));}
            if((String) myData.get("credentialValue2")!=""){
                changeCredentailsEntity.setOldCredentialValue(CryptoUtil.encryptAES((String) myData.get("credentialValue2"), AES_Key, "AES/ECB/PKCS5PADDING"));}
            if((String) myData.get("EncryptionKey")!=""){
                changeCredentailsEntity.setEncryptionKey(CryptoUtil.encryptRSA((String) myData.get("EncryptionKey"), public_key, "RSA/ECB/PKCS1PADDING"));}

            String payload = request.toJson(changeCredentailsEntity);

            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass,
                    "Generate "+executionMessage+" payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate "+executionMessage+" payload.", e);
            throw new RuntimeException("error while creating the Generate "+executionMessage+" payload.", e);
        }
    }

    public String createChangeCredentialPayload(HashMap myData, String otpRecieved,String executionMessage) {
        try {
            ChangeCredentailsEntity changeCredentailsEntity = new ChangeCredentailsEntity();
            User user = new User();
            Validation validation = new Validation();
            MobileEntity mobileEntity = new MobileEntity();

            if((String) myData.get("userId")!=""){user.setBankuserId((String) myData.get("userId"));}
            if((String) myData.get("mobileNumber")!=""){mobileEntity.setNumber((String) myData.get("mobileNumber"));}
            if((String) myData.get("countryCode")!=""){mobileEntity.setCountryCode((String) myData.get("countryCode"));}
            user.setMobile(mobileEntity);

            if((String) myData.get("emailAddress")!=""){user.setEmailAddress((String) myData.get("emailAddress"));}
            changeCredentailsEntity.setUser(user);


            if((String) myData.get("Validation_type")!=""){validation.setType(Integer.parseInt(myData.get("Validation_type").toString()));}
            if((String) myData.get("Validation_dateOfBirth")!=""){validation.setDateOfBirth((String) myData.get("Validation_dateOfBirth"));}
            if(otpRecieved!=""){validation.setOtp(otpRecieved);}

            changeCredentailsEntity.setValidation(validation);

            if((String) myData.get("CredentialType")!=""){changeCredentailsEntity.setCredentialType(Integer.parseInt(myData.get("CredentialType").toString()));}

            if(executionMessage.equalsIgnoreCase("Change Credential"))
            {
                if((String) myData.get("credentialValue")!=""){
                    changeCredentailsEntity.setCredentialValue((String) myData.get("credentialValue2"));}
                if((String) myData.get("credentialValue2")!=""){
                    changeCredentailsEntity.setOldCredentialValue((String) myData.get("credentialValue"));}
            }
            else  // code for reset credential
            {
                if((String) myData.get("credentialValue")!=""){
                    changeCredentailsEntity.setCredentialValue((String) myData.get("credentialValue"));}
            }


            if((String) myData.get("EncryptionKey")!=""){
                changeCredentailsEntity.setEncryptionKey((String) myData.get("EncryptionKey"));}

            String payload = request.toJson(changeCredentailsEntity);

            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass,
                    "Generate "+executionMessage+" payload has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Generate "+executionMessage+" payload.", e);
            throw new RuntimeException("error while creating the Generate "+executionMessage+" payload.", e);
        }
    }

    public Response getResponseResetCredential(HashMap myData, String otpRecieved) {

        try {
            Response response = null;
            String payload = createChangeCredentialPayload(myData,otpRecieved,"Reset Credential");
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));

            response = RestUtil.postByJson(payload, APIEndPoints.Authenticate_ResetCredential_EndPoint, request);
            Reporter.logReport(AuthenticateComponent.class, log_Type_Pass, "Generate Reset credentials response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(AuthenticateComponent.class, log_Type_Fail, "error while creating the Reset credentials authenticate response.", e);
            throw new RuntimeException("error while creating the Reset credentials OTP response.", e);
        }
    }



    public String TestGenerateOTPAPI(HashMap myData)
    {
        String schemaPath = responseSchemaFolderPath + "//Authentication//GetOTPResponse.json";
        String otpRecieved="";
        Response response = getResponseGenOTP(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response,schemaPath);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
        otpRecieved=commMethod.validateIdamOTP((String) myData.get("mobileNumber"));
        return otpRecieved;
    }

    public void TestResetCredsAPI(HashMap myData, String otpRecieved)
    {
        String schemaPath = responseSchemaFolderPath + "//Authentication//ChangeCredentialResponse.json";
        Response response = getResponseResetCredential(myData,otpRecieved);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response,schemaPath);
        commMethod.validateResponseStatusMessage(response,status_Success);
    }

    public void TestChangeCredsAPI(HashMap myData)
    {
        String schemaPath = responseSchemaFolderPath + "//Authentication//ChangeCredentialResponse.json";
        Response response = getResponseChangeCredential(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response,schemaPath);
        commMethod.validateResponseStatusMessage(response, Constants.status_Success);
    }

    public void TestAuthenticationAPI(HashMap myData)
    {
        String schemaPath = responseSchemaFolderPath + "//Authentication//AuthenticateResponse.json";
        Response response = getResponseAuthenticate(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response,schemaPath);
        commMethod.validateResponseStatusMessage(response,status_Initiated);
    }
}
