package ComponentFile;

import ResponseEntity.*;
import ResponseEntity.TransactionResponseEntity.GetSettlementsFileResponseEntity;
import ResponseEntity.TransactionResponseEntity.GetSettlementsResponseEntity;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.ConfigParams;
import entity.InputFiler;
import entity.InputFilter;
import entity.TransactionEntity.GetTransactionEntity;
import io.restassured.response.Response;
import org.openqa.selenium.remote.server.handler.DeleteSession;
import org.testng.Assert;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.*;

public class TransactionsComponent extends SetUp {

    Gson request = new Gson();
    CommonMethods commMethod;
    public static String strFile = "";

    public void transactionsComponent() {
        commMethod = new CommonMethods();
    }


    public Response getResponseGetTransations(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetTransactionsPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            //  request.put("Content-Length", (String) myData.get("Content-Length"));
            // request.put("Host", (String) myData.get("Host"));
            request.put("Accept", (String) myData.get("Accept"));
            request.put("Connection", (String) myData.get("Connection"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-Key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            //request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Transaction_GetTransaction_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Get Transaction response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get Transaction response.", e);
            throw new RuntimeException("error while creating the Get Transaction response.", e);
        }
    }

    private String createGetTransactionsPayload(HashMap myData) {
        try {
            GetTransactionEntity parent = new GetTransactionEntity();
            InputFiler inputFiler = new InputFiler();

            if ((String) myData.get("merchantId") != "") {
                inputFiler.setMerchantId((String) myData.get("merchantId"));
            }
            if ((String) myData.get("responseType") != "") {
                inputFiler.setResponseType((String) myData.get("responseType"));
            }
            if ((String) myData.get("startDateTime") != "") {
                inputFiler.setStartDateTime((String) myData.get("startDateTime"));
            }
            if ((String) myData.get("endDateTime") != "") {
                inputFiler.setEndDateTime((String) myData.get("endDateTime"));
            }
            if ((String) myData.get("paymentMethods") != "") {
                String strTemp = (String) myData.get("paymentMethods");
                String[] arrTemp = strTemp.split("%%");
                List<String> paymentMethods = Arrays.asList(arrTemp);
                inputFiler.setPaymentMethods(paymentMethods);
            }
            if ((String) myData.get("transactionStatus") != "") {
                String strTemp = (String) myData.get("transactionStatus");
                String[] arrTemp = strTemp.split("%%");
                List<String> transactionStatus = Arrays.asList(arrTemp);
                inputFiler.setTransactionStatus(transactionStatus);
            }
            if ((String) myData.get("minTransactionAmount") != "") {
                inputFiler.setMinTransactionAmount(Double.parseDouble(myData.get("minTransactionAmount").toString()));
            }
            if ((String) myData.get("maxTransactionAmount") != "") {
                inputFiler.setMaxTransactionAmount((Double.parseDouble(myData.get("maxTransactionAmount").toString())));
            }
            if ((String) myData.get("transactionType") != "") {
                inputFiler.setTransactionType((String) myData.get("transactionType"));
            }
            parent.setInputFiler(inputFiler);

            ConfigParams configParam = new ConfigParams();
            if ((String) myData.get("Config_page") != "") {
                configParam.setPage(Integer.parseInt(myData.get("Config_page").toString()));
            }
            if ((String) myData.get("Config_size") != "") {
                configParam.setSize(Integer.parseInt(myData.get("Config_size").toString()));
            }
            if ((String) myData.get("Config_sortColumn") != "") {
                configParam.setSortColumn((String) myData.get("Config_sortColumn"));
            }
            if ((String) myData.get("Config_sortType") != "") {
                configParam.setSortType((String) myData.get("Config_sortType"));
            }
            if ((String) myData.get("Config_mediaType") != "") {
                configParam.setMediaType((String) myData.get("Config_mediaType"));
            }
            parent.setConfigParams(configParam);

            String strTemp = (String) myData.get("outputDomains");
            if (strTemp != "") {
                String[] arrTemp = strTemp.split("%%");
                List<String> outputDomain = Arrays.asList(arrTemp);
                parent.setOutputDomains(outputDomain);
            }

            String payload = request.toJson(parent);
            System.out.println(payload);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "Get Transaction has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the the Get Transaction payload.", e);
            throw new RuntimeException("error while creating the the Get Transaction payload.", e);
        }

    }

    public String getTransactionSchemaPath(String testdataType) {
        String schemaPath = responseSchemaFolderPath + "//Transactions//";

        try {

            switch ( testdataType ) {
                //Case statements
                case "ALL_TRANSACTION":
                    schemaPath = schemaPath + "Transaction_responseType_ALL.json";
                    break;
                case "DEFAULT_TRANSACTION":
                    schemaPath = schemaPath + "Transaction_responseType_Default.json";
                    break;
                case "ALL_REFUND":
                    schemaPath = schemaPath + "Refund_responseType_ALL.json";
                    break;
                case "DEFAULT_REFUND":
                    schemaPath = schemaPath + "Refund_responseType_Default.json";
                    break;
                case "ALL_SETTLEMENT":
                    schemaPath = schemaPath + "Settlement_responseType_ALL.json";
                    break;
                case "DEFAULT_SETTLEMENT":
                    schemaPath = schemaPath + "Settlement_responseType_Default.json";
                    break;
                case "CUSTOM_TRANSACTION":
                    schemaPath = schemaPath + "responseType_Custom.json";
                    break;
                case "CUSTOM_REFUND":
                    schemaPath = schemaPath + "responseType_Custom.json";
                    break;
                case "CUSTOM_SETTLEMENT":
                    schemaPath = schemaPath + "responseType_Custom.json";
                    break;
            }
        } catch (Exception e) {
            throw new RuntimeException("error while generating Schema path.", e);
        }
        return schemaPath;
    }

    public Response getResponseGetTransationById(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetTransactionsPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            //  request.put("Content-Length", (String) myData.get("Content-Length"));
            // request.put("Host", (String) myData.get("Host"));
            request.put("Accept", (String) myData.get("Accept"));
            request.put("Connection", (String) myData.get("Connection"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-Key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            //request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Transaction_GetTransactionById_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Get Transaction by Id response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get Transaction by Id response.", e);
            throw new RuntimeException("error while creating the Get Transaction by Id response.", e);
        }
    }

    public Response getResponseGetRefunds(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetTransactionsPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            //  request.put("Content-Length", (String) myData.get("Content-Length"));
            // request.put("Host", (String) myData.get("Host"));
            request.put("Accept", (String) myData.get("Accept"));
            request.put("Connection", (String) myData.get("Connection"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-Key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            //request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Transaction_GetTransaction_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Get Refunds response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get refund response.", e);
            throw new RuntimeException("error while creating the Get refund response.", e);
        }
    }

    public Response getResponseGetRefundById(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetTransactionsPayload(myData);

            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            //  request.put("Content-Length", (String) myData.get("Content-Length"));
            // request.put("Host", (String) myData.get("Host"));
            request.put("Accept", (String) myData.get("Accept"));
            request.put("Connection", (String) myData.get("Connection"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-Key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            //request.put("x-device-info", (String) myData.get("x-device-info"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Transaction_GetTransactionById_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Get Refund by Id response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get Refund by Id response.", e);
            throw new RuntimeException("error while creating the Get Refund by Id response.", e);
        }
    }

    public Response getResponseGetSettlements(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetSettlementsPayload(myData);
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Settlement_GetSettlements_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Get Settlement response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get Settlement response.", e);
            throw new RuntimeException("error while creating the Get Settlement response.", e);
        }
    }

    private String createGetSettlementsPayload(HashMap myData) {
        try {
            GetTransactionEntity parent = new GetTransactionEntity();
            InputFilter inputFilter = new InputFilter();

            if ((String) myData.get("merchantId") != "") {
                inputFilter.setMerchantId((String) myData.get("merchantId"));
            }
            if ((String) myData.get("startDateTime") != "") {
                inputFilter.setStartDateTime((String) myData.get("startDateTime"));
            }
            if ((String) myData.get("endDateTime") != "") {
                inputFilter.setEndDateTime((String) myData.get("endDateTime"));
            }
            parent.setInputFilter(inputFilter);

            ConfigParams configParam = new ConfigParams();
            if ((String) myData.get("Config_page") != "") {
                configParam.setPage(Integer.parseInt(myData.get("Config_page").toString()));
            }
            if ((String) myData.get("Config_size") != "") {
                configParam.setSize(Integer.parseInt(myData.get("Config_size").toString()));
            }
            // parent.setConfigParams(configParam);

            String payload = request.toJson(parent);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "Get Settlement has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the the Get Settlement payload.", e);
            throw new RuntimeException("error while creating the the Get Settlement payload.", e);
        }

    }


    public Response getResponseGenerateSettlementReport(HashMap myData) {
        try {
            Response response = null;
            String payload = createGetSettlementsPayload(myData);
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.postByJson(payload, APIEndPoints.Settlement_GenerateSettlementReport_EndPoint, request);

            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Generate Settlement report response created :" + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Generate Settlement report response.", e);
            throw new RuntimeException("error while creating the Generate Settlement report response.", e);
        }
    }

    public Response getResponseGetSettlementFile(HashMap myData, String strFile, String extension, String TestDataType) {
        try {
            if (myData.containsKey(TestDataType)) {
                Set<Map.Entry<String, String>> entry = myData.entrySet();
                for (Map.Entry<String, String> dataSet : entry) {
                    if (dataSet.getKey().equals(TestDataType)) {
                        myData.put(TestDataType, "");
                    }
                }
            }
            System.out.println("strFile =" + strFile);
            Response response = null;
            String payload = createGetSettlementFilePayload(myData, TestDataType);
            Map<String, String> request = new HashMap<String, String>();

            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("x-api-Key", (String) myData.get("x-api-key"));
            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-access-token", (String) myData.get("x-access-token"));
            request.put("x-jwt-token", (String) myData.get("x-jwt-token"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            String strEndPoint = APIEndPoints.Settlement_GetSettlementsFile_EndPoint.concat(strFile + "." + extension);
            System.out.println(strEndPoint);
            response = RestUtil.postByJson(payload, strEndPoint, request);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass, "Download settlement file response created." + response.prettyPrint(), null);
            return response;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Download settlement file response.", e);
            throw new RuntimeException("error while creating the Download Settlement file response.", e);
        }

    }

    private String createGetSettlementFilePayload(HashMap myData, String attribute) {
        try {
            GetTransactionEntity parent = new GetTransactionEntity();
            InputFilter inputFilter = new InputFilter();
            if (attribute.equalsIgnoreCase("merchant_Id")) {
                inputFilter.setMerchantId((String) ((String) myData.get("merchantId")).concat("&&&"));
            } else {
                inputFilter.setMerchantId((String) myData.get("merchantId"));
            }
            parent.setInputFilter(inputFilter);
            String payload = request.toJson(parent);
            System.out.println(payload);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "Get Settlement file has been created. Payload : " + payload, null);
            return payload;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while creating the Get Settlement file payload.", e);
            throw new RuntimeException("error while creating the Get Settlement file payload.", e);
        }
    }

    private ResultSet getSettlementsDB(HashMap myData) {
        ResultSet resultSet;
        String query;
        try {
            //logic need to be implemented to convert startDateTime and endDateTime from miliseconds to db format.
            //need to update query in where clause.
            query = "select REPORT_GENERATED_AT, SETTLED_TXN_COUNT,SETTLED_TXN_AMOUNT,REFUND_COUNT ,REFUND_AMOUNT,NET_SETTLEMENT_AMOUNT,\n" +
                    "SETTLEMENT_REF_NUMBER,GENERATED_FILE_NAME from settlement_summary where MERCHANT_ID ='" + (String) myData.get("merchantId") + "'";
            System.out.println(query);
            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "DB Value fetched for get Settlements for merchants", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while fetching data from DB for get Settlements for merchants.", e);
            throw new RuntimeException("error while fetching data from DB for get Settlements for merchants", e);
        }
    }

    private ResultSet getSettlementsReportDB(HashMap myData) {
        ResultSet resultSet;
        String query;
        try {
            //logic need to be implemented to convert startDateTime and endDateTime from miliseconds to db format.
            //need to update query in where clause.
            query = "select REPORT_GENERATED_AT, SETTLED_TXN_COUNT,SETTLED_TXN_AMOUNT,REFUND_COUNT ,REFUND_AMOUNT,NET_SETTLEMENT_AMOUNT,\n" +
                    "SETTLEMENT_REF_NUMBER,GENERATED_FILE_NAME from settlement_summary where MERCHANT_ID ='" + (String) myData.get("merchantId") + "' ORDER BY REPORT_GENERATED_AT desc FETCH FIRST 1 ROWS ONLY";
            System.out.println(query);
            resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "DB Value fetched for generate settlement report for merchants", null);
            return resultSet;
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while fetching data from DB for generate settlement report for merchants.", e);
            throw new RuntimeException("error while fetching data from DB for generate settlement report for merchants", e);
        }
    }

    private String convertGetSettlementsResultSetToJson(ResultSet resultSet, HashMap myData, Response response) {
        String responsePayload = "";
        try {
            Gson dbRequest = new Gson();
            GetSettlementsResponseEntity parentBody = new GetSettlementsResponseEntity();
            parentBody.setStatus(status_Success);
            parentBody.setTimeStamp(CommonMethods.getValueFromResponse(response, "timeStamp"));
            ResponseEntity.Data data = new ResponseEntity.Data();
            Page page = new Page();
            resultSet.last();
            int totalElements = resultSet.getRow();
            int size = Integer.parseInt(myData.get("Config_size").toString());
            page.setSize(size);
            page.setTotalElements(totalElements);
            int totalPage = (totalElements - 1) / size;
            //page.setTotalPages(totalPage);
            page.setTotalPages(32);
            page.setNumber(Integer.parseInt(myData.get("Config_page").toString()));
            data.setPage(page);

            ArrayList<Settlement> content = new ArrayList<Settlement>();
            resultSet.beforeFirst();

            while (resultSet.next()) {
                Settlement settlement = new Settlement();
                String settlementDate = resultSet.getString("REPORT_GENERATED_AT");
                int settledTransactionCount = resultSet.getInt("SETTLED_TXN_COUNT");
                double settledTransactionAmount = resultSet.getDouble("SETTLED_TXN_AMOUNT");
                int refundCount = resultSet.getInt("REFUND_COUNT");
                double refundAmount = resultSet.getDouble("REFUND_AMOUNT");
                double settlementAmount = resultSet.getDouble("NET_SETTLEMENT_AMOUNT");
                String settlementReferenceNumber = resultSet.getString("SETTLEMENT_REF_NUMBER");
                String fileName = resultSet.getString("GENERATED_FILE_NAME");
                if(settlementDate.contains(".")) {
                    settlement.setSettlementDate(settlementDate.substring(0, settlementDate.lastIndexOf(".")));
                }else
                {
                    settlement.setSettlementDate(settlementDate);
                }
                settlement.setSettledTransactionCount(settledTransactionCount);
                settlement.setSettledTransactionAmount(settledTransactionAmount);
                settlement.setRefundCount(refundCount);
                settlement.setRefundAmount(refundAmount);
                DecimalFormat dec = new DecimalFormat("#0.00");
                settlement.setSettlementAmount(Double.parseDouble(dec.format(settlementAmount)));
                settlement.setSettlementReferenceNumber(settlementReferenceNumber);
                settlement.setFileName(fileName);
                content.add(settlement);
            }
            data.setContent(content);
            parentBody.setData(data);
            responsePayload = dbRequest.toJson(parentBody);
        } catch (Exception e) {
            throw new RuntimeException("error while converting db values into json.", e);
        }
        return responsePayload;
    }

    public void validateGetSettlementsResponseBody(Response response, HashMap myData) {
        try {
            ResultSet resultSet = getSettlementsDB(myData);
            String dbValueToJson = convertGetSettlementsResultSetToJson(resultSet, myData, response);
            String responseBody = response.getBody().asString();

            ObjectMapper mapper = new ObjectMapper();
            Assert.assertEquals(mapper.readTree(dbValueToJson), mapper.readTree(responseBody), "Get Settlements resonse body matches with DB");
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "Get Settlements response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while validating Settlements response body.", e);
            throw new RuntimeException("error while validating Get Settlements response body.", e);
        }
    }

    public void validateGenerateSettlementReportResponseBody(Response response, HashMap myData) {
        try {
            ResultSet resultSet = getSettlementsReportDB(myData);
            String dbValueToJson = convertGenerateSettlementReportResultSetToJson(resultSet, response);
            String responseBody = response.getBody().asString();

            ObjectMapper mapper = new ObjectMapper();
            Assert.assertEquals(mapper.readTree(dbValueToJson), mapper.readTree(responseBody), "Get Settlements resonse body matches with DB");
            Reporter.logReport(TransactionsComponent.class, log_Type_Pass,
                    "Generate Settlement report response body matches with DB", null);
        } catch (Exception e) {
            Reporter.logReport(TransactionsComponent.class, log_Type_Fail, "error while validating Settlements response body.", e);
            throw new RuntimeException("error while validating Get Settlements response body.", e);
        }
    }

    private String convertGenerateSettlementReportResultSetToJson(ResultSet resultSet, Response response) {
        String responsePayload = "";
        try {
            Gson dbRequest = new Gson();
            GetSettlementsFileResponseEntity parentBody = new GetSettlementsFileResponseEntity();
            parentBody.setStatus(status_Success);
            parentBody.setTimeStamp(CommonMethods.getValueFromResponse(response, "timeStamp"));
            ResponseEntity.TransactionResponseEntity.Data data = new ResponseEntity.TransactionResponseEntity.Data();
            while (resultSet.next()) {
                String settlementDate = resultSet.getString("REPORT_GENERATED_AT");
                int settledTransactionCount = resultSet.getInt("SETTLED_TXN_COUNT");
                double settledTransactionAmount = resultSet.getDouble("SETTLED_TXN_AMOUNT");
                int refundCount = resultSet.getInt("REFUND_COUNT");
                double refundAmount = resultSet.getDouble("REFUND_AMOUNT");

                double settlementAmount = resultSet.getDouble("NET_SETTLEMENT_AMOUNT");
                String settlementReferenceNumber = resultSet.getString("SETTLEMENT_REF_NUMBER");

                String fileName = resultSet.getString("GENERATED_FILE_NAME");


                data.setSettlementDate(settlementDate.substring(0, settlementDate.lastIndexOf(".")));
                data.setSettledTransactionCount(settledTransactionCount);
                data.setSettledTransactionAmount(settledTransactionAmount);
                data.setRefundCount(refundCount);
                data.setRefundAmount(refundAmount);
                DecimalFormat dec = new DecimalFormat("#0.00");
                data.setSettlementAmount(Double.parseDouble(dec.format(settlementAmount)));
                data.setSettlementReferenceNumber(settlementReferenceNumber);
                data.setFileName(fileName);
            }
            parentBody.setData(data);
            responsePayload = dbRequest.toJson(parentBody);
        } catch (Exception e) {
            throw new RuntimeException("error while converting db values into json.", e);
        }
        return responsePayload;
    }
}

