package ComponentFile;

import ResponseEntity.CardsMerchantDataList;
import ResponseEntity.ConfigResponseEntity;
import ResponseEntity.ConfigValueList;
import ResponseEntity.MMSResponseEntity.GetCardsMerchantResponseEntity;
import ResponseEntity.MMSResponseEntity.GetConfigResponseEntity;
import ResponseEntity.MMSResponseEntity.GetMerchantConfigListResponseEntity;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.SetUp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.utilities.apiUtils.RestUtil;
import com.utilities.connectionUtils.DataBaseUtility;
import entity.ConfigParams;
import entity.Data;
import entity.InputFilter;
import entity.MMSEntity.*;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import java.sql.ResultSet;
import java.util.*;

public class GSTComponent extends SetUp {
    Gson request = new Gson();
    CommonMethods commMethod;
    public static String strYear="",strMonth="",strFile="";
    public GSTComponent() {
        commMethod = new CommonMethods();
    }



    public Response getResponseGSTInvoices(HashMap myData) {
        try
        {
            Response response = null;

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            String strEndPoint = APIEndPoints.GST_GetGSTInvoices_EndPoint.concat((String) myData.get("mid")+"?year="+(String) myData.get("year"));
            response = RestUtil.getByUrl(strEndPoint, request);

            String strTest=(String) myData.get("TestDescription");
            if((strTest.equalsIgnoreCase("With Proper Data"))||(String) myData.get("TestdataType")!="")
            {
                JSONObject obj = new JSONObject(response.prettyPrint());
                JSONArray arr = obj.getJSONArray("invoices");
                for (int count = 0; count < arr.length(); count++) {
                    strFile = arr.getJSONObject(count).getString("file");
                    System.out.println(strFile);
                }
            }
            Reporter.logReport(GSTComponent.class, log_Type_Pass, "GET GST Invoices response created :" + response.prettyPrint(), null);
            return response;
        }
        catch (Exception e)
        {
            Reporter.logReport(GSTComponent.class, log_Type_Fail, "error while creating the GET GST Invoices response.", e);
            throw new RuntimeException("error while creating the GET GST Invoices response.", e);
        }
    }


    public Response getResponseColumns(HashMap myData) {
        try
        {
            Response response = null;

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));

            response = RestUtil.getByUrl(APIEndPoints.GST_GetColumns_EndPoint, request);
            Reporter.logReport(GSTComponent.class, log_Type_Pass, "GET Columns response created :" + response.prettyPrint(), null);
            return response;
        }
        catch (Exception e) {
            Reporter.logReport(GSTComponent.class, log_Type_Fail, "error while creating the GET Columns response.", e);
            throw new RuntimeException("error while creating the GET Columns response.", e);
        }
    }

    public Response getResponseDownloadGSTInvoices(HashMap myData,String strFile,String strExtension,String header) {

        try
        {
            if(myData.containsKey(header)){
                Set<Map.Entry<String,String>> entry= myData.entrySet();
                for (Map.Entry<String,String> me: entry ) {
                    if (me.getKey().equals(header)) {
                        myData.put(header, "");
                    }
                }
            }
            if(header.equals("m_id"))
            {
                myData.put("mid", "##");
            }
            Response response = null;

            Map<String, String> request = new HashMap<String, String>();

            request.put("x-channel-id", (String) myData.get("x-channel-id"));
            request.put("x-api-key", (String) myData.get("x-api-key"));
            request.put("x-trace-id", (String) myData.get("x-trace-id"));
            request.put("Content-Type", (String) myData.get("Content-Type"));
            request.put("appIDToken",(String) myData.get("validationToken"));
            request.put("userIDToken",(String) myData.get("validationToken"));
            String strEndPoint="";

            if(strExtension!="")
                strEndPoint=APIEndPoints.GST_DownloadGSTInvoice_EndPoint.concat((String) myData.get("mid")+"/"+strFile+"."+strExtension);
            else
                strEndPoint=APIEndPoints.GST_DownloadGSTInvoice_EndPoint.concat((String) myData.get("mid")+"/"+strFile);
            response = RestUtil.getByUrl(strEndPoint, request);
            System.out.println(response.prettyPrint());
            Reporter.logReport(GSTComponent.class, log_Type_Pass, "Download GST Invoice response created." , null);
            return response;
        }
        catch (Exception e)
        {
            Reporter.logReport(GSTComponent.class, log_Type_Fail, "error while creating the Download GST Invoice response.", e);
            throw new RuntimeException("error while creating the Download GST Invoice response.", e);
        }
    }
}
