package Utils;

import ComponentFile.AuthenticateComponent;
import base.Constants;
import base.SetUp;
import com.utilities.connectionUtils.DataBaseUtility;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.Assert;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLOutput;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertThat;

public class CommonMethods extends SetUp {
    public void validateResponseStatusCode(Response response, String statusCode) {
        try {
            Assert.assertEquals(response.statusCode()+"", statusCode, "Response status code is equal to : " + statusCode);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response code matches with : " + statusCode, null);
        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response code mismatch actual : " + response.statusCode() + " , Expected : " + statusCode, e);
            throw new RuntimeException("error while validating response code.", e);
        }
    }

    public void validateResponseSchema(Response response, String schemaFilePath) {
        try {
            String responseBody = response.getBody().asString();
            File fTemp=new File(schemaFilePath);
            assertThat(responseBody, matchesJsonSchema(fTemp));
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response Schema matches", null);
        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response Schema mismatch ", e);
            throw new RuntimeException("Response Schema mismatch.", e);
        }
    }

    public void validateResponseStatusMessage(Response response, String statusValue) {
        try {
            JsonPath jsonPathEvaluator = response.jsonPath();
            String status = jsonPathEvaluator.get("status");
            Assert.assertEquals(status, statusValue, "Response Body Status Message is equal to : " + statusValue);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response Body Status Message matches : " + statusValue, null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response Body Status Message Mismatch ", e);
            throw new RuntimeException("Response Body Status Message Mismatch .", e);
        }
    }

    public void validateResponseFailureStatusNotPresent(Response response) {
        try {
            JsonPath jsonPathEvaluator = response.jsonPath();
            String status = jsonPathEvaluator.get("status");

            if(status == null)
            {
                Assert.assertEquals(true,true,"Status field is not available in response body");
                Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Status field is not available in response body ", null);
            }
            else
            {
                Assert.assertEquals(true,false,"Status field is available in response body");
                Reporter.logReport(CommonMethods.class, Constants.log_Type_Fail, "Status field is available in response body", null);
            }
        } catch (Exception e) {
            throw new RuntimeException("Status field is available in response body");
        }
    }

    public void validateResponseContainsMessage(Response response, String strMessage) {
        try {
            String responseBody = response.getBody().asString().toLowerCase();
            Assert.assertTrue(responseBody.contains(strMessage.toLowerCase()), "Response Body Message contain : " + strMessage);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response Body Message contain : " + strMessage, null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response Body Message does not contain : " + strMessage, e);
            throw new RuntimeException("Response Body Message does not contain : " + strMessage, e);
        }
    }

    public void validateResponseErrorCode(Response response, String errorCodeValue) {
        try {
            JsonPath jsonPathEvaluator = response.jsonPath();
            String code = jsonPathEvaluator.get("error.code");
            Assert.assertEquals(code, errorCodeValue, "Response Body Error code is equal to : " + errorCodeValue);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response Body Error code matches : " + errorCodeValue, null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response Body Error code Mismatch ", e);
            throw new RuntimeException("Response Body Error code Mismatch .", e);
        }
    }

    public void validateResponseErrorMessage(Response response, String errorMessageValue) {
        try {
            JsonPath jsonPathEvaluator = response.jsonPath();
            String message = jsonPathEvaluator.get("error.message");
            Assert.assertEquals(message, errorMessageValue, "Response Body Error Message is equal to : " + errorMessageValue);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "Response Body Error Message matches : " + errorMessageValue, null);

        } catch (Exception e) {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "Response Body Error Message Mismatch ", e);
            throw new RuntimeException("Response Body Error Message Mismatch .", e);
        }
    }

    public static String getValueFromResponse(Response response, String ReqParameter)
    {

        try {
            JsonPath jsonPathEvaluator = response.jsonPath();
            String actualValue = jsonPathEvaluator.get(ReqParameter);
            System.out.println(actualValue);
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "given parameter is available in response body ", null);
            return actualValue;
        }
        catch  (Exception e)
        {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "given parameter is not available in response body ", null);
            throw new RuntimeException("given parameter is not available in response body", null);
        }
    }

    public String validateIdamOTP (String number){
        String strOTP="";
        try
        {
            String query = "select time_stamp, TRANSACTIONID, EXTRACTVALUE(xmltype(transaction),'//*[local-name()=\"Value\"]') as OTP from log\n" +
                    "where interfaceID='JMIDAMSNotificationServices' and transactionid like'%OTP_+91" + number + "%' and transactiontype='Received'\n" +
                    "order by time_stamp desc";

            DataBaseUtility.createOracleDatabaseConnection("10.140.139.110", "1521", "tiborc", "tibcocle", "tibcocle");

            ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);
            try {
                if (resultSet != null && resultSet.next())
                    strOTP = resultSet.getString("OTP");
                else
                    throw new AssertionError("OTP not present in IDAM Database");
                resultSet.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            Assert.assertTrue(strOTP.length()==6, "OTP present in IDAM Database : "+strOTP );
            Reporter.logReport(CommonMethods.class, Constants.log_Type_Pass, "OTP present in IDAM Database : " + strOTP, null);
        }
        catch (Exception e)
        {
            Reporter.logReport(CommonMethods.class, log_Type_Fail, "OTP not present in IDAM Database !!!" , e);
            throw new RuntimeException("OTP not present in IDAM Database !!! ", e);
        }
        return strOTP;
    }

}
