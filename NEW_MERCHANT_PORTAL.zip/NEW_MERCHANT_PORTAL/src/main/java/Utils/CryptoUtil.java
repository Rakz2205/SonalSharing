package Utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class CryptoUtil {

    private transient static final Logger LOG = LoggerFactory.getLogger(CryptoUtil.class);

    public static String generateHash(String data) {
        String SHA256Hash = null;
        try {
            MessageDigest msgDigest = MessageDigest.getInstance("SHA-256");
            SHA256Hash = Base64.getEncoder().withoutPadding().encodeToString(msgDigest.digest(data.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException nsa) {
            LOG.info(nsa.getMessage());
        }
        return SHA256Hash;
    }

    public static long secureRandomGenerator(int length) {
        /*
        Generate a secure random number of given length, with the most significant digit not being 0
        */
        if (length > 18 || length < 1) {
            throw new IllegalArgumentException("Required length between 1 to 18, both inclusive.");
        }
        SecureRandom random = new SecureRandom();
        double d = random.nextDouble();
        int i = random.nextInt(9) + 1; // Ensure first digit is not 0 by generating random number from 0 - 8 and adding 1 to it.
        return (long) ((d + i) * Math.pow(10, length - 1));
    }

    public static String encryptAES(String plainData, String aesKey, String transformation) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        /*
        This function takes plain data, aes key, and a transformation string (ex. "AES/ECB/PKCS5PADDING")
        and returns a base 64 encoded encrypted data.
         */
        SecretKeySpec secretKey = new SecretKeySpec(aesKey.getBytes(StandardCharsets.UTF_8), "AES");
        LOG.info("EncryptionUtil -> getting and initializing Cipher instance");
        Cipher cipher = Cipher.getInstance(transformation);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        return Base64.getEncoder().encodeToString(cipher.doFinal(plainData.getBytes()));
    }

    public static String decryptAES(String encryptedData, String aesKey, String transformation) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        /*
        This function takes base 64 encoded encrypted data, aes key, and a transformation string (ex. "AES/ECB/PKCS5PADDING")
        and returns plain data.
         */
        SecretKeySpec secretKey = new SecretKeySpec(aesKey.getBytes(StandardCharsets.UTF_8), "AES");
        LOG.info("EncryptionUtil -> getting and initializing Cipher instance");
        Cipher cipher = Cipher.getInstance(transformation);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedData)));
    }

    public static String encryptRSA(String plainData, String base64PublicKey, String transformation) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeySpecException, BadPaddingException, IllegalBlockSizeException, InvalidKeyException {
        /*
        This function takes plain data, Base 64 encoded public key, and a transformation string (ex. "RSA/ECB/PKCS1Padding")
        and returns Base 64 encoded encrypted data.
         */
        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey));
        LOG.info("EncryptionUtil -> getting and initializing Cipher instance");
        Cipher cipher = Cipher.getInstance(transformation);
        PublicKey publicKey = getPublicKey(publicKeySpec);
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return Base64.getEncoder().encodeToString(cipher.doFinal(plainData.getBytes()));
    }

    public static String decryptRSA(String encryptedData, String base64PrivateKey, String transformation) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        /*
        This function takes Base 64 encoded encrypted data, Base 64 encoded private key, and a transformation string (ex. "RSA/ECB/PKCS1Padding")
        and returns plain data.
         */
        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey));
        LOG.info("EncryptionUtil -> getting and initializing Cipher instance");
        Cipher cipher = Cipher.getInstance(transformation);
        PrivateKey privateKey = getPrivateKey(privateKeySpec);
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedData)));
    }

    private static PublicKey getPublicKey(EncodedKeySpec publicKeySpec) throws NoSuchAlgorithmException, InvalidKeySpecException {
        LOG.info("EncryptionUtil -> getting PublicKey instance");
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(publicKeySpec);
    }

    private static PrivateKey getPrivateKey(EncodedKeySpec privateKeySpec) throws NoSuchAlgorithmException, InvalidKeySpecException {
        LOG.info("EncryptionUtil -> getting PrivateKey instance");
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(privateKeySpec);
    }

    public static String maskSensitiveValues(String strText) {

        if (strText == null || strText.equals(""))
            return "";
        int length = strText.length();
        int start = 0;
        int end = length / 2;
        char maskChar = '*';
        if (end > strText.length())
            end = strText.length();
        int maskLength = end - start;
        if (maskLength == 0)
            return strText;
        StringBuilder sbMaskString = new StringBuilder(maskLength);
        for (int i = 0; i < maskLength; i++) {
            sbMaskString.append(maskChar);
        }
        return strText.substring(0, start)
                + sbMaskString.toString()
                + strText.substring(start + maskLength);
    }

    public static String generateAesKey() {
        KeyGenerator gen = null;
        SecretKey secret = null;
        byte[] binary = null;
        String key = null;
        try {
            gen = KeyGenerator.getInstance("AES");
            secret = gen.generateKey();
            binary = secret.getEncoded();
            key = String.format("%032X", new BigInteger(+1, binary));
        } catch (Exception e) {
        }
        return key;
    }

    public static String getPublicKey() {
        String publicKey = "";
        String publicCertificatePath = System.getProperty("user.dir") +
                "//src//main//resources//Certificate//jpb_rsa_public_sit.pem";

        try (BufferedReader br = new BufferedReader(new FileReader(publicCertificatePath))) {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line);
                line = br.readLine();
            }
            publicKey = sb.toString();
            publicKey = publicKey.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return publicKey;
    }
}
