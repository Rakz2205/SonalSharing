package entity.TransactionEntity;

import entity.ConfigParams;
import entity.InputFiler;
import entity.InputFilter;

import java.util.List;

public class GetTransactionEntity
{
    private InputFiler inputFiler;
    private InputFilter inputFilter;
    private ConfigParams configParams;
    private List outputDomains;


    public InputFiler getInputFiler() {
        return inputFiler;
    }

    public GetTransactionEntity setInputFiler(InputFiler inputFiler) {
        this.inputFiler = inputFiler;
        return this;
    }

    public InputFilter getInputFilter() {
        return inputFilter;
    }

    public void setInputFilter(InputFilter inputFilter) {
        this.inputFilter = inputFilter;
    }

    public ConfigParams getConfigParams() {
        return configParams;
    }

    public GetTransactionEntity setConfigParams(ConfigParams configParams) {
        this.configParams = configParams;
        return this;
    }

    public List getOutputDomains() {
        return outputDomains;
    }

    public GetTransactionEntity setOutputDomains(List outputDomains) {
        this.outputDomains = outputDomains;
        return this;
    }
}
