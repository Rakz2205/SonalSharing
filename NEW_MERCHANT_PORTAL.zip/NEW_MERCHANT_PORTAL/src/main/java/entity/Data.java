package entity;

import ResponseEntity.CardsMerchantDataList;
import ResponseEntity.ConfigValueList;

import java.util.List;

public class Data {

    private String mid;
    private List<ConfigValueList> configValues;

    public List<ConfigValueList> getConfigValues() {
        return configValues;
    }

    public void setConfigValues(List<ConfigValueList> configValues) {
        this.configValues = configValues;
    }


    public List<ConfigValueList> getData() {
        return configValues;
    }


    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

}
