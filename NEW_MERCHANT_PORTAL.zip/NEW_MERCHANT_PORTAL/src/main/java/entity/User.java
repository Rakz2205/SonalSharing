package entity;

public class User {

    private String userId;
    private MobileEntity mobile;
    private String emailAddress;

    public String getBankuserId() {
        return userId;
    }

    public void setBankuserId(String userId) {
        this.userId = userId;
    }

    public MobileEntity getMobile() { return mobile; }

    public void setMobile(MobileEntity mobile) { this.mobile = mobile; }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
