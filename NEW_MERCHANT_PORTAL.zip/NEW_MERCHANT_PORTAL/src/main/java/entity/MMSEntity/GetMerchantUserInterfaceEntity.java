package entity.MMSEntity;

import entity.ConfigParams;

public class GetMerchantUserInterfaceEntity
{
    private String mid;
    private String templateId;
    private ConfigParams configParams;

    public String getMid() {
        return mid;
    }

    public GetMerchantUserInterfaceEntity setMid(String mid) {
        this.mid = mid;
        return this;
    }

    public String getTemplateId() {
        return templateId;
    }

    public GetMerchantUserInterfaceEntity setTemplateId(String templateId) {
        this.templateId = templateId;
        return this;
    }

    public ConfigParams getConfigParams() {
        return configParams;
    }

    public GetMerchantUserInterfaceEntity setConfigParams(ConfigParams configParams) {
        this.configParams = configParams;
        return this;
    }
}
