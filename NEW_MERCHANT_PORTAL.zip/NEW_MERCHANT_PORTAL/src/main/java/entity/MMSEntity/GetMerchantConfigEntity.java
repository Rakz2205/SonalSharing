package entity.MMSEntity;

public class GetMerchantConfigEntity
{
    private String mid;
    private String configType;
    private String status;

    public String getMid() {
        return mid;
    }

    public String getConfigType() {
        return configType;
    }

    public String getStatus() {
        return status;
    }

    public GetMerchantConfigEntity setMid(String mid) {
        this.mid = mid;
        return this;
    }

    public GetMerchantConfigEntity setConfigType(String configType) {
        this.configType = configType;
        return this;
    }

    public GetMerchantConfigEntity setStatus(String status) {
        this.status = status;
        return this;
    }
}
