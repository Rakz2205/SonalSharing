package entity.MMSEntity;

public class GetMerchantConfigList
{
    private String mid;

    public String getMid() {
        return mid;
    }

    public GetMerchantConfigList setMid(String mid) {
        this.mid = mid;
        return this;
    }
}
