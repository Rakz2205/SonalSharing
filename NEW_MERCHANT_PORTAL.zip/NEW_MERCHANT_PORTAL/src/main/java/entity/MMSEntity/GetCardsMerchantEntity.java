package entity.MMSEntity;

public class GetCardsMerchantEntity
{
    private String mid;

    public String getMid() {
        return mid;
    }

    public GetCardsMerchantEntity setMid(String mid) {
        this.mid = mid;
        return this;
    }
}
