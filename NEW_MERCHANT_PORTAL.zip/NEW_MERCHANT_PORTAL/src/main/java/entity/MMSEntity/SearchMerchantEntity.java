package entity.MMSEntity;

import entity.ConfigParams;
import entity.InputFilter;

import java.util.ArrayList;
import java.util.List;

public class SearchMerchantEntity
{
    private InputFilter inputFilter;
    private List outputDomains;
    private ConfigParams configParams;

    public InputFilter getInputFilter() {
        return inputFilter;
    }

    public SearchMerchantEntity setInputFilter(InputFilter inputFilter) {
        this.inputFilter = inputFilter;
        return this;
    }

    public List getOutputDomains() {
        return outputDomains;
    }

    public SearchMerchantEntity setOutputDomains(List outputDomains) {
        this.outputDomains = outputDomains;
        return this;
    }

    public ConfigParams getConfigParams() {
        return configParams;
    }

    public SearchMerchantEntity setConfigParams(ConfigParams configParams) {
        this.configParams = configParams;
        return this;
    }
}
