package entity;

public class InputFilter
{
    private String mid;
    private String userID;
    private String merchantId;
    private String startDateTime;
    private String endDateTime;


    public String getMid() {
        return mid;
    }

    public InputFilter setMid(String mid) {
        this.mid = mid;
        return this;
    }

    public String getUserID() {
        return userID;
    }

    public InputFilter setUserID(String userID) {
        this.userID = userID;
        return this;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }
}
