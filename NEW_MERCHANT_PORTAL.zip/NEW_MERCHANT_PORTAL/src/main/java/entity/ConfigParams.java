package entity;

public class ConfigParams
{
    private int page;
    private int size;
    private String sortColumn;
    private String sortType;
    private String mediaType;

    public String getMediaType() {
        return mediaType;
    }

    public ConfigParams setMediaType(String mediaType) {
        this.mediaType = mediaType;
        return this;
    }

    public int getPage() {
        return page;
    }

    public ConfigParams setPage(int page) {
        this.page = page;
        return this;
    }

    public int getSize() {
        return size;
    }

    public ConfigParams setSize(int size) {
        this.size = size;
        return this;
    }

    public String getSortColumn() {
        return sortColumn;
    }

    public ConfigParams setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
        return this;
    }

    public String getSortType() {
        return sortType;
    }

    public ConfigParams setSortType(String sortType) {
        this.sortType = sortType;
        return this;
    }
}
