package entity;

import java.util.List;

public class InputFiler
{
    private String merchantId;
    private String responseType;
    private String startDateTime;
    private String endDateTime;
    private List paymentMethods;
    private List transactionStatus;
    private double minTransactionAmount;
    private double maxTransactionAmount;
    private String transactionType;

    public String getMerchantId() {
        return merchantId;
    }

    public InputFiler setMerchantId(String merchantId) {
        this.merchantId = merchantId;
        return this;
    }

    public String getResponseType() {
        return responseType;
    }

    public InputFiler setResponseType(String responseType) {
        this.responseType = responseType;
        return this;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public InputFiler setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
        return this;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public InputFiler setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
        return this;
    }

    public List getPaymentMethods() {
        return paymentMethods;
    }

    public InputFiler setPaymentMethods(List paymentMethods) {
        this.paymentMethods = paymentMethods;
        return this;
    }

    public List getTransactionStatus() {
        return transactionStatus;
    }

    public InputFiler setTransactionStatus(List transactionStatus) {
        this.transactionStatus = transactionStatus;
        return this;
    }

    public double getMinTransactionAmount() {
        return minTransactionAmount;
    }

    public InputFiler setMinTransactionAmount(double minTransactionAmount) {
        this.minTransactionAmount = minTransactionAmount;
        return this;
    }

    public double getMaxTransactionAmount() {
        return maxTransactionAmount;
    }

    public InputFiler setMaxTransactionAmount(double maxTransactionAmount) {
        this.maxTransactionAmount = maxTransactionAmount;
        return this;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public InputFiler setTransactionType(String transactionType) {
        this.transactionType = transactionType;
        return this;
    }
}
