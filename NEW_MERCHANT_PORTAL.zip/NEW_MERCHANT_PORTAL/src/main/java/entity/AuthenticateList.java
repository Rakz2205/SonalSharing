package entity;

public class AuthenticateList {

    private String mode;
    private String value;
    private String action;

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setAction(String action) { this.action = action; }

    public String getAction() { return action; }
}
