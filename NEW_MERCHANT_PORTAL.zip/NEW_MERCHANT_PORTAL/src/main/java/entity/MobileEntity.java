package entity;

public class MobileEntity {
    private String countryCode = "+91";
    private String mobileNumber = null;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getNumber() {
        return mobileNumber;
    }

    public void setNumber(String number) {
        this.mobileNumber = number;
    }
}
