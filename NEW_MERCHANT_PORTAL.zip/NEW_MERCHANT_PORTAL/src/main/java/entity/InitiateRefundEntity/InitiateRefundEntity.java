package entity.InitiateRefundEntity;

public class InitiateRefundEntity
{
    private String mid;
    private String originalId;
    private String source;
    private String rrn;
    private String terminalId;
    private boolean livemode;
    private String invoice;
    private String acquiringInstId;
    private String transactionTime;
    private int currency;
    private int acquiringInstCountryCode;
    private double amount;

    public String getMid() {
        return mid;
    }

    public InitiateRefundEntity setMid(String mid) {
        this.mid = mid;
        return this;
    }

    public String getOriginalId() {
        return originalId;
    }

    public InitiateRefundEntity setOriginalId(String originalId) {
        this.originalId = originalId;
        return this;
    }

    public String getSource() {
        return source;
    }

    public InitiateRefundEntity setSource(String source) {
        this.source = source;
        return this;
    }

    public String getRrn() {
        return rrn;
    }

    public InitiateRefundEntity setRrn(String rrn) {
        this.rrn = rrn;
        return this;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public InitiateRefundEntity setTerminalId(String terminalId) {
        this.terminalId = terminalId;
        return this;
    }

    public boolean isLivemode() {
        return livemode;
    }

    public InitiateRefundEntity setLivemode(boolean livemode) {
        this.livemode = livemode;
        return this;
    }

    public String getInvoice() {
        return invoice;
    }

    public InitiateRefundEntity setInvoice(String invoice) {
        this.invoice = invoice;
        return this;
    }

    public String getAcquiringInstId() {
        return acquiringInstId;
    }

    public InitiateRefundEntity setAcquiringInstId(String acquiringInstId) {
        this.acquiringInstId = acquiringInstId;
        return this;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public InitiateRefundEntity setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
        return this;
    }

    public int getCurrency() {
        return currency;
    }

    public InitiateRefundEntity setCurrency(int currency) {
        this.currency = currency;
        return this;
    }

    public int getAcquiringInstCountryCode() {
        return acquiringInstCountryCode;
    }

    public InitiateRefundEntity setAcquiringInstCountryCode(int acquiringInstCountryCode) {
        this.acquiringInstCountryCode = acquiringInstCountryCode;
        return this;
    }

    public double getAmount() {
        return amount;
    }

    public InitiateRefundEntity setAmount(double amount) {
        this.amount = amount;
        return this;
    }
}
