package entity.authenticationEntity;

import entity.AuthenticateList;
import entity.User;

import java.util.List;

public class GenerateOTPEntity
{
    private User user;
    private List<AuthenticateList> authenticateList;
    private String scope;

    public User getUser() {
        return user;
    }

    public List<AuthenticateList> getAuthenticateList() {
        return authenticateList;
    }

    public String getScope() {
        return scope;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setAuthenticateList(List<AuthenticateList> authenticateList) {
        this.authenticateList = authenticateList;
    }

    public GenerateOTPEntity setScope(String scope) {
        this.scope = scope;
        return this;
    }

}
