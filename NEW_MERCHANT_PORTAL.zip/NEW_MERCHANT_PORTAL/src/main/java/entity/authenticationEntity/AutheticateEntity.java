package entity.authenticationEntity;

import entity.AuthenticateList;
import entity.User;

import java.util.List;

public class AutheticateEntity {
    private User user;
    private List<AuthenticateList> authenticateList;
    private String scope;
    private String encryptionKey;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<AuthenticateList> getAuthenticateList() {
        return authenticateList;
    }

    public void setAuthenticateList(List<AuthenticateList> authenticateList) {
        this.authenticateList = authenticateList;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getEncryptionKey() {
        return encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }
}

