package entity.authenticationEntity;

import entity.AuthenticateList;
import entity.User;
import entity.Validation;

import java.util.List;

public class ChangeCredentailsEntity {
    private User user;
    private Validation validation;
    private int credentialType;
    private String credentialValue;
    private String oldCredentialValue;
    private String encryptionKey;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Validation getValidation() {
        return validation;
    }

    public void setValidation(Validation validation) {
        this.validation = validation;
    }

    public int getCredentialType() {
        return credentialType;
    }

    public void setCredentialType(int credentialType) {
        this.credentialType = credentialType;
    }

    public String getCredentialValue() {
        return credentialValue;
    }

    public void setCredentialValue(String credentialValue) {
        this.credentialValue = credentialValue;
    }

    public String getOldCredentialValue() {
        return oldCredentialValue;
    }

    public void setOldCredentialValue(String oldCredentialValue) {
        this.oldCredentialValue = oldCredentialValue;
    }

    public String getEncryptionKey() {
        return encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }
}
