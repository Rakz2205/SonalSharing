package ResponseEntity;

public class CardsMerchantDataList
{

    private String merchantId;
    private String cardType;
    private String scheme;
    private String isDomesticAllowed;
    private String isInternationalAllowed;
    private String isPremium;


    public String getMerchantId() {
        return merchantId;
    }

    public CardsMerchantDataList setMerchantId(String merchantId) {
        this.merchantId = merchantId;
        return this;
    }

    public String getCardType() {
        return cardType;
    }

    public CardsMerchantDataList setCardType(String cardType) {
        this.cardType = cardType;
        return this;
    }

    public String getScheme() {
        return scheme;
    }

    public CardsMerchantDataList setScheme(String scheme) {
        this.scheme = scheme;
        return this;
    }

    public String getIsDomesticAllowed() {
        return isDomesticAllowed;
    }

    public CardsMerchantDataList setIsDomesticAllowed(String isDomesticAllowed) {
        this.isDomesticAllowed = isDomesticAllowed;
        return this;
    }

    public String getIsInternationalAllowed() {
        return isInternationalAllowed;
    }

    public CardsMerchantDataList setIsInternationalAllowed(String isInternationalAllowed) {
        this.isInternationalAllowed = isInternationalAllowed;
        return this;
    }

    public String getIsPremium() {
        return isPremium;
    }

    public void setIsPremium(String isPremium) {
        this.isPremium = isPremium;
    }
}
