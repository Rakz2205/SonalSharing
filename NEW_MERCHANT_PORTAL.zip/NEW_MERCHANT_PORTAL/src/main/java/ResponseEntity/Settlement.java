package ResponseEntity;

public class Settlement {
    private String settlementDate;
    private int settledTransactionCount;
    private double settledTransactionAmount;
    private int refundCount;
    private double refundAmount;
    private double settlementAmount;
    private String settlementReferenceNumber;
    private String fileName;

    public String getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(String settlementDate) {
        this.settlementDate = settlementDate;
    }

    public int getSettledTransactionCount() {
        return settledTransactionCount;
    }

    public void setSettledTransactionCount(int settledTransactionCount) {
        this.settledTransactionCount = settledTransactionCount;
    }

    public double getSettledTransactionAmount() {
        return settledTransactionAmount;
    }

    public void setSettledTransactionAmount(double settledTransactionAmount) {
        this.settledTransactionAmount = settledTransactionAmount;
    }

    public int getRefundCount() {
        return refundCount;
    }

    public void setRefundCount(int refundCount) {
        this.refundCount = refundCount;
    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public double getSettlementAmount() {
        return settlementAmount;
    }

    public void setSettlementAmount(double settlementAmount) {
        this.settlementAmount = settlementAmount;
    }

    public String getSettlementReferenceNumber() {
        return settlementReferenceNumber;
    }

    public void setSettlementReferenceNumber(String settlementReferenceNumber) {
        this.settlementReferenceNumber = settlementReferenceNumber;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
