package ResponseEntity;

public class ConfigValueList
{
    private int id;
    private String key;
    private String value;

    public int getId() {
        return id;
    }

    public ConfigValueList setId(int id) {
        this.id = id;
        return this;
    }

    public String getKey() {
        return key;
    }

    public ConfigValueList setKey(String key) {
        this.key = key;
        return this;
    }

    public String getValue() {
        return value;
    }

    public ConfigValueList setValue(String value) {
        this.value = value;
        return this;
    }
}
