package ResponseEntity.MMSResponseEntity;

import ResponseEntity.CardsMerchantDataList;
import entity.Data;

import java.util.List;

public class GetMerchantConfigListResponseEntity
{
    private String status;
    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }



    public String getStatus() {
        return status;
    }

    public GetMerchantConfigListResponseEntity setStatus(String status) {
        this.status = status;
        return this;
    }

}
