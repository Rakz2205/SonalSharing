package ResponseEntity.MMSResponseEntity;

import ResponseEntity.ConfigResponseEntity;
import entity.MobileEntity;

public class GetConfigResponseEntity
{
    private String status;
    private ConfigResponseEntity response;

    public String getStatus() {
        return status;
    }

    public GetConfigResponseEntity setStatus(String status) {
        this.status = status;
        return this;
    }

    public ConfigResponseEntity getResponse() {
        return response;
    }

    public GetConfigResponseEntity setResponse(ConfigResponseEntity response) {
        this.response = response;
        return this;
    }
}
