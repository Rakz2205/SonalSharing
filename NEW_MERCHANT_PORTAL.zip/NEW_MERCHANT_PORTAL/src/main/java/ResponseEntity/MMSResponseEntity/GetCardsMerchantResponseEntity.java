package ResponseEntity.MMSResponseEntity;

import ResponseEntity.CardsMerchantDataList;

import java.util.List;

public class GetCardsMerchantResponseEntity
{
    private String status;
    private List<CardsMerchantDataList> data;

    public String getStatus() {
        return status;
    }

    public GetCardsMerchantResponseEntity setStatus(String status) {
        this.status = status;
        return this;
    }

    public List<CardsMerchantDataList> getData() {
        return data;
    }

    public GetCardsMerchantResponseEntity setData(List<CardsMerchantDataList> data) {
        this.data = data;
        return this;
    }
}
