package ResponseEntity;

import entity.AuthenticateList;

import java.util.List;

public class ConfigResponseEntity
{
    private String mid;
    private String configType;
    private List<ConfigValues> configValues;
    private String status;

    public String getMid() {
        return mid;
    }

    public ConfigResponseEntity setMid(String mid) {
        this.mid = mid;
        return this;
    }

    public String getConfigType() {
        return configType;
    }

    public ConfigResponseEntity setConfigType(String configType) {
        this.configType = configType;
        return this;
    }

    public List<ConfigValues> getConfigValues() {
        return configValues;
    }

    public ConfigResponseEntity setConfigValues(List<ConfigValues> configValues) {
        this.configValues = configValues;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public ConfigResponseEntity setStatus(String status) {
        this.status = status;
        return this;
    }
}
