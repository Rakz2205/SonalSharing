package ResponseEntity.TransactionResponseEntity;

import ResponseEntity.Data;

public class GetSettlementsResponseEntity {
    private String status;
    private ResponseEntity.Data data;
    private String timeStamp;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public GetSettlementsResponseEntity setData(Data data) {
        this.data = data;
        return this;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

}
