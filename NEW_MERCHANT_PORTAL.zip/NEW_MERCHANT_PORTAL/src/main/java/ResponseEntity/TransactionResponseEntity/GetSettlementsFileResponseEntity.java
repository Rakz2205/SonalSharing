package ResponseEntity.TransactionResponseEntity;

public class GetSettlementsFileResponseEntity {
    private String status;
    private Data data;
    private String timeStamp;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public GetSettlementsFileResponseEntity setData(Data data) {
        this.data = data;
        return this;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

}
