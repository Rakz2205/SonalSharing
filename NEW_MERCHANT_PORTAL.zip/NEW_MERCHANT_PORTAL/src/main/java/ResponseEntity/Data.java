package ResponseEntity;


import java.util.List;

public class Data{
    private Page page;
    private List<Settlement> content;

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public List<Settlement> getContent() {
        return content;
    }

    public void setContent(List<Settlement> content) {
        this.content = content;
    }

}
