package MerchantManagement_API;

import ComponentFile.MMSComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class MerchantUserInterface extends SetUp {
    private CommonMethods commMethod;
    private MMSComponent mmsComp;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "PositiveScenario"})
    public void MerchantUserInterfaceTest(HashMap myData) {
        Reporter.initiateTestReport(MerchantUserInterface.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        String schemaPath = responseSchemaFolderPath + "//MMS//MerchantUserInterfaceResponse.json";
        Response response = mmsComp.getResponseMerchantUserInterface(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response, schemaPath);
        commMethod.validateResponseStatusMessage(response, status_Success);
        mmsComp.validateMerchantUserInterfaceResponseBody(response, myData);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "NegativeScenario"})
    public void MerchantUserInterfaceTestNegative(HashMap myData) {
        Reporter.initiateTestReport(MerchantUserInterface.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        Response response = mmsComp.getResponseMerchantUserInterface(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }

}
