package MerchantManagement_API;

import ComponentFile.MMSComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class SearchMerchant extends SetUp {
    private CommonMethods commMethod;
    private MMSComponent mmsComp;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "PositiveScenario"})
    public void SearchMerchantTest(HashMap myData) {
        Reporter.initiateTestReport(SearchMerchant.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        String schemaPath = responseSchemaFolderPath + "//MMS//";
        Response response = mmsComp.getResponseSearchMerchant(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        String testDataType = (String) myData.get("TestdataType");
        if (testDataType.equalsIgnoreCase("SEARCH_USING_MID"))
            commMethod.validateResponseSchema(response, schemaPath + "SearchMerchantByMid.json");
        else
            commMethod.validateResponseSchema(response, schemaPath + "SearchMerchantByUserId.json");
        commMethod.validateResponseStatusMessage(response, status_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "NegativeScenario"})
    public void SearchMerchantTestNegative(HashMap myData) {
        Reporter.initiateTestReport(SearchMerchant.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        Response response = mmsComp.getResponseSearchMerchant(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {

    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }

}
