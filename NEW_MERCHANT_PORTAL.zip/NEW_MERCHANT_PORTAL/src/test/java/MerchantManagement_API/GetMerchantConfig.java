package MerchantManagement_API;

import ComponentFile.MMSComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class GetMerchantConfig extends SetUp {
    private CommonMethods commMethod;
    private MMSComponent mmsComp;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "PositiveScenario"})
    public void GetMerchantConfigTest(HashMap myData) {
        Reporter.initiateTestReport(GetMerchantConfig.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        String schemaPath = responseSchemaFolderPath + "//MMS//getMerchantConfigResponse.json";
        Response response = mmsComp.getResponseGetMerchantConfig(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response, schemaPath);
        commMethod.validateResponseStatusMessage(response, status_Success);
        mmsComp.validateMerchantConfigResponseBody(response, myData);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:MMS", "API", "MerchantManagement", "NegativeScenario"})
    public void GetMerchantConfigTestNegative(HashMap myData) {
        Reporter.initiateTestReport(GetMerchantConfig.class, String.format((String) myData.get("TestDescription")));
        mmsComp = new MMSComponent();
        commMethod = new CommonMethods();
        Response response = mmsComp.getResponseGetMerchantConfig(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }
}
