package InitiateRefund_API;

import ComponentFile.InitiateRefundComponent;
import ComponentFile.MMSComponent;
import DataProvider.BrowserNameProvider;
import MerchantManagement_API.GetMerchantConfig;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.HashMap;

public class InitiateRefund extends SetUp
{
    private CommonMethods commMethod;
    private InitiateRefundComponent iRefComp;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:InitiateRefund", "API", "InitiateRefund", "PositiveScenario"})
    public void InitiateRefundTest(HashMap myData) {
        Reporter.initiateTestReport(InitiateRefund.class, String.format((String) myData.get("TestDescription")));
        iRefComp = new InitiateRefundComponent();
        commMethod = new CommonMethods();
        String schemaPath = responseSchemaFolderPath + "//InitiateRefund//InitiateRefundResponse.json";
        Response response = iRefComp.getResponseInitiateRefund(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response, schemaPath);
        commMethod.validateResponseStatusMessage(response, status_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:InitiateRefund", "API", "InitiateRefund", "NegativeScenario"})
    public void InitiateRefundTestNegative(HashMap myData) {
        Reporter.initiateTestReport(InitiateRefund.class, String.format((String) myData.get("TestDescription")));
        iRefComp = new InitiateRefundComponent();
        commMethod = new CommonMethods();
        Response response = iRefComp.getResponseInitiateRefund(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {Reporter.tearDownTestReport(testResult); }
}
