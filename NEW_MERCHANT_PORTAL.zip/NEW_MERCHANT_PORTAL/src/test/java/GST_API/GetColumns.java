package GST_API;

import ComponentFile.GSTComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class GetColumns extends SetUp {
    private GSTComponent gstComp;
    private CommonMethods commMethod;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:GST", "API", "GST", "PositiveScenario"})
    public void GetColumnsTest(HashMap myData) {
        Reporter.initiateTestReport(GetColumns.class, String.format((String) myData.get("TestDescription")));
        gstComp = new GSTComponent();
        commMethod = new CommonMethods();
        String schemaPath=responseSchemaFolderPath+"//GST//GetColumns.json";
        Response response = gstComp.getResponseColumns(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response, schemaPath);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:GST", "API", "GST", "NegativeScenario"})
    public void GetColumnsTestNegative(HashMap myData) {
        Reporter.initiateTestReport(GetColumns.class, String.format((String) myData.get("TestDescription")));
        gstComp = new GSTComponent();
        commMethod = new CommonMethods();
        String schemaPath=responseSchemaFolderPath+"//GST//GetColumns.json";
        Response response = gstComp.getResponseColumns(myData);
        commMethod.validateResponseStatusCode(response, (String)myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }


    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }

}
