package ToBeDeleted;

import org.testng.annotations.Test;

public class SuiteTest {
    @Test(groups = {"API", "Transaction", "PositiveScenario"})
    public void testt() {
        System.out.println("successfully executed test by suite xml");
    }

}
