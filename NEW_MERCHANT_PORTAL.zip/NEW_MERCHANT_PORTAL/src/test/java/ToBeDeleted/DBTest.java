package ToBeDeleted;

import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import com.utilities.connectionUtils.DataBaseUtility;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.TimeZone;

public class DBTest extends SetUp {

    @Test()
    public void testGetAddressNegativeCase() {
        //just printing a value from db
        String query = "Select MID from Merchant where Merchant_id='62'";

        ResultSet resultSet = DataBaseUtility.executeSelectStatement(dbMerchant, query);
        try {
            resultSet.next();
            System.out.println(resultSet.getString("MID"));
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }

    }

    @BeforeMethod(groups = {"sanity", "All"})
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod(groups = {"sanity", "All"})
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
        ConnectionSetup.closeTestConnections();
    }

    public static LocalDateTime getDateTimeFromTimestamp(String timestamp) {
        if (null == timestamp || timestamp.trim().length() == 0) {
            return null;
        }
        Long longValue = Long.parseLong(timestamp);
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(longValue), TimeZone
                .getDefault().toZoneId());
    }

    public static void main(String[] args) {
        System.out.println(getDateTimeFromTimestamp("1591624472495"));
    }
}
