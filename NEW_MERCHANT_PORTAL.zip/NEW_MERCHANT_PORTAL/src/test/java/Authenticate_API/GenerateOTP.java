package Authenticate_API;

import ComponentFile.AuthenticateComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.APIEndPoints;
import base.ConnectionSetup;
import base.SetUp;
import com.utilities.apiUtils.RestUtil;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.Map;

public class GenerateOTP extends SetUp {
    private AuthenticateComponent authComp;
    private CommonMethods commMethod;

    @Test(enabled=false,dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups =  {"SheetName:Authentication", "API", "Authentication", "PositiveScenario"})
    public void GenerateOTPTest(HashMap myData) {
        Reporter.initiateTestReport(GenerateOTP.class, String.format((String) myData.get("TestDescription")));
        authComp = new AuthenticateComponent();
        commMethod = new CommonMethods();
        Response response = authComp.getResponseGenOTP(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseSchema(response,"GetOTPResponse.json");
        commMethod.validateResponseStatusMessage(response,status_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups =  {"SheetName:Authentication", "API", "Authentication", "NegativeScenario"})
    public void GenerateOTPTestNegative(HashMap myData) {
        Reporter.initiateTestReport(GenerateOTP.class, String.format((String) myData.get("TestDescription")));
        authComp = new AuthenticateComponent();
        commMethod = new CommonMethods();
        String schemaPath = responseSchemaFolderPath + "//Failure//JsonFailureSchema.json";
        Response response = authComp.getResponseGenOTP(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }
}
