package Authenticate_API;

import ComponentFile.AuthenticateComponent;
import ComponentFile.GSTComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class AuthenticateAllAPI extends SetUp
{
    private AuthenticateComponent authComp;
    private CommonMethods commMethod;

    @Test(enabled =false,dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups =  {"SheetName:Authentication", "API", "Authentication", "PositiveScenario"})
    public void authenticateTestALLAPI(HashMap myData) {
        Reporter.initiateTestReport(Authenticate.class, String.format((String) myData.get("TestDescription")));
        authComp = new AuthenticateComponent();
        commMethod = new CommonMethods();

        String otpRecieved=authComp.TestGenerateOTPAPI(myData);
        authComp.TestResetCredsAPI(myData,otpRecieved);
        authComp.TestChangeCredsAPI(myData);
        authComp.TestAuthenticationAPI(myData);
    }

    @BeforeMethod()
    public void beforeSetup() { }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }
}
