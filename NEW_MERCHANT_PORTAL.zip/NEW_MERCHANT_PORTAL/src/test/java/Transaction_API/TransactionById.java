package Transaction_API;

import ComponentFile.TransactionsComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class TransactionById extends SetUp {
    private CommonMethods commMethod;
    private TransactionsComponent transactionsComponent;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "PositiveScenario"})
    public void GetTransactionByIdTest(HashMap myData) {
        Reporter.initiateTestReport(TransactionById.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response = transactionsComponent.getResponseGetTransationById(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response, status_Success);
        String schemaPath = transactionsComponent.getTransactionSchemaPath((String) myData.get("TestdataType"));
        commMethod.validateResponseSchema(response, schemaPath);
        // Response data will be validated once tables are created in Data Lake
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "PositiveScenario"})
    public void GetTransactionByIdTestOtherThanJson(HashMap myData) {
        Reporter.initiateTestReport(TransactionById.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response = transactionsComponent.getResponseGetTransationById(myData);
        commMethod.validateResponseStatusCode(response, responseCode_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "NegativeScenario"})
    public void GetTransactionByIdTestNegative(HashMap myData) {
        Reporter.initiateTestReport(TransactionById.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response = transactionsComponent.getResponseGetTransationById(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }
}
