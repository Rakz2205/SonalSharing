package Transaction_API;

import ComponentFile.GSTComponent;
import ComponentFile.TransactionsComponent;
import DataProvider.BrowserNameProvider;
import Utils.CommonMethods;
import Utils.Reporter;
import base.ConnectionSetup;
import base.SetUp;
import io.restassured.response.Response;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class GenerateSettlementReport extends SetUp {
    private CommonMethods commMethod;
    private TransactionsComponent transactionsComponent;

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "PositiveScenario"})
    public void GetGenerateSettlementReportTest(HashMap myData) {
        Reporter.initiateTestReport(GenerateSettlementReport.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response = transactionsComponent.getResponseGenerateSettlementReport(myData);
        String schemaPath = responseSchemaFolderPath + "//Transactions//GenerateSettlementReport.json";
        commMethod.validateResponseStatusCode(response, responseCode_Success);
        commMethod.validateResponseStatusMessage(response, status_Success);
        commMethod.validateResponseSchema(response, schemaPath);
        transactionsComponent.validateGenerateSettlementReportResponseBody(response, myData);
        transactionsComponent.strFile = commMethod.getValueFromResponse(response, "data.fileName");
        response = transactionsComponent.getResponseGetSettlementFile(myData, transactionsComponent.strFile, (String) myData.get("File_extension"),"");
        commMethod.validateResponseStatusCode(response, responseCode_Success);
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "NegativeScenario"})
    public void GetGenerateSettlementReportTestNegative(HashMap myData) {
        Reporter.initiateTestReport(GenerateSettlementReport.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response = transactionsComponent.getResponseGetSettlements(myData);
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
        commMethod.validateResponseSchema(response, responseFailureSchemaPath);
        commMethod.validateResponseFailureStatusNotPresent(response);
        commMethod.validateResponseErrorMessage(response, (String) myData.get("MessageToBeValidated"));
        commMethod.validateResponseErrorCode(response, (String) myData.get("errorCode"));
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "NegativeScenario"})
    public void GetSettlementFileTestNegative(HashMap myData) {
        Reporter.initiateTestReport(GenerateSettlementReport.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response=null;
        Response responseGenerateSettlementReport = transactionsComponent.getResponseGenerateSettlementReport(myData);
        transactionsComponent.strFile = commMethod.getValueFromResponse(responseGenerateSettlementReport, "data.fileName");
        response = transactionsComponent.getResponseGetSettlementFile(myData, transactionsComponent.strFile, (String) myData.get("File_extension"),(String) myData.get("TestdataType"));
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
    }

    @Test(dataProvider = "BrowserNameList", dataProviderClass = BrowserNameProvider.class, groups = {"SheetName:Transaction", "API", "Transaction", "NegativeScenario"})
    public void GetSettlementFileTestNegativeWithInvalidFile(HashMap myData) {
        Reporter.initiateTestReport(GenerateSettlementReport.class, String.format((String) myData.get("TestDescription")));
        transactionsComponent = new TransactionsComponent();
        commMethod = new CommonMethods();
        Response response=null;
        if ((String) myData.get("File_name") != "") {
            response = transactionsComponent.getResponseGetSettlementFile(myData, (String) myData.get("File_name"), (String) myData.get("File_extension"),"");
        } else {
            response = transactionsComponent.getResponseGetSettlementFile(myData, "", (String) myData.get("File_extension"),"");
        }
        commMethod.validateResponseStatusCode(response, (String) myData.get("ResponseStatusCode"));
    }

    @BeforeMethod()
    public void beforeSetup() {
        ConnectionSetup.createTestConnections();
    }

    @AfterMethod()
    public void afterSetup(ITestResult testResult) {
        Reporter.tearDownTestReport(testResult);
    }
}
