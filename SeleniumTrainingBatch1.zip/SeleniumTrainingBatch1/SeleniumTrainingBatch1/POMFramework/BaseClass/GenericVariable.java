package BaseClass;

public class GenericVariable 
{
	public static String googleURL="https://www.google.com";
	
	public static String searchString="Amazon";
	
	public static String matchString="Images";
}
