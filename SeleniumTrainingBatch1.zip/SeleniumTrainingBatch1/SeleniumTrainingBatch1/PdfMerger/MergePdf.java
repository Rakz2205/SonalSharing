import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.*;

//import org.apache.pdfbox.multipdf.PDFMergerUtility;
//import org.apache.pdfbox.pdmodel.PDDocument;

public class MergePdf {

	public static void main(String[] args) throws IOException , IOException {
		//Loading an existing PDF document
	      File file1 = new File("D:\\Personal Docs\\R.K Marketing\\GST Purchase Sales Data\\R.K Marketing\\2018-2019\\Annual Statement\\RK BOB 18-19 part 1.pdf");
	      //PDDocument doc1 = PDDocument.load(file1);
	       
	      File file2 = new File("D:\\Personal Docs\\R.K Marketing\\GST Purchase Sales Data\\Priyansh Marketing\\2018-2019\\Annual Statement\\PRIYANSH BOB Statement 2018-19 part 4.pdf");
	      //PDDocument doc2 = PDDocument.load(file2);
	      
	      File file3 = new File("D:\\Personal Docs\\R.K Marketing\\GST Purchase Sales Data\\R.K Marketing\\2018-2019\\Annual Statement\\RK BOB 18-19 part 3.pdf");
	      //PDDocument doc3 = PDDocument.load(file3);
	       
	      File file4 = new File("D:\\Personal Docs\\R.K Marketing\\GST Purchase Sales Data\\Priyansh Marketing\\2018-2019\\Annual Statement\\PRIYANSH BOB Statement 2018-19 part 6.pdf");
	     // PDDocument doc4 = PDDocument.load(file4);
	         
	      //Instantiating PDFMergerUtility class
	     // PDFMergerUtility PDFmerger = new PDFMergerUtility();

	      //Setting the destination file
	      PDFmerger.setDestinationFileName("D:\\Personal Docs\\R.K Marketing\\GST Purchase Sales Data\\Priyansh Marketing\\2018-2019\\Annual Statement\\merged.pdf");

	      //adding the source files
	      PDFmerger.addSource(file2);
	      PDFmerger.addSource(file4);

	      //Merging the two documents
	      PDFmerger.mergeDocuments();

	      System.out.println("Documents merged");
	      //Closing the documents
	     // doc1.close();
	      //doc2.close();

	}
}
