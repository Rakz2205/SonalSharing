package Day5;

public class FetchTableValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		Assignement
//
//		Launch "http://toolsqa.com/automation-practice-table/"
//
//
//		fetch the text present in table and print in similar manner
//		Note : Don't store values in variable/Array/ List , directly print the value
//		in console using getText()
//
//		Output should be :
//
//		Structure  Country  City  Height  Built  Rank  �  
//		Burj Khalifa  UAE  Dubai  829m  2010  1  details  
//		Clock Tower Hotel  Saudi Arabia  Mecca  601m  2012  2  details  
//		Taipei 101  Taiwan  Taipei  509m  2004  3  details  
//		Financial Center  China  Shanghai  492m  2008  4  details 
		
	}

}
