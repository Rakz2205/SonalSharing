package Day1;

import java.awt.AWTException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IntensePortalAutomation {
	public static WebDriver driver;
	public static WebDriverWait wait;
	
	//public static String intensePortalURL="https://stcafapproval.rjil.ril.com:9443";
	public static String intensePortalURL="http://ppcafapproval.rjil.ril.com:9443/Uniserve-Web/LogInAction.do";
	public static String userName="saivinayak1.bangera";
	public static String password="Work@2020";
	public static String ornNumber="SCSB2019112225";
	
	
	//locators
	
	public static void main(String[] args) throws InterruptedException, AWTException 
	{
		// TODO Auto-generated method stub
        initializeDriver();
        launchURL(intensePortalURL);
        loginIntoIntensePortal(userName,password);
        Thread.sleep(5000);
        goToInbox();
		Thread.sleep(5000);
		searchORN(ornNumber);
		Map allValueMap = fetchAllValues();
		
		//clickOnActivate();
		
		logoutFromIntensePortal();
		driver.close();
	}
	
	public static void clickOnActivate()
	{
		driver.findElement(By.id("submitbtn_top")).click();
	}
	public static void initializeDriver()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Rakesh\\Office Stuff\\BC App Onbaording\\BC_OPS_INTENSE\\BC_OPS_INTENSE\\src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--start-maximized");
        chromeOptions.addArguments("--ignore-ssl-errors=yes");
        chromeOptions.addArguments("--ignore-certificate-errors");
        driver = new ChromeDriver(chromeOptions);
        wait = new WebDriverWait(driver,30);
	}
	
	public static void launchURL(String url)
	{
		driver.get(url);
	}
	
	public static void loginIntoIntensePortal(String uName,String uPassword)
	{
		driver.findElement(By.name("username")).sendKeys(uName);
		driver.findElement(By.name("password")).sendKeys(uPassword);
		
		driver.findElement(By.xpath("//input[@value='Login']")).click();
	}
	
	
	public static void logoutFromIntensePortal() throws InterruptedException
	{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).click();
		driver.findElement(By.xpath("//*[text()='Logout']")).click();
		
		Thread.sleep(2000);
	}
	
	
	public static void goToInbox()
	{
		WebElement inboxTab = driver.findElement(By.xpath("//*[@id='SubmodLI_113']/a"));
		wait.until(ExpectedConditions.elementToBeClickable(inboxTab));
		inboxTab.click();
	}
	
	public static void searchORN(String ornNumber) throws InterruptedException
	{
		driver.switchTo().frame(0);
		
		// directly clicking on first value
		driver.findElement(By.xpath("//*[@class='k-grid-content']//table//tr[1]/td[2]")).click();
		
		
		//WebElement ornTextBox = driver.findElement(By.id("orn_id_search"));
		//wait.until(ExpectedConditions.elementToBeClickable(ornTextBox));
		//ornTextBox.sendKeys(ornNumber);
		//driver.findElement(By.xpath("//*[@title='Search']")).click();
	}
	
	public static Map fetchAllValues()
	{
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		
		
		//fetching all the values
		Map<String,String> allValues= new HashMap<>();
		Actions actions = new Actions(driver);
		List<WebElement> parentList = driver.findElements(By.xpath("//ul[@id='panelbar']/li"));
		
		for(int i=1; i<=parentList.size();i++)
        {
			String myXpath="(//ul[@id='panelbar']/li)["+i+"]/div//div";
			
			List<WebElement> innerDiv = driver.findElements(By.xpath(myXpath));
			
			System.out.println(innerDiv.size());
			
			for(int j=0;j<innerDiv.size();j++)
			{
				String mapKey="";
				String mapValue="";
				try
				{
					WebElement eachElementLabel = innerDiv.get(j).findElement(By.tagName("label"));
					actions.moveToElement(eachElementLabel);
					actions.perform();
					try {
					WebElement eachElementSelect = innerDiv.get(j).findElement(By.tagName("Select"));
					if(eachElementSelect.isDisplayed())
					{
						Select select = new Select(eachElementSelect);
						WebElement option = select.getFirstSelectedOption();
						String defaultItem = option.getText();
						mapKey=eachElementSelect.getAttribute("id");
						mapValue=defaultItem;
					}}catch(Exception e) {}
					try {
					WebElement eachElementTextArea = innerDiv.get(j).findElement(By.tagName("textarea"));
					if(eachElementTextArea.isDisplayed())
					{
						mapKey=eachElementTextArea.getAttribute("id");
						mapValue=eachElementTextArea.getAttribute("value");
					}}catch(Exception e) {}
					try {
					WebElement eachElementInput = innerDiv.get(j).findElement(By.tagName("input"));
					if(eachElementInput.isDisplayed())
					{
						mapKey=eachElementInput.getAttribute("id");
						mapValue=eachElementInput.getAttribute("value");
					}}catch(Exception e) {}
					
					
					// putting value in hashmap
					if(allValues.containsKey(mapKey))
					{
						allValues.replace(mapKey, mapValue);
					}
					else
					{
						allValues.put(mapKey, mapValue);
					}
					
					
				}
				catch(Exception e){}
				 
			}
			
        }
		
		
		// printing hashmap
		
		System.out.println("========================");
		
		
		Set<Entry<String, String>> st = allValues.entrySet();
		for (Map.Entry iteartor : st) {
			Object srcKey = iteartor.getKey();
			String srcValue = allValues.get(srcKey) + "";
			
			System.out.println(srcKey +"=="+srcValue);
		}
		
		return allValues;
	}

}
