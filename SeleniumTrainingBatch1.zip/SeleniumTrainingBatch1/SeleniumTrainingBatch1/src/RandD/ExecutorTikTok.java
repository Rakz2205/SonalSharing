package RandD;

import java.io.IOException;

public class ExecutorTikTok {

	public static void main(String[] args) throws InterruptedException
{
		// TODO Auto-generated method stub
		try {
			//Runtime.getRuntime().exec( "wscript " );
			
			System.out.println("before");
			String path=System.getProperty("user.dir");
			path="C:\\Rakesh\\CT\\msgbox.vbs";
			Process proc = Runtime.getRuntime().exec(new String[] {"wscript.exe",path});
			proc.waitFor();
			System.out.println("after");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
