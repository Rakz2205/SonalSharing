package ToBeDeleted;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UniqueDigits {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		String strTemp=getDateInFormat();
		
		long val=Long.parseLong(strTemp);
		
		for(int i=0;i<1000;i++)
		{
			System.out.println(val++);
		}
		
	}
	
	public static String getUniqueNumber()
	{
		Date date= new Date();
		long time = date.getTime();
		
		String temp=time+"";
		temp=temp.substring(1, 13);
		
		
		return temp;
	}
	
	public static String getDateInFormat()
	{
		
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
        SimpleDateFormat timeOnly = new SimpleDateFormat("yyMMddhhmmsss");
		return timeOnly.format(cal.getTime())+"";
		
	}
}
