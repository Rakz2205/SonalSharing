package ToBeDeleted;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class getNumberOfClick {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		System.out.println(noOfClicks("14-Feb-1990"));
	}
		
	public static int noOfClicks(String dob) throws ParseException
	{
		//convert input date in dd-mmm-yyyy format
		SimpleDateFormat dateFormatter = new SimpleDateFormat("M");
		
		Date inputDate=new SimpleDateFormat("dd-MMM-yyyy").parse(dob); 
		String dobMonth=dateFormatter.format(inputDate);
		
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
        
		String currMonth=dateFormatter.format(date);
		return (Integer.parseInt(dobMonth)-Integer.parseInt(currMonth));
	}

}
