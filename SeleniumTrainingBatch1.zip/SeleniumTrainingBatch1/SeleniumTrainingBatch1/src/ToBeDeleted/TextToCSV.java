package ToBeDeleted;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class TextToCSV {

	public static void main(String[] args) throws Exception 
	{
		// TODO Auto-generated method stub
		
		String txtFilePath="C:\\Rakesh\\Office Stuff\\Sonal\\TextToCSVConverter\\IMPSREMCBSEXTREP-19-03-2020-180001.text";
		List<String> data = readFileInList(txtFilePath);
		List<String> updatedData = trimList(data);
		createCSVFile("C:\\Rakesh\\Office Stuff\\Sonal\\TextToCSVConverter\\output.csv",updatedData);
	}
	
	public static void createCSVFile(String csvFileName,List<String> writeData) throws IOException
	{
		FileWriter fw=new FileWriter(csvFileName);
		
		for(int i=0;i<writeData.size();i++)
		{
			fw.write(writeData.get(i));
			fw.write("\n");
		}
        fw.close(); 
	}
	
	public static List<String> readFileInList(String fileName) {
	    List<String> lines = Collections.emptyList();
	    try {
	      lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
	    } catch (IOException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    }
	    return lines;
	}
	
	public static List<String> trimList(List<String> data)
	{
		List<String> updatedData=new ArrayList<String>();
		
		for(int i=0;i<data.size();i++)
		{
			String strTemp=data.get(i);
			//replacing extra spaces
			strTemp = strTemp.trim().replaceAll("  +", ",");
			
			boolean addFlag=true;
			
			if(strTemp.length()==0)
			{
				addFlag=false;
			}
			
			if(strTemp.contains("TRAN_AMOUNT"))
			{
				addFlag=false;
			}
			if(strTemp.startsWith("--") || strTemp.endsWith("--"))
			{
				addFlag=false;
			}
			
			if(addFlag)
			{
				updatedData.add(strTemp);
			}
		}
		return updatedData;
	}

}
