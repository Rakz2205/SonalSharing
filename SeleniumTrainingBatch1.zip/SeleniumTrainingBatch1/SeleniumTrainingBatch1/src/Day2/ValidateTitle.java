package Day2;

public class ValidateTitle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//if title matches exactly  print pass else print fail
	}

}
