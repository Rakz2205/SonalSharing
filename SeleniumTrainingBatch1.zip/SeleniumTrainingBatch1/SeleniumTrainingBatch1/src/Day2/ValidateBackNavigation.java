package Day2;

public class ValidateBackNavigation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// launch google
		
		// launch flipkart or amazon
		
		// navigate back
		
		// validate url contains google print true or false
	}

}
