

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.ClickElement;
import org.openqa.selenium.support.ui.Select;

public class IEGoogle 
{
	static Robot robot;
	static WebDriver driver;
	static String genericXpath="(//*[text()='%%labelName']//following-sibling::td)[1]";
	static String genericInputXpath="((//*[text()='%%labelName']//following-sibling::td)[1]/input)[%%ElementPosition]";
	static String genericSelectXpath="((//*[text()='%%labelName']//following-sibling::td)[1]/select)[1]";
	static String goButtonXpath="//*[@id='Go']";
	
	static Map transactionDetails = new HashMap();
	
	
	public static void main(String[] args) throws InterruptedException, AWTException 
	{
		transactionDetails.put("DRRFLNB3565300200", "100");
		transactionDetails.put("CRRFLNB3563800100", "100");
		
		
		
		// setup
		robot = new Robot();
		InternetExplorerOptions options = new InternetExplorerOptions();
		options.introduceFlakinessByIgnoringSecurityDomains();
		options.ignoreZoomSettings();
		options.requireWindowFocus();
		System.setProperty("webdriver.ie.driver", "C:\\Rakesh\\Office Stuff\\Jars\\IEDriverServer_32 bit.exe");
		driver = new InternetExplorerDriver(options);
		driver.get("https://jmngcd1bli330v03.jpb.jio.com:12500/SSO/ui/SSOLogin.jsp");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		
		//my code
		
		loginIntoFinacle("TEST5","jio@2020");
		
		selectCoreServer();
		
		String TranId=addTransaction(transactionDetails);
		//logoutFinacle();
		//loginIntoFinacle("TEST4","jio@2020");
		//postTransaction("");
		
		
		
	}
	
	private static String addTransaction(Map transactionDetailsToAdd) throws InterruptedException {
		// TODO Auto-generated method stub
		goToShortCutMenu("HTM");
		selectFieldValue("Function","A - Add");
		selectFieldValue("Transaction Type/Subtype", "T/BI - Bank Induced");
		driver.findElement(By.xpath(goButtonXpath)).click();
		
		//loop to add all the transaction
		Set<Map.Entry> accTemp = transactionDetailsToAdd.entrySet();
		for (Map.Entry iteartor : accTemp) 
		{
			Object srcKey = iteartor.getKey();
			String amountToBeAdd = transactionDetailsToAdd.get(srcKey) + "";
			
			String addType=srcKey.toString().substring(0, 1).toUpperCase();
			String accountNumber=srcKey.toString().substring(1);
			
			System.out.println(addType);
			System.out.println(accountNumber);
			System.out.println(amountToBeAdd);
			Thread.sleep(2000);
			if(addType.equals("D"))
			{
				System.out.println("inside D type");
				clickRadioButton("Part Transaction Type","1");
			}
			else if(addType.equals("C"))
			{
				System.out.println("inside c type");
				clickRadioButton("Part Transaction Type","2");
			}
			writeFieldInputValue("Ref. CCY/Amt.", "2", amountToBeAdd);
			writeFieldInputValue("A/c. ID", "1", accountNumber);
			
			
			driver.findElement(By.xpath("//input[@id='partTranDetail_AddNew']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@id='partTranDetail_AddNew']")).click();
		}
		driver.findElement(By.xpath("//input[@id='Save']")).click();
		
		
		//fetch text from label
		String tranId=driver.findElement(By.xpath("//label[@id='tranId']")).getText();
		System.out.println(tranId);
		
		driver.findElement(By.xpath("//input[@id='Ok']")).click();
		return tranId;
	}
	
	
	private static void postTransaction(String postTranId) throws InterruptedException {
		//postTranId="0114";
		goToShortCutMenu("HTM");
		selectFieldValue("Function","P - Post");
		writeFieldInputValue("Transaction ID", "1", postTranId);
		
		//driver.findElement(By.xpath(goButtonXpath)).click();
	
	}
	
	public static void selectCoreServer() throws InterruptedException, AWTException
	{
		WebElement dropdownContinent = driver.findElement(By.name("appSelect"));
		
		Select select=new Select(dropdownContinent);
		
		select.selectByVisibleText("CoreServer");
		
		
		//alert.a
		clickIfAlertExist();
		Thread.sleep(1000);
		
		clickIfAlertExist();
		Thread.sleep(10000);
		
		// below function is for time being to by pass login on holiday day
		authorizeLogin("","");
		
		// need to handle for holiday login
        Thread.sleep(2000);
        driver.switchTo().frame("CoreServer");
        driver.switchTo().frame("FINW");
		
	}
	public static void loginIntoFinacle(String loginUsername,String loginPassword) throws InterruptedException
	{
		Thread.sleep(1000);
        driver.switchTo().frame("loginFrame");
		driver.findElement(By.xpath("//*[@id='usertxt']")).sendKeys(loginUsername);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='passtxt']")).sendKeys(loginPassword);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='Submit']")).click();
		
		//check if user already login appears
		try {
			System.out.println("inside try");
			
			WebElement alreadyLoginButton = driver.findElement(By.xpath("//*[@name='Submit2']"));
			
			
			if(alreadyLoginButton.isEnabled())
			{
				System.out.println("inside user login");
				driver.findElement(By.xpath("//*[@name='Submit2']")).click();
				Thread.sleep(1000);
				clickIfAlertExist();
				
				driver.findElement(By.xpath("//*[@id='usertxt']")).sendKeys(loginUsername);
				Thread.sleep(1000);
				
				driver.findElement(By.xpath("//*[@id='passtxt']")).sendKeys(loginPassword);
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='Submit']")).click();
			}
		}
		catch(Exception e)
		{
			
		}
		
		
	}
	
	public static void logoutFinacle() throws InterruptedException
	{
		driver.switchTo().defaultContent();
		driver.switchTo().frame("loginFrame");
		WebElement logoutButton = driver.findElement(By.xpath("((//*[@class='topnavi'])[3])/img"));
		logoutButton.click();
		Thread.sleep(1000);
		clickIfAlertExist();
		driver.close();
	}
	
	public static void authorizeLogin(String loginUsername,String loginPassword) throws InterruptedException, AWTException
	{
		//driver.switchTo().alert().sendKeys("test5" + Keys.TAB + "jio@2020" +Keys.TAB + Keys.ENTER );
		robot.keyPress(KeyEvent.VK_T);
        robot.keyPress(KeyEvent.VK_E);
        robot.keyPress(KeyEvent.VK_S);
        robot.keyPress(KeyEvent.VK_T);
        robot.keyPress(KeyEvent.VK_4);
        ROBOTACTION("TAB", 1);
        
        robot.keyPress(KeyEvent.VK_J);
        robot.keyPress(KeyEvent.VK_I);
        robot.keyPress(KeyEvent.VK_O);
        ROBOTACTION("PRESS_SHIFT", 1);	
        robot.keyPress(KeyEvent.VK_2);
        ROBOTACTION("RELEASE_SHIFT", 1);
        robot.keyPress(KeyEvent.VK_2);
        robot.keyPress(KeyEvent.VK_0);
        robot.keyPress(KeyEvent.VK_2);
        robot.keyPress(KeyEvent.VK_0);
        ROBOTACTION("ENTER", 1);
	}
	
	public static void ROBOTACTION(String KEY , int n) throws InterruptedException, AWTException {
		
		switch (KEY){
            case "TAB":
                for (int i=1;i<=n;i++){
                    robot.keyPress(KeyEvent.VK_TAB);
                    System.out.println("Clicked on TAB "+i+" time");
                    Thread.sleep(150);
                }
                break;
            case "PRESS_SHIFT":
                for (int i=1;i<=n;i++){
                    robot.keyPress(KeyEvent.VK_SHIFT);
                    System.out.println("Press on SHIFT "+i+" time");
                    Thread.sleep(500);
                }
                break;
            case "RELEASE_SHIFT":
                for (int i=1;i<=n;i++){
                    robot.keyRelease(KeyEvent.VK_SHIFT);
                    System.out.println("Released SHIFT "+i+" time");
                    Thread.sleep(500);
                }
                break;
            case "ENTER":
                for (int i=1;i<=n;i++){
                    robot.keyPress(KeyEvent.VK_ENTER);
                    System.out.println("CLicked on ENTER "+i+" time");
                    Thread.sleep(500);
                }
                break;
            case "DOWN":
                for (int i=1;i<=n;i++){
                    robot.keyPress(KeyEvent.VK_DOWN);
                    System.out.println("CLicked on DOWN "+i+" time");
                    Thread.sleep(500);
                }
                break;
            case "SPACE":
                for (int i=1;i<=n;i++){
                    robot.keyPress(KeyEvent.VK_SPACE);
                    System.out.println("Clicked on SPACE "+i+" time");
                    Thread.sleep(500);
                }
                break;
        }
    }
	
	public static String fetchFixedValue(String strLabel)
	{
		String xpathTemp=genericXpath.replaceAll("%%labelName", strLabel);
		
		
		return driver.findElement(By.xpath(xpathTemp)).getText();
	}
	
	
	public static String fetchFieldInputValue(String strLabel,String elementPosition)
	{
		String xpathTemp=genericInputXpath.replaceAll("%%labelName", strLabel);
		xpathTemp=xpathTemp.replaceAll("%%ElementPosition", elementPosition);
		
		return driver.findElement(By.xpath(xpathTemp)).getAttribute("value");
	}
	
	public static void writeFieldInputValue(String strLabel,String elementPosition,String valueToEnter)
	{
		String xpathTemp=genericInputXpath.replaceAll("%%labelName", strLabel);
		xpathTemp=xpathTemp.replaceAll("%%ElementPosition", elementPosition);
		
		
		driver.findElement(By.xpath(xpathTemp)).sendKeys(valueToEnter);
	}
	
	public static void clickRadioButton(String strLabel,String elementPosition)
	{
		String xpathTemp=genericInputXpath.replaceAll("%%labelName", strLabel);
		xpathTemp=xpathTemp.replaceAll("%%ElementPosition", elementPosition);
		
		
		driver.findElement(By.xpath(xpathTemp)).click();
	}
	
	public static void selectCheckbox(String strLabel,String elementPosition)
	{
		String xpathTemp=genericInputXpath.replaceAll("%%labelName", strLabel);
		xpathTemp=xpathTemp.replaceAll("%%ElementPosition", elementPosition);
		
		
		driver.findElement(By.xpath(xpathTemp)).click();
	}
	public static void selectFieldValue(String strLabel,String textToSelect)
	{
		String xpathTemp=genericSelectXpath.replaceAll("%%labelName", strLabel);
		Select select=new Select(driver.findElement(By.xpath(xpathTemp)));
		select.selectByVisibleText(textToSelect);
	}
	
	public static boolean isAlertPresent() 
	{ 
	    try 
	    { 
	        driver.switchTo().alert(); 
	        return true; 
	    }   // try 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }   // catch 
	}
	
	public static void clickIfAlertExist()
	{
		if(isAlertPresent())
		{
			Alert alert = driver.switchTo().alert();
			alert.accept();
		}
	}
	public static void goToShortCutMenu(String strFinMenu)
	{
		driver.findElement(By.xpath("//*[@id='menuName']")).sendKeys(strFinMenu);
		driver.findElement(By.xpath("//*[@id='gotomenu']")).click();
		
		clickIfAlertExist();
	}
}
