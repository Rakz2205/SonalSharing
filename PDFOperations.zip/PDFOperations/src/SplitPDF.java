import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;

import java.io.File; 
import java.io.IOException; 

import java.util.List; 
import java.util.Iterator; 

public class SplitPDF {

	public static void main(String[] args) throws IOException, COSVisitorException {
		
		// TODO Auto-generated method stub
		
		String pdfFolderPath="C:\\Rakesh\\My Docs\\Fuel and toll tax";
		
		String parentPdfFileName="petrol 5-12 500.pdf";
		
		String pdfOutputFolderPath="C:\\Rakesh\\My Docs\\Fuel and toll tax\\Splitted";
		
		System.out.println(pdfFolderPath+"\\"+parentPdfFileName);
		
		File file = new File(pdfFolderPath+"\\"+parentPdfFileName); 
	    PDDocument doc = PDDocument.load(file);
	    
	  //Instantiating Splitter class 
	      Splitter splitter = new Splitter(); 
	      
	      //splitting the pages of a PDF document 
	      List<PDDocument> Pages = splitter.split(doc); 

	      //Creating an iterator 
	      Iterator<PDDocument> iterator = Pages.listIterator();         

	      //Saving each page as an individual document 
	      int i = 1; 
	      
	      while(iterator.hasNext()){ 
	         PDDocument pd = iterator.next(); 
	         pd.save(pdfOutputFolderPath+"\\"+parentPdfFileName+"_"+i+".pdf"); 
	         i++;
	      } 
	      System.out.println("PDF splitted");  
		
	}

}
