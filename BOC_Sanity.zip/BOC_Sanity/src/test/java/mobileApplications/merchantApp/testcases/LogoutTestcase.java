package mobileApplications.merchantApp.testcases;
/**
 * To perform Logout Functionality
 *
 * @author Sneha Dasari
 */

import mobileApplications.merchantApp.appPages.LandingPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerApp.class, utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LogoutTestcase extends BaseClass {
    LandingPage landingPage;

    public LogoutTestcase() {

    }

    @BeforeMethod
    public void setUp() {
        landingPage = new LandingPage();
    }

    @Test
    public void TestLogout() {
        extent = ExtentTestManager.startTest("APP Automation :-- Merchant App    " + "\n" + " Logout in Merchant App", "Logout Test");
        landingPage.doLogout();
    }

    @AfterMethod
    public void tearDown() {
        androidDriver.quit();
    }

}

