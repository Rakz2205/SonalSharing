package mobileApplications.merchantApp.testcases;
/**
 * To verify the data displayed on Profile
 *
 * @author Sneha Dasari
 */
import mobileApplications.merchantApp.appPages.LandingPage;
import mobileApplications.merchantApp.appPages.ProfilePage;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ProfileTestcase  extends BaseClass
{
    LandingPage landingPage;
    ProfilePage profilePage;

    public ProfileTestcase()
    {

    }

    @BeforeMethod
    public void setUp()
    {
        landingPage = new LandingPage();
        profilePage=new ProfilePage();
    }

    @Test
    public void CheckProfileDetails() {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant App"+"\n"+" Check Profile details in Merchant App","check profile details Test");
        LogManager.getLogger(LoginTestcase.class).info("In Login");
        landingPage.goToProfilePage();
        profilePage.checkProfileDetails(merchantAppPro.getProperty("ProfileName"),merchantAppPro.getProperty("ProfileMobileno"),merchantAppPro.getProperty("ProfileEmail"),merchantAppPro.getProperty("ProfileDOB"),
                merchantAppPro.getProperty("ProfileGender"),merchantAppPro.getProperty("ProfileTID"),merchantAppPro.getProperty("ProfileMID"));
    }
}
