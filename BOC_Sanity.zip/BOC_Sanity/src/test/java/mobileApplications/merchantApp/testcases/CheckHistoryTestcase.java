package mobileApplications.merchantApp.testcases;
/**
 * To Verify the History and apply filters
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.merchantApp.appPages.LandingPage;
import mobileApplications.merchantApp.appPages.TransactionPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class CheckHistoryTestcase  extends BaseClass {
    LandingPage landingPage;
    TransactionPage transactionPage;

    public CheckHistoryTestcase() {

    }

    @BeforeMethod
    public void setUp() throws IOException {
        landingPage = new LandingPage();
        transactionPage=new TransactionPage();
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
    }

    @Test
    public void VerifySalesTab() {
        extent= ExtentTestManager.startTest("Merchant APP: Verify Sales History in Merchant APP","MPOS App");
        landingPage.goToHistoryPage();
        transactionPage.checkForSalesTab();
        transactionPage.applyFilter();
    }

    @Test
    public void VerifyPaidTab() {
        extent= ExtentTestManager.startTest("Merchant APP: Verify Paid History in Merchant APP","MPOS App");
        landingPage.goToHistoryPage();
        transactionPage.checkForPaidTab();
        transactionPage.applyFilter();
    }

    @Test
    public void VerifyStatementTab() {
        extent= ExtentTestManager.startTest("Merchant APP: Verify Statement History in Merchant APP","MPOS App");
        landingPage.goToHistoryPage();
        transactionPage.checkForStatementTab();
        transactionPage.applyFilter();
    }
}
