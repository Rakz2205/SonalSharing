package mobileApplications.merchantApp.testcases;
/**
 * To perform help related testcases
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.merchantApp.appPages.HelpPage;
import mobileApplications.merchantApp.appPages.LandingPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class VerifyHelpTestcase extends BaseClass
{
    LandingPage landingPage;
    HelpPage helpPage;

    public VerifyHelpTestcase()
    {

    }

    @BeforeMethod
    public void setUp() throws IOException
    {
        landingPage = new LandingPage();
        helpPage=new HelpPage();
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
    }

    @Test
    public void verifyHelpEmailModule()
    {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant App"+"\n"+" Verify email module in Merchant App","Verify email module Test");
        landingPage.goToHelpPage();
        helpPage.verifyEmail();
    }

    @Test(dependsOnMethods = "verifyHelpEmailModule")
    public void verifyHelpCallModule() {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant App"+"\n"+" Verify call module in Merchant App","Verify call module in Merchant App");
        helpPage.verifyCallSupport();
    }

    @Test(dependsOnMethods = "verifyHelpCallModule")
    public void verifyHelpFaqModule() {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant App"+"\n"+"Verify FAQ module in Merchant App","Verify FAQ module in Merchant App");
        helpPage.verifyFaqs();
    }
}
