package mobileApplications.merchantApp.testcases;
/**
 * To perform Login Testcase
 *
 * @author Sneha Dasari
 */
import mobileApplications.merchantApp.appPages.LoginPage;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoginTestcase extends BaseClass {
    LoginPage login;

    public LoginTestcase() {

    }

    @BeforeMethod
    public void setUp() {
        merchantAppsInstallation("MPOS");
        merchantAppLaunch();
        login = new  LoginPage();
    }

    @Test
    public void Test(){
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant App"+"\n"+" Login in Merchant App","Login Test");
        LogManager.getLogger(LoginTestcase.class).info("In Login");
        LogManager.getLogger(LoginTestcase.class).info(merchantAppPro.getProperty("mobile_no"));
        login.doLogin(merchantAppPro.getProperty("mobile_no"),merchantAppPro.getProperty("password"),merchantAppPro.getProperty("merchantStorename"));
    }

}
