package mobileApplications.merchantApp.testcases;
/**
 * To perform Forget Password Functionality
 *
 * @author Sneha Dasari
 */
import mobileApplications.merchantApp.appPages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ForgetPasswordTestcase extends BaseClass {
   LoginPage loginPage;

    public ForgetPasswordTestcase() {

    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage=new LoginPage();

    }

    @Test
    public void forgetPasswordTest()
    {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant APP"+"\n"+" Forget Password in Merchant APP","Forget Password Test");
        loginPage.forgetPassword(merchantAppPro.getProperty("mobile_no"),merchantAppPro.getProperty("forgetNewPassword"),merchantAppPro.getProperty("merchantStorename"));
    }
}
