package mobileApplications.merchantApp.testcases;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.merchantApp.appPages.LandingPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.io.IOException;
/**
 * To perform Change Password Functionality
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangePasswordTestcase extends BaseClass {
    LandingPage landingPage;

    public ChangePasswordTestcase() {

    }

    @BeforeMethod
    public void setUp() {

        landingPage = new LandingPage();
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
    }

    @Test
    public void changePasswordTest()
    {
        extent= ExtentTestManager.startTest("APP Automation :-- Merchant APP"+"\n"+" Change Password in Merchant APP","Change Passsword Test");
        landingPage.changePassword(merchantAppPro.getProperty("password"),merchantAppPro.getProperty("ChangingPwd"));
    }
}
