package mobileApplications.jpbApp.testcases;


import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpbApp.entity.*;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static mobileApplications.jpbApp.jpbUtils.Constants.HOME;
import static mobileApplications.jpbApp.jpbUtils.Constants.SENDMONEY;
/**
 * To perform IMPS transactional testcase
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class IMPSTransactionTest extends BaseClass {

    HomeEntity homeEntity;
    LoginEntity loginEntity;
    SendMoneyEntity sendMoneyEntity;
    SendMoneyReviewEntity sendMoneyReviewEntity;
    ChangeMPINEntity changeMPINEntity;
    TransactionResultEntity transactionResultEntity;
    HistoryEntity historyEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;

    public IMPSTransactionTest() {
        //super();
    }

    @BeforeMethod
    public void BeginTest()
    {
        loginEntity = new LoginEntity();
        homeEntity = new HomeEntity();
        sendMoneyEntity = new SendMoneyEntity();
        sendMoneyReviewEntity = new SendMoneyReviewEntity();
        changeMPINEntity = new ChangeMPINEntity();
        transactionResultEntity= new TransactionResultEntity();
    }

    //Verifying the IMPS Transfer Functionality
    @Test
    public void VerifyIMPSTransaction()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the IMPS Transfer Functionality","Jio Payments Bank - Transactional Testcase");
        //loginEntity.loginToJPB();

        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(SENDMONEY);

        sendMoneyEntity.sendMoney(JPBAppPro.getProperty("bankAccountNumber"), Constants.TransactionType.IMPS_OUTWARD);
        sendMoneyReviewEntity.reviewTransaction();
        //waitFor(15);
        changeMPINEntity.enterMPIN();

        txnResult = transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in IMPS
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        //Verifying the Transaction History Details
        historyEntity.getTxnHistoryDetails("IMPS",JPBAppPro.getProperty("impsAmount"));

    }

}
