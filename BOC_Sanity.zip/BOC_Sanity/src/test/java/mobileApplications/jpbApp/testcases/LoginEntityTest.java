package mobileApplications.jpbApp.testcases;

import org.apache.logging.log4j.LogManager;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.*;
import utilityLibrary.reports.Listeners.TestListenerApp;
import webPortals.agentPortal.testcases.LoadOwnTradingBalTestcase;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
/**
 * To perform Login testcase
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoginEntityTest extends BaseClass
{
    LoginEntity loginEntity;
    //ExtentTest extent;
    public LoginEntityTest()
    {
        super();
    }

    @BeforeClass
    public void BeginTest()
    {
        JPBAppLaunch();
        loginEntity = new LoginEntity();
    }

    @Test
    public void VerifyLogin()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Login Functionality","Jio Payments Bank - Non Transactional Testcase");
        loginEntity.loginToJPB();
        LogManager.getLogger(LoginEntityTest.class).info("Login Entity Test Passed");
    }

}
