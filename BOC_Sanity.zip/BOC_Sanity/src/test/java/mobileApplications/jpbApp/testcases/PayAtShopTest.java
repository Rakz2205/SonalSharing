package mobileApplications.jpbApp.testcases;

import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.HistoryEntity;
import mobileApplications.jpbApp.entity.LoginEntity;
import mobileApplications.jpbApp.entity.PayAtShopEntity;
import mobileApplications.jpbApp.entity.TransactionResultEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static utilityLibrary.testData.Constants.UPI_HANDLE;

/**
 * To perform Pay At Shop transactional testcase
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class PayAtShopTest extends BaseClass
{
    LoginEntity loginEntity;
    PayAtShopEntity payAtShopEntity;
    TransactionResultEntity transactionResultEntity;
    HistoryEntity historyEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;
    public PayAtShopTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {
        //JPBAppLaunch();
        loginEntity = new LoginEntity();
        //loginEntity.loginToJPB();
        payAtShopEntity = new PayAtShopEntity();
        transactionResultEntity = new TransactionResultEntity();
    }

    //Verifying the Pay At Shop(Merchant Pay) Functionality
    @Test
    public void VerifyPayAtShop()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Pay At Shop(Merchant Pay) Functionality","Jio Payments Bank - Transactional Testcase");
        payAtShopEntity.performMerchantTransaction(JPBAppPro.getProperty("MerchantNumber"));
        txnResult=transactionResultEntity.checkForSuceessScreen();
        payAtShopTxnId = getTextfromElement(transactionResultEntity.txnID);
        LogManager.getLogger(PayAtShopTest.class).info("Pay At Shop Txn Id: "+payAtShopTxnId);
        payAtShopDate = getTextfromElement(transactionResultEntity.txnDate);
        LogManager.getLogger(PayAtShopTest.class).info("Pay At Shop Date: "+payAtShopDate);

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in IMPS
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("MerchantAmount"));

    }

    //Verifying the Pay At Shop(Merchant Pay) Functionality
    @Test
    public void VerifyPayAtShopUPI()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Pay At Shop(Merchant Pay) Functionality","Jio Payments Bank - Transactional Testcase");
        payAtShopEntity.performMerchantTransaction(UPI_HANDLE);
        txnResult=transactionResultEntity.checkForSuceessScreen();
        upiTxnId = getTextfromElement(transactionResultEntity.txnID);
        LogManager.getLogger(PayAtShopTest.class).info("Pay At Shop Upi Txn Id: "+upiTxnId);
        upiTxnDate = getTextfromElement(transactionResultEntity.txnDate);
        LogManager.getLogger(PayAtShopTest.class).info("Pay At Shop Date: "+upiTxnDate);

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in IMPS
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("MerchantAmount"));

    }

}
