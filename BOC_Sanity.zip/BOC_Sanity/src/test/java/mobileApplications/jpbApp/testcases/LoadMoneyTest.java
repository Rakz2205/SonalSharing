package mobileApplications.jpbApp.testcases;


import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpbApp.entity.HistoryEntity;
import mobileApplications.jpbApp.entity.LoadMoneyEntity;
import mobileApplications.jpbApp.entity.LoginEntity;
import mobileApplications.jpbApp.entity.TransactionResultEntity;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static mobileApplications.jpbApp.jpbUtils.Constants.DEBITCARD;
import static mobileApplications.jpbApp.jpbUtils.Constants.NETBANKING;
/**
 * To perform Load Money Transactional testcases
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoadMoneyTest extends BaseClass
{
    LoginEntity loginEntity;
    LoadMoneyEntity loadMoneyEntity;
    HistoryEntity historyEntity;
    TransactionResultEntity transactionResultEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;
    public LoadMoneyTest()
    {
        //super();
    }

    @BeforeMethod
    public void BeginTest()
    {
        loginEntity = new LoginEntity();
        loadMoneyEntity = new LoadMoneyEntity();
        transactionResultEntity = new TransactionResultEntity();
    }

    //Verifying the Load Money by Debit Card Functionality
    @Test
    public void VerifyLoadMoneyTestByDebitCard() {

        extent = ExtentTestManager.startTest("JPB APP: Verifying the Load Money by Debit Card Functionality","Jio Payments Bank - Transactional Testcase");
        loadMoneyEntity.performLoadMoney(DEBITCARD);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        /*//Capturing screenshot after passbook is open
        takeSnapShot("Bank Page is opened in Passbook");*/

        historyEntity.getTxnHistoryDetails("Add Money",JPBAppPro.getProperty("loadMoneyAmount"));

    }

    //Verifying the Load Money by NetBanking Functionality
    @Test
    public void VerifyLoadMoneyTestByNetBanking()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Load Money By NetBanking Functionality","Jio Payments Bank - Transactional Testcase");
        loadMoneyEntity.performLoadMoney(NETBANKING);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        historyEntity.getTxnHistoryDetails("Load",JPBAppPro.getProperty("loadMoneyAmount"));

    }

}
