package mobileApplications.jpbApp.testcases;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.HistoryEntity;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import utilityLibrary.reports.Listeners.TestListenerApp;
/**
 * To Verify the History and apply filter
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class HistoryTest extends BaseClass
{
    LoginEntity loginEntity;
    HistoryEntity historyEntity;
    //ExtentTest extent;
    public HistoryTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {
        //JPBAppLaunch();
        loginEntity = new LoginEntity();
        //loginEntity.loginToJPB();
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
        historyEntity=new HistoryEntity();

    }

    //Verifying the Bank Tab in Passbook
    @Test
    public void VerifyTodayBankHistory()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Bank Tab in Passbook","Jio Payments Bank - Non Transactional Testcase");
        historyEntity.TodayHistory("Bank");
    }

    //Verifying the Payments Tab in Passbook
    @Test
    public void VerifyTodayPaymentsHistory()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Payments Tab in Passbook","Jio Payments Bank - Non Transactional Testcase");
        historyEntity.TodayHistory("Payments");
    }

    //Verifying the UPI Tab in Passbook
    @Test
    public void VerifyTodayUPIHistory()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the UPI Tab in Passbook","Jio Payments Bank - Non Transactional Testcase");
        historyEntity.TodayHistory("UPI");
    }

    //Verifying the Custom Filters of Bank Tab in Passbook
    @Test
    public void VerifyCustomBankHistory(){
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Custom Filters of Bank Tab in Passbook","Jio Payments Bank - Non Transactional Testcase");
        historyEntity.CustomFilterHistory("Bank");
    }

    //Verifying the Custom Filters of Payments Tab in Passbook
    @Test
    public void VerifyCustomPaymentsHistory()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Custom Filters of Payments Tab in Passbook","Jio Partner Merchant App");
        historyEntity.CustomFilterHistory("Payments");
    }

    //Verifying the Custom Filters of UPI Tab in Passbook
    @Test
    public void VerifyCustomUPIHistory()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Custom Filters of UPI Tab in Passbook","Jio Partner Merchant App");
        historyEntity.CustomFilterHistory("UPI");
    }

}
