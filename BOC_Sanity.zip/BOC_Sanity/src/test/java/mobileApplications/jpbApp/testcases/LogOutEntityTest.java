package mobileApplications.jpbApp.testcases;
/**
 * To perform Logout from Application testcase
 *
 * @author Sneha Dasari
 */
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.*;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LogOutEntityTest extends BaseClass
{
    LoginEntity loginEntity;
    //ExtentTest extent;
    public LogOutEntityTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {

        //JPBAppLaunch();
        loginEntity = new LoginEntity();
    }

    @Test
    public void VerifyLogout()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Logout Functionality","Jio Payments Bank - Non Transactional Testcase");
        //loginEntity.loginToJPB();
        loginEntity.logoutfromJPB();
    }

    @AfterMethod
    public void tearDown()
    {
        androidDriver.quit();
    }

}
