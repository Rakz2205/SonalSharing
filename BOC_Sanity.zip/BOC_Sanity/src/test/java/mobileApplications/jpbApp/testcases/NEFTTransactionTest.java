package mobileApplications.jpbApp.testcases;


import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpbApp.entity.*;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static mobileApplications.jpbApp.jpbUtils.Constants.HOME;
import static mobileApplications.jpbApp.jpbUtils.Constants.SENDMONEY;
/**
 * To perform NEFT transactional testcase
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class NEFTTransactionTest extends BaseClass {

    HomeEntity homeEntity;
    LoginEntity loginEntity;
    SendMoneyEntity sendMoneyEntity;
    SendMoneyReviewEntity sendMoneyReviewEntity;
    ChangeMPINEntity changeMPINEntity;
    HistoryEntity historyEntity;
    TransactionResultEntity transactionResultEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;

    public NEFTTransactionTest() {
        //super();
    }

    @BeforeMethod
    public void BeginTest()
    {
        //JPBAppLaunch();
        loginEntity = new LoginEntity();
        homeEntity = new HomeEntity();
        sendMoneyEntity = new SendMoneyEntity();
        sendMoneyReviewEntity = new SendMoneyReviewEntity();
        changeMPINEntity = new ChangeMPINEntity();
        transactionResultEntity = new TransactionResultEntity();
    }

    //Verifying the NEFT Transfer Functionality
    @Test
    public void VerifyNEFTTransaction()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the NEFT Transfer Functionality","Jio Payments Bank - Transactional Testcase");
        //loginEntity.loginToJPB();
        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(SENDMONEY);
        sendMoneyEntity.sendMoney(JPBAppPro.getProperty("bankAccountNumber"), Constants.TransactionType.NEFT_OUTWARD);
        sendMoneyReviewEntity.reviewTransaction();
        //waitFor(15);
        changeMPINEntity.enterMPIN();
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in NEFT
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        historyEntity.getTxnHistoryDetails("NEFT",JPBAppPro.getProperty("impsAmount"));

    }

}
