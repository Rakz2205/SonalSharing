package mobileApplications.jpbApp.testcases;

/**
 * To perform MPIN related testcases
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.ChangeMPINEntity;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangeMPINEntityTest extends BaseClass
{
    ChangeMPINEntity changeMPINEntity;
    LoginEntity loginEntity;

    public ChangeMPINEntityTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {
        JPBAppLaunch();
        changeMPINEntity = new ChangeMPINEntity();
        loginEntity = new LoginEntity();
    }

    //Verifying the Change Mpin Functionality
    @Test
    public void VerifyChangeMPIN()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Change MPIN Functionality","Jio Payments Bank - Non Transactional Testcase");
        loginEntity.loginToJPB();
        changeMPINEntity.changeMPIN();
    }

    @Test
    public void VerifyForgetMPIN()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Forgot MPIN Functionality","Jio Payments Bank - Non Transactional Testcase");
        changeMPINEntity.forgetMPIN();
    }


}
