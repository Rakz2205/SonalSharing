package mobileApplications.jpbApp.testcases;

import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpbApp.entity.*;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static mobileApplications.jpbApp.jpbUtils.Constants.HOME;
import static mobileApplications.jpbApp.jpbUtils.Constants.SENDMONEY;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class UPITransactionTest extends BaseClass {

    HomeEntity homeEntity;
    LoginEntity loginEntity;
    SendMoneyEntity sendMoneyEntity;
    SendMoneyReviewEntity sendMoneyReviewEntity;
    NPCIEntity npciEntity;
    TransactionResultEntity transactionResultEntity;
    HistoryEntity historyEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;

    public UPITransactionTest() {
        //super();
    }

    @BeforeMethod
    public void BeginTest()
    {
        //JPBAppLaunch();
        loginEntity = new LoginEntity();
        homeEntity = new HomeEntity();
        sendMoneyEntity = new SendMoneyEntity();
        sendMoneyReviewEntity = new SendMoneyReviewEntity();
        npciEntity = new NPCIEntity();
        transactionResultEntity= new TransactionResultEntity();
    }


    //Verifying the UPI Functionality
    @Test
    public void VerifyUPITransaction() {

        extent = ExtentTestManager.startTest("JPB APP: Verifying the UPI Functionality","Jio Payments Bank - Transactional Testcase");
        //loginEntity.loginToJPB();
        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(SENDMONEY);
        sendMoneyEntity.sendMoney(JPBAppPro.getProperty("bankAccountNumber"), Constants.TransactionType.UPI_SENDMONEY);
        sendMoneyReviewEntity.reviewTransactionforUPI();
        //waitFor(15);
        npciEntity.enterUPIPin();
        //npciEntity.enterUPIPin();
        //waitFor(60);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in IMPS
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Bank");

        historyEntity.getTxnHistoryDetails("UPI",JPBAppPro.getProperty("MerchantAmount"));
    }

}
