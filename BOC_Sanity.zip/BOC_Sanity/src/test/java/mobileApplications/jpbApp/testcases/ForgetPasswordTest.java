package mobileApplications.jpbApp.testcases;
/**
 * To perform Forget Password Functionality
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.ForgetPasswordEntity;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.*;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ForgetPasswordTest extends BaseClass
{
    ForgetPasswordEntity forgetPasswordEntity;
    //ExtentTest extent;
    LoginEntity loginEntity;
    public ForgetPasswordTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {
        //JPBAppLaunch();
        forgetPasswordEntity = new ForgetPasswordEntity();
        loginEntity = new LoginEntity();
    }

    //Verifying the Forget Password Functionality
    @Test
    public void VerifyForgetPassword()  {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Forget Password Functionality","Jio Payments Bank - Non Transactional Testcase");
        loginEntity.forgetPasswordInit();
        forgetPasswordEntity.forgetPassword();
        loginEntity.loginToJPB();
    }


}
