package mobileApplications.jpbApp.testcases;

import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpbApp.entity.*;
import org.apache.logging.log4j.LogManager;
import utilityLibrary.base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class BillPaymentTest extends BaseClass {

    HomeEntity homeEntity;
    BillPaymentEntity billPaymentEntity;
    LoginEntity loginEntity;
    HistoryEntity historyEntity;
    TransactionResultEntity transactionResultEntity;
    //ExtentTest extent;
    int flag;
    boolean txnResult;

    public BillPaymentTest() {

    }

    @BeforeMethod
    public void BeginTest()
    {
        loginEntity = new LoginEntity();
        homeEntity = new HomeEntity();
        billPaymentEntity = new BillPaymentEntity();
        transactionResultEntity = new TransactionResultEntity();
    }

    //Verifying Prepaid Mobile Recharge By NetBanking
    @Test
    public void VerifyPrepaidRechargeByNetBanking() {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Prepaid Mobile Recharge By NetBanking","Bill Pay Transactions");
        LogManager.getLogger(BillPaymentTest.class).info("\n BILL PAYMENT FOR : " + MOBILEPREPAID);

        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(MOBILE);
        billPaymentEntity.billPayment(MOBILEPREPAID,NETBANKING);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in Mobile Recharge
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Payments");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("prepaidAmount"));


    }

    //Verifying Prepaid Mobile Recharge By Debit Card
    @Test
    public void VerifyPrepaidRechargeByDebitCard() {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Prepaid Mobile Recharge By Debit Card","Bill Pay Transactions");
        LogManager.getLogger(BillPaymentTest.class).info("\n BILL PAYMENT FOR : " + MOBILEPREPAID);
        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(MOBILE);
        billPaymentEntity.billPayment(MOBILEPREPAID,DEBITCARD);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in Mobile Recharge
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Payments");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("prepaidAmount"));


    }

    //Verifying Prepaid Mobile Recharge By Wallet
    @Test
    public void VerifyPrepaidByWALLET() {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Prepaid Mobile Recharge By Wallet","Bill Pay Transactions");
        LogManager.getLogger(BillPaymentTest.class).info("\n BILL PAYMENT FOR : " + MOBILEPREPAID);
        //loginEntity.loginToJPB();
        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(MOBILE);
        billPaymentEntity.billPayment(MOBILEPREPAID,WALLET);
        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in Mobile Recharge
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Payments");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("prepaidAmount"));

    }

    //Verifying Postpaid Mobile Recharge By Wallet
    //@Test
    public void VerifyPostpaidByWALLET(){
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Postpaid Mobile Recharge By Wallet","Bill Pay Transactions");
        LogManager.getLogger(BillPaymentTest.class).info("\n BILL PAYMENT FOR : " + MOBILEPOSTPAID);
        //loginEntity.loginToJPB();
        homeEntity.navigateToPage(HOME);
        homeEntity.navigateToPage(MOBILE);
        billPaymentEntity.billPayment(MOBILEPOSTPAID,WALLET);

        txnResult=transactionResultEntity.checkForSuceessScreen();

        //Clicking on the HomeButton
        transactionResultEntity.clickHomeButton(txnResult);

        //Checking the Passbook after Transaction is completed successfully in Mobile Recharge
        historyEntity = new HistoryEntity();
        historyEntity.selectTab("Payments");

        historyEntity.getTxnHistoryDetails("Payment",JPBAppPro.getProperty("postpaidAmount"));


    }

}
