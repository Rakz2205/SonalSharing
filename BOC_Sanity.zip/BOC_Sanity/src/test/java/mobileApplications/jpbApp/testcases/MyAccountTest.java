package mobileApplications.jpbApp.testcases;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.LoginEntity;
import mobileApplications.jpbApp.entity.MyAccountEntity;
import org.testng.Assert;
import org.testng.annotations.*;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import static utilityLibrary.testData.Constants.*;

/**
 * To Verify the Profile Data on My Account Page
 *
 * @author Sneha Dasari
 */
@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class MyAccountTest extends BaseClass
{
    MyAccountEntity myAccountEntity;
    LoginEntity loginEntity;
    //ExtentTest extent;
    public MyAccountTest()
    {
        //super();
    }

    @BeforeClass
    public void BeginTest()
    {
        //JPBAppLaunch();
        loginEntity = new LoginEntity();
        myAccountEntity= new MyAccountEntity();
        //loginEntity.loginToJPB();
        myAccountEntity.myAccountDetails();
    }

    //Verifying the Change Marital Status in My Account Functionality
    @Test
    public void VerifyMaritalStatusChange() {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Change Marital Status in My Account Functionality","Jio Payments Bank - Non Transactional Testcase");
        myAccountEntity.changeMaritalStatus("Single");

        myAccountEntity.getMaritalStatusAfterChange("MARRIED");
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));

        myAccountEntity.changeMaritalStatus("Married");

        myAccountEntity.getMaritalStatusAfterChange("SINGLE");
    }

    //Verifying the Change Email Id in My Account Functionality
    @Test
    public void VerifyEmailIDChange() {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Change Email Id in My Account Functionality","Jio Payments Bank - Non Transactional Testcase");
        myAccountEntity.changeEmail(JPBAppPro.getProperty("tempEmail"));

        myAccountEntity.getEmailTextAFterChange(JPBAppPro.getProperty("tempEmail"));
        myAccountEntity.changeEmail(JPBAppPro.getProperty("email"));

        myAccountEntity.getEmailTextAFterChange(JPBAppPro.getProperty("email"));
    }

    //Verifying the Details in My Account Functionality
    @Test
    public void VerifyDetails()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Details in My Account Functionality","Jio Payments Bank - Non Transactional Testcase");
        myAccountEntity.getSavingsAcNum();
        myAccountEntity.getBankIFSC();
        myAccountEntity.getMID();
        myAccountEntity.getCKYCID();
    }

}
