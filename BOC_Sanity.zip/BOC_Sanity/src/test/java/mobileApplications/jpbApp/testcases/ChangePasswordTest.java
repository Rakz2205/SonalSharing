package mobileApplications.jpbApp.testcases;
/**
 * To perform Change Password Functionality
 *
 * @author Sneha Dasari
 */
import mobileApplications.jpbApp.entity.ChangePasswordEntity;
import org.testng.annotations.Listeners;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import mobileApplications.jpbApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangePasswordTest extends BaseClass
{
    ChangePasswordEntity changePasswordEntity;
    LoginEntity loginEntity;
    //ExtentTest extent;
    public ChangePasswordTest()
    {
        //super();
    }

    @BeforeMethod
    public void BeginTest()
    {
        //JPBAppLaunch();
        changePasswordEntity = new ChangePasswordEntity();
        loginEntity = new LoginEntity();
    }

    //Verifying the Change Password Functionality
    @Test
    public void VerifyChangePassword()
    {
        extent = ExtentTestManager.startTest("JPB APP: Verifying the Change Password Functionality","Jio Payments Bank - Non Transactional Testcase");
        //loginEntity.loginToJPB();
       changePasswordEntity.changePassword();
    }


}
