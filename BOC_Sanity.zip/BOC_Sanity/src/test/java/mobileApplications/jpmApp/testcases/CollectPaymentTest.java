package mobileApplications.jpmApp.testcases;
/**
 * To perform Collect Payment transactional testcase
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpmApp.entity.CollectPaymentEntity;
import mobileApplications.jpmApp.entity.LoginEntity;

import mobileApplications.jpmApp.entity.TxnHistoryEntity;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.*;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import static mobileApplications.jpmApp.entity.CollectPaymentEntity.*;
import static mobileApplications.jpmApp.entity.CollectPaymentEntity.barcodeValue;
import static utilityLibrary.testData.Constants.*;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class CollectPaymentTest extends BaseClass
{

    LoginEntity loginEntity;
    CollectPaymentEntity collectPaymentEntity;
    TxnHistoryEntity txnHistoryEntity;

    public CollectPaymentTest()
    {


    }

    @BeforeClass
    public void BeginTest()
    {

    }

    @Test
    public void VerifyBarCode()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Profile Functionality","Jio Partner Merchant App");

        JPBAppLaunch();

        //Getting barcode value from JPB to proceed with the payment
        collectPaymentEntity = new CollectPaymentEntity();
        collectPaymentEntity.getBarcodeValueFromJPB();


    }

    @Test
    public void VerifyCollectPayment()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Profile Functionality","Jio Partner Merchant App");

        JPMAppLaunchNoReset();

        //Performing Collect Payment
        collectPaymentEntity = new CollectPaymentEntity();
        collectPaymentEntity.performCollectPayment(barcodeValue);

        //Verifying Transaction History for transaction
        txnHistoryEntity = new TxnHistoryEntity();
        txnHistoryEntity.getTxnHistoryDetails("JioMoney",amountReceivedCPVar);

        //Performing Refund
        txnHistoryEntity.performRefundForPayAtShop(transactionIDCPVar,amountReceivedCPVar,"Jio Money");

        txnHistoryEntity.getRefundDetails(amountReceivedCPVar);
    }

    @AfterTest
    public void tearDown()
    {
        androidDriver.quit();
    }

}
