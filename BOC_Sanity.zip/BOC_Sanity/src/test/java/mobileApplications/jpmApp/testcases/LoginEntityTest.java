package mobileApplications.jpmApp.testcases;
/**
 * To perform Login testcase
 *
 * @author Sneha Dasari
 */

import mobileApplications.jpmApp.entity.LoginEntity;
import mobileApplications.jpmApp.entity.SearchMIDEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.FileNotFoundException;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoginEntityTest extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    //ExtentTest extent;
    public LoginEntityTest()
    {


    }

    @BeforeClass
    public void BeginTest()  {
        merchantAppsInstallation("JPM");
        JPMAppLaunch();
        loginEntity = new LoginEntity();
    }


    @Test
    public void VerifyLogin()  {
        extent = ExtentTestManager.startTest("APP Automation  JPM APP: Verifying the Login Functionality","Jio Partner Merchant App");
        loginEntity.loginToJPM();
    }

    //@Test
    public void VerifyLogout()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Logout Functionality","Jio Partner Merchant App");
        loginEntity.logoutFromJPM();
    }
}
