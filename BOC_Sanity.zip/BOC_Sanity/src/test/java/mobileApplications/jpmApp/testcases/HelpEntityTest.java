package mobileApplications.jpmApp.testcases;
/**
 * To perform Help testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import mobileApplications.jpmApp.entity.HelpEntity;
import mobileApplications.jpmApp.entity.LoginEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class HelpEntityTest extends BaseClass
{
    HelpEntity helpEntity;
    LoginEntity loginEntity;
    //ExtentTest extent;
    public HelpEntityTest()
    {

    }

    @BeforeClass
    public void BeginTest()
    {
        //JPMAppLaunch();
        //loginEntity = new LoginEntity();
        /*androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));*/
        JPMAppLaunchNoReset();
    }

    @Test
    public void VerifyEmailUs()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Help: Email Us Functionality","Jio Partner Merchant App");
        helpEntity.emailUs();
    }

    @Test
    public void VerifyCallSupport()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Help: Call Support Functionality","Jio Partner Merchant App");
        helpEntity = new HelpEntity();
        helpEntity.clickOnHelp();
        helpEntity.callSupport();
    }

    @Test
    public void VerifyFAQS()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Help: FAQs Functionality","Jio Partner Merchant App");

        helpEntity.faqs();

        helpEntity.faqsTab();

    }

    @Test
    public void VerifyTutorialinFAQS()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Help: Tutorial Videos Functionality","Jio Partner Merchant App");
        helpEntity.tutorialsTab();
    }

}
