package mobileApplications.jpmApp.testcases;
/**
 * To Verify Transaction History and apply filters
 *
 * @author Sneha Dasari
 */

import com.relevantcodes.extentreports.LogStatus;
import mobileApplications.jpmApp.entity.TxnHistoryEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class TxnHistoryTest extends BaseClass
{
    TxnHistoryEntity txnHistoryEntity;
    static int flag=0;
    String methodName="";
    //ExtentTest extent;
    public TxnHistoryTest()
    {

    }

    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        //androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
    }

    @Test
    public void VerifySalesTxnHistory()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Sales Transaction History Functionality","Jio Partner Merchant App");
        txnHistoryEntity.getSalesTxnHistory();
        //takeSnapShot("After Sales Transaction History");

        txnHistoryEntity.changeFilter();

        //txnHistoryEntity.performRefundForPayAtShop(upiTxnId,JPBAppPro.getProperty("MerchantAmount"),"UPI");
        txnHistoryEntity.performRefundForPayAtShop("110025713019",JPBAppPro.getProperty("MerchantAmount"),"UPI");

        txnHistoryEntity.getRefundDetails(JPBAppPro.getProperty("MerchantAmount"));
    }

    @Test
    public void VerifyPurchasesTxnHistory()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Purchases Transaction History Functionality","Jio Partner Merchant App");

        txnHistoryEntity.getPurchasesTxnHistory();
        /*takeSnapShot("After Purchase Transaction History");*/

        txnHistoryEntity.changeFilter();
    }

    @Test
    public void VerifyCustomFilters()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Custom Filters Functionality","Jio Partner Merchant App");
        txnHistoryEntity = new TxnHistoryEntity();
        txnHistoryEntity.changeFilter();
    }
}
