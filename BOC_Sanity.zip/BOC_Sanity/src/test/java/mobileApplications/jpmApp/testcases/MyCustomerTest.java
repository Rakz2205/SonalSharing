package mobileApplications.jpmApp.testcases;

import mobileApplications.jpmApp.entity.MyCustomerEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class MyCustomerTest extends BaseClass
{
    MyCustomerEntity myCustomerEntity;
    public MyCustomerTest()
    {

    }
    @BeforeClass
    public void BeginTest()
    {

        JPMAppLaunchNoReset();
        myCustomerEntity= new MyCustomerEntity();
    }

    @Test
    public void VerifyAddCustomerByIcon() {
        //initialization();
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Add Customer By Icon Functionality","Jio Partner Merchant App");
        myCustomerEntity= new MyCustomerEntity();
        myCustomerEntity.addCustomerByAddIcon(JPMAppPro.getProperty("CustomerName1"),JPMAppPro.getProperty("CustomerNumber1"));
    }

    @Test
    public void VerifyDeleteCustomer()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Delete Customer Functionality","Jio Partner Merchant App");
        myCustomerEntity.deleteAddedCustomer(JPMAppPro.getProperty("CustomerNumber1"));
    }

    @Test
    public void VerifyAddCustomerBySearchText()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Add New Customer By Search Text Functionality","Jio Partner Merchant App");
        myCustomerEntity.addCustomerByButton(JPMAppPro.getProperty("CustomerName2"),JPMAppPro.getProperty("CustomerNumber2"));
        myCustomerEntity.deleteAddedCustomer(JPMAppPro.getProperty("CustomerNumber1"));
    }


}
