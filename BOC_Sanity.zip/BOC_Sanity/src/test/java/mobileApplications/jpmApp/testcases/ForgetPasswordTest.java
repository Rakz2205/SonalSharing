package mobileApplications.jpmApp.testcases;
/**
 * To perform Forget Password testcase
 *
 * @author Sneha Dasari
 */
import mobileApplications.jpmApp.entity.ForgetPasswordEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ForgetPasswordTest extends BaseClass
{
    ForgetPasswordEntity forgetPasswordEntity;
    //ExtentTest extent;

    public ForgetPasswordTest()
    {

    }
    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        forgetPasswordEntity= new ForgetPasswordEntity();

    }

    @Test
    public void VerifyForgotPassword() {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Forget Password Functionality","Jio Partner Merchant App");
        forgetPasswordEntity.forgotPassword();
    }


}
