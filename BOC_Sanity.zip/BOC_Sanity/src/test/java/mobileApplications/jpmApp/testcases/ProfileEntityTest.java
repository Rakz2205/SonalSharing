package mobileApplications.jpmApp.testcases;
/**
 * To Verify Profile related testcases
 *
 * @author Sneha Dasari
 */
import mobileApplications.jpmApp.entity.LoginEntity;
import mobileApplications.jpmApp.entity.ProfileEntity;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ProfileEntityTest extends BaseClass
{
    ProfileEntity profileEntity;

    LoginEntity loginEntity;
    //ExtentTest extent;
    public ProfileEntityTest()
    {

    }

    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        profileEntity = new ProfileEntity();
        loginEntity = new LoginEntity();
    }

    @Test
    public void VerifyProfileDetails()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Profile Functionality","Jio Partner Merchant App");
        profileEntity.profileDetails();
        profileEntity.getProfileName();
        profileEntity.getMobileNumber();
        profileEntity.getDOB();
        profileEntity.getStoreName();
        profileEntity.getTIDNumber();
        profileEntity.getMIDNumber();
    }
}
