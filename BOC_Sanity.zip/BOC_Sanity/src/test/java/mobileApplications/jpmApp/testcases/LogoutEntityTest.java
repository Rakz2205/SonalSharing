package mobileApplications.jpmApp.testcases;

/**
 * To perform Logout from Application
 *
 * @author Sneha Dasari
 */
import mobileApplications.jpmApp.entity.LoginEntity;
import mobileApplications.jpmApp.entity.SearchMIDEntity;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LogoutEntityTest extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    //ExtentTest extent;
    public LogoutEntityTest()
    {


    }

    @BeforeMethod
    public void BeginTest(){
        //JPMAppLaunchNoReset();
        loginEntity = new LoginEntity();
    }


    @Test
    public void VerifyLogout() {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Logout Functionality","Jio Partner Merchant App");
        loginEntity.logoutFromJPM();
    }

    @AfterMethod
    public void tearDown()
    {
        androidDriver.quit();
    }
}
