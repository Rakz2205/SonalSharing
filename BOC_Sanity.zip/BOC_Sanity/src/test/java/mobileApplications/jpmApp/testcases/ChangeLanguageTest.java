package mobileApplications.jpmApp.testcases;
/**
 * To perform Change Language Testcase
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import mobileApplications.jpbApp.entity.HistoryEntity;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import mobileApplications.jpmApp.entity.ChangeLanguageEntity;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangeLanguageTest extends BaseClass
{
    ChangeLanguageEntity changeLanguageEntity;
    //ExtentTest extent;

    public ChangeLanguageTest()
    {

    }
    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        changeLanguageEntity= new ChangeLanguageEntity();

    }

    @Test
    public void VerifyChangeLanguage() {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Change Language Functionality","Jio Partner Merchant App");

        //Changing Language to Hindi
        LogManager.getLogger(ChangeLanguageTest.class).info("CHANGING LANGUAGE TO HINDI");
        changeLanguageEntity.changeLanguage("hindi","भाषा बदलें");

        //Changing Language back to English
        LogManager.getLogger(ChangeLanguageTest.class).info("CHANGING LANGUAGE BACK TO ENGLISHHHHH");
        changeLanguageEntity.swapLanguage("english","CHANGE LANGUAGE");

    }


}
