package mobileApplications.jpmApp.testcases;

/**
 * To perform Change Password testcase
 *
 * @author Sneha Dasari
 */

import mobileApplications.jpmApp.entity.ChangePasswordEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangePasswordTest extends BaseClass
{
    ChangePasswordEntity changePasswordEntity;
    //ExtentTest extent;

    public ChangePasswordTest()
    {

    }
    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        changePasswordEntity= new ChangePasswordEntity();

    }

    @Test
    public void VerifyChangePassword() {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Change Password Functionality","Jio Partner Merchant App");
        changePasswordEntity.changePassword();
    }


}
