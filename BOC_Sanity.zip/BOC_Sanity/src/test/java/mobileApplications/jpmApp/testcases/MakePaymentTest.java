package mobileApplications.jpmApp.testcases;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mobileApplications.jpmApp.entity.MakePaymentEntity;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */

@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class MakePaymentTest extends BaseClass
{
    MakePaymentEntity makePaymentEntity;
    //ExtentTest extent;
    public MakePaymentTest()
    {

    }
    @BeforeClass
    public void BeginTest()
    {
        JPMAppLaunchNoReset();
        makePaymentEntity= new MakePaymentEntity();
    }

    @Test
    public void VerifyMakePayment() {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Make Payment Functionality","Jio Partner Merchant App");
        makePaymentEntity.makePayment();
    }


}
