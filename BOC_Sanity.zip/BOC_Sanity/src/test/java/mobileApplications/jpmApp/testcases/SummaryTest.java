package mobileApplications.jpmApp.testcases;
/**
 * To Verify Summary and apply filters
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import mobileApplications.jpmApp.entity.ProfileEntity;
import mobileApplications.jpmApp.entity.SummaryEntity;
import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.asserts.SoftAssert;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerApp;


@Listeners({TestListenerApp.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class SummaryTest extends BaseClass
{
    SummaryEntity summaryEntity;
    //ExtentTest extent;
    public SummaryTest()
    {

    }

    @BeforeClass
    public void BeginTest()
    {
        /*//JPMAppLaunch();
        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));*/
        JPMAppLaunchNoReset();
    }

    @Test
    public void VerifySalesSummary()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Sales Summary Functionality","Jio Partner Merchant App");
        LogManager.getLogger(ProfileEntity.class).info("Verify Sales Summary");
        summaryEntity.getSalesSummary();

        /*summaryEntity.changeFilterToYesterday();
        takeSnapShot("After Changing Filter to Yesterday");*/

        summaryEntity.changeFilterToLastWeek();

        summaryEntity.customFilter();
        //takeSnapShot("After Changing Filter to Custom");

        summaryEntity.getJioMoneyBalance();

        softAssert.assertAll();
    }


    @Test
    public void VerifyPaidSummary()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Paid Summary Functionality","Jio Partner Merchant App");
        LogManager.getLogger(SummaryTest.class).info("Verify Paid Summary");

        summaryEntity.getPaidSummary();
        //takeSnapShot("After Verifying Paid Summary");

        /*summaryEntity.changeFilterToYesterday();
        takeSnapShot("After Changing Filter to Yesterday");*/

        summaryEntity.changeFilterToLastWeek();
        //takeSnapShot("After Changing Filter to Last Week");

        summaryEntity.customFilter();
        /*takeSnapShot("After Changing Filter to Custom");*/

        summaryEntity.getJioMoneyBalance();

        softAssert.assertAll();
    }

    @Test
    public void VerifySettlementsSummary()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Settlements Summary Functionality","Jio Partner Merchant App");

        LogManager.getLogger(SummaryTest.class).info("Verify Settlements Summary");

        /*Assert.assertTrue(summaryEntity.getSettlementsSummary().contains("₹"),"Settlements Screen not loaded Successfully");
        String d="data:image/png;base64," + ((TakesScreenshot) androidDriver).
                getScreenshotAs(OutputType.BASE64);
        ExtentTestManager.getTest().log(LogStatus.PASS, "After Verifying Settlements Summary",
                ExtentTestManager.getTest().addBase64ScreenShot(d));*/

        /*summaryEntity.changeFilterToYesterday();
        takeSnapShot("After Changing Filter to Yesterday");*/

        /*softAssert.assertTrue(summaryEntity.changeFilterToLastWeek().length()>0,"Last Week Filter Failed");
        ExtentTestManager.getTest().log(LogStatus.PASS, "After Changing Filter to Last Week",
                ExtentTestManager.getTest().addBase64ScreenShot(d));

        softAssert.assertTrue(summaryEntity.customFilter().length()>0,"Customer Filter Failed");
        ExtentTestManager.getTest().log(LogStatus.PASS, "After Changing Filter to Custom",
                ExtentTestManager.getTest().addBase64ScreenShot(d));
*/
        summaryEntity.getSettlementFilters();
        //summaryEntity.getJioMoneyBalance();
        softAssert.assertAll();
    }

    //@Test(dependsOnMethods = {"VerifySettlementsSummary","VerifyMDRandGSTDetails"})
    public void VerifySettlementDetails()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Settlements Details Functionality","Jio Partner Merchant App");
        Assert.assertTrue(summaryEntity.getSettlementDetails().contains("Txn")  || summaryEntity.getSettlementDetails().contains("Settlement Details"),"Settlements Screen not loaded Successfully");
    }

    //@Test(dependsOnMethods = {"VerifySettlementsSummary"})
    public void VerifyMDRandGSTDetails()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the MDR and GST Functionality","Jio Partner Merchant App");
        Assert.assertTrue(summaryEntity.MDRandGSTisPresent().length()>0,"MDR and GST not present");

    }

    //@Test
    public void VerifyFilterToYesterday()  {
        LogManager.getLogger(SummaryTest.class).info("VerifyFilterToYesterday");
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Apply Yesterday's Filter Functionality","Jio Partner Merchant App");
        //summaryEntity = new SummaryEntity();
        summaryEntity.changeFilterToYesterday();
    }

    @Test
    public void VerifyFilterToLastWeek()  {
        LogManager.getLogger(SummaryTest.class).info("VerifyFilterToYesterday");
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Apply Last Week Filter Functionality","Jio Partner Merchant App");
        //summaryEntity = new SummaryEntity();
        summaryEntity.changeFilterToLastWeek();
    }

    @Test
    public void VerifyCustomFilter()  {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Apply Custom Filter Functionality","Jio Partner Merchant App");
        summaryEntity = new SummaryEntity();
        summaryEntity.customFilter();
    }

    @Test
    public void VerifyJioMoneyBalance()
    {
        extent = ExtentTestManager.startTest("JPM APP: Verifying the Jio Money Balance on Summary Page Functionality","Jio Partner Merchant App");
        summaryEntity.getJioMoneyBalance();
    }

}
