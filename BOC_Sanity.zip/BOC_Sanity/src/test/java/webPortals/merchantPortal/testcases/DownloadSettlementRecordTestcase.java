package webPortals.merchantPortal.testcases;
/**
 * To perform Download Settlement Report Functionality
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.HomePage;
import webPortals.merchantPortal.webPages.ReportPage;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class DownloadSettlementRecordTestcase extends BaseClass {
    HomePage homePage;
    ReportPage reportPage;

    public DownloadSettlementRecordTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage = new HomePage();
        reportPage = new ReportPage();
    }

    @Test
    public void downloadSettlementReport() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Download Settlement Report in Merchant Portal","Download Settlement Report in Merchant Portal");
        homePage.goToReports();
        reportPage.downloadSettlementReport();
    }

    @AfterMethod
    public void tearDown()
    {
        clickElement(homePage.homePageSymbol);
    }

}
