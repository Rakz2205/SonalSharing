package webPortals.merchantPortal.testcases;
/**
 * To Verify History and Apply Filters
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.HistoryPage;
import webPortals.merchantPortal.webPages.HomePage;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class HistoryTestcase extends BaseClass {
    HomePage homePage;
    HistoryPage historyPage;

    public HistoryTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage= new HomePage();
        historyPage=new HistoryPage();
    }

    @Test
    public void viewHistory() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Check History Testcase in Merchant Portal","Check History Testcase in Merchant Portal");
        homePage.goToHistory();
        historyPage.verifyDetails();
    }

}
