package webPortals.merchantPortal.testcases;
/**
 * To perform Change Password Functionality
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import webPortals.merchantPortal.webPages.ProfilePage;


import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangePasswordTestcase extends BaseClass {
   LoginPage loginPage;
   ProfilePage profilePage;

   public ChangePasswordTestcase() {

    }

    @BeforeMethod
    public void setUp() throws IOException {
        clearNotification();
        //initialization();
        loginPage=new LoginPage();
        profilePage=new ProfilePage();
    }

    @Test
    public void changePassword()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal "+"\n"+" Change Password in Merchant Portal","Change Password in Merchant Portal");
        /*driver.get(merchantPortalPro.getProperty("URL"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        loginPage.login(merchantPortalPro.getProperty("Mer_Mobile"),merchantPortalPro.getProperty("Mer_Pword"),merchantPortalPro.getProperty("Mer_MID"));*/
        loginPage.goToProfile();
        profilePage.changePassword(merchantPortalPro.getProperty("Mer_Pword"),merchantPortalPro.getProperty("temp_pword"));
    }
}
