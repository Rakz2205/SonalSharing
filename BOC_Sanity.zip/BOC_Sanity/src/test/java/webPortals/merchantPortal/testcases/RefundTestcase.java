package webPortals.merchantPortal.testcases;
/**
 * To perform Refund Transactional Testcase
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.HomePage;
import webPortals.merchantPortal.webPages.RefundPage;

import java.io.IOException;
import java.util.Properties;

import static webPortals.merchantPortal.webPages.AcceptPaymentsPage.*;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class RefundTestcase extends BaseClass {
    HomePage homePage;
    RefundPage refundPage;
    public static Properties refundProp;

    public RefundTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage= new HomePage();
        refundPage=new RefundPage();
    }

    @Test
    public void VerifyFullRefundJPB() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the Full Refund Functionality","Web Portal");
        homePage.goToHistory();
        /*File f = new File("outputFiles//merchantAcceptPayment.properties");

        try {
            FileInputStream fis = new FileInputStream(f);
            refundProp = new Properties();
            refundProp.load(fis);
        } catch (Exception e) {
            LogManager.getLogger(RefundTestcase.class).info("File Not Found");
        }
        refundPage.performRefund("Full",refundProp.getProperty("transactionID"),"Debit Card",refundProp.getProperty("amountReceived"),refundProp.getProperty("dateAndTime"));*/
        refundPage.performRefund("Full",transactionIDVar,"Debit Card",amountReceivedVar,dateAndTimeVar);
        //refundPage.performRefund("Full","110025489121","Jio Money","1.00","04/02/2020, 13:29:09");
        driver.navigate().refresh();
        homePage.goToHistory();
        refundPage.checkHistoryForRefunds();

    }

    @Test
    public void VerifyFullRefundP2M() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the Full Refund Functionality","Web Portal");
        homePage.goToHistory();
        /*File f = new File(projectPath+"//outputFiles//P2MAcceptPayment.properties");
        FileInputStream fis = new FileInputStream(f);
        refundProp = new Properties();
        try {
            refundProp.load(fis);
        } catch (Exception e) {
            LogManager.getLogger(RefundTestcase.class).info("File Not Found");
        }*/
        //refundPage.performRefund("Full",refundProp.getProperty("transactionID"),"Jio Money",refundProp.getProperty("amountReceived"),refundProp.getProperty("dateAndTime"));
        //refundPage.performRefund("Full",payAtShopTxnId,"Jio Money","1.00",payAtShopDate);
        refundPage.performRefund("Full","110025712986","Jio Money","1.00","10/02/2020 4:04 pm");
        driver.navigate().refresh();
        homePage.goToHistory();
        refundPage.checkHistoryForRefunds();
    }

    @Test
    public void VerifyHistoryDetailsForRefundDetails() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the History for Refund Payments","Merchant Portal");
        driver.navigate().refresh();
        homePage.goToHistory();
        refundPage.checkHistoryForRefunds();

    }

}
