package webPortals.merchantPortal.testcases;
/**
 * To perform Logout Functionality
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LogoutTestcase extends BaseClass {
    LoginPage loginPage;

    public LogoutTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage = new LoginPage();
    }

    @Test
    public void doLogOut() {
        extent = ExtentTestManager.startTest("logout Test For Merchant Portal", "Logout Test");
        loginPage.logout();
        extent.log(LogStatus.INFO,"Logout testcase executed successfully");

    }

    @AfterMethod
    public void tearDown() {
        LogManager.getLogger(LogoutTestcase.class).info("in after method");
    }
}
