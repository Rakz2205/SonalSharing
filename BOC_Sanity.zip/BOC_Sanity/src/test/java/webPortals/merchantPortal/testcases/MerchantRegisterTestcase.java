package webPortals.merchantPortal.testcases;
/**
 * To perform New Merchant Onboarding
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import webPortals.merchantPortal.webPages.MerchantOnboarding;

import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class MerchantRegisterTestcase extends BaseClass {
    LoginPage loginPage;
    MerchantOnboarding merchantOnboarding;

    public MerchantRegisterTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage= new LoginPage();
        merchantOnboarding=new MerchantOnboarding();
    }

    @Test
    public void registerMerchant() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Register merchant in Merchant Portal","Register merchant in Merchant Portal");
        loginPage.clickOnRegisterHere();
        merchantOnboarding.enterPersonalDetails(merchantPortalPro.getProperty("Mer_Mobile"),merchantPortalPro.getProperty("Mer_FName"),merchantPortalPro.getProperty("Mer_LName"),merchantPortalPro.getProperty("Mer_Pword"),merchantPortalPro.getProperty("Mer_Business_Channel") , merchantPortalPro.getProperty("Mer_Business_Ownership"),
                merchantPortalPro.getProperty("Mer_Gender"),merchantPortalPro.getProperty("Mer_DOB"),merchantPortalPro.getProperty("Mer_POI"), merchantPortalPro.getProperty("Mer_POI_ID"));
        merchantOnboarding.enterBuisnessDetails(merchantPortalPro.getProperty("MerBus_Display_Name"), merchantPortalPro.getProperty("MerBus_Legal_Name"), merchantPortalPro.getProperty("MerBus_Pan"), merchantPortalPro.getProperty("MerBus_Industry_Type"), merchantPortalPro.getProperty("MerBus_Line"), merchantPortalPro.getProperty("MerBus_YearOfBus"),  merchantPortalPro.getProperty("Mer_GST_Category") , merchantPortalPro.getProperty("MerBus_Addr1"), merchantPortalPro.getProperty("MerBus_Addr2"),
                merchantPortalPro.getProperty("MerBus_Pin"), merchantPortalPro.getProperty("MerBus_State"), merchantPortalPro.getProperty("MerBus_WebAddr"), merchantPortalPro.getProperty("MerBus_Landline"), merchantPortalPro.getProperty("MerBus_Email"),merchantPortalPro.getProperty("MerBus_DailyTransVal"),
                merchantPortalPro.getProperty("MerBus_POA"),   merchantPortalPro.getProperty("MerBus_POAID"));
        merchantOnboarding.enterPaymentDetails(merchantPortalPro.getProperty("MerPay_Product"),merchantPortalPro.getProperty("MerPay_AccHolderName"),merchantPortalPro.getProperty("MerPay_AccNo"), merchantPortalPro.getProperty("MerPay_IFSC"));
        merchantOnboarding.uploadDocuments( merchantPortalPro.getProperty("MerDoc_POI"), merchantPortalPro.getProperty("MerDoc_POA"),merchantPortalPro.getProperty("MerDOc_POB_Select"),merchantPortalPro.getProperty("MerDoc_POBImage"),merchantPortalPro.getProperty("MerDoc_POB_ID"),merchantPortalPro.getProperty("MerDoc_CancelledCheque"),
                merchantPortalPro.getProperty("MerDoc_FinancialDoc"), merchantPortalPro.getProperty("MerDoc_FinancialImage"));
        extent.log(LogStatus.INFO,"Register merchant testcase executed successfully");

    }

    @AfterMethod
    public void tearDown(){
        LogManager.getLogger(MerchantRegisterTestcase.class).info("Logging Out");
        loginPage.logout();
        LogManager.getLogger(MerchantRegisterTestcase.class).info("Logging IN");
        loginPage.login(merchantPortalPro.getProperty("Mer_Mobile"),merchantPortalPro.getProperty("Mer_Pword"),merchantPortalPro.getProperty("Mer_MID"));
    }
}
