package webPortals.merchantPortal.testcases;
/**
 * To perform Download Transactional Report Functionality
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.HomePage;
import webPortals.merchantPortal.webPages.ReportPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class DownloadReportTestcase extends BaseClass {
   HomePage homePage;
   ReportPage reportPage;

    public DownloadReportTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage=new HomePage();
        reportPage=new ReportPage();
    }

    @Test
    public void downloadReport() throws InterruptedException, FileNotFoundException {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Download report in Merchant Portal","Login Test");
        driver.navigate().refresh();
        homePage.goToReports();
        reportPage.downloadReport();
        extent.log(LogStatus.PASS,"Testcase is completed Successfully");
    }
}
