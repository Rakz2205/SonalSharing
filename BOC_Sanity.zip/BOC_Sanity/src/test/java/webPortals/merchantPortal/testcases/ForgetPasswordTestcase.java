package webPortals.merchantPortal.testcases;
/**
 * To perform Forget Password Functionality
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.ForgetPasswordPage;
import webPortals.merchantPortal.webPages.LoginPage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ForgetPasswordTestcase extends BaseClass {
    LoginPage loginPage;
    ForgetPasswordPage forgetPasswordPage;

    public ForgetPasswordTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        clearNotification();
        initialization();
        driver.get(merchantPortalPro.getProperty("URL"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        loginPage=new LoginPage();
        forgetPasswordPage=new ForgetPasswordPage();
    }

    @Test
    public void forgetPassword() throws  MalformedURLException {
        extent = ExtentTestManager.startTest("Merchant Portal: Verifying the Forget Password Functionality","Verifying the Forget Password Functionality");
        loginPage.clickOnForgotPasswordLink();
        forgetPasswordPage.forgotPassword(merchantPortalPro.getProperty("Mer_Mobile"),merchantPortalPro.getProperty("Mer_Pword"));
    }

    @AfterMethod
    public void tearDown()
    {
      driver.quit();
    }

}
