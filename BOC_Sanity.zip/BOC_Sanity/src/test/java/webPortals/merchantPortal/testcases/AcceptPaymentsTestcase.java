package webPortals.merchantPortal.testcases;
/**
 * To perform Accept Payments Transactional Testcase
 *
 * @author Sneha Dasari
 */
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.AcceptPaymentsPage;
import webPortals.merchantPortal.webPages.HomePage;

import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class AcceptPaymentsTestcase extends BaseClass {
   HomePage homePage;
   AcceptPaymentsPage acceptPaymentsPage;

    public AcceptPaymentsTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage=new HomePage();
        acceptPaymentsPage=new AcceptPaymentsPage();
    }

    @Test
    public void VerifyAcceptPaymentsByBarcode() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the Accept Payments with Correct Barcode","Merchant Portal");
        driver.navigate().refresh();
        homePage.goToAcceptPayments();
        acceptPaymentsPage.acceptPaymentinJPB();

    }


    @Test
    public void VerifyHistoryDetailsForAcceptPayments() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the History for Accept Payments","Merchant Portal");
        driver.navigate().refresh();
        homePage.goToHistory();
        acceptPaymentsPage.checkHistoryforAcceptPayments();
    }


}
