package webPortals.merchantPortal.testcases;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import webPortals.merchantPortal.webPages.SupportPage;

import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class SupportTestcase extends BaseClass {
    SupportPage supportPage;
    LoginPage loginPage;

    public SupportTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        supportPage = new SupportPage();
        loginPage = new LoginPage();
    }

    @Test
    public void VerifyFeedBackSupport() {
        extent= ExtentTestManager.startTest("Merchant Portal: Verifying the Support Functionality","Merchant Web Portal");
        boolean result;
        loginPage.goToSupport();
        supportPage.feedbackSupport();

    }

}
