package webPortals.merchantPortal.testcases;
/**
 * To perform Login Functionality
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.*;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import java.io.FileNotFoundException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoginTestcase extends BaseClass {
    LoginPage loginPage;

    public LoginTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp(){
        clearNotification();
        initialization();
        loginPage= new LoginPage();
    }

    @Test
    public void doLogin() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Login in Merchant Portal","Login Test");
        //Cookie cookie=new Cookie("ihjggbbefi","mOz3FZBRWqA=","merchant.jiomoney.com","/JioMerchant/faces/oracle/webcenter/portalapp/pages",null);

        driver.get(merchantPortalPro.getProperty("URL"));
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //driver.manage().addCookie(cookie);
        loginPage.login(merchantPortalPro.getProperty("Mer_Mobile"),merchantPortalPro.getProperty("Mer_Pword"),merchantPortalPro.getProperty("Mer_MID"));
        extent.log(LogStatus.INFO,"Login testcases Successfully");
    }

   // @AfterMethod()
    public void tearDown(){

    }


}
