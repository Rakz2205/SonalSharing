package webPortals.merchantPortal.testcases;
/**
 * To perform Update Profile Testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.merchantPortal.webPages.LoginPage;
import webPortals.merchantPortal.webPages.ProfilePage;
import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class UpdateProfileTestcase extends BaseClass {
    LoginPage loginPage;
    ProfilePage profilePage;

    public UpdateProfileTestcase() throws FileNotFoundException {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage= new LoginPage();
        profilePage=new ProfilePage();
    }

    @Test
    public void updateProfile() throws InterruptedException {
        extent= ExtentTestManager.startTest("WEB Automation :-- Merchant Portal    "+"\n"+" Update Profile Testcase in Merchant Portal","Update Profile Testcase in Merchant Portal");
        loginPage.goToProfile();
        profilePage.updateEmail(merchantPortalPro.getProperty("updated_email"),merchantPortalPro.getProperty("Mer_Pword"));
        extent.log(LogStatus.PASS,"Update Profile Testcase completed Successfully");

    }

}
