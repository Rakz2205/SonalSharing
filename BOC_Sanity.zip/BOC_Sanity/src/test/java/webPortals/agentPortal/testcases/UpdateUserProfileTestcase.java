package webPortals.agentPortal.testcases;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;

import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.SettingPage;
import webPortals.agentPortal.webPages.UpdateUserProfilePage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class UpdateUserProfileTestcase extends BaseClass {
    public SettingPage settingPage;
    public UpdateUserProfilePage updateUserProfilePage;

    public UpdateUserProfileTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        settingPage = new SettingPage();
        updateUserProfilePage=new UpdateUserProfilePage();
    }

    @Test
    public void updateUserProfileTest() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Update user profile In Agent Portal");
        extent.log(LogStatus.INFO,"Update user profile In Agent Portal");
        settingPage.goToUserProfilePage();
        updateUserProfilePage.updateUserProfile(agentportalPro.getProperty("newUserId"));
    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(UpdateUserProfileTestcase.class).info("in after method");
    }
}

