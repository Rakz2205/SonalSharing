package webPortals.agentPortal.testcases;
/**
 * To download FTR report testcase
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.SettingPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class DownloadFTRTestcase extends BaseClass {
    SettingPage SettingPage;

    public DownloadFTRTestcase()  {

    }

    @BeforeMethod
    public void setUp() throws IOException {
        SettingPage=new SettingPage();
    }

    @Test(description="Download FTR In Agent Portal")
    public void downloadFTRTest() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Download FTR In Agent Portal");
        extent.log(LogStatus.PASS,"Download FTR In Agent Portal");
        SettingPage.downloadFTR(agentportalPro.getProperty("fromDate"),agentportalPro.getProperty("toDate"));

    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(DownloadFTRTestcase.class).info("in after method");
        driver.quit();
        LogManager.getLogger(DownloadFTRTestcase.class).info("Driver: "+driver);
    }
}


