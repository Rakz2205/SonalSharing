package webPortals.agentPortal.testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.HierarchyAndCommissionPage;
import webPortals.agentPortal.webPages.HomePage;
import webPortals.agentPortal.webPages.LoginPage;

import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
//@Listeners(utilityLibrary.reports.Listeners.AnnotationTransformer.class)

public class HierarchyAndCommissionTestcase extends BaseClass {
    public LoginPage loginPage;
    public HierarchyAndCommissionPage hierarchyAndCommissionPage;
    public HomePage homePage;

    public HierarchyAndCommissionTestcase() {
    }


    @BeforeClass
    public void setUp() throws IOException, InterruptedException {

        hierarchyAndCommissionPage = new HierarchyAndCommissionPage();
        homePage = new HomePage();
        loginPage = new LoginPage();
    }

    @Test
    public void VerifyLevel4AgentDetails() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Verify Level 1 Agent Details");
        hierarchyAndCommissionPage.clickLevel4Agent();

    }

    @Test
    public void VerifyLevel2AgentDetails() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Verify Level 1 Agent Details");
        hierarchyAndCommissionPage.clickLevel2Agent();

    }

    @Test
    public void VerifyLevel3AgentDetails() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Verify Level 1 Agent Details");
        hierarchyAndCommissionPage.clickLevel3Agent();

    }

    @Test
    public void VerifyLevel1AgentDetails(){
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Verify Level 1 Agent Details");
        homePage.goToHierarchyAndComm();
        hierarchyAndCommissionPage.clickLevel1Agent();

    }


}
