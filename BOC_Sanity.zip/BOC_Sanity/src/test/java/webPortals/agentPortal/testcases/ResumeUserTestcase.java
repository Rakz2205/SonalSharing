package webPortals.agentPortal.testcases;
/**
 * To perform Resume User testcase
 *
 * @author Sneha Dasari
 */

import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.AgentUserMgmtPage;
import webPortals.agentPortal.webPages.LoginPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ResumeUserTestcase extends BaseClass {
    public LoginPage loginPage;
    public AgentUserMgmtPage agentUserMgmtPage;

    public ResumeUserTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage = new LoginPage();
        agentUserMgmtPage=new AgentUserMgmtPage();
    }

    @Test
    public void resumeUserTest()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Add User In Agent Portal");
        extent.log(LogStatus.PASS,"Add User In Agent Portal");
        agentUserMgmtPage.resumeUser(agentportalPro.getProperty("userMobileNo"));

    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(ResumeUserTestcase.class).info("in after method");
    }
}
