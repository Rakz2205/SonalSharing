package webPortals.agentPortal.testcases;
/**
 * To perform Load Own trading Balance testcase
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.HomePage;
import webPortals.agentPortal.webPages.LoadOwnTradingBalPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoadOwnTradingBalTestcase extends BaseClass {
    HomePage homePage;
    LoadOwnTradingBalPage loadOwnTradingBalPage;

    public LoadOwnTradingBalTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage = new HomePage();
        loadOwnTradingBalPage = new LoadOwnTradingBalPage();
    }

    @Test(description = "Load Own Trading balance")
    public void loadTradingBalTest() {
        extent = ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Load Own Trading balance");
        extent.log(LogStatus.PASS, "Load Own Trading balance");
        homePage.goToLoadOwnTradingBal();
        loadOwnTradingBalPage.loadOwnTradingBalance(agentportalPro.getProperty("amount"), agentportalPro.getProperty("BankName"));
        LogManager.getLogger(LoadOwnTradingBalTestcase.class).info("Load Own Trading Balance Passed");
    }

    @Test(description = "Load Own Trading balance")
    public void VerifyLoadOwnTradingforDebit() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Load Own Trading balance");
        extent.log(LogStatus.PASS,"Load Own Trading balance");
        homePage.goToLoadOwnTradingBal();
        loadOwnTradingBalPage.loadOwnTradingBalanceforDebit(agentportalPro.getProperty("amount"));

    }

    //@AfterMethod
    public void tearDown() {
        LogManager.getLogger(LoadOwnTradingBalTestcase.class).info("Is Driver Empty :" + driver.toString().contains("(null)") + " : " + driver);
        //driver.quit();
        LogManager.getLogger(LoadOwnTradingBalTestcase.class).info("Is Driver Empty :" + driver.toString().contains("(null)") + " : " + driver);
    }
}


