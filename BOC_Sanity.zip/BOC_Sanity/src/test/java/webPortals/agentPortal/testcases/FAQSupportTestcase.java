package webPortals.agentPortal.testcases;

import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.FAQSupport;
import webPortals.agentPortal.webPages.HomePage;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class FAQSupportTestcase extends BaseClass {
    HomePage homePage;
    FAQSupport faqSupport;

    public FAQSupportTestcase() {
    }

    @BeforeMethod
    public void setUp() {
        homePage=new HomePage();
        faqSupport=new FAQSupport();
    }

    @Test(description="FAQ Test In Agent Portal")
    public void FAQTest()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.checkAboutJioMoney();
        extent.log(LogStatus.PASS,"FAQ Testcase passed Successfully");
    }

    @Test
    public void FAQGenerateCodeTest() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.generateCode();
        extent.log(LogStatus.PASS,"FAQ Testcase passed Successfully");
    }

    @Test
    public void VerifyConsumerFeedback() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.raiseFAQsTicket("Consumer");
    }

    @Test
    public void VerifyAgentFeedback()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.raiseFAQsTicket("Agent");
    }

    @Test
    public void FAQSignUp() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.checkJioMoneySignUp();
    }

    @Test
    public void FAQAgentActivities() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.checkAgentActivities();
    }

    @Test
    public void FAQMyAccount() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "FAQSupport In Agent Portal");
        extent.log(LogStatus.INFO,"FAQSupport In Agent Portal");
        homePage.goToFAQSupportPage();
        faqSupport.checkMyAccount();
    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(FAQSupportTestcase.class).info("in after method");
    }
}
