package webPortals.agentPortal.testcases;
/**
 * To perform Load Money testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.LoadMoneyPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class LoadmoneyTestcase extends BaseClass {
    LoadMoneyPage loadMoneyPage;

    public LoadmoneyTestcase()  {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loadMoneyPage=new LoadMoneyPage();
    }

    @Test(description="Load Money Test In Agent Portal")
    public void loadMoneyTest() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Load Money Test In Agent Portal");
        extent.log(LogStatus.INFO,"Load Money Test In Agent Portal");
        loadMoneyPage.loadMoney(agentportalPro.getProperty("MobileNo"),agentportalPro.getProperty("LoadMoneyAmount"));

    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(LoadmoneyTestcase.class).info("in after method");
    }

}
