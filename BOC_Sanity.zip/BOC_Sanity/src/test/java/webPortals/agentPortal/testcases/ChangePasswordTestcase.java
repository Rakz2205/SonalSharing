package webPortals.agentPortal.testcases;
/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.LoginPage;
import webPortals.agentPortal.webPages.SettingPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class ChangePasswordTestcase extends BaseClass {
    public LoginPage loginPage;
    public SettingPage settingPage;

    public ChangePasswordTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage = new LoginPage();
        settingPage=new SettingPage();
    }

    @Test(description="Password Change In Agent Portal")
    public void changePassword(){
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Change password in Agent portal");
        extent.log(LogStatus.PASS,"Change password in Agent portal");
        settingPage.changePassword(agentportalPro.getProperty("password"),agentportalPro.getProperty("tempPassword"),agentportalPro.getProperty("tempPassword"));
       // settingPage.changePassword(pro.getProperty("tempPassword"),pro.getProperty("password"),pro.getProperty("password"));
    }
}
