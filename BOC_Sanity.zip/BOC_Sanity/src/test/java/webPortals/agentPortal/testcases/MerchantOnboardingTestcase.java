package webPortals.agentPortal.testcases;
/**
 * To perform Merchant Onboarding testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.HomePage;
import webPortals.agentPortal.webPages.LoginPage;
import webPortals.agentPortal.webPages.MerchantOnboardPage;
import webPortals.agentPortal.webPages.SettingPage;

import java.io.FileNotFoundException;
import java.io.IOException;

import static utilityLibrary.testData.Constants.*;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class MerchantOnboardingTestcase extends BaseClass {
    public LoginPage loginPage;
    public SettingPage settingPage;
    public HomePage homepage;
    public MerchantOnboardPage merchantOnboardPage;

    public MerchantOnboardingTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage = new LoginPage();
        settingPage=new SettingPage();
        homepage= new HomePage();
        merchantOnboardPage=new MerchantOnboardPage();

    }

    @Test(description = "")
    public void onboardMerchantTest(){
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Merchant onboard In Agent Portal");
        extent.log(LogStatus.INFO,"Merchant onboard In Agent Portal");
        homepage.selectJioMoneyPartner();

        merchantOnboardPage.enterBasicDetails(agentportalPro.getProperty("merchant_fname"),agentportalPro.getProperty("merchant_lname"),
                agentportalPro.getProperty("merchant_dob"),agentportalPro.getProperty("merchant_gender"),agentportalPro.getProperty("merchant_email"),
                agentportalPro.getProperty("merchant_web"),agentportalPro.getProperty("merchant_mobile"),
                agentportalPro.getProperty("merchant_alterMobile"),agentportalPro.getProperty("merchant_landline"));

        merchantOnboardPage.enterAddressDetails(agentportalPro.getProperty("merchant_AddressType"),agentportalPro.getProperty("merchant_flatname"),
                agentportalPro.getProperty("merchant_buildingNo"),agentportalPro.getProperty("merchant_area"),agentportalPro.getProperty("merchant_subLocality"),
                agentportalPro.getProperty("merchant_Street"),agentportalPro.getProperty("merchant_landmark"),
                agentportalPro.getProperty("merchant_pincode"),agentportalPro.getProperty("merchant_city"),
                agentportalPro.getProperty("merchant_district"),agentportalPro.getProperty("merchant_state"),
                agentportalPro.getProperty("merchant_website"),agentportalPro.getProperty("merchant_storeemail"),agentportalPro.getProperty("merchant_storeName"));

        merchantOnboardPage.enterCompanyDetails(agentportalPro.getProperty("merchant_BuisnessLine"),agentportalPro.getProperty("merchant_yrsOfBuisness"),
                agentportalPro.getProperty("merchant_Desc"),agentportalPro.getProperty("merchant_transValue"),agentportalPro.getProperty("merchant_transPerDay"),
                agentportalPro.getProperty("merchant_returnPolicy"),agentportalPro.getProperty("merchant_DeliveryPeriod"));

        merchantOnboardPage.enterFinancialInfo(agentportalPro.getProperty("merchant_pan"),agentportalPro.getProperty("merchant_taxNo"),
                agentportalPro.getProperty("merchant_tan"),agentportalPro.getProperty("merchant_tin"),agentportalPro.getProperty("merchant_lst"),
                agentportalPro.getProperty("merchant_cst"),agentportalPro.getProperty("merchant_gst_cat"),
                agentportalPro.getProperty("merchant_SettlementType"),agentportalPro.getProperty("merchant_settlementFrq"),agentportalPro.getProperty("merchant_settlementMedium"),
                agentportalPro.getProperty("merchant_accName"),agentportalPro.getProperty("merchant_accNo"),
                agentportalPro.getProperty("merchant_ifsc"),agentportalPro.getProperty("merchant_bankname"),agentportalPro.getProperty("merchant_Branchname"));

        merchantOnboardPage.uploadDocuments(agentportalPro.getProperty("merchant_ProofOfaddress"),agentportalPro.getProperty("merchant_POA_ID"),
                agentportalPro.getProperty("merchant_POAPath"),agentportalPro.getProperty("merchant_ProofOfBuisness"),agentportalPro.getProperty("merchant_POB_ID"),
                agentportalPro.getProperty("merchant_POBPath"),agentportalPro.getProperty("merchant_CheckLeaf"),
                agentportalPro.getProperty("merchant_checkRemark"),agentportalPro.getProperty("merchant_checkpath"),agentportalPro.getProperty("merchant_ProofOfindentity"),
                agentportalPro.getProperty("merchant_IdentityNo"),agentportalPro.getProperty("merchant_IdentityExpDate"),
                agentportalPro.getProperty("merchant_identityProofPath"),agentportalPro.getProperty("merchant_mafId"),agentportalPro.getProperty("merchant_mafPath"),agentportalPro.getProperty("merchant_photoPath"),
                agentportalPro.getProperty("merchant_doc"),agentportalPro.getProperty("merchant_FinDocPath"));

    }
}
