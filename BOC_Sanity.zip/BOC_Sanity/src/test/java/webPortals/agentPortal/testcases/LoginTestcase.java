package webPortals.agentPortal.testcases;
/**
 * To perform Login related testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.AgentUserMgmtPage;
import webPortals.agentPortal.webPages.LoginPage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
//@Listeners(utilityLibrary.reports.Listeners.AnnotationTransformer.class)

public class LoginTestcase extends BaseClass {
    public LoginPage loginPage;
    public AgentUserMgmtPage agentUserMgmtPage;

    public LoginTestcase()  {
    }


    @BeforeMethod
    public void setUp() {
        clearNotification();
        initialization();
        agentUserMgmtPage = new AgentUserMgmtPage();
        loginPage = new LoginPage();
    }

    @Test(description = "Login in Agent Portal")
    public void doLogin() {
        extent = ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal    " + "\n" + " Login in Agent Portal", "Login in Agent Portal");
        extent.log(LogStatus.INFO, "Login In Agent Portal");
        driver.get(agentportalPro.getProperty("URL"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        loginPage.login(agentportalPro.getProperty("username"), agentportalPro.getProperty("password"));
        extent.log(LogStatus.PASS, "Login Test case is Passed");
    }


}
