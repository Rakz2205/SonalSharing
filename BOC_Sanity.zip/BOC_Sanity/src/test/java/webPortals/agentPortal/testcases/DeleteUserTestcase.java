package webPortals.agentPortal.testcases;
/**
 * To perform Delete User testcase
 *
 * @author Sneha Dasari
 */

import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.AgentUserMgmtPage;
import webPortals.agentPortal.webPages.LoginPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class DeleteUserTestcase extends BaseClass {
    public LoginPage loginPage;
    public AgentUserMgmtPage agentUserMgmtPage;

    public DeleteUserTestcase() {

    }

    @BeforeMethod
    public void setUp() throws IOException {
        loginPage = new LoginPage();
        agentUserMgmtPage=new AgentUserMgmtPage();
    }

    @Test(description="Delete User from Agent Portal")
    public void deleteUserTest()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Delete user in Agent Portal");
        extent.log(LogStatus.PASS,"Delete User In Agent Portal");
        agentUserMgmtPage.deleteUser(agentportalPro.getProperty("userMobileNo"));

    }
}
