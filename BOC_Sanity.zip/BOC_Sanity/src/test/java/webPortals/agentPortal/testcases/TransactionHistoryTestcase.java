package webPortals.agentPortal.testcases;
/**
 * To Verify transaction history and apply filter testcases
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;
import utilityLibrary.reports.Listeners.TestListenerWeb;
import webPortals.agentPortal.webPages.HomePage;
import webPortals.agentPortal.webPages.TransactionHistoryPage;

import java.io.FileNotFoundException;
import java.io.IOException;

@Listeners({TestListenerWeb.class,utilityLibrary.reports.Listeners.AnnotationTransformer.class})
public class TransactionHistoryTestcase extends BaseClass {
    HomePage homePage;
    TransactionHistoryPage transactionHistoryPage;

    public TransactionHistoryTestcase() {
    }

    @BeforeMethod
    public void setUp() throws IOException {
        homePage= new HomePage();
        transactionHistoryPage=new TransactionHistoryPage();
    }

    @Test(description = "Transaction history Test in Agent Portal")
    public void VerifyTransactionHistory() {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Transaction history Test in Agent Portal");
        extent.log(LogStatus.PASS,"Transaction history Test in Agent Portal");
        homePage.goToTransactionHistory();
        transactionHistoryPage.downloadTransactionHistory(agentportalPro.getProperty("dateRange"));

    }

    @Test(description = "Custom Transaction history Test in Agent Portal")
    public void VerifyCustomTransactionHistory()  {
        extent= ExtentTestManager.startTest("WEB Automation :-- Agent UI Portal ", "Custom Transaction history Test in Agent Portal");
        extent.log(LogStatus.PASS,"Custom Transaction history Test in Agent Portal");
        homePage.goToTransactionHistory();
        transactionHistoryPage.downloadTransactionHistoryForCustom(agentportalPro.getProperty("fromDateRange"),agentportalPro.getProperty("EndDateRange"));

    }

    @AfterMethod
    public void tearDown()
    {
        LogManager.getLogger(TransactionHistoryTestcase.class).info("in after method");
    }
}