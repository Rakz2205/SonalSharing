package mobileApplications.jpbApp.entity;
/**
 * To verify the data displayed in profile
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;

public class MyAccountEntity extends BaseClass
{
    ProfileEntity profileEntity;
    ChangeMPINEntity changeMPINEntity;
    public MyAccountEntity()
    {
        try
        {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            profileEntity = new ProfileEntity();
            changeMPINEntity = new ChangeMPINEntity();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in MyAccountEntity(): "+ex.getMessage());
        }

    }

    @FindBy(id = "tvSavingsAcNo")
    WebElement jpbAccountNumber;

    @FindBy(id = "tvBankIFSC")
    WebElement jpbIFSCCOde;

    @FindBy(id = "tvMMID")
    WebElement jpbMID;

    @FindBy(id = "tvKYCID")
    WebElement jpbKYCID;

    @FindBy(xpath = "//*[@text='Marital Details']")
    WebElement maritalDetailsButton;

    @FindBy(xpath = "//*[contains(@text,'Email')]")
    WebElement emailButton;

    @FindBy(id="etMaritalStatus")
    WebElement maritalDetailsDropdown;

    @FindBy(id="btnUpdate")
    WebElement MaritalStatusUpdateButton;

    @FindBy(xpath = "//*[contains(@text, 'Married')]")
    WebElement marriedOption;

    @FindBy(xpath = "//*[contains(@text, 'Single')]")
    WebElement singleOption;

    @FindBy(id="etJpbUpdateEmail")
    WebElement emailTextField;

    @FindBy(id="btnJpbUpdateEmail")
    WebElement updateEmailButton;

    public void myAccountDetails()
    {
        try
        {
            profileEntity.NavigateTo(Constants.MY_ACCOUNT);
            changeMPINEntity.enterMPIN();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in myAccountDetails():"+ex.getMessage());
        }

    }

    public void changeMaritalStatus(String mStatus)
    {
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(maritalDetailsButton);
            clickElement(maritalDetailsDropdown);
            if(mStatus.equalsIgnoreCase("Married"))
            {
                clickElement(singleOption);
                waitFor(30);
            }
            else
            {
                clickElement(marriedOption);
                waitFor(30);
            }
            clickElement(MaritalStatusUpdateButton);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in changeMaritalStatus(String mStatus): "+ex.getMessage());
        }

    }

    public void getMaritalStatusAfterChange(String changedMaritalStatus)
    {
        try
        {
            waitFor(maritalDetailsButton,30);
            clickElement(maritalDetailsButton);
            waitFor(30);
            waitFor(maritalDetailsDropdown,20);
            String maritalStatusValue = getTextfromElement(maritalDetailsDropdown);
            Assert.assertTrue(maritalStatusValue.equalsIgnoreCase(changedMaritalStatus),"Marital Status did not change to "+changedMaritalStatus);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getMaritalStatusAfterChange(): "+ex.getMessage());
        }

    }

    public void changeEmail(String newEmail){
        try
        {
            clickElement(emailButton);
            if(!isElementDisplayed(emailTextField))
            {
                changeMPINEntity.enterMPIN();
            }
            emailTextField.clear();
            emailTextField.sendKeys(newEmail);
            androidDriver.hideKeyboard();
            waitFor(updateEmailButton,20);
            clickElement(updateEmailButton);
            waitFor(30);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in changeEmail(String newEmail): "+ex.getMessage());
        }

    }

    public void getEmailTextAFterChange(String changedEmail)
    {
        try
        {
            waitFor(30);
            waitFor(emailButton,10);
            clickElement(emailButton);
            waitFor(30);
            waitFor(emailTextField,10);
            waitFor(30);
            String emailValue= getTextfromElement(emailTextField);
            waitFor(updateEmailButton,20);
            clickElement(updateEmailButton);
            waitFor(30);
            Assert.assertTrue(emailValue.equalsIgnoreCase(changedEmail),"Email ID is not changed to "+changedEmail);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getEmailTextAFterChange(): "+ex.getMessage());
        }

    }

    public void getSavingsAcNum()
    {

        try
        {
            LogManager.getLogger(MyAccountEntity.class).info(getTextfromElement(jpbAccountNumber));
            Assert.assertTrue(getTextfromElement(jpbAccountNumber).equalsIgnoreCase(JPBAppPro.getProperty("jpbSavingsNum")),"Savings Account number is not displayed");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in getSavingsAcNum(): "+ex.getMessage());
        }
    }

    public void getBankIFSC()
    {
        try
        {
            LogManager.getLogger(MyAccountEntity.class).info(getTextfromElement(jpbIFSCCOde));
            Assert.assertTrue(getTextfromElement(jpbIFSCCOde).equalsIgnoreCase(JPBAppPro.getProperty("jpbIFSCCode")),"IFSC code is not displayed");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in getBankIFSC(): "+ex.getMessage());
        }
    }

    public void getMID()
    {
        try
        {
            LogManager.getLogger(MyAccountEntity.class).info(getTextfromElement(jpbMID));
            Assert.assertTrue(getTextfromElement(jpbMID).equalsIgnoreCase(JPBAppPro.getProperty("jpbMMID")),"MMID number is not displayed");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in getMID(): "+ex.getMessage());
        }
    }

    public void getCKYCID()
    {
        try
        {
            LogManager.getLogger(MyAccountEntity.class).info(getTextfromElement(jpbKYCID));
            Assert.assertTrue(getTextfromElement(jpbKYCID).equalsIgnoreCase(JPBAppPro.getProperty("jpbCKYCNumber")),"CKYC number is not displayed");

        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in getCKYCID(): "+ex.getMessage());
        }
    }

    }
