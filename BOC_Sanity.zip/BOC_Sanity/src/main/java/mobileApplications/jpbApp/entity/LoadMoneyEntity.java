package mobileApplications.jpbApp.entity;
/**
 * To Load money into the wallet
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;

public class LoadMoneyEntity extends BaseClass {

    @FindBy(id = "etAmount")
    private WebElement enterAmount;

    @FindBy(id = "btnLoad")
    private WebElement loadButton;


    @FindBy(id = "tvUpiRadioButton")
    private WebElement upiSelect;


    @FindBy(id = "tvNetBankingRadioButton")
    private WebElement netBankingSelect;

    @FindBy(id = "tvDebitCardRadioButton")
    private WebElement debitCardSelect;

    @FindBy (xpath ="//*[contains(@resource-id,'rvSavedInstruments')]//*[@text='UPI']" )
    private WebElement upiPushOption; //This is an alternative to click on third party Bank for UPI Push. The radio button is tedious to find since there are possibilities of multiple elements

    @FindBy(xpath="//android.widget.TableRow/android.widget.ImageView[2]")
    private WebElement submitButtonNpciPage;

    @FindBy(id = "tvCreditCardRadioButton")
    private WebElement creditCardSelect;


    @FindBy(id = "tvYes")
    private WebElement cancelPayment;


    @FindBy(id = "tvNo")
    private WebElement continuePayment;


    @FindBy(id = "tvCreditTransactionId")
    private WebElement transactionIdLabel;


    @FindBy(id = "btnPay")
    private WebElement reviewAndPay ;

    @FindBy(xpath = "//android.widget.TextView[@text='Punjab National Bank - Retail']")
    private WebElement selectBankName;

    @FindBy(id = "btnConfirm")
    private WebElement confirmAndAdd ;

    @FindBy(xpath = "//android.widget.Spinner[@text='Select']")
    private WebElement bankStatus ;

    @FindBy(xpath = "//android.widget.CheckedTextView[@text='Success']")
    private WebElement success;

    @FindBy(xpath = "//android.widget.Button[@text='Submit']")
    private WebElement submitButton ;

    @FindBy(id = "etCardNumber")
    private WebElement debitCardNumber ;

    @FindBy(id = "etName")
    private WebElement nameOnCard ;

    @FindBy(id = "etExpiry")
    private WebElement expiryDate ;


    @FindBy(id = "etCvv")
    private WebElement cardCVV ;

    @FindBy(id = "btnAdd")
    private  WebElement debitCardReviewAndPay ;

    @FindBy(xpath = "//android.widget.TextView [@text='Add Money Failed']")
    private WebElement failureTitle ;

    @FindBy(id = "tvCreditTransactionId")
    private WebElement transactionId ;

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'JOT')]")
    private WebElement rrnPushTxn ;

    @FindBy(xpath = "//*[contains(@text,'Transaction Type')]/following-sibling::android.widget.TextView")
    private WebElement transactionType ;

    @FindBy(xpath = "//*[contains(@text,'Reason')]/following-sibling::android.widget.TextView")
    private  WebElement transactionReason ;

    @FindBy(xpath = "//*[contains(@text,'Phone No')]/following-sibling::android.widget.TextView")
    private WebElement transactionMobile;

    @FindBy(xpath = "//android.widget.Button[@text='Home']")
    private WebElement homeButton ;

    @FindBy(id="tvSuccessTitle")
    public WebElement successTitle;

    @FindBy(id="tvTransactionStatusTitle")
    private WebElement transactionSuccessUpi;

    @FindBy(xpath = "//*[contains(@text,'ENTER UPI PIN')]")
    private WebElement npciPageTitle;

    @FindBy(id="ivMore")
    private WebElement addLimit;

    @FindBy(id = "tvAddMoney")
    public WebElement addMoneyOption;

    HomeEntity homeEntity;
    ChangeMPINEntity changeMPINEntity;
    OpenLoopEntity openLoopEntity;

    public LoadMoneyEntity() {
        try
        {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            homeEntity = new HomeEntity();
            changeMPINEntity=new ChangeMPINEntity();
            openLoopEntity = new OpenLoopEntity();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in LoadMoneyEntity(): "+ex.getMessage());
        }

    }

    public void performLoadMoney(String transactionMethod)
    {
        try
        {
            homeEntity.navigateToPage(HOME);
            homeEntity.navigateToPage(ADDMONEY);
            try{
                changeMPINEntity.enterMPIN();
            }
            catch(Exception ex)
            {
                LogManager.getLogger(LoadMoneyEntity.class).info("MPIN is not asked");
            }
            clickElement(addMoneyOption);
            waitFor(enterAmount,20);
            enterAmount.sendKeys(JPBAppPro.getProperty("loadMoneyAmount"));
            clickElement(loadButton);
            openLoopEntity.openLoopPayments("",transactionMethod);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in performLoadMoney(String transactionMethod): "+ex.getMessage());
        }

    }
}
