package mobileApplications.jpbApp.entity;


import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.jpbUtils.AppUtil;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;
import java.util.List;


public class SendMoneyReviewEntity extends BaseClass {

    @FindBy(id = "tvArrowIcon1")
    private WebElement detailOfTransaction;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Jio Payments Bank']")
    private WebElement jioPaymentsBank;

    @FindBy(xpath = "//android.widget.Button[@text='Confirm & Pay']")
    private WebElement confirmAndPayButton;

    @FindBy(id = "tvCancelIcon")
    private WebElement cancellationBtn;

    @FindBy(id = "tvBankName")
    public WebElement bankVerify;

    @FindBy(id = "tvBankIcon")
    private WebElement bankIcon;

    @FindBy(id = "tvPhoneNo")
    public WebElement acountType;

    @FindBy(id = "tvTransferAmount")
    public WebElement transferAmount;

    @FindBy(id = "tvFeeAmount")
    public WebElement feeDetails;

    @FindBy(xpath = "//android.widget.TextView[@text= 'Transfer Amount']")
    public WebElement transferAmountField;

    @FindBy(xpath = "//android.widget.TextView[@text= 'Fees']")
    public WebElement feeDetailsField;

    //UPI Page objects
    @FindBy(id = "rlAccountsContainer")
    private List<WebElement> bankList;

    @FindBy(xpath = "//android.widget.Button[@text='Enter UPI PIN']")
    WebElement proceedToNpciPage;

    public SendMoneyReviewEntity() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void reviewTransaction(){
        try
        {
            waitFor(15);

            clickElement(jioPaymentsBank);
            waitFor(15);

            clickElement(confirmAndPayButton);
            waitFor(15);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in reviewTransaction(): "+ex.getMessage());
        }


    }

    public void reviewTransactionforUPI()
    {
        try
        {
            waitFor(15);
            clickElement(bankList.get(0));
            waitFor(15);
            AppUtil.scrollScreen();
            AppUtil.scrollScreen();
            clickElement(proceedToNpciPage);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in reviewTransactionforUPI(): "+ex.getMessage());
        }

    }



}
