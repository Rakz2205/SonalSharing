package mobileApplications.jpbApp.entity;
/**
 * To perform operations on elements present on home screen
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;

public class HomeEntity extends BaseClass {

    @FindBy(id = "action_home")
    public WebElement homeBtn;

    @FindBy(id = "action_transfer")
    public WebElement fundTransferOption;

    @FindBy(id = "tv_profile_pic_small")
    private WebElement hamburgerMenuOption;


    @FindBy(xpath = "//android.widget.TextView [@text='Add']")
    private WebElement addMoneyOption;


    @FindBy(xpath = "//android.widget.TextView [@text='DTH']")
    private WebElement selectDTHOption ;


    @FindBy(xpath = "//android.widget.TextView [@text='Electricity']")
    private WebElement selectElectricityOption ;

    @FindBy(xpath = "//android.widget.TextView [@text='Toll']")
    private WebElement selectTollOption ;


    @FindBy(xpath = "//android.widget.TextView [@text='Mobile']")
    private WebElement selectMobileOption ;

    @FindBy(xpath = "//android.widget.TextView [@text='Bus Tickets']")
    private WebElement selectBusTicketOption ;


    @FindBy(id = "btnAllServicesText")
    private WebElement selectOtherServices ;

    @FindBy(id = "btnAllServices")
    private WebElement AllServiceClose ;


    @FindBy(xpath = "//android.widget.TextView [@text='Datacard']")
    private WebElement selectDataCardPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Broadband/Landline']")
    private WebElement selectBroadBandLandLinePayment;


    @FindBy(xpath = "//android.widget.TextView [@text='Gas']")
    private WebElement selectGasPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Insurance']")
    private WebElement selectInsurancePayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Water']")
    private WebElement selectWaterPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Municipal Taxes']")
    private WebElement selectMuncipleTaxesPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Metro']")
    private WebElement selectMetroPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='E-Challan']")
    private WebElement selectEChallanPayment;


    @FindBy(xpath = "//android.widget.TextView [@text='Housing Society']")
    private WebElement selectHousingSocietyPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Charity']")
    public WebElement selectCharityPayment;

    @FindBy(xpath = "//android.widget.TextView [@text='Subscription']")
    private WebElement selectSubscriptionPayment;


    @FindBy(xpath = "//android.widget.TextView [@text='Passbook']")
    private WebElement selectPassBook;

    @FindBy(id = "tvYes")
    private WebElement logoutAlertAccept;

    @FindBy(id = "ivWallet")
    private WebElement HomePageWalletButton;


    @FindBy(xpath = "//android.widget.TextView[@text='Pay at Shop']")
    private WebElement selectPayAtShop;

    @FindBy(id = "action_profile")
    private WebElement selectProfile;

    @FindBy(xpath = "//android.widget.TextView [@text='Profile']")
    private WebElement profileOption;

    @FindBy(id = "homeToolbarTitle")
    private WebElement JioMoneyIcon;

    @FindBy(id = "ivNotification")
    private WebElement NotificationBell;

    @FindBy(id = "ivWallet")
    public WebElement WalletIcon;

    @FindBy(id = "tvAdd")
    private WebElement AddMoneyIcon;

    @FindBy(id = "btnAllServices")
    private WebElement ALLServiceIcon;

    @FindBy(id = "btnAllServicesText")
    private WebElement CloseALLServiceIcon;

    @FindBy(id = "ivHomeBanner")
    private WebElement HomeBannerIcon;

    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'Prepaid & Postpaid')]")
    private WebElement PreANDPost;

    @FindBy(xpath = "//android.widget.TextView[@text='Pay at Shop']")
    private WebElement PayAtShop;

    @FindBy(xpath = "//android.widget.TextView[@text='Mobile']")
    private WebElement Mobile;

    @FindBy(xpath = "//android.widget.TextView[@text='Electricity']")
    private WebElement Electricity;

    @FindBy(xpath = "//android.widget.TextView[@text='DTH']")
    private WebElement DTH;
   //@FindBy(xpath = "//android.widget.TextView[contains(@text, 'Prepaid & Postpaid')]")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'Transfer')]")
    private WebElement MoneyTransfer;

    @FindBy(xpath = "//android.widget.TextView[@text='Toll']")
    private WebElement Toll;

    @FindBy(xpath = "//android.widget.TextView[@text='Bus Tickets']")
    private WebElement BusTickets;

    @FindBy(id = "btnRedo")
    private WebElement RepeatButtonClick;

    @FindBy(id = "tvViewAllLabel")
    private WebElement ViewAllButtonClick;

    @FindBy(xpath = "//android.widget.TextView[@text='Home']")
    private WebElement HomeIcon;

    /*@FindBy(xpath = "//android.widget.TextView[@text='Offers']")
    private WebElement OffersIcon;*/

    @FindBy(id = "action_offers")
    private WebElement OffersIcon;

    /*@FindBy(xpath = "//android.widget.TextView[@text='Transfer']")
    private WebElement TransferIcon;*/

    @FindBy(id = "action_transfer")
    private WebElement TransferIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='OK']")
    private WebElement OKButtonClick;

    @FindBy(xpath = "//android.widget.TextView[@text='Passbook']")
    public WebElement PassbookText;

    @FindBy(id = "action_passbook")
    public WebElement PassbookIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Profile']")
    private WebElement ProfileIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Offers & Loyalty']")
    private WebElement OffersLoyaltyIcon;
    @FindBy(xpath = "//android.widget.TextView[@text='Pay at Shop']")
    private WebElement payAtShop;


    @FindBy(xpath = "//android.widget.TextView[@text='Get exciting offers from various brands']")
    private WebElement OffersTabIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Loyalty Cards']")
    private WebElement LoyaltyCardsIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Cashback Deals']")
    private WebElement CashbackDealsIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Sodexo Meal Pass']")
    private WebElement SodexoMealPassIcon;

    @FindBy(id = "llUpgradeBtn")
    private WebElement UpgradeBtnIcon;

    @FindBy(xpath = "//android.widget.TextView[@text='Welcome to Jio Payment Bank']")
    private WebElement WelcometoJioPaymentBankText;

    @FindBy(id = "buttonGetStart")
    private WebElement GetStartedButton;

    @FindBy(id = "ivCardImage")
    private WebElement element1;

    @FindBy(id = "tvYes")
    private WebElement OKButtonC;

    @FindBy(id = "tvMybillsLabel")
    private WebElement selectMyBills;

    @FindBy(id = "tvScheduledPaymentsLabel")
    private WebElement selectScheduledPayments;

    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'My Bills')]")
    private WebElement myBillsPageTitle;

    @FindBy(id = "tvToolbarTitle")
    private WebElement manageBillsPageTitle;

    @FindBy(xpath = "android.widget.TextView[contains(@text, 'Add Bills')]")       //
    private WebElement addBillsPageTitle;

    @FindBy(id = "menu_settings")
    private WebElement settingBtnOnMyBills;

    @FindBy(id = "iv_list_item_autopay")
    private WebElement calenderIconOnManageBillsPage;

    @FindBy(id = "b_add_bills")
    private WebElement addBillsBtnOnManageBillsPage;

    @FindBy(id = "ivJioIcon")
    private WebElement jioIconOnHomescreen;

    @FindBy(id = "tvToolbarTitle")
    private WebElement PaymentDueText;

    @FindBy(id = "b_add_bills")
    private WebElement AddBillsButton;

    @FindBy(id = "events_per_day")
    private WebElement CurrentDate;

    @FindBy(id = "display_current_date")
    private WebElement MonthYear;

    @FindBy(id = "next_month")
    private WebElement nextMonthClick;



    public HomeEntity(){
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void navigateToPage(String page){
        try
        {
            waitFor(20);
            LogManager.getLogger(HomeEntity.class).info("Navigating to Page : " + page);
            switch (page){
                case MOBILE :
                    clickElement(selectMobileOption);
                    break;
                case SENDMONEY :
                    waitFor(fundTransferOption,30);
                    clickElement(fundTransferOption);
                    break;
                case PASSBOOK :
                    waitFor(PassbookIcon,30);
                    clickElement(PassbookIcon);
                    break;
                case PAYATSHOP:
                    LogManager.getLogger(HomeEntity.class).info("Clicking Pay at Shop Option");
                    clickElement(payAtShop);
                    LogManager.getLogger(HomeEntity.class).info("Clicked Pay at Shop Option");
                    break;
                case ADDMONEY:
                    LogManager.getLogger(HomeEntity.class).info("Clicking Load Money Option");
                    clickElement(WalletIcon);
                    LogManager.getLogger(HomeEntity.class).info("Clicked Load Money Option");
                    break;
                case HOME:
                    LogManager.getLogger(HomeEntity.class).info("Clicking on Home Button");
                    clickElement(homeBtn);
                    LogManager.getLogger(HomeEntity.class).info("Clicked Home Button");
                    break;

            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in navigateToPage(String page): "+ex.getMessage());
        }

    }



}
