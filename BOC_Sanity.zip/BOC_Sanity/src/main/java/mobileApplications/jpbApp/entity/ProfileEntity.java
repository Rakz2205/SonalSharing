package mobileApplications.jpbApp.entity;
/**
 * To perform operations on elements present in Profile
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;

public class ProfileEntity extends BaseClass {
    @FindBy(id = "action_profile")
    WebElement profile;

    @FindBy(xpath = "//android.widget.TextView[@text='My Account']")
    WebElement myAccount;

    @FindBy(xpath = "//android.widget.TextView[@text='Security']")
    WebElement security;

    @FindBy(xpath = "//android.widget.TextView[@text='Favorites']")
    WebElement favorites;

    @FindBy(xpath = "//android.widget.TextView[@text='Help & FAQ's']")
    WebElement helpAndFaqs;

    @FindBy(xpath = "//android.widget.TextView[@text='About Us']")
    WebElement aboutUs;

    @FindBy(xpath = "//android.widget.TextView[@text='Rate App']")
    WebElement rateApp;

    @FindBy(xpath = "//android.widget.TextView[@text='Logout']")
    WebElement logout;


    @FindBy(id = "civ_user_img")
    WebElement userImage;

    @FindBy(id = "user_name")
    WebElement userName;

    @FindBy(id = "user_phonenumber")
    WebElement userPhoneNumber;

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Help')]")
    WebElement helpAndFaq;

    @FindBy(xpath = "//android.widget.TextView [@text='Rate App']")
    WebElement raAppOption;

    public ProfileEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void NavigateTo(String page)
    {
        try
        {
            waitFor(profile,30);
            clickElement(profile);
            waitFor(myAccount,30);
            switch (page) {
                case MY_ACCOUNT:
                    clickElement(myAccount);
                    break;
                case SECURITY:
                    clickElement(security);
                    break;
                case FAVORITES:
                    clickElement(favorites);
                    break;
                case HELP_AND_FAQS:
                    clickElement(helpAndFaqs);
                    break;
                case ABOUT_US:
                    clickElement(aboutUs);
                    break;
                case RATE_APP:
                    clickElement(rateApp);
                    break;
                case LOGOUT:
                    clickElement(logout);
                    break;
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in NavigateTo(String page): "+ex.getMessage());
        }


    }

}
