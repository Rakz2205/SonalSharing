package mobileApplications.jpbApp.entity;

/**
 * To perform Send Money Functionality
 *
 * @author Sneha Dasari
 */

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilityLibrary.base.BaseClass;
import mobileApplications.jpbApp.jpbUtils.AppUtil;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;
import java.util.List;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.text;
import static utilityLibrary.testData.Constants.*;

public class SendMoneyEntity extends BaseClass {

    //@FindBy(xpath = "//android.widget.TextView[@text = 'Aadhaar Seeding']")
    @FindBy(id = "etAmount")
    public WebElement enterAmount;

    @FindBy(id = "actNameOrNumber")
    private WebElement accountNoPhoneNoUpiID;

    @FindBy(id = "tvScanCodeIcon")
    private WebElement scanQRCode;

    @FindBy(xpath = "//android.widget.EditText[contains(@text,'Phone No')]")
    public WebElement accountNoPhoneNoUpiIDTextField;


    @FindBy(id = "tvadd")
    public WebElement addAccountNoOrVpaButton;
    @FindAll(@FindBy( id = "tvAccountName"))
    private List<WebElement> selectAccountNoFromAutosugessionList;

    @FindBy(id = "etRepeatAccNo")
    private WebElement reEnterAccountNoTextField;

    @FindBy(id = "etIfsc")
    private WebElement enterIFSCode;

    @FindBy(id = "etAccountName")
    private WebElement accountHolderNameTextField;

    @FindBy(id = "etPayMethod")
    private WebElement paymentMethodOption;

    @FindBy(id = "etComment")
    public WebElement commentTextField;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Instant Transfer (UPI)']")
    private WebElement UPI_paymentMode;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Instant Transfer (IMPS)']")
    private WebElement IMPS_paymentMode;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Will be transferred in 2 hours (NEFT)']")
    private WebElement NEFT_paymentMode;

    @FindBy(id = "btnMoneyTransferProceed")
    //@FindBy(xpath = "//android.widget.Button[@text = 'Proceed']")
    public WebElement proceedButton_sendMoney;

    @FindBy(id="tvYes")
    private WebElement confirmElement;

    @FindBy(xpath = "//android.widget.Button[@text='Confirm & Pay']")
    public WebElement confirmAndPay;
    @FindBy(id = "tvNo")
    private WebElement contactPermission;

    @FindBy(xpath = "//android.widget.TextView[@text='Favorites']")
    private WebElement favorites;

    @FindBy(id = "tvBankNote")
    private WebElement bankNote;

    @FindBy(id = "tvSendMoneyTip")
    private WebElement tip;

    @FindBy(id = "sectionHeader")
    private List<WebElement> headers;

    @FindBy(id = "//android.widget.TextView[contains(@text, 'UPI Handles']")
    private WebElement upiHandleHeader;

    @FindBy(id = "//android.widget.TextView[contains(@text, 'Other Bank A/c']")
    private WebElement otherBankAccount;

    @FindBy(id = "//android.widget.TextView[contains(@text, 'JioMoney Connections']")
    private WebElement mobileNumbers;

    @FindBy(xpath = "//android.widget.TextView[@text='Please enter a valid Mobile Number or Name']")
    public WebElement mobileErrorMsg;

    @FindBy(xpath = "//android.widget.TextView[@text='Please enter a valid transaction amount']")
    public WebElement amountErrorMsg;

    @FindBy(xpath = "//android.widget.TextView[@text='INVALID VIRTUAL ADDRESS']")
    private WebElement VPAErrorMsg;

    public SendMoneyEntity()  {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }


//    @FindBy(id = "action_scan")
//    private WebElement scanQRCodeToEnterVPAHandle;

    public List<WebElement> getSelectAccountNoFromAutosugessionList() {
        return selectAccountNoFromAutosugessionList;
    }

    public WebElement getElement(List<WebElement> webElementList, String number, String type){
        try
        {
            for (WebElement element:webElementList){
                if(element.getText().contains(number) && element.getText().contains(type))
                    return element;
            }
            return null;
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getElement(List<WebElement> webElementList, String number, String type): "+ex.getMessage());
        }


    }

    public void sendMoney(String toAccountNumber, Constants.TransactionType transactionType) {
        try
        {
            waitFor(15);
//        sendMoneyPage.getContactPermission().click();
            waitFor(enterAmount,30);
            enterAmount.sendKeys(JPBAppPro.getProperty("impsAmount"));
            androidDriver.hideKeyboard();
            clickElement(accountNoPhoneNoUpiID);
            waitFor(15);
            accountNoPhoneNoUpiIDTextField.sendKeys(toAccountNumber);
            androidDriver.hideKeyboard();
            waitFor(40);
            clickElement(getElement(selectAccountNoFromAutosugessionList,toAccountNumber,"A/c"));
            waitFor(reEnterAccountNoTextField,20);
            reEnterAccountNoTextField.sendKeys(toAccountNumber);
            androidDriver.hideKeyboard();
            enterIFSCode.sendKeys(JPBAppPro.getProperty("bankIFSC"));
            waitFor(15);
            accountHolderNameTextField.sendKeys(JPBAppPro.getProperty("bankHolderName"));
            waitFor(15);
            androidDriver.hideKeyboard();
            waitFor(15);
            clickElement(paymentMethodOption);
            waitFor(15);
            switch (transactionType){
                case NEFT_OUTWARD:
                    clickElement(NEFT_paymentMode);
                    break;
                case IMPS_OUTWARD:
                    clickElement(IMPS_paymentMode);
                    break;
                case UPI_SENDMONEY:
                    clickElement(UPI_paymentMode);
                    break;
            }

            waitFor(15);

            commentTextField.sendKeys("Automation Test");
            androidDriver.hideKeyboard();
            waitFor(15);
            AppUtil.scrollScreen();
            androidDriver.openNotifications();
            Thread.sleep(MIN_WAIT_TIME);
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            //((JavascriptExecutor)androidDriver).executeScript("arguments[0].click();",proceedButton_sendMoney);
            clickElement(proceedButton_sendMoney);
            clickElement(proceedButton_sendMoney);
            waitFor(15);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in sendMoney(String toAccountNumber, Constants.TransactionType transactionType): "+ex.getMessage());
        }


    }


}
