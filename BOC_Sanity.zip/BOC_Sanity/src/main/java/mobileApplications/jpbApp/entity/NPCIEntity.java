package mobileApplications.jpbApp.entity;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;
/**
 * To perform operations related to NPCI Page
 *
 * @author Sneha Dasari
 */
public class NPCIEntity extends BaseClass {

    @FindBy(xpath="//android.widget.TableRow/android.widget.ImageView[2]")
    private WebElement submitButtonNpciPage;

    @FindBy(xpath = "//*[contains(@text,'ENTER UPI PIN')]")
    private WebElement npciPageTitle;

    @FindBy(id = "form_item_input")
    private WebElement upiPinElement;

    @FindBy(xpath = "//android.widget.Button[@text='Enter UPI PIN']")
    private WebElement proceedToNpciPage;




    public NPCIEntity() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    public void enterUPIPin(){

        try
        {
            waitFor(upiPinElement,30);
            clickElement(upiPinElement);
            waitFor(androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@index,1)]")),60);
            String upiPin = JPBAppPro.getProperty("UPIPIN");
            char[] digits = new char[4];
            upiPinElement.sendKeys(JPBAppPro.getProperty("UPIPIN"));
            clickElement(submitButtonNpciPage);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterUPIPin(): "+ex.getMessage());
        }

    }
}