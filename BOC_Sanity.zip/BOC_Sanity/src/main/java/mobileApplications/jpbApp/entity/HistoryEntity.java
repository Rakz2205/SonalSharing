package mobileApplications.jpbApp.entity;
/**
 * To check history and apply filters
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.jpbUtils.Constants;
import mobileApplications.jpbApp.jpbUtils.FilterUtils;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.util.List;

import static utilityLibrary.utils.FilterUtils.*;

public class HistoryEntity extends BaseClass {

    ChangeMPINEntity changeMPINEntity;
    HomeEntity homeEntity;
    //FilterUtils filterUtils;

    public HistoryEntity() {
        try {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            changeMPINEntity = new ChangeMPINEntity();
            homeEntity = new HomeEntity();
            //filterUtils=new FilterUtils();
            //homeEntity.navigateToPage(HOME);
            homeEntity.navigateToPage(Constants.PASSBOOK);
            try {
                changeMPINEntity.enterMPIN();
            }
            catch(Exception ex)
            {
                LogManager.getLogger(HistoryEntity.class).info("MPIN is not asked");
            }
        }catch (Exception ex)
        {
            throw new RuntimeException("Error in HistoryEntity(): "+ex.getMessage());
        }

    }

    @FindAll(@FindBy(id="btnDate"))
    List<WebElement> dates;

    @FindAll(@FindBy(id="btnMonth"))
    List<WebElement> months;

    @FindBy(id="tvRightOne")
    WebElement historyFilter;

    @FindBy(id="rbLastOneMonth")
    WebElement lastOneMonth;

    @FindBy(id="rbLastSevenDays")
    WebElement lastSevenDays;

    @FindBy(id="rbLastThreeMonth")
    WebElement lastThreeMonths;

    @FindBy(id="rbLastNMonth")
    WebElement lastSixMonths;

    @FindBy(id="rbLastPickDate")
    WebElement pickADate;

    @FindBy(id="etTrxSelectStartDate")
    WebElement startDateButton;

    @FindBy(id="etTrxSelectEndDate")
    WebElement endDateButton;

    @FindBy(xpath="//android.view.View[@content-desc='31 October 2019']")
    WebElement calenderDates;

    @FindBy(id="button1")
    WebElement calenderOKButton;

    @FindBy(id="button2")
    WebElement calenderCancelButton;

    @FindBy(id="android:id/prev")
    WebElement prevButton;

    @FindBy(id="btnProceed")
    WebElement proceedButton;

    @FindBy(xpath="//android.support.v7.app.ActionBar.Tab[@content-desc='Bank']/android.widget.RelativeLayout/android.widget.TextView")
    WebElement bankTab;

    @FindBy(xpath="//android.support.v7.app.ActionBar.Tab[@content-desc='Payments']/android.widget.RelativeLayout/android.widget.TextView")
    WebElement paymentsTab;

    @FindBy(xpath = "//android.support.v7.app.ActionBar.Tab[@content-desc='UPI']/android.widget.RelativeLayout/android.widget.TextView")
    WebElement upiTab;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.LinearLayout/android.support.v4.view.ViewPager/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.TextView")
    WebElement noTransactionsText;

    @FindBy(id="tvDuration")
    WebElement durationText;

    @FindAll(@FindBy(id="tvTransactionPrice"))
    List<WebElement> txnPrice;

    @FindAll(@FindBy(id="tvTransactionDetail"))
    List<WebElement> txnTypeDetails;



    WebElement startDate;
    String d1,d2, mon1,mon2, y1,y2;
    String customDateText;

    public void TodayHistory(String tabOption)
    {
        boolean result;
        try
        {
            selectTab(tabOption);
            if (areElementsDisplayed(dates))
            {
                LogManager.getLogger(HistoryEntity.class).info(dates.size() + " transactions are done");
                result = dates.size()>0;
            } else if (isElementDisplayed(noTransactionsText)) {
                LogManager.getLogger(HistoryEntity.class).info(getTextfromElement(noTransactionsText));
                result = true;
            } else {
                LogManager.getLogger(HistoryEntity.class).info("Error occured when "+tabOption+" was opened");
                result = false;
            }
            Assert.assertTrue(result, "Bank Page error occured");

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in TodayHistory(String tabOption): "+ex.getMessage());
        }

    }

    public void selectTab(String opt)
    {
        try
        {
            if(opt.equalsIgnoreCase("Payments"))
            {
                clickElement(paymentsTab);
            }
            else if(opt.equalsIgnoreCase("UPI"))
            {
                clickElement(upiTab);
            }
            else
            {
                clickElement(bankTab);
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in selectTab(String opt): "+ex.getMessage());
        }
        finally {
            //Capturing screenshot after passbook is open
            takeSnapShot(opt+" Tab is clicked in Passbook section");
        }

    }

    public void CustomFilterHistory(String tabOption)
    {
        try
        {
            boolean result;
            selectTab(tabOption);
            clickElement(historyFilter);
            clickElement(pickADate);
            clickElement(startDateButton);
            if (getDate() == "1" && !getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************Start1***************");
                clickElement(prevButton);
                clickElement(startDate = androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 " + " " + getPreviousMonth() + " " + getYear() + "']")));
                clickElement(calenderOKButton);
                d1="01";
                mon1=getPreviousMonth().substring(0,3);
                y1=getYear();
            } else if (getDate() == "1" && getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************Start2***************");
                clickElement(prevButton);
                clickElement(startDate = androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 " + " " + getPreviousMonth() + " " + getPreviousYear() + "']")));
                clickElement(calenderOKButton);
                d1="01";
                mon1=getPreviousMonth().substring(0,3);
                y1=getPreviousYear();
            }
            else if (getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************Start2***************");
                clickElement(prevButton);
                clickElement(startDate = androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 " + getPreviousMonth() + " " + getPreviousYear() + "']")));
                clickElement(calenderOKButton);
                d1="01";
                mon1=getPreviousMonth().substring(0,3);
                y1=getPreviousYear();
            } else {
                LogManager.getLogger(HistoryEntity.class).info("*****************Start3***************");
                clickElement(prevButton);
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01" + " " + getPreviousMonth() + " " + getYear() + "']")));
                clickElement(calenderOKButton);
                d1="01";
                mon1=getPreviousMonth().substring(0,3);
                y1=getYear();
            }
            clickElement(endDateButton);
            if (getDate() == "1" && !getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************End1***************");
                clickElement(prevButton);
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='28" + " " + getPreviousMonth() + " " + getYear() + "']")));
                clickElement(calenderOKButton);
                d2="28";
                mon2=getPreviousMonth().substring(0,3);
                y2=getYear();
            } else if (getDate() == "1" && getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************End2***************");
                clickElement(prevButton);
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='31" + " " + getPreviousMonth() + " " + getPreviousYear() + "']")));
                clickElement(calenderOKButton);
                d2="31";
                mon2=getPreviousMonth().substring(0,3);
                y2=getPreviousYear();
            }else if (getMonth().equalsIgnoreCase("January")) {
                LogManager.getLogger(HistoryEntity.class).info("*****************End2***************");
                clickElement(prevButton);
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='31" + " " + getPreviousMonth() + " " + getPreviousYear() + "']")));
                clickElement(calenderOKButton);
                d2="31";
                mon2=getPreviousMonth().substring(0,3);
                y2=getPreviousYear();
            } else {
                LogManager.getLogger(HistoryEntity.class).info("*****************End3***************");

                if(getDate().length()==1)
                {
                    d2="0"+getDate();
                    LogManager.getLogger(HistoryEntity.class).info("Custom Date:"+d2);
                }
                else
                {
                    d2=getDate();
                }
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='" + d2 + " " + getMonth() + " " + getYear() + "']")));
                clickElement(calenderOKButton);
                mon2=getMonth().substring(0,3);
                y2=getYear();
            }
            clickElement(proceedButton);

            try {
                changeMPINEntity.enterMPIN();
            }
            catch (Exception ex)
            {
                LogManager.getLogger(HistoryEntity.class).info("MPIN is not asked");
            } finally {
                if (isElementDisplayed(noTransactionsText)) {
                    result = true;
                } else if (isElementDisplayed(durationText)) {
                    result = getCustomDuration(d1, d2, mon1, mon2, y1, y2);
                } else {
                    result = false;
                }
                Assert.assertTrue(result, "Custom Filter for Bank Failed");
            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in CustomFilterHistory(String tabOption): "+ex.getMessage());
        }

        }

    public boolean getCustomDuration(String dd1, String dd2, String monn1, String monn2, String yy1, String yy2) {

        try
        {
            customDateText = dd1 + " " + monn1 + " " + yy1 + " To " + dd2 + " " + monn2 + " " + yy2;
            LogManager.getLogger(HistoryEntity.class).info("Custom Date in getCustomDurationMethod : "+customDateText);
            waitFor(durationText, 60);
            return getTextfromElement(durationText).equalsIgnoreCase(customDateText);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getCustomDuration(): "+ex.getMessage());
        }


    }

    public void getTxnHistoryDetails(String txnType, String tranPrice)
    {
        int flag;
        try
        {
            if (areElementsDisplayed(dates))
            {
                flag = getDate().contains(getTextfromElement(dates.get(0)))? getTextfromElement(txnTypeDetails.get(0)).contains(txnType) ? getTextfromElement(txnPrice.get(0)).contains(tranPrice) ? 0 : 4 : 3 : 2;
            }
            else {
                flag = 1;
            }
            softAssert.assertEquals(flag,0,"Prepaid Mobile transaction is not displayed in PassBook");
            softAssert.assertFalse(flag == 1, "Transaction Entry is not displayed in PassBook section");
            softAssert.assertFalse(flag == 2, "Transaction Date mismatch");
            softAssert.assertFalse(flag == 3, "Transaction Type Mismatch");
            softAssert.assertFalse(flag == 4, "Transaction Amount Mismatch");
            softAssert.assertAll();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getTxnHistoryDetails(String txnType, String tranPrice): "+ex.getMessage());
        }

    }




}
