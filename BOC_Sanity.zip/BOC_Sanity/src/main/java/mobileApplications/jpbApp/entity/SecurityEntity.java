package mobileApplications.jpbApp.entity;
/**
 * To perform Change Password, change MPIN, Forget MPIN etc Security related functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.jpbUtils.Constants;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

public class SecurityEntity extends BaseClass {

    @FindBy(xpath = "//android.widget.TextView[@text='Change JioMoney Password']")
    private WebElement changeJioMoneyPassword;

    @FindBy(xpath = "//android.widget.TextView[@text='Change MPIN']")
    public WebElement changeMPin;

    @FindBy(xpath = "//android.widget.TextView[@text='Forgot MPIN']")
    public WebElement forgotMPin;

    @FindBy(xpath = "//android.widget.TextView[@text='Linked Merchants']")
    private WebElement enableTouchID;

    @FindBy(xpath = "//android.widget.TextView[@text='Linked Merchants']")
    private WebElement linkedMerchants;

    @FindBy(xpath = "//android.widget.ImageButton[@index = '0']")
    private WebElement backBtn;


    public SecurityEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void NavigateTo(String page)
    {
        try
        {
            switch (page) {
                case Constants.CHANGE_JIOMONEY_PASSWORD:
                    clickElement(changeJioMoneyPassword);
                    break;
                case Constants.CHANGE_MPIN:
                    clickElement(changeMPin);
                    break;
                case Constants.FORGOT_MPIN:
                    clickElement(forgotMPin);
                    break;
                case Constants.ENABLE_TOUCH_ID:
                    clickElement(enableTouchID);
                    break;
                case Constants.LINKED_MERCHANTS:
                    clickElement(linkedMerchants);
                    break;
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in NavigateTo(String page): "+ex.getMessage());
        }

    }
}
