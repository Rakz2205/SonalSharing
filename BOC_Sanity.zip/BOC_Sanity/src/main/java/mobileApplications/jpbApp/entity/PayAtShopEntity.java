package mobileApplications.jpbApp.entity;
/**
 * To perform payments to Merchant functionality using Barcode and Mobile
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.HOME;
import static mobileApplications.jpbApp.jpbUtils.Constants.PAYATSHOP;
import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;

public class PayAtShopEntity extends BaseClass {

    ChangeMPINEntity changeMPINEntity;
    HomeEntity homeEntity;

    @FindBy(xpath = "//android.widget.TextView[@text='Barcode']")
    public WebElement barcodeTab;

    @FindBy(className = "android.widget.EditText")
    public WebElement amountToPay_barcode;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Pay Now']")
    public WebElement payNowButton;

    @FindBy(xpath = "//android.widget.TextView[@text='Mobile']")
    public WebElement mobileTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Mobile Number/VPA of Merchant']")
    public WebElement merchantMobileOrVPA;

    //@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.widget.EditText[2]")
    @FindBy(xpath = "//android.widget.TextView[contains(@text , 'Amount to Pay')]")
    public WebElement amountToPay_mobile;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Remarks(Optional)']")
    public WebElement remarks_optional;

    @FindBy(id = "permission_allow_button")
    public WebElement accessYourContact;

    @FindBy(xpath = "//android.widget.TextView[@text='Mobile']")
    public WebElement merchantName_Rahul;

    @FindBy(xpath = "//android.widget.Button[@text='Review & Pay']")
    public WebElement reviewAndPayButton;

    @FindBy(xpath = "//android.widget.Button[@text='Confirm & Pay']")
    public WebElement confirmAndPayButton;

    @FindBy(xpath = "//android.widget.TextView[@index='1']")
    public WebElement suggestName;

    @FindBy(xpath = "//android.view.View[@index='0']")
    public WebElement suggestTab;

    @FindBy(xpath = "//android.widget.TextView[@index = '5']")
    public WebElement nameErrorMessage;

    @FindBy(xpath = "//android.widget.TextView[@index = '10']")
    public WebElement amountErrorMessage;

    @FindBy(xpath = "//android.view.view[@index='3']")
    public WebElement loyalityIcon;

    @FindBy(xpath = "//*[contains(@text,'Testing Merchant')]")
    public WebElement selectMerchant;

    @FindBy(id = "tvBarCode")
    public WebElement barcode;

    public PayAtShopEntity() {
        try
        {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
            homeEntity = new HomeEntity();
            changeMPINEntity = new ChangeMPINEntity();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in PayAtShopEntity(): "+ex.getMessage());
        }

    }

    public void performMerchantTransaction(String merchantRecipient) {
        try
        {
            homeEntity.navigateToPage(HOME);
            homeEntity.navigateToPage(PAYATSHOP);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(mobileTab);
            waitFor(merchantMobileOrVPA,20);
            merchantMobileOrVPA.clear();
            merchantMobileOrVPA.sendKeys(merchantRecipient);
            clickElement(selectMerchant);
            clickElement(selectMerchant);
            waitFor(amountToPay_mobile,20);
            //clickElement(amountToPay_mobile);
            Thread.sleep(AVG_WAIT_TIME);
            amountToPay_mobile.clear();
            amountToPay_mobile.sendKeys(JPBAppPro.getProperty("MerchantAmount"));
            //amountToPay_mobile.sendKeys("0.10");
            androidDriver.hideKeyboard();
            waitFor(payNowButton,20);
            clickElement(payNowButton);
            waitFor(reviewAndPayButton,20);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(reviewAndPayButton);
            waitFor(confirmAndPayButton,20);
            clickElement(confirmAndPayButton);
            changeMPINEntity.enterMPIN();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in performMerchantTransaction(): "+ex.getMessage());
        }

    }

    public String payUsingBarcode() {
        try
        {
            homeEntity.navigateToPage(HOME);
            homeEntity.navigateToPage(PAYATSHOP);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(barcodeTab);
            waitFor(amountToPay_mobile,20);
            //clickElement(amountToPay_mobile);
            Thread.sleep(AVG_WAIT_TIME);
            amountToPay_mobile.clear();
            amountToPay_mobile.sendKeys(JPBAppPro.getProperty("MerchantAmount"));
            androidDriver.hideKeyboard();
            waitFor(payNowButton,20);
            clickElement(payNowButton);
            changeMPINEntity.enterMPIN();
            waitFor(barcode,30);
            String barcodeValue=getTextfromElement(barcode);
            return barcodeValue;
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in payUsingBarcode(): "+ex.getMessage());
        }


    }


}
