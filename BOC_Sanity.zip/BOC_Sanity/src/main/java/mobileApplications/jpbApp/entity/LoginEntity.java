package mobileApplications.jpbApp.entity;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;
/**
 * To perform Login Functionality
 *
 * @author Sneha Dasari
 */
public class LoginEntity extends BaseClass
{

    @FindBy(id="rlSimSelectOne")
    WebElement simOne;

    @FindBy(id="rlSimSelectTwo")
    WebElement simTwo;

    @FindBy(id="tvSimSelectVerify")
    WebElement sendSms;

    @FindBy(id = "etMobileNumber")
    public WebElement mobileNumberTextField;

    @FindBy(id = "etPassword")
    public WebElement passwordTextField;

    @FindBy(id = "btnSignin")
    public WebElement loginButton;

    @FindBy(id = "tvlater")
    WebElement touchIdLater;

    @FindBy(id = "tvok")
    WebElement touchIdOk;

    @FindBy(id = "tvForgotPassword")
    WebElement forgotPassword;

    @FindBy(id = "tvLoading")
    WebElement loginSignUp;

    @FindBy(xpath = "//android.widget.TextView[@text='Authentication Failed']")
    WebElement authFailed;

    @FindBy(xpath = "//android.widget.TextView[@text='Please enter a valid Mobile Number']")
    WebElement WrongMobNumberAlert;

    @FindBy(id = "tvHelpFaq")
    WebElement helpFAQ;

    @FindBy(id = "btnSignin")
    WebElement loginButtonEnabled;

    @FindBy(id = "tvCreateAcc")
    WebElement createAccBtn;

    @FindBy(id = "action_profile")
    WebElement profileViewButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.view.ViewGroup/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[6]/android.widget.LinearLayout/android.widget.TextView[2]")
    WebElement logoutButton;

    @FindBy(id = "tvYes")
    WebElement confirmYes;



    public LoginEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    //Login to JPM
    public void loginToJPB(){
        try
        {
            String result;
            if(isElementDisplayed(simOne))
            {
                if(JPBAppPro.getProperty("simNumber").equalsIgnoreCase("One"))
                {
                    clickElement(simOne);
                }
                else
                {
                    clickElement(simTwo);
                }

            }
            while(isElementDisplayed(sendSms))
            {
                if(getTextfromElement(sendSms).contains("delivered"))
                {
                    break;
                }
                else
                {
                    waitFor(sendSms,30);
                    clickElement(sendSms);
                }
            }
            result = enterCredentials(JPBAppPro.getProperty("MobileNumber"),JPBAppPro.getProperty("Password"));
            Assert.assertTrue(result.equalsIgnoreCase("true"),"Login Failed");

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in loginToJPB(): "+ex.getMessage());
        }


    }

    public String enterCredentials(String mob, String pass)
    {
        /*try
        {*/
            waitFor(mobileNumberTextField,30);
            mobileNumberTextField.sendKeys(mob);
            clickElement(loginButton);
            waitFor(passwordTextField,30);
            passwordTextField.sendKeys(pass);
            androidDriver.hideKeyboard();
            waitFor(10);
            clickElement(loginButton);
            waitFor(profileViewButton,30);
            if(isElementDisplayed(profileViewButton))
                return "true";
            else
                return "";
       /* }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in enterCredentials(): "+ex.getMessage());
        }*/


    }

    public void logoutfromJPB()
    {
        try
        {
            clickElement(profileViewButton);
            waitFor(logoutButton, 30);
            clickElement(logoutButton);
            clickElement(confirmYes);
            waitFor(sendSms,30);
            Assert.assertTrue(getTextfromElement(sendSms).equalsIgnoreCase("Send SMS"),"Logout Failed");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in logoutfromJPB(): "+ex.getMessage());
        }

    }

    public void forgetPasswordInit()
    {
        try
        {
            if(isElementDisplayed(simOne))
            {
                if(JPBAppPro.getProperty("simNumber").equalsIgnoreCase("One"))
                {
                    clickElement(simOne);
                }
                else
                {
                    clickElement(simTwo);
                }
            }
            waitFor(sendSms,30);
            clickElement(sendSms);
            waitFor(mobileNumberTextField,30);
            mobileNumberTextField.sendKeys(JPBAppPro.getProperty("MobileNumber"));
            clickElement(loginButton);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in forgetPasswordInit(): "+ex.getMessage());
        }

    }




}
