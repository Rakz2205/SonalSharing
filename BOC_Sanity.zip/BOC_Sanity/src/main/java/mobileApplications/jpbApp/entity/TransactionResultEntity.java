package mobileApplications.jpbApp.entity;
/**
 * To get the Transaction Results
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;
import java.util.List;

public class TransactionResultEntity extends BaseClass
{
    String tnType, tnPrice;
    @FindBy(id="tvTransactionStatusTitle")
    private WebElement txnFailure;

    @FindAll(@FindBy( xpath = "//android.widget.TextView"))
    private List<WebElement> txnDetails;

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Success')]")
    public WebElement txnSuccessMsg;

    @FindBy(xpath = "//android.widget.Button[contains(@text, 'Home')]")
    public WebElement homeButton;

    @FindBy(id = "tvYes")
    public WebElement cancelPaymentButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    public WebElement txnID;

    @FindBy(xpath = "//*[@id='tvCreditTransactionId']")
    public WebElement txnId;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout[2]/android.widget.TextView[2]")
    public WebElement txnDate;


    public TransactionResultEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    public boolean checkForSuceessScreen(){

        try
        {
            try {
                waitFor(txnSuccessMsg,120);
                if(isElementDisplayed(txnSuccessMsg)) {
                    return true;
                }
                else
                {
                    LogManager.getLogger(TransactionResultEntity.class).info("Success Message is not displayed");
                    return false;
                }
            }
            catch (TimeoutException e ) {
                LogManager.getLogger(TransactionResultEntity.class).info("Time out occurred after waiting for success screen");
                return false;
            }
            catch (NoSuchElementException e ) {
                LogManager.getLogger(TransactionResultEntity.class).info("Transaction failed");
                return false;
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in checkForSuceessScreen(): "+ex.getMessage());
        }
        finally {
            //Capturing screenshot for Transaction Result screen
            takeSnapShot("Transaction Result for Load Money");
        }

    }

    public WebElement getTxnFailure() {
        try
        {
            return txnFailure;
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getTxnFailure(): "+ex.getMessage());
        }

    }

    public String getTxnType()
    {
        try
        {
            return tnType;
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getTxnType(): "+ex.getMessage());
        }

    }

    public String getTxnAmount()
    {
        try
        {
            return tnPrice;
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in getTxnAmount(): "+ex.getMessage());
        }

    }

    public void clickHomeButton(boolean txnResult)
    {
        try
        {
            if(!txnResult)
            {
                waitFor(homeButton,30);
                if(isElementDisplayed(homeButton))
                {
                    clickElement(homeButton);
                }
                else
                {
                    androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                    if(!isElementDisplayed(cancelPaymentButton)) {
                        androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                        clickElement(cancelPaymentButton);
                    }
                    else {
                        clickElement(cancelPaymentButton);
                    }
                    clickElement(homeButton);
                }
            }
            else
            {
                clickElement(homeButton);
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in clickHomeButton(boolean txnResult): "+ex.getMessage());
        }
        finally {
            Assert.assertTrue(txnResult,"Transaction Failed");
        }

    }

}