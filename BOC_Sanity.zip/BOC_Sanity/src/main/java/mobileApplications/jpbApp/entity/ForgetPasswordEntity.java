package mobileApplications.jpbApp.entity;
/**
 * To perform forget password functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class ForgetPasswordEntity extends BaseClass
{
    @FindBy(id = "etMobileNumber")
    private WebElement mobNumber;

    @FindBy(id = "etDob")
    private WebElement dateOfBirth;

    @FindBy(id = "btnCreate")
    private WebElement createButton;

    @FindBy(id = "etOtp")
    private WebElement otpTextField;

    @FindBy(id = "etPassword")
    private WebElement passwordObject;

    @FindBy(id = "etConfirmPassword")
    private WebElement confirmPassword;

    @FindBy(id = "btnVerifyDOB")
    private WebElement verifyDOBButton;

    @FindBy(id = "tvSimSelectMessage")
    public WebElement verifyHomePageMessage;

    @FindBy(xpath = "//android.widget.TextView[@text='The password must contain atleast 1 number and 1 alpha character']")
    public WebElement passwordNotMatch;

    @FindBy(xpath = "//android.widget.TextView[@text='Password should not contain more than 3 sequence numbers or characters.']")
    public WebElement passwordNotMatchSeq;

    @FindBy(xpath = "//android.widget.TextView[@text='Passwords don't match']")
    public WebElement passwordContainsNotMatch;

    @FindBy(id = "tvForgotPassword")
    private WebElement forgotPassword;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='android:id/message_text']")
    private WebElement otpMessage;

    @FindBy(id="tvSimSelectVerify")
    WebElement sendSms;

    public ForgetPasswordEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void forgetPassword()
    {
        try
        {
            androidDriver.openNotifications();
            clickElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")));
            clickElement(forgotPassword);
            dateOfBirth.sendKeys(JPBAppPro.getProperty("DOB"));
            clickElement(verifyDOBButton);
            androidDriver.openNotifications();
            waitFor(otpMessage,60);
            String otpmessage= getTextfromElement(otpMessage);
            //LogManager.getLogger(ForgetPasswordEntity.class).info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
            LogManager.getLogger(ForgetPasswordEntity.class).info(otpmessage);
            String otp=otpmessage.replaceAll("[^0-9]","").substring(0,6).trim();
            LogManager.getLogger(ForgetPasswordEntity.class).info("Your otp is "+otp);
            clickElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")));
            if(!isElementDisplayed(otpTextField))
            {
                androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            }
            otpTextField.sendKeys(otp);
            passwordObject.sendKeys(JPBAppPro.getProperty("Password"));
            confirmPassword.sendKeys(JPBAppPro.getProperty("Password"));
            clickElement(createButton);
            waitFor(sendSms,30);
            Assert.assertTrue(getTextfromElement(sendSms).equalsIgnoreCase("Send SMS"),"Forget Password Failed");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in forgetPassword(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("Forget Password");
        }

    }
}
