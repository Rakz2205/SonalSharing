package mobileApplications.jpbApp.entity;
/**
 * To perform Open Loop transactions
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.omg.SendingContext.RunTime;
import utilityLibrary.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;


public class OpenLoopEntity extends BaseClass {

    ChangeMPINEntity changeMPINEntity;

    @FindBy(id = "etAmount")
    private WebElement enterAmount;

    @FindBy(id = "btnLoad")
    private WebElement loadButton;

    @FindBy(id="checkBalance")
    private WebElement check_balance_option;

    @FindBy(id = "tvUpiRadioButton")
    private WebElement upiSelect;

    @FindBy(id = "tvJioInsufficientBalanceInfo")
    private WebElement insuffBal;


    @FindBy(id = "tvNetBankingRadioButton")
    public WebElement netBankingSelect;

    @FindBy (xpath ="//*[contains(@resource-id,'rvSavedInstruments')]//*[@text='UPI']" )
    private WebElement upiPushOption; //This is an alternative to click on third party Bank for UPI Push. The radio button is tedious to find since there are possibilities of multiple elements

    @FindBy(id = "tvDebitCardRadioButton")
    public WebElement debitCardSelect;


    @FindBy(id = "tvCreditCardRadioButton")
    private WebElement creditCardSelect;


    @FindBy(id = "tvYes")
    private WebElement cancelPayment;


    @FindBy(id = "tvNo")
    private WebElement continuePayment;


    @FindBy(id = "tvCreditTransactionId")
    private WebElement transactionIdLabel;


    @FindBy(id = "btnPay")
    private WebElement reviewAndPay ;

    @FindBy(xpath = "//android.widget.TextView[@text='Punjab National Bank - Retail']")
    private WebElement selectBankName;

    @FindBy(id = "btnConfirm")
    private WebElement confirmAndAdd ;

    @FindBy(xpath = "//android.widget.Spinner[@text='Select']")
    private WebElement bankStatus ;

    @FindBy(xpath = "//android.widget.CheckedTextView[@text='Success']")
    private WebElement success;

    @FindBy(xpath = "//android.widget.Button[@text='Submit']")
    private WebElement submitButton ;

    @FindBy(id = "etCardNumber")
    private WebElement debitCardNumber ;

    @FindBy(id = "etName")
    private WebElement nameOnCard ;

    @FindBy(id = "etExpiry")
    private WebElement expiryDate ;


    @FindBy(id = "etCvv")
    private WebElement cardCVV ;

    @FindBy(id = "btnAdd")
    private  WebElement debitCardReviewAndPay ;

    @FindBy(id = "btnAdd")
    private  WebElement creditCardReviewAndPay ;

    @FindBy(id = "tvFailureTitle")
    private WebElement failureTitle ;

    @FindBy(id = "tvCreditTransactionId")
    private WebElement transactionId ;

    @FindBy(id = "tvPaymentType")
    private WebElement transactionType ;

    @FindBy(id = "tvTransactionReason")
    private  WebElement transactionReason ;

    @FindBy(id = "tvTransactionPhone")
    private WebElement transactionMobile;

    @FindBy(id = "btnHome")
    private WebElement homeButton ;

    // DTH Failure

    @FindBy(id = "tvDebitTransactionId")
    private WebElement transactionIdRecharge ;

    @FindBy(id = "tvTransactionPhone")
    private WebElement rechargeToText;


    public OpenLoopEntity() {
        try {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
            changeMPINEntity = new ChangeMPINEntity();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in OpenLoopEntity: "+ex.getMessage());
        }

    }


    public void openLoopPayments(String transactionType,String transactionMethod){

        try
        {
            waitFor(20);

            switch (transactionMethod) {
                case UPI :
                    clickElement(upiSelect);
                    break;

                case NETBANKING :
                    waitFor(30);
                    //clickElement(netBankingSelect);
                    TouchAction action = new TouchAction(androidDriver);
                    action.tap(PointOption.point(netBankingSelect.getLocation()));
                    action.perform();
                    waitFor(30);
                    clickElement(reviewAndPay);
                    waitFor(30);
                    clickElement(selectBankName);
                    waitFor(30);
                    clickElement(confirmAndAdd);
                    waitFor(20);
                    try {
                        changeMPINEntity.enterMPIN();
                    }
                    catch (Exception ex)
                    {
                        LogManager.getLogger(OpenLoopEntity.class).info("MPIN is not asked");
                    }
                    break;
                case DEBITCARD :
                    waitFor(20);
                    waitFor(debitCardSelect,30);
                    clickElement(debitCardSelect);
                    waitFor(10);
                    waitFor(reviewAndPay,30);
                    clickElement(reviewAndPay);
                    waitFor(debitCardNumber,30);
                    debitCardNumber.sendKeys(JPBAppPro.getProperty("DebitCardNumber"));
                    androidDriver.hideKeyboard();
                    waitFor(nameOnCard,30);
                    nameOnCard.sendKeys(JPBAppPro.getProperty("DebitCardName"));
                    androidDriver.hideKeyboard();
                    waitFor(expiryDate,30);
                    expiryDate.sendKeys(JPBAppPro.getProperty("DebitCardExpDate"));
                    androidDriver.hideKeyboard();
                    waitFor(cardCVV,30);
                    cardCVV.sendKeys(JPBAppPro.getProperty("DebitCardCvv"));
                    androidDriver.hideKeyboard();
                    waitFor(debitCardReviewAndPay,30);
                    clickElement(debitCardReviewAndPay);
                    waitFor(confirmAndAdd,30);
                    clickElement(confirmAndAdd);
                    waitFor(20);
                    break;
                case WALLET :
                    if(isElementDisplayed(insuffBal))
                    {
                        break;
                    }
                    waitFor(30);
                    waitFor(reviewAndPay,30);
                    clickElement(reviewAndPay);
                    waitFor(confirmAndAdd,30);
                    clickElement(confirmAndAdd);
                    waitFor(40);
                    changeMPINEntity.enterMPIN();
                    break;

            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in openLoopPayments(String transactionType,String transactionMethod): "+ex.getMessage());
        }



    }


}
