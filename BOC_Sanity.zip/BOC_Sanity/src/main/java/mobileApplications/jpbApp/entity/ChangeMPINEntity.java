package mobileApplications.jpbApp.entity;
/**
 * To perform MPIN related Operations
 *
 * @author Sneha Dasari
 */

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;
import static mobileApplications.jpbApp.jpbUtils.Constants.*;

public class ChangeMPINEntity extends BaseClass
{
    @FindBy(id="btnProceed")
    WebElement proceedButton;

    ProfileEntity profileEntity;
    SecurityEntity securityEntity;
    LoginEntity loginEntity;

    public ChangeMPINEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
        profileEntity = new ProfileEntity();
        securityEntity = new SecurityEntity();
        loginEntity = new LoginEntity();
    }

    public void changeMPIN()
    {
        try
        {
            profileEntity.NavigateTo(SECURITY);
            securityEntity.NavigateTo(CHANGE_MPIN);
            char[] digits = new char[4];
            String mpin = JPBAppPro.getProperty("MPIN");
            for(int i=0;i<digits.length;i++)
            {
                digits[i]=mpin.charAt(i);
                clickElement(androidDriver.findElement(By.xpath("//android.widget.Button[contains(@text,"+digits[i]+")]")));
            }
            mpin = JPBAppPro.getProperty("NewMPIN");
            for(int j=0;j<2;j++)
            {
                for(int i=0;i<digits.length;i++)
                {
                    digits[i]=mpin.charAt(i);
                    clickElement(androidDriver.findElement(By.xpath("//android.widget.Button[contains(@text,"+digits[i]+")]")));
                    waitFor(10);
                }
            }
            Assert.assertTrue(getTextfromElement(securityEntity.changeMPin).equalsIgnoreCase("Change MPIN"),"Change MPIN Failed");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in changeMPIN(): "+ex.getMessage());
        }



    }

    public void forgetMPIN()
    {
        try
        {
            waitFor(20);
            LogManager.getLogger(ChangeMPINEntity.class).info("Forget Mpin");
            securityEntity.NavigateTo(FORGOT_MPIN);
            waitFor(loginEntity.passwordTextField,30);
            loginEntity.passwordTextField.sendKeys(JPBAppPro.getProperty("Password"));
            waitFor(proceedButton,30);
            clickElement(proceedButton);
            waitFor(30);
            String mpin = JPBAppPro.getProperty("MPIN");
            char[] digits = new char[4];

            for(int j=0;j<2;j++)
            {
                for(int i=0;i<digits.length;i++)
                {
                    digits[i]=mpin.charAt(i);
                    clickElement(androidDriver.findElement(By.xpath("//android.widget.Button[contains(@text,"+digits[i]+")]")));
                    waitFor(10);
                }
            }
            Assert.assertTrue(getTextfromElement(securityEntity.forgotMPin).equalsIgnoreCase("Forgot MPIN"),"Forget MPIN Failed");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in forgetMPIN(): "+ex.getMessage());
        }


    }

    public void enterMPIN()
    {
        try
        {
            String mpin = JPBAppPro.getProperty("MPIN");
            char[] digits = new char[4];
            for(int i=0;i<digits.length;i++)
            {
                digits[i]=mpin.charAt(i);
                clickElement(androidDriver.findElement(By.xpath("//android.widget.Button[contains(@text,"+digits[i]+")]")));
                waitFor(10);
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterMPIN(): "+ex.getMessage());
        }


    }

}
