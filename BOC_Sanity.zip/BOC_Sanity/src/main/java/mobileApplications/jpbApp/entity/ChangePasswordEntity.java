package mobileApplications.jpbApp.entity;
/**
 * To change password
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.jpbUtils.Constants;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class ChangePasswordEntity extends BaseClass
{
    @FindBy(id = "etOldPassword")
    private WebElement oldPasswordField;

    @FindBy(id = "etNewPassword")
    private WebElement newPasswordField;

    @FindBy(id = "etConfPassword")
    private WebElement confirmPasswordField;

    @FindBy(id = "btnChange")
    private WebElement changePasswordBtn;

    @FindBy(id = "tvSimSelectMessage")
    private WebElement msgAfterChangingPassword;

    @FindBy(id = "textinput_error")
    private WebElement msgAfterEnteringSamePassword;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Authentication Failed']")
    private WebElement msgAfterEnteringWrongOldPassword;

    @FindBy(id = "textinput_error")
    private WebElement msgAfterEnteringSamenewAndConfirmPassword;

    @FindBy(xpath = "//android.widget.ImageButton[@index = '0']")
    private WebElement backBtn;

    @FindBy(id = "tvNoteDesc")
    private WebElement passwordPolicy;

    @FindBy(id="tvSimSelectVerify")
    WebElement sendSms;

    ProfileEntity profileEntity;
    SecurityEntity securityEntity;

    public ChangePasswordEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
        profileEntity = new ProfileEntity();
        securityEntity = new SecurityEntity();
    }

    public void changePassword()
    {
        try
        {
            //profileEntity.NavigateTo(SECURITY);
            securityEntity.NavigateTo(Constants.CHANGE_JIOMONEY_PASSWORD);
            oldPasswordField.sendKeys(JPBAppPro.getProperty("Password"));
            newPasswordField.sendKeys(JPBAppPro.getProperty("TempPassword"));
            confirmPasswordField.sendKeys(JPBAppPro.getProperty("TempPassword"));
            clickElement(changePasswordBtn);
            waitFor(sendSms,30);
            Assert.assertTrue(getTextfromElement(sendSms).equalsIgnoreCase("Send SMS"),"Change Password Failed");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in changePassword(): "+ex.getMessage());
        }

    }
}
