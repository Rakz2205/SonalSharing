package mobileApplications.jpbApp.entity;;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static mobileApplications.jpbApp.jpbUtils.Constants.*;
import static utilityLibrary.testData.Constants.MAX_WAIT_TIME;

/**
 * To perform Bill Pay transactions like Mobile Recharge(Prepaid and Postpaid)
 *
 * @author Sneha Dasari
 */

public class BillPaymentEntity extends BaseClass {

OpenLoopEntity openLoopEntity;

    @FindBy(id = "etAmount")
    private WebElement amountText;

    @FindBy(id = "btnLoad")
    private WebElement loadButton;


    @FindBy(id = "tvUpiRadioButton")
    private WebElement upiSelect;




    // DTH Bill Payment

    @FindBy(xpath = "//android.widget.TextView [@text='Airtel Digital TV']")
    private WebElement selectAirtelTVDTH;

    @FindBy(xpath = "//android.widget.TextView [@text='Dish TV']")
    private WebElement selectDishTVDTH;

    @FindBy(xpath = "//android.widget.TextView [@text='Reliance Digital TV']")
    private WebElement selectRelianceTVDTH;

    @FindBy(xpath = "//android.widget.TextView [@text='Sun Direct']")
    private WebElement selectSunTVDTH;

    @FindBy(xpath = "//android.widget.TextView [@text='Tata Sky']")
    private WebElement selectTataSkyDTH;


    @FindBy(xpath = "//android.widget.TextView [@text='Videocon D2H']")
    private WebElement selectVideoConDTH;

    @FindBy(xpath = "//android.widget.EditText [@text='Subscriber ID']")
    private WebElement subscriberID;


    @FindBy(xpath = "//android.widget.EditText [@text='Amount']")
    private WebElement dthRechargeAmount;


    @FindBy(id = "etvNickName")
    private WebElement nickName;

    @FindBy(id = "btnProceed")
    private WebElement proceedBtn ;

    @FindBy(id = "tvYes")
    private WebElement rechargeAgainBtn;

    @FindBy(id = "tvDialogTitle")
    private WebElement rechargeNowTitle;


    // Electricity Payment

    @FindBy(xpath = "//android.widget.TextView [@text='Adani Electricity Mumbai']")
    private WebElement selectAdaniMumbaiOperator;


    @FindBy(xpath = "//android.widget.TextView [@text='BESCOM - Bangalore']")
    private WebElement selectBescomOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='BEST - Mumbai']")
    private WebElement selectBestMumbaiOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='BSES Rajdhani - Delhi']")
    private WebElement selectBSESRajdhaniDelhiOperator;


    @FindBy(xpath = "//android.widget.TextView [@text='BSES Yamuna - Delhi']")
    private WebElement selectBSESYamunaDelhiOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='Bharatpur Electricity Services Ltd']")
    private WebElement selectBharatPurElectricityOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='Bikaner Electricity Supply Limited']")
    private WebElement selectBikanerElectricityOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='CESC - Kolkata']")
    private WebElement selectCESCKolkataOperator;

    @FindBy(xpath = "//android.widget.TextView [@text='CESU, Odisha']")
    private WebElement selectCESUOdishaOperator;


    @FindBy(xpath = "//android.widget.TextView [@text='CSEB - Chhattisgarh']")
    private WebElement selectCSEBChhattisgarhOperator;


    @FindBy(xpath = "//android.widget.EditText [@text='Consumer Id']")
    private WebElement electricityCustomerId;



    @FindBy(id = "btnPayOptions")
    private WebElement payBillBtn;


    // Toll

    @FindBy(id = "tvMetroName")
    private WebElement selectMEPToll ;

    @FindBy(id = "etEtcSelectVehNumber")
    private WebElement vehicleNumber ;

    @FindBy(id = "btnEtcRecharge")
    private WebElement tollRechargeProceedBtn;

    @FindBy(xpath = "//android.widget.RadioButton [@text='RGSL - RAJIV GANDHI SEA LINK TOLL']")
    private WebElement selectRGSL ;

    @FindBy(xpath = "//android.widget.RadioButton [@text='MEP - AIROLI TOLL PLAZA']")
    private WebElement selectMEPAiroli ;

    @FindBy(id ="etEtcSelectRechargeAmount")
    private WebElement tollRechargeAmountSelect ;

    @FindBy(id ="btnEtcProceedToPay")
    private WebElement tollProceedAndPay;

    @FindBy(xpath ="//android.widget.RadioButton [@text='₹500']")
    private WebElement tollRechargeAmount;

    @FindBy(id = "tvRechargeVehNo")
    private WebElement tollRechargeVehicleNumber;


    // Mobile PrePaid

    @FindBy(id = "atvMobNo")
    private WebElement mobileNumberRecharge;

    @FindBy(id ="etAmount")
    private WebElement mobileRechargeAmount;

    @FindBy(id = "bPay")
    private WebElement payOptionsBtn;

    @FindBy(id = "rbPrePaid")
    private WebElement prePaidRadioBtn;

    // Mobile PostPaid

    @FindBy(id = "etvAmount")
    private WebElement postPaidAmount;

    @FindBy(id = "rbPostPaid")
    private WebElement postPaidRadioBtn ;

    // BROAD BAND AND LANDLINE  :

    @FindBy(xpath = "//android.widget.TextView [@text='Airtel']")
    private WebElement selectAirtelLandLine;

    @FindBy(xpath = "//android.widget.TextView [@text='BSNL Landline and Broadband']")
    private WebElement selectBSNLLandLine;

    @FindBy(xpath = "//android.widget.TextView [@text='MTNL Delhi']")
    private WebElement selectMTNLDelhiLandLine;

    @FindBy(xpath = "//android.widget.TextView [@text='MTNL Mumbai']")
    private WebElement selectMTNLMumbaiLandLine;

    @FindBy(xpath = "//android.widget.EditText [@text='Telephone Number']")
    private WebElement selectAirtelBroadBandLandLineNumber;



    // SUBSCRIPTION

    @FindBy(xpath = "//android.widget.TextView [@text='India Today']")
    private WebElement selectIndiaToday;

    @FindBy(xpath ="//android.widget.TextView [@text='Readers Digest']")
    private WebElement selectReaderDigest;


    // Below 3 fields name / addressline1 and addressline2 are common across charity and subscription so using name sc - subscription / charity

    @FindBy(xpath = "//android.widget.EditText [@text='Name']")
    private WebElement scName;

    @FindBy(xpath = "//android.widget.EditText [@text='Address Line 1']")
    private WebElement scAddress1;

    @FindBy(xpath = "//android.widget.EditText [@text='Address Line 2']")
    private WebElement scAddress2;


    @FindBy(id = "btnOperator")
    private WebElement operatorBtn;


    @FindBy(xpath = "//android.widget.TextView [@text='India Today English 1 Year - Rs. 2340.00']")
    private WebElement subscriptionSchemeEnglish1Year;

    @FindBy(xpath = "//android.widget.TextView [@text='India Today Hindi 1 Year - Rs. 1320.00']")
    private WebElement subscriptionSchemeHindi1Year;

    @FindBy(xpath = "//android.widget.TextView [@text='Auto Today 1 Year - Rs. 1080.00']")
    private WebElement subscriptionSchemeAuto1Year;

    /*@FindBy(xpath = "//android.widget.Button [@text='Select Amount']")
    private WebElement selectSubscriptionSchemeAmount;*/

    @FindBy(xpath = "//android.widget.TextView [@text='711.00']")
    private WebElement readerDigestSubscriptionAmount;


    // Charity

    @FindBy(xpath = "//android.widget.TextView [@text='CPAA']")
    private WebElement cpaaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Child Rights and You']")
    private WebElement childRightAndYouCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Childline India']")
    private WebElement childlineIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Concern India']")
    private WebElement concernIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Give India Foundation']")
    private WebElement giveIndiaFoundationCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Helpage India']")
    private WebElement helpAgeIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='National Association of Blind']")
    private WebElement nationalAssociationOfBlindCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='PETA India']")
    private WebElement petaIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='PRIDE India']")
    private WebElement prideIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='SAVE India']")
    private WebElement saveIndiaCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Siddivinayak Trust']")
    private WebElement siddiVinayakTrustCharity;


    @FindBy(xpath = "//android.widget.TextView [@text='WISE']")
    private WebElement wiseCharity;

    @FindBy(xpath = "//android.widget.TextView [@text='Cancer Screening']")
    private WebElement cancerScreening;

    @FindBy(xpath = "//android.widget.TextView [@text='Patient Care']")
    private WebElement patientCare;


    @FindBy(xpath = "//android.widget.EditText [@text='Amount']")
    private WebElement charityAmount;


    @FindBy(xpath = "//android.widget.TextView [@text='Education']")
    private WebElement educationContributionScheme;

    @FindBy(xpath = "//android.widget.TextView [@text='Health Care']")
    private WebElement healthCareContributionScheme;

    @FindBy(xpath = "//android.widget.TextView [@text='Support']")
    private WebElement supportContributionScheme;


    // GAS



    @FindBy(xpath = "//android.widget.TextView [@text='Aavantika Gas Ltd.']")
    private WebElement avantikaGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Adani Gas']")
    private WebElement adaniGas;




    @FindBy(xpath = "//android.widget.TextView [@text='Central U.P. Gas Ltd']")
    private WebElement centralUPGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Charotar Gas - Guj']")
    private WebElement charotarGas;



    @FindBy(xpath = "//android.widget.TextView [@text='Gail Gas Ltd.']")
    private WebElement gailGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Gujarat Gas']")
    private WebElement gujratGas;


    @FindBy(xpath = "//android.widget.TextView [@text='IRM Energy Private Limited']")
    private WebElement irmEnergyGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Indian Oil Adani Gas Pvt Ltd']")
    private WebElement indianOilAdaniGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Indraprastha Gas']")
    private WebElement indraprasthaGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Kapil Chopra Enterprise']")
    private WebElement kapilChopraGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Mahanagar Gas']")
    private WebElement mahanagarGas;


    @FindBy(xpath = "//android.widget.TextView [@text='Maharashtra Natural Gas Ltd. (MNGL)']")
    private WebElement maharashtraNaturalGas;


    @FindBy(id = "actNameOrNumber")
    private WebElement customerId;


    @FindBy(id = "etvAmount")
    private WebElement amount;



    @FindBy(id = "tvSuccessTitle")
    public WebElement successTitle;


    @FindBy(xpath = "//android.widget.TextView [contains(@text='Payment Successful')]")
    public WebElement successTitleGas;

    @FindBy(id = "btnHome")
    private WebElement homeButton ;

    @FindBy(id = "tvTransactionId")
    private  WebElement transactionId;

    //

    @FindBy(xpath = "//android.widget.TextView [@text='Enable Auto Pay?']")
    public WebElement autoPayEnable;

    @FindBy(id = "tvNo")
    private WebElement selectNo;


    // INSURANCE


    @FindBy(xpath = "//android.widget.TextView [@text='Aditya Birla Sun Life Ins']")
    public WebElement adityaBirlaInsurance;


    @FindBy(xpath = "//android.widget.TextView [@text='Aegon Life Insurance']")
    public WebElement aegonLifeInsurance;


    @FindBy(xpath = "//android.widget.TextView [@text='Aviva Life Insurance']")
    public WebElement avivaLifeInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='Bajaj Allianz Life Insurance']")
    public WebElement bajajAllianzInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='Bharti AXA Life Insurance']")
    public WebElement bhartiAXAInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='Canara HSBC Oriental Bank of Commerce Life Insurance Co. Ltd']")
    public WebElement canaraHSBCInsurance;


    @FindBy(xpath = "//android.widget.TextView [@text='Edelweiss Tokio Life Insurance']")
    public WebElement edelweissInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='ICICI Pru Life Insurance']")
    public WebElement iciciInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='IDBI Federal Life Insurance']")
    public WebElement idbiInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='IndiaFirst Life Insurance']")
    public WebElement indiaFirstInsurance;


    @FindBy(xpath = "//android.widget.TextView [@text='Max Life Insurance']")
    public WebElement maxLifeInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='Metlife Life Insurance']")
    public WebElement pnbMetLifeInsurance;


    @FindBy(xpath = "//android.widget.TextView [@text='SBILIFE  Insurance']")
    public WebElement sbiLifeInsurance;

    @FindBy(xpath = "//android.widget.TextView [@text='Tata AIA Life Insurance']")
    public WebElement tataLifeInsurance;

    @FindBy(xpath = "//android.widget.EditText [@text='Policy Number']")
    public WebElement policyNumber;

    @FindBy(xpath = "//android.widget.EditText [@text='Client ID']")
    public WebElement policyClientId;


    @FindBy(id = "snackbar_text")
    public WebElement bannerText;

    // Mobile PrePaid


    public BillPaymentEntity() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
        openLoopEntity = new OpenLoopEntity();
    }

    public void billPayment(String billType,String transactionType) {

        try
        {
            waitFor(prePaidRadioBtn,MAX_WAIT_TIME);

            switch (billType) {
                case MOBILEPREPAID:
                    clickElement(prePaidRadioBtn);
                    waitFor(mobileNumberRecharge,20);
                    mobileNumberRecharge.sendKeys(JPBAppPro.getProperty("prepaidNumber"));
                    LogManager.getLogger(BillPaymentEntity.class).info("Keyboard state is " + androidDriver.getKeyboard());
                    androidDriver.hideKeyboard();
                    waitFor(amountText,20);
                    clickElement(amountText);
                    amountText.sendKeys(JPBAppPro.getProperty("prepaidAmount"));
                    androidDriver.hideKeyboard();
                    waitFor(payOptionsBtn,20);
                    clickElement(payOptionsBtn);
                    waitFor(rechargeAgainBtn,20);
                    if(isElementDisplayed(rechargeAgainBtn))
                    {
                        clickElement(rechargeAgainBtn);
                    }
                    openLoopEntity.openLoopPayments(MOBILEPREPAID, transactionType);
                    waitFor(20);
                    break;
                case MOBILEPOSTPAID :
                    clickElement(postPaidRadioBtn);
                    waitFor(20);
                    mobileNumberRecharge.sendKeys(JPBAppPro.getProperty("postpaidNumber"));
                    androidDriver.hideKeyboard();
                    waitFor(payOptionsBtn,20);
                    clickElement(payOptionsBtn);
                    androidDriver.openNotifications();
                    waitFor(15);
                    androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                    waitFor(postPaidAmount,20);
                    postPaidAmount.sendKeys(JPBAppPro.getProperty("postpaidAmount"));
                    androidDriver.hideKeyboard();
                    waitFor(payBillBtn,20);
                    clickElement(payBillBtn);
                    waitFor(20);
                    openLoopEntity.openLoopPayments(MOBILEPOSTPAID,transactionType);
                    waitFor(20);
                    break;
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in billPayment(String billType,String transactionType): "+ex.getMessage());
        }

    }


}
