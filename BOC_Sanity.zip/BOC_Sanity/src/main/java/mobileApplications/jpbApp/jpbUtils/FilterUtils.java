package mobileApplications.jpbApp.jpbUtils;

import org.apache.logging.log4j.LogManager;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;


public class FilterUtils extends BaseClass
{
    public FilterUtils() throws FileNotFoundException
    {

    }

    public String getMonth()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("MMMM");
        LogManager.getLogger(FilterUtils.class).info(ft.format(d));
        return ft.format(d);
    }

    public String getYear()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("YYYY");
        LogManager.getLogger(FilterUtils.class).info(ft.format(d));
        return ft.format(d);
    }

    public String getDate()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("d");
        LogManager.getLogger(FilterUtils.class).info(ft.format(d));
        return ft.format(d);
    }

    public String getYesterdayDate()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("d");

        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        LogManager.getLogger(FilterUtils.class).info(ft.format(cal.getTime()));
        return ft.format(cal.getTime());
    }

    public String getPreviousMonth()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("MMMM");
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        LogManager.getLogger(FilterUtils.class).info(ft.format(cal.getTime()));
        return ft.format(cal.getTime());
    }

    public String getPreviousYear()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("YYYY");
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -1);
        LogManager.getLogger(FilterUtils.class).info(ft.format(cal.getTime()));
        return ft.format(cal.getTime());
    }

    public static String getFirstDateOfCurrentMonth()
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate todaydate = LocalDate.now();
        LogManager.getLogger(FilterUtils.class).info(dtf.format(todaydate.withDayOfMonth(1)));
        return dtf.format(todaydate.withDayOfMonth(1));
    }

}
