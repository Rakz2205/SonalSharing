package mobileApplications.jpbApp.jpbUtils;

import io.appium.java_client.MobileBy;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class AppUtil extends BaseClass {
    public AppUtil() throws FileNotFoundException {
    }

    public static void scrollDown(int x, int y) {

        Dimension size_device = androidDriver.manage().window().getSize();

        Double scrollHeightStart = size_device.getHeight() * 0.9;
        int scrollStart = scrollHeightStart.intValue();

        Double scrollHeightEnd = size_device.getHeight() * 0.1;
        int scrollEnd = scrollHeightEnd.intValue();

        try {
            new TouchAction((PerformsTouchActions) androidDriver)
                    .press(PointOption.point(x, scrollStart))
                    .moveTo(PointOption.point(y, scrollEnd))
                    .release()
                    .perform();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error in Scroll");

        }

    }

    public static void scrollUp() {

        Dimension size_device = androidDriver.manage().window().getSize();

        Double scrollHeightStart = size_device.getHeight() * 0.1;
        int scrollStart = scrollHeightStart.intValue();

        Double scrollHeightEnd = size_device.getHeight() * 0.9;
        int scrollEnd = scrollHeightEnd.intValue();

        try {
            new TouchAction((PerformsTouchActions) androidDriver)
                    .press(PointOption.point(0, scrollStart))
                    .moveTo(PointOption.point(0, scrollEnd))
                    .release()
                    .perform();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error in Scroll");

        }

    }

    public static void scrollScreen()
    {
        TouchAction touchAction = new TouchAction(androidDriver);
        touchAction.press(PointOption.point(704,1108)).moveTo(PointOption.point(704,700)).perform();
        LogManager.getLogger(AppUtil.class).info("Scrolled");
    }

    public static void scrolltoElementText(String elementName)
    {
        try {
            androidDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(" + "new UiSelector().textContains(\"" + elementName + "\").instance(0))"));
        }
        catch (Exception e)
        {
            LogManager.getLogger(AppUtil.class).info("Failed on scrolltoElementText Function");
        }
    }



    static void wait(int time) {
        androidDriver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);

    }

    static void waitDefault() {
        androidDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

    }

    public static void waitForText(WebElement element, String text) {
        WebDriverWait wait = new WebDriverWait(androidDriver, 20);
        wait.until(ExpectedConditions.textToBePresentInElement(element, text));
    }

    public static void waitForElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(androidDriver, 20);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public static void tap(int offsetx, int offsety){
        TouchAction action = new TouchAction(androidDriver);
        action.tap(PointOption.point(offsetx,offsety)).perform();
        //action.press(PointOption.point(568,1395)).moveTo(PointOption.point(560, 455)).release().perform();
    }

    public static void sleep(long time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void takeScreenShot() {
        // Set folder name to store screenshots.
        String destDir = "screenshots";
        // Capture screenshot.
        File scrFile = ((TakesScreenshot) androidDriver).getScreenshotAs(OutputType.FILE);

        // Set date format to set It as screenshot file name.
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy__hh_mm_ssaa");
        // DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy__hh_mm_ssaa");
        // Create folder under project with name "screenshots" provided to destDir.
        new File(destDir).mkdirs();
        // Set file name using current date time.
        String destFile = dateFormat.format(new Date()) + ".png";

        try {
            // Copy paste file at destination folder location
            FileUtils.copyFile(scrFile, new File(destDir + "/" + destFile));
            // FileUtils.copyFile(scrFile, new File(destDir + "/" + destFile));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String randomNumber(String number) throws IOException {
        String s1 = number;
        double d = Math.random();
        d = d * 1000000000.0;
        int i = (int) d;
        String s2 = String.valueOf(i);
        String s3 = s1 + s2;
        LogManager.getLogger(AppUtil.class).info(s3);
        return s3;

    }

    public static int customerOtpPage(String mobileNumber) throws IOException {
        int custotp = 0;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String url = "jdbc:oracle:thin:@//10.140.139.110:1521/tiborc";
            String user = "tibcocle";
            String pass = "tibcocle";
            Connection con = DriverManager.getConnection(url, user, pass);
            LogManager.getLogger(AppUtil.class).info("DB Connected Successfully");
            Statement stmt = con.createStatement();
            String Query = "SELECT TBL.TIME_STAMP,XMLTYPE(TBL.TRANSACTION).EXTRACT('//NotificationReq/HandleNotificationReq/ContactMedium/item/value/text()').getStringVal()as MOBILE_NO,\r\n"
                    + "XMLTYPE(TBL.TRANSACTION).EXTRACT('//NotificationReq/HandleNotificationReq/notificationPayload/item/Value/text()').getStringVal()as OTP,\r\n"
                    + "TBL.TRANSACTION \r\n" + "FROM TIBCOCLE.LOG TBL \r\n"
                    + "WHERE TBL.COMPONENTNAME = 'NotificationService'\r\n" + "AND TBL.transactiontype = 'Received'\r\n"
                    + "AND TBL.TRANSACTION LIKE '%" + mobileNumber + "%'\r\n"
                    + "AND TBL.message = 'JSONRequest has been received successfully'\r\n"
                    + "ORDER BY TBL.TIME_STAMP desc";
            LogManager.getLogger(AppUtil.class).info(" Querry Run : " + Query);
            ResultSet rs = stmt.executeQuery(Query);
            LogManager.getLogger(AppUtil.class).info("Query Executed Successfully");

            if (rs.next()) {
                custotp = rs.getInt(3);
                LogManager.getLogger(AppUtil.class).info("OTP is "+custotp);
                LogManager.getLogger(AppUtil.class).info("Otp fetched");
            }
            rs.close();
            con.close();
            stmt.close();

        } catch (Exception e) {
            LogManager.getLogger(AppUtil.class).info("Failed to fetch otp");
        }
        return custotp;
    }

    public static void scrollDownUpdated(String str) {

        androidDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(" + "new UiSelector().text(\""+str+"\"))"));
    }


    public static void scrollDownUpdated() {

        androidDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView("+ "new UiSelector().text(\"Link your Visa, Maestro & Other cards\"))"));

    }


}