package mobileApplications.jpbApp.jpbUtils;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;


public class LoginUtils extends BaseClass
{
    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/TextInputLayout/android.widget.FrameLayout/android.widget.EditText")
    WebElement mobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/proceed']")
    WebElement proceedButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[2]/android.widget.FrameLayout/android.widget.EditText")
    WebElement pwdField;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[2]/android.widget.FrameLayout/android.widget.EditText

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/login']")
    WebElement loginButton;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.TextView[2]

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/store_name_txt']")
    WebElement storedName;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/tvTbTitle']")
    WebElement title;

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='More options']")
    WebElement moreOptions;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/title']")
    WebElement logOutButton2;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/tvConfirm']")
    WebElement confirmYes;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
    WebElement settingsButton;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/tvLogout']")
    WebElement logOutButton1;

    public LoginUtils() throws FileNotFoundException {
    }

    public void enterLoginCreds(String mobileNo, String Password)
    {
        waitFor(mobileNumber,40);
        mobileNumber.clear();
        mobileNumber.sendKeys(mobileNo);
        proceedButton.click();
        waitFor(pwdField,20);
        pwdField.sendKeys(Password);
        loginButton.click();
    }

    public boolean enterCredentials()
    {
        enterLoginCreds(JPBAppPro.getProperty("singleMIDmobileNo"),JPBAppPro.getProperty("singleMIDpassword"));
        boolean flag = false;
        try
        {
            flag = settingsButton.isDisplayed();
            return flag;
        }
        catch (Exception ex)
        {
            flag = false;
            return flag;
        }
    }

    //Login to JPM
    public String loginToJPM()
    {
        if(enterCredentials())
        {
            try{
                waitFor(storedName, 30);
                storedName.getText();
                return storedName.getText();
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        else
        {
            try{
                waitFor(title,30);
                title.getText();
                return title.getText();
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }

    public String logoutFromJPM()
    {
        if(enterCredentials())
        {
            waitFor(settingsButton, 40);
            settingsButton.click();
            LogManager.getLogger(LoginUtils.class).info("Settings button is clicked");
            androidDriver.lockDevice();
            androidDriver.unlockDevice();
            waitFor(logOutButton1,60);
            logOutButton1.click();
            LogManager.getLogger(LoginUtils.class).info("logout button is clicked");
            confirmYes.click();
            LogManager.getLogger(LoginUtils.class).info("Confirm Yes is clicked");
            try
            {
                waitFor(proceedButton,20);
                return proceedButton.getText();
            }
            catch(Exception ex)
            {
                return "";
            }

        }
        else
        {
            waitFor(moreOptions, 60);
            moreOptions.click();
            androidDriver.lockDevice();
            androidDriver.unlockDevice();
            waitFor(logOutButton2,30);
            logOutButton2.click();
            confirmYes.click();
            try
            {
                waitFor(proceedButton,20);
                return proceedButton.getText();
            }
            catch(Exception ex)
            {
                return "";
            }
        }
    }

}
