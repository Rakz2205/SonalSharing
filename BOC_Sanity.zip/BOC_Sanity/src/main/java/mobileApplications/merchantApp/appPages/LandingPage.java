package mobileApplications.merchantApp.appPages;
/**
 * To perform actions on elements present on Landing Page
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.TouchAction;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;
import java.util.Set;

import static io.appium.java_client.touch.offset.PointOption.point;
import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;


public class LandingPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(androidDriver, 60);

    @FindBy(id = "com.jio.bapp:id/ivHamburger")
    public  WebElement hamBurgermenu;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Settings']")
    public WebElement setting;

    @FindBy(id =  "com.jio.bapp:id/tvLogout")
    public  WebElement logout;

    @FindBy(id = "com.jio.bapp:id/tvChangePassword")
    public  WebElement changePassword;

    @FindBy(id = "com.jio.bapp:id/etOldPassword")
    public  WebElement oldPassword;

    @FindBy(id = "com.jio.bapp:id/etNewPassword")
    public  WebElement newPassword;

    @FindBy(id = "com.jio.bapp:id/tvUpdatePassword")
    public  WebElement updatePasswordBtn;

    @FindBy(id = "com.jio.bapp:id/tvConfirm")
    public  WebElement logoutYes;

    @FindBy(id = "com.jio.bapp:id/imgProgress")
    public  WebElement processingSymbol;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Transactions']")
    public  WebElement transaction;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Help']")
    public  WebElement help;

    @FindBy(xpath = "//android.widget.TextView[@text = 'My Profile']")
    public  WebElement Profile;

    public LandingPage(){
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    public void doLogout() {
        try
        {
            waitFor(hamBurgermenu,30);
            clickElement(hamBurgermenu);
            extent.log(LogStatus.INFO,"Clicked on menu button");
            waitFor(setting,30);
            clickElement(setting);
            extent.log(LogStatus.INFO,"Clicked on setting Icon");
            waitFor(processingSymbol,30);
            androidDriver.openNotifications();
            Thread.sleep(AVG_WAIT_TIME);
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            Thread.sleep(AVG_WAIT_TIME);
            //Logout on click is not working so using Tap option
            //clickElement(logout);
            new TouchAction(androidDriver).tap(point(163,1018)).perform();
            extent.log(LogStatus.INFO,"Clicked on logout option");
            waitFor(logoutYes,30);
            clickElement(logoutYes);
            extent.log(LogStatus.INFO,"Clicked on Yes button");
        } catch (Exception ex) {
            throw new RuntimeException("Error in  doLogout(): "+ex.getMessage());
        }

    }

    public void changePassword(String oldPWD, String newPWD) {
        try
        {
            extent.log(LogStatus.INFO,"Clicked on menu button");
            Set<String> contextNames = androidDriver.getContextHandles();
            for (String contextName : contextNames) {
                LogManager.getLogger(LandingPage.class).info("************");
                LogManager.getLogger(LandingPage.class).info(contextName);
            }
            waitFor(setting,30);
            clickElement(setting);
            extent.log(LogStatus.INFO,"Clicked on setting Icon");

            // wait.until(ExpectedConditions.invisibilityOf(processingSymbol));
            androidDriver.openNotifications();
            Thread.sleep(AVG_WAIT_TIME);
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            Thread.sleep(AVG_WAIT_TIME);

            //clickElement(changePassword);
            //Click on Change Password is not working
            //Hence Tapping the element
            new TouchAction(androidDriver).tap(point(191,673)).perform();
            extent.log(LogStatus.INFO,"Clicked on change password tab");
            //androidDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            waitFor(oldPassword,30);
            oldPassword.sendKeys(oldPWD);
            extent.log(LogStatus.INFO,"Entered OLD Password");
            waitFor(newPassword,30);
            newPassword.sendKeys(newPWD);
            extent.log(LogStatus.INFO,"Entered NEW Password");
            waitFor(updatePasswordBtn,30);
            clickElement(updatePasswordBtn);
            extent.log(LogStatus.INFO,"Clicked on update password button");
        } catch (Exception ex) {
            throw new RuntimeException("Error in changePassword(String oldPWD, String newPWD): "+ex.getMessage());
        }
        //wait.until(ExpectedConditions.visibilityOf(hamBurgermenu));
        //hamBurgermenu.click();

    }

    public void goToHistoryPage()
    {
        try
        {
            //wait.until(ExpectedConditions.visibilityOf(hamBurgermenu));
            //hamBurgermenu.click();
            extent.log(LogStatus.INFO,"Clicked on menu button");
            waitFor(transaction,30);
            clickElement(transaction);
            extent.log(LogStatus.INFO,"Clicked on trasaction tab");
            // wait.until(ExpectedConditions.invisibilityOf(processingSymbol));
        } catch (Exception ex) {
            throw new RuntimeException("Error in goToHistoryPage(): "+ex.getMessage());
        }


    }

    public void goToHelpPage()
    {
        try
        {
            waitFor(hamBurgermenu,30);
            clickElement(hamBurgermenu);
            //TouchAction touchAction = new TouchAction(androidDriver);
            //touchAction.tap(PointOption.point(51,75)).perform();
            extent.log(LogStatus.INFO,"Clicked on menu button");
            waitFor(help,30);
            clickElement(help);
            extent.log(LogStatus.INFO,"Clicked on Help tab");
            // wait.until(ExpectedConditions.invisibilityOf(processingSymbol));
        } catch (Exception ex) {
            throw new RuntimeException("Error in goToHelpPage(): "+ex.getMessage());
        }


    }

    public void goToProfilePage()
    {
        try
        {
            waitFor(hamBurgermenu,30);
            clickElement(hamBurgermenu);
            extent.log(LogStatus.INFO,"Clicked on hamBurgermenu");
            waitFor(Profile,30);
            clickElement(Profile);
            extent.log(LogStatus.INFO,"Clicked on Profile");
        } catch (Exception ex) {
            throw new RuntimeException("Error in goToProfilePage(): "+ex.getMessage());
        }

    }



}
