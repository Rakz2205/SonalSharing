package mobileApplications.merchantApp.appPages;
/**
 * To Verify the data displayed on Profile
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;

import static io.appium.java_client.touch.offset.PointOption.point;
import static utilityLibrary.testData.Constants.*;

public class ProfilePage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(androidDriver, 25);

    @FindBy(xpath = "//android.widget.TextView[@text = 'My Profile']")
    public  WebElement myProfileButton;

    @FindBy(id = "com.jio.bapp:id/homeProfileRyt")
    public WebElement profileIcon;

    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    public WebElement profilePage;

    @FindBy(id = "com.jio.bapp:id/tvNameValue")
    public WebElement profileName;

    @FindBy(id = "com.jio.bapp:id/tvMobileNumValue")
    public WebElement profileNumber;

    @FindBy(id = "com.jio.bapp:id/tvEmailValue")
    public WebElement profileEmail;

    @FindBy(id = "com.jio.bapp:id/tvDobValue")
    public WebElement profileDOB;

    @FindBy(id = "com.jio.bapp:id/tvGenderValue")
    public WebElement profileGender;

    @FindBy(id = "com.jio.bapp:id/tvTIdValue")
    public WebElement profileTID;

    @FindBy(id = "com.jio.bapp:id/tvMIdValue")
    public WebElement profileMID;

    public ProfilePage() {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    public void checkProfileDetails(String name,String no, String email, String dob, String gender,
                             String TID, String MID) {

        try
        {
            /*waitForClickable(myProfileButton,10);
            clickElement(myProfileButton);*/
            waitFor(profileNumber,5);
            new TouchAction(androidDriver).tap(point(1012,1065)).perform();
            waitFor(profileNumber,5);
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));

            Actualtext = getTextfromElement(profileNumber);
            softAssert.assertEquals(Actualtext,no);
            extent.log(LogStatus.INFO,"Verified Profile number");
            Actualtext = getTextfromElement(profileEmail);
            softAssert.assertEquals(Actualtext,email);
            Actualtext = getTextfromElement(profileDOB);
            softAssert.assertEquals(Actualtext,dob);
            extent.log(LogStatus.INFO,"Verified Profile dob");
            Actualtext = getTextfromElement(profileGender);
            softAssert.assertEquals(Actualtext,gender);
            extent.log(LogStatus.INFO,"Verified Profile gender");
            Actualtext = getTextfromElement(profileTID);
            softAssert.assertEquals(Actualtext,TID);
            extent.log(LogStatus.INFO,"Verified Profile TID");
            Actualtext = getTextfromElement(profileMID);
            softAssert.assertEquals(Actualtext,MID);
            extent.log(LogStatus.INFO,"Verified Profile MID");
            softAssert.assertAll();
            extent.log(LogStatus.PASS,"Verified All Profile Details");
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkProfileDetails(): "+ex.getMessage());
        }

    }



}
