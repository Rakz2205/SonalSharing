package mobileApplications.merchantApp.appPages;
/**
 * To Login into the Application
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

public class LoginPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(androidDriver, 25);

    @FindBy(id = "com.jio.bapp:id/mobileNumber")
    public  WebElement mobileNo;

    @FindBy(id = "com.jio.bapp:id/proceed")
    public WebElement proceed;

    @FindBy(id = "com.jio.bapp:id/jiomoneySubtext")
    public WebElement existingJioMoneyPasswordmsg;
    //Provide your existing JioMoney password to continue

    @FindBy(id = "com.jio.bapp:id/password")
    public WebElement password;

    @FindBy(id = "com.jio.bapp:id/login")
    public WebElement loginBtn;

    @FindBy(id = "com.jio.bapp:id/search_button")
    public WebElement searchBtn;

    @FindBy(id = "com.jio.bapp:id/search_src_text")
    public WebElement searchByStoreName;

    @FindBy(id = "com.jio.bapp:id/tvStoreName")
    public WebElement clickOnDesiredStoreName;

    @FindBy(id = "com.jio.bapp:id/tvSubTitle")
    public WebElement verifyDesiredStoreName;

    @FindBy(id = "com.jio.bapp:id/forgot")
    public WebElement forget;

    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    public WebElement forgetPasswordTitle;
    //Forgot Password?

    @FindBy(id ="com.jio.bapp:id/otp")
    public WebElement forgetPasswordOTPField;

    @FindBy(id = "com.jio.bapp:id/pass")
    public WebElement fpNewPassword;

    @FindBy(id = "com.jio.bapp:id/confirm")
    public WebElement fpConfirmBtn;

    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    public WebElement fpLandingPage;
    //Select Account

    @FindBy(id = "com.jio.bapp:id/search_button")
    public WebElement fpLandingPageSearchBtn;


    public LoginPage() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }


    public void doLogin(String mobile,String pwd,String mer_Storename)
    {
        try
        {
            mobileNo.clear();
            LogManager.getLogger(LoginPage.class).info(mobile);
            mobileNo.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered Mobile no");
            clickElement(proceed);
            extent.log(LogStatus.INFO,"Clicked on Proceed");
            waitFor(loginBtn,30);
            Actualtext = getTextfromElement(existingJioMoneyPasswordmsg);
            softAssert.assertEquals(Actualtext,"Provide your existing JioMoney password to continue");
            softAssert.assertAll();
            password.sendKeys(pwd);
            extent.log(LogStatus.INFO,"Entered Password");
            clickElement(loginBtn);
            extent.log(LogStatus.PASS,"Login button clicked");
            if(isElementDisplayed(searchBtn))
            {
                waitFor(searchBtn,30);
                clickElement(searchBtn);
                searchByStoreName.sendKeys(mer_Storename);
                clickElement(clickOnDesiredStoreName);
            }
            waitFor(verifyDesiredStoreName,30);
            Actualtext = getTextfromElement(verifyDesiredStoreName);
            softAssert.assertEquals(Actualtext,mer_Storename);
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in doLogin(String mobile,String pwd,String mer_Storename): "+ex.getMessage());
        }

    }

    public void forgetPassword(String mobile,String ForgetNewPassword,String mer_Storename)
    {
        String result;
        try
        {
            LogManager.getLogger(LoginPage.class).info("start of open notification");
            androidDriver.openNotifications();
            waitFor(20);
            androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")).click();
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            androidDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
            mobileNo.clear();
            mobileNo.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered Mobile no");
            clickElement(proceed);
            extent.log(LogStatus.INFO,"Clicked on proceed button");
            waitFor(loginBtn,30);
            clickElement(forget);
            extent.log(LogStatus.INFO,"Clicked on forget password link");
            androidDriver.openNotifications();
            String OTP=androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='android:id/message_text']")).getText();
            String otp=OTP.replaceAll("[^0-9]","").substring(0,6).trim();
            LogManager.getLogger(LoginPage.class).info("Your otp is "+otp);
            waitFor(20);
            clickElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")));
            forgetPasswordOTPField.sendKeys(otp);
            extent.log(LogStatus.INFO,"Entered OTP in OTP field");
            fpNewPassword.sendKeys(ForgetNewPassword);
            extent.log(LogStatus.INFO,"Entered new password in field");
            clickElement(fpConfirmBtn);
            extent.log(LogStatus.INFO,"Clicked on confirm button");
            if(isElementDisplayed(searchBtn))
            {
                waitFor(searchBtn,30);
                clickElement(searchBtn);
                searchByStoreName.sendKeys(mer_Storename);
                clickElement(clickOnDesiredStoreName);
            }
            waitFor(verifyDesiredStoreName,30);
            result = getTextfromElement(verifyDesiredStoreName);
            Assert.assertTrue(result.equalsIgnoreCase(merchantAppPro.getProperty("merchantStorename")));

        } catch (Exception ex) {
            throw new RuntimeException("Error in forgetPassword(String mobile,String ForgetNewPassword,String mer_Storename): "+ex.getMessage());
        }

    }



}
