package mobileApplications.merchantApp.appPages;


import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.utils.FilterUtils;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;
import java.util.Set;

import static io.appium.java_client.touch.offset.PointOption.point;
import static utilityLibrary.testData.Constants.*;

public class TransactionPage  extends BaseClass {
    WebDriverWait wait = new WebDriverWait(androidDriver, 25);

    @FindBy(id = "com.jio.bapp:id/imgProgress")
    public WebElement processingSymbol;

    @FindBy(id = "com.jio.bapp:id/tvSales")
    public WebElement salesTab;

    @FindBy(id = "com.jio.bapp:id/tvPaid")
    public WebElement paidTab;

    @FindBy(id = "com.jio.bapp:id/tvStatement")
    public WebElement statementTab;

    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    public WebElement transactionHeading;

    @FindBy(xpath = "//android.widget.RelativeLayout[@index='4']")
    public WebElement filter;

    @FindBy(id = "com.jio.bapp:id/fromDate")
    public WebElement filterFromDate;

    @FindBy(id = "com.jio.bapp:id/toDate")
    public WebElement filterToDate;

    @FindBy(id = "android:id/button1")
    public WebElement dateOkBtn;

    @FindBy(id = "com.jio.bapp:id/applyFilter")
    public WebElement applyFilterBtn;

    @FindBy(id = "com.jio.bapp:id/last")
    public WebElement filterBar;
    //From 17-10-2019 To 18-10-2019 (All)

    public TransactionPage() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    public void checkForSalesTab()
    {
        try
        {
            waitFor(transactionHeading,30);
            boolean salesTabPresence=isElementDisplayed(salesTab);
            softAssert.assertTrue(salesTabPresence);
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkForSalesTab(): "+ex.getMessage());
        }

    }

    public void checkForPaidTab()
    {
        try
        {
            waitFor(transactionHeading,30);
            boolean salesTabPresence=isElementDisplayed(paidTab);
            softAssert.assertTrue(salesTabPresence);
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkForPaidTab(): "+ex.getMessage());
        }

    }

    public void checkForStatementTab()
    {
        try
        {
            waitFor(transactionHeading,30);
            boolean salesTabPresence=isElementDisplayed(statementTab);
            softAssert.assertTrue(salesTabPresence);
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkForStatementTab(): "+ex.getMessage());
        }

    }

    public void applyFilter() {


        try
        {
            Set<String> contextNames = androidDriver.getContextHandles();
            for (String contextName : contextNames) {
                LogManager.getLogger(TransactionPage.class).info("************");
                LogManager.getLogger(TransactionPage.class).info(contextName);
            }
            Thread.sleep(MIN_WAIT_TIME);


            //  wait.until(ExpectedConditions.visibilityOf(transactionHeading));
      /*  boolean salesTabPresence=salesTab.isDisplayed();
        softAssert.assertTrue(salesTabPresence);
        softAssert.assertAll();*/
            //clickElement(filter);
            new TouchAction(androidDriver).tap(point(1000,443)).perform();
            waitFor(filterFromDate,30);
            clickElement(filterFromDate);
            String preDate= FilterUtils.getPreviousDateInDDMMYY();
            clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='"+preDate+"']")));
            clickElement(dateOkBtn);
            waitFor(filterToDate,30);
            clickElement(filterToDate);
            String CurrentDate= FilterUtils.getCurrentDate();
            clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='"+CurrentDate+"']")));
            clickElement(dateOkBtn);
            waitFor(applyFilterBtn,30);
            clickElement(applyFilterBtn);
            Actualtext=getTextfromElement(filterBar);
            String preDateinNo=FilterUtils.getPreviousDateInNo();
            String currentDateInNo=FilterUtils.getCurrentdateInNo();
            softAssert.assertEquals(Actualtext,"From "+preDateinNo+" To "+currentDateInNo+" (All)");
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in checkFilterForSalesTab(): "+ex.getMessage());
        }

    }


}
