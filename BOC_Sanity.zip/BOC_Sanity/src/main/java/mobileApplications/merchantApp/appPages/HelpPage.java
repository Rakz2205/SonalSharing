package mobileApplications.merchantApp.appPages;
/**
 * To perform Help related operations
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;

public class HelpPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(androidDriver, 25);

    public HelpPage() {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver), this);
    }

    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    public WebElement HelpPageTitle;
    //Help

    @FindBy(id = "com.jio.bapp:id/tvEmailUs")
    public WebElement emailUs;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Email']")
    public WebElement email;

    @FindBy(xpath = "//android.widget.TextView[@text = 'Gmail']")
    public WebElement gmail;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/android.widget.TextView[2]\n")
    public WebElement callSupport;

    @FindBy(id = "com.samsung.android.dialer:id/dialButtonImage")
    public WebElement phoneDailBtn;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[3]/android.widget.TextView[2]\n")
    public WebElement faqs;

    @FindBy(xpath = "//android.widget.TextView[@text = 'FAQs']")
    public WebElement faqTab;
    //FAQs

    @FindBy(xpath = "//android.widget.TextView[@text = 'Help']")
    public  WebElement help;

    public void verifyEmail() {
        try
        {
            Actualtext = HelpPageTitle.getText();
            softAssert.assertEquals(Actualtext,"Help");
            emailUs.click();
            extent.log(LogStatus.INFO,"Clicked on email us");
            Actualtext = email.getText();
            softAssert.assertEquals(Actualtext,"Email");
            Actualtext = gmail.getText();
            softAssert.assertEquals(Actualtext,"Gmail");
            softAssert.assertAll();
            androidDriver.navigate().back();
            androidDriver.navigate().back();
        } catch (Exception ex) {
            throw new RuntimeException("Error in verifyEmail(): "+ex.getMessage());
        }

    }

    public void verifyCallSupport() {
        try
        {
            wait.until(ExpectedConditions.visibilityOf(help));
            help.click();
            extent.log(LogStatus.INFO,"Clicked on help menu");
            Thread.sleep(AVG_WAIT_TIME);
            callSupport.click();
            extent.log(LogStatus.INFO,"Clicked on call supoort");
            // wait.until(ExpectedConditions.visibilityOf(phoneDailBtn));
            androidDriver.navigate().back();
            Thread.sleep(AVG_WAIT_TIME);
            androidDriver.navigate().back();
            Thread.sleep(AVG_WAIT_TIME);
            wait.until(ExpectedConditions.visibilityOf(callSupport));
            Actualtext = callSupport.getText();
            softAssert.assertEquals(Actualtext,"Call Support");
            softAssert.assertAll();
            androidDriver.navigate().back();
        } catch (Exception ex) {
            throw new RuntimeException("Error in verifyCallSupport(): "+ex.getMessage());
        }


    }

    public void verifyFaqs(){
        try
        {
            wait.until(ExpectedConditions.visibilityOf(help));
            help.click();
            extent.log(LogStatus.INFO,"Clicked on help menu");
            Thread.sleep(AVG_WAIT_TIME);
            faqs.click();
            extent.log(LogStatus.INFO,"Clicked on FAQ Option");
            Actualtext = faqTab.getText();
            softAssert.assertEquals(Actualtext,"FAQs");
            Thread.sleep(AVG_WAIT_TIME);
            androidDriver.navigate().back();
            Thread.sleep(AVG_WAIT_TIME);
            Actualtext = faqs.getText();
            softAssert.assertEquals(Actualtext,"FAQs");
            softAssert.assertAll();
            androidDriver.navigate().back();
        } catch (Exception ex) {
            throw new RuntimeException("Error in verifyFaqs(): "+ex.getMessage());
        }

    }





}
