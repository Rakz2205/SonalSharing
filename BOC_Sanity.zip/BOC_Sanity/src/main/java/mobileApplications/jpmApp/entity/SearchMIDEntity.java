package mobileApplications.jpmApp.entity;
/**
 * To Verify if multiple MIDs are present and select one by searching
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class SearchMIDEntity extends BaseClass
{

    @FindBy(id = "com.jio.bapp:id/search_button")
    WebElement searchButton;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v7.widget.LinearLayoutCompat/android.support.v7.widget.LinearLayoutCompat/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText")
    WebElement searchText;


    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.LinearLayout")
    WebElement searchedMerchantID;

    @FindBy(id="com.jio.bapp:id/tvMerchantId")
    WebElement MIDNumber;

    @FindBy(id = "com.jio.bapp:id/btnLanguageSave")
    WebElement saveButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
    WebElement settingsButton;



    public SearchMIDEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void selectMID()
    {
        try
        {
            waitFor(searchButton,30);
            clickElement(searchButton);
            searchText.sendKeys(JPMAppPro.getProperty("searchMID"));
            searchedMerchantID.click();
            clickElement(saveButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in selectMID(): "+ex.getMessage());
        }

    }
}
