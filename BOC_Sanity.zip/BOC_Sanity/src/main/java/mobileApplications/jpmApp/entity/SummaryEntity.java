package mobileApplications.jpmApp.entity;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.utils.FilterUtils;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;

import static utilityLibrary.utils.FilterUtils.*;

/**
 * To check the summary and apply filters
 *
 * @author Sneha Dasari
 */
public class SummaryEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    //FilterUtils filterUtils;
    public SummaryEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
        clickElement(summaryIcon);
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Summary']")
    WebElement summaryIcon;

    @FindBy(id="com.jio.bapp:id/tvSettlementAmountLabel")
    WebElement totalSalesAmountLabel;

    @FindBy(id="com.jio.bapp:id/tvTotalSales")
    WebElement totalSalesAmount;

    @FindBy(id="com.jio.bapp:id/tvTotalTransactions")
    WebElement totalSalesTransactions;

    @FindBy(id="com.jio.bapp:id/tvDateRange")
    WebElement dateRange;

    @FindBy(id="com.jio.bapp:id/llDateFilter")
    WebElement dateFilter;

    @FindBy(id="com.jio.bapp:id/ivSlidingArrow")
    WebElement jioMoneySlidingArrow;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[3]/android.widget.TextView")
    WebElement jioMoneyBalance;

    @FindBy(xpath = "//*[@text='Today']")
    WebElement todayFilter;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[2]/android.widget.TextView")
    WebElement yesterdayFilter;

    @FindBy(xpath = "//*[@text='Last Week']")
    WebElement lastWeekFilter;

    @FindBy(xpath = "//*[@text='This Month']")
    WebElement thisMonthFilter;

    @FindBy(xpath = "//*[@text='Custom Date']")
    WebElement customDateFilter;

    @FindBy(id="com.jio.bapp:id/snackbar_text")
    WebElement snackBarText;

    @FindBy(xpath="//android.widget.ImageButton[@content-desc='Previous month']")
    WebElement prevMonthArrow;

    //android:id/date_picker_header_date
    @FindBy(xpath = "//android.view.View[@content-desc='09 October 2019']")
    WebElement ddate;

    @FindBy(id="android:id/button1")
    WebElement OKButton;

    @FindBy(id="android:id/button2")
    WebElement cancelButton;

    @FindBy(xpath = "//*[@text='Paid']")
    WebElement PaidButton;

    @FindBy(xpath = "//*[@text='Settlement']")
    WebElement SettlementsButton;

    @FindBy(id = "com.jio.bapp:id/tvBankLabel")
    WebElement bankName;

    @FindBy(id="com.jio.bapp:id/tvTotalSettlement")
    WebElement totalSettlementAmount;

    @FindBy(id="com.jio.bapp:id/tvGrossAmount")
    WebElement grossAmount;

    @FindBy(id="com.jio.bapp:id/tvFeeDeduction")
    WebElement feeDeduction;

    @FindBy(id="com.jio.bapp:id/ivShowFeeDeduction")
    WebElement showFeeDeduction;

    @FindBy(id="com.jio.bapp:id/tvTotalAmountTransferred")
    WebElement totalAmountTransferred;

    @FindBy(id="com.jio.bapp:id/tvMDR")
    WebElement MDRAmount;

    @FindBy(id="com.jio.bapp:id/tvGST")
    WebElement GSTAmount;

    @FindBy(id="com.jio.bapp:id/ivShowSettlement")
    WebElement showSettlementDetails;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.support.v7.widget.RecyclerView/android.view.ViewGroup[1]")
    WebElement settlementsDetailsCard;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.support.v7.widget.RecyclerView/android.view.ViewGroup[1]/android.widget.TextView[1]")
    WebElement txnID;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView")
    WebElement settlementDetailsHeaderText;

    @FindBy(xpath = "//android.widget.ImageButton[@content-desc='Navigate up']")
    WebElement BackToSummaryPage;

    @FindBy(id = "com.jio.bapp:id/tvDateInfo")
    WebElement settlementDateInfo;
    //06 Jan - 12 Jan
    //10 Jan 2020
    //Jan 2020

    @FindBy(id = "com.jio.bapp:id/tvWeek")
    WebElement settlementWeekFilter;

    @FindBy(id = "com.jio.bapp:id/tvMonth")
    WebElement settlementMonthFilter;


    public void getSalesSummary()
    {
        String result;
        try
        {
            if(isElementDisplayed(snackBarText))
            {
                result = "";
            }
            else
            {
                result = getTextfromElement(totalSalesAmount);
            }

            Assert.assertTrue(result.length()>0,"Sales Page not Loaded");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getSalesSummary(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("After Verifying Sales Summary");
        }

    }

    public void changeFilterToYesterday()
    {
        String result;
        try
        {
            clickElement(dateFilter);
            clickElement(yesterdayFilter);
            if(isElementDisplayed(snackBarText))
            {
                result = "";
            }
            else
            {
                String DateRangeText = getTextfromElement(dateRange);
                try
                {
                    LogManager.getLogger(SummaryEntity.class).info("Integer Value: "+Integer.parseInt(getTextfromElement(dateRange).substring(0,2)));
                    LogManager.getLogger(SummaryEntity.class).info(DateRangeText.substring(0,2));
                    if(DateRangeText.substring(0,2).equalsIgnoreCase(getYesterdayDate()))
                    {
                        LogManager.getLogger(SummaryEntity.class).info(DateRangeText.substring(0,2));
                        result = getTextfromElement(dateRange);
                    }
                    else
                        result = "";
                }
                catch(Exception ex)
                {
                    LogManager.getLogger(SummaryEntity.class).info("Date Range with substring 0,1: "+DateRangeText.substring(0,1));
                    if(DateRangeText.substring(0,1).equalsIgnoreCase(getYesterdayDate()))
                    {
                        LogManager.getLogger(SummaryEntity.class).info("Date Range After SubString: "+getTextfromElement(dateRange).substring(0,1));
                        result = getTextfromElement(dateRange);
                    }
                    else
                        result = "";
                }
            }
            softAssert.assertTrue(result.length()>0,"Yesterday Filter Failed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in changeFilterToYesterday(): "+ex.getMessage());
        }

    }


    public void changeFilterToLastWeek()
    {
        String result;
        try
        {
            clickElement(dateFilter);
            clickElement(lastWeekFilter);
            if(isElementDisplayed(snackBarText))
            {
                result= "";
            }
            else
            {
                String DateRangeText = getTextfromElement(dateRange).replaceAll("[^0-9]", "");
                LogManager.getLogger(SummaryEntity.class).info(DateRangeText.substring(0, 2));
                if(DateRangeText.substring(0, 2).equalsIgnoreCase(getFirstDateOfWeek()))
                {
                    LogManager.getLogger(SummaryEntity.class).info(DateRangeText.substring(0, 2));
                    result = getTextfromElement(dateRange);
                }
                else {
                    LogManager.getLogger(SummaryEntity.class).info("Date Range with substring 0,1: " + DateRangeText.substring(0, 1));
                    if(DateRangeText.substring(0, 1).equalsIgnoreCase(getFirstDateOfWeek()))
                    {
                        LogManager.getLogger(SummaryEntity.class).info("Date Range After SubString: " + DateRangeText.substring(0, 1));
                        result = getTextfromElement(dateRange);
                    }
                    else
                        result = "";

                }
            }

            softAssert.assertTrue(result.length()>0,"Last Week Filter Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in changeFilterToLastWeek(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("After Changing Filter to Last Week");
        }

    }

    public void customFilter()
    {
        String result;
        try
        {
            if(isElementDisplayed(snackBarText))
            {
                result = "";
            }
            else{
                clickElement(dateFilter);
                waitFor(customDateFilter,30);
                clickElement(customDateFilter);
                if(getDate().equalsIgnoreCase("01") || getDate().equalsIgnoreCase("1"))
                {
                    clickElement(prevMonthArrow);
                    clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 "+getPreviousMonth()+" 2019']")));
                    clickElement(OKButton);
                    clickElement(OKButton);
                    result = getTextfromElement(dateRange);
                }
                else
                {
                    clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 "+getMonth()+" "+getYear()+"']")));
                    clickElement(OKButton);
                    clickElement(OKButton);
                    result = getTextfromElement(dateRange);
                }

            }

            softAssert.assertTrue(result.length()>0,"Customer Filter Failed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in customFilter(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("After Changing Filter to Custom");
        }


    }


    public void getJioMoneyBalance()
    {
        String result;
        try
        {
            if(isElementDisplayed(snackBarText))
            {
                clickElement(jioMoneySlidingArrow);
                result = "";
            }
            else
            {
                clickElement(jioMoneySlidingArrow);
                waitFor(jioMoneyBalance,30);
                String JioMoneyBalance=getTextfromElement(jioMoneyBalance);
                LogManager.getLogger(SummaryEntity.class).info("Jio Money Wallet Balance: "+JioMoneyBalance);
                androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                clickElement(summaryIcon);
                //clickElement(BackToSummaryPage);
                result = JioMoneyBalance;
            }
            softAssert.assertTrue(result.length()>0,"Jio Money Balance is not Displayed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in getJioMoneyBalance(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("Jio Money Balance");
        }

    }

    public void getPaidSummary()
    {
        String result;
        try
        {
            clickElement(PaidButton);
            if(isElementDisplayed(snackBarText))
            {
                result= "";
            }
            else
            {
                result= getTextfromElement(totalSalesAmountLabel);
            }
            Assert.assertTrue(result.equalsIgnoreCase("Total Paid Amount"),"Jio Money Balance is not Displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getPaidSummary(): "+ex.getMessage());
        }
        finally
        {
            takeSnapShot("After Verifying Paid Summary");
        }

    }

    public String getSettlementsSummary()
    {
        try
        {
            clickElement(SettlementsButton);
            if(isElementDisplayed(snackBarText))
            {
                return "";
            }
            else
            {
                return getTextfromElement(totalSettlementAmount);
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in getSettlementsSummary(): "+ex.getMessage());
        }

    }

    public String MDRandGSTisPresent()
    {
        try
        {
            clickElement(SettlementsButton);
            clickElement(showFeeDeduction);
            if(isElementDisplayed(MDRAmount) && isElementDisplayed(GSTAmount))
            {
                return getTextfromElement(MDRAmount)+" "+getTextfromElement(GSTAmount);
            }
            else
                return "";
        } catch (Exception ex) {
            throw new RuntimeException("Error in MDRandGSTisPresent(): "+ex.getMessage());
        }

    }

    public String getSettlementDetails()
    {
        try
        {
            clickElement(summaryIcon);
            clickElement(SettlementsButton);
            clickElement(showSettlementDetails);
            if(isElementDisplayed(snackBarText))
            {
                /*clickElement(BackToSummaryPage);*/
                androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                return "";
            }
            else
            {
                waitFor(settlementsDetailsCard,30);
                if(isElementDisplayed(settlementsDetailsCard))
                {
                    String txnId= getTextfromElement(txnID);
                    /*clickElement(BackToSummaryPage);*/
                    androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                    return txnId;
                }
                else
                {
                    String headerText = getTextfromElement(settlementDetailsHeaderText);
                    /*clickElement(BackToSummaryPage);*/
                    androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
                    return headerText;
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in getSettlementDetails(): "+ex.getMessage());
        }

    }


    public void getSettlementFilters()
    {
        try
        {
            clickElement(SettlementsButton);
            softAssert.assertTrue(getTextfromElement(settlementDateInfo).contains(getDate()), "Day Filter Failed");
            takeSnapShot("Settlement Filters");

            waitForClickable(settlementWeekFilter,30);
            clickElement(settlementWeekFilter);
            softAssert.assertTrue(getTextfromElement(settlementDateInfo).contains(getFirstDateOfWeek()),"Week Filter Failed");
            takeSnapShot("Settlement Week Filters");

            waitForClickable(settlementMonthFilter,30);
            clickElement(settlementMonthFilter);
            softAssert.assertTrue(getTextfromElement(settlementDateInfo).contains(getMonth().substring(0,3)),"Month Filter Failed");
            takeSnapShot("Settlement Month Filters");

            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in getSettlementFilters(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("Settlement Filters");
        }

    }


}
