package mobileApplications.jpmApp.entity;
/**
 * To perform Collect Payment functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import mobileApplications.jpbApp.entity.LoginEntity;
import mobileApplications.jpbApp.entity.PayAtShopEntity;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Properties;


public class CollectPaymentEntity extends BaseClass
{
    mobileApplications.jpbApp.entity.LoginEntity loginEntity;
    PayAtShopEntity payAtShopEntity;
    public static String transactionIDCPVar;
    public static String customerMobileNumberVar;
    public static String amountReceivedCPVar;
    public static String dateAndTimeCPVar;
    public static String barcodeValue;
    public String result;

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Collect')]")
    WebElement collectPaymentIcon;

    @FindBy(id = "com.jio.bapp:id/formula")
    WebElement amountTextField;

    @FindBy(id = "com.jio.bapp:id/tvProceedToPayment")
    WebElement proceedToPaymentButton;

    @FindBy(id = "com.jio.bapp:id/tvBillAmountValue")
    WebElement billAmountValue;
    //₹ .01

    @FindBy(id = "com.jio.bapp:id/llScanOrEnterCode")
    WebElement jioMoneyCodeButton;

    @FindBy(id = "com.jio.bapp:id/tvEnterCode")
    WebElement enterCodeButton;

    @FindBy(id = "com.jio.bapp:id/etEnterCode")
    WebElement enterCodeTextField;

    @FindBy(id = "com.jio.bapp:id/tvSubmit")
    WebElement submitButton;

    @FindBy(id = "com.jio.bapp:id/digit_0")
    WebElement digitZero;

    @FindBy(id = "com.jio.bapp:id/dec_point")
    WebElement decimalPoint;

    @FindBy(id = "com.jio.bapp:id/digit_1")
    WebElement digitOne;

    @FindBy(id = "com.jio.bapp:id/tvTransactionIdValue")
    WebElement transactionIDGenerated;

    @FindBy(id = "com.jio.bapp:id/tvDateTimeValue")
    WebElement dateAndTimeOfTransaction;

    @FindBy(id = "com.jio.bapp:id/tvBillAmountValue")
    WebElement billAmountDisplayed;

    @FindBy(id = "com.jio.bapp:id/tvHome")
    WebElement homeButton;

    @FindBy(id = "com.jio.bapp:id/tvTransactionSuccessful")
    WebElement transactionSuccessfulMsg;
    //Transaction Successful





    public CollectPaymentEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void getBarcodeValueFromJPB()
    {
        try
        {
            //JPBAppLaunch();
            loginEntity = new LoginEntity();
            loginEntity.loginToJPB();

            payAtShopEntity = new PayAtShopEntity();
            barcodeValue=payAtShopEntity.payUsingBarcode();
            Assert.assertTrue(barcodeValue.length()>0,"Barcode Value is not fetched..!!");
        } catch (Exception ex) {
            throw new RuntimeException("Error in : "+ex.getMessage());
        }

    }

    public void performCollectPayment(String barcodeVar)
    {
        try
        {
            clickElement(collectPaymentIcon);
            waitFor(amountTextField,30);
            //amountTextField.sendKeys("0.01");
            waitForClickable(digitZero,30);
            clickElement(digitZero);
            waitForClickable(decimalPoint,30);
            clickElement(decimalPoint);
            waitForClickable(digitZero,30);
            clickElement(digitZero);
            waitForClickable(digitOne,30);
            clickElement(digitOne);
            waitForClickable(proceedToPaymentButton,30);
            clickElement(proceedToPaymentButton);
            waitForClickable(jioMoneyCodeButton,30);
            clickElement(jioMoneyCodeButton);
            waitForClickable(enterCodeButton,30);
            clickElement(enterCodeButton);
            waitFor(enterCodeTextField,30);
            enterCodeTextField.sendKeys(barcodeVar);
            waitForClickable(submitButton,30);
            clickElement(submitButton);
            if(isElementDisplayed(transactionSuccessfulMsg))
            {
                transactionIDCPVar = getTextfromElement(transactionIDGenerated).trim();
                amountReceivedCPVar = getTextfromElement(billAmountDisplayed).trim();
                dateAndTimeCPVar = getTextfromElement(dateAndTimeOfTransaction).trim();
                /*try
                {
                    fout = new FileOutputStream(projectPath+"//outputFiles//JPBToJPMP2M.properties");
                    writeProperties = new Properties();
                    writeProperties.setProperty("transactionID",transactionIDCPVar);
                    writeProperties.setProperty("amountReceived",amountReceivedCPVar);
                    writeProperties.setProperty("dateAndTime",dateAndTimeCPVar);
                    writeProperties.store(fout,"P2M Barcode Purchase Transaction");
                }
                catch(Exception ex)
                {
                    LogManager.getLogger(CollectPaymentEntity.class).info("Writing into file has failed");
                }*/
                result = transactionIDCPVar;
            }
            else{
                result = "";
            }
            waitForClickable(homeButton,20);
            clickElement(homeButton);
            Assert.assertTrue(result.length()>0,"Collect Payment has failed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in performCollectPayment(String barcodeVar): "+ex.getMessage());
        }

    }
}
