package mobileApplications.jpmApp.entity;

import io.appium.java_client.TouchAction;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
/**
 * To perform Change Language functionality
 *
 * @author Sneha Dasari
 */
public class ChangeLanguageEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    public ChangeLanguageEntity()
    {
        try
        {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            loginEntity = new LoginEntity();
            searchMIDEntity = new SearchMIDEntity();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in ChangeLanguageEntity(): "+ex.getMessage());
        }

    }



    @FindBy(id="com.jio.bapp:id/tvchangelanguage")
    WebElement changeLanguage;

    @FindBy(id="com.jio.bapp:id/back")
    WebElement backButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[4]")
    WebElement hindiLanguage;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[1]")
    WebElement englishLanguage;

    @FindBy(id="com.jio.bapp:id/btnLanguageSave")
    WebElement saveLanguageButton;

    //@FindBy(id = "android:id/title")
    @FindBy(id = "com.jio.bapp:id/tvTbTitle")
    WebElement settingsTitle;

    @FindBy(id = "com.jio.bapp:id/imgProgress")
    public  WebElement processingSymbol;
    WebDriverWait wait = new WebDriverWait(androidDriver, 60);


    public void changeLanguage(String lang, String changedLangTo){

        try
        {
            loginEntity.clickOnSettingsButton();
            LogManager.getLogger(ChangeLanguageEntity.class).info("Settings button clicked");
            swapLanguage(lang, changedLangTo);

        }catch (Exception ex)
        {
            throw new RuntimeException("Error in changeLanguage(String lang): "+ex.getMessage());
        }
        finally {
            //Capturing Screenshot
            takeSnapShot("After Changing Language to HINDI");
        }

    }

    public void swapLanguage(String language, String changedLangTo) {

        try
        {
            waitFor(changeLanguage,5);
            LogManager.getLogger(ChangeLanguageEntity.class).info("Clicking Change Language");
            if(LoginEntity.flag == false)
            {
                new TouchAction(androidDriver).press(PointOption.point( 61,834)).moveTo(PointOption.point(424,834)).release().perform();
            }
            else
            {
                new TouchAction(androidDriver).press(PointOption.point( 46,665)).moveTo(PointOption.point(413,665)).release().perform();
            }

            LogManager.getLogger(ChangeLanguageEntity.class).info("Clicked Change Language");
            if(language.equalsIgnoreCase("hindi"))
                clickElement(hindiLanguage);
            else
                clickElement(englishLanguage);
            clickElement(saveLanguageButton);
            waitFor(settingsTitle,10);
            if(LoginEntity.flag == false)
            {
                new TouchAction(androidDriver).press(PointOption.point( 61,834)).moveTo(PointOption.point(424,834)).release().perform();
            }
            else
            {
                new TouchAction(androidDriver).press(PointOption.point( 46,665)).moveTo(PointOption.point(413,665)).release().perform();
            }
            Assert.assertTrue(getTextfromElement(settingsTitle).equalsIgnoreCase(changedLangTo),"Change Language Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in swapLanguage(String language): " + ex.getMessage());
        }

    }



}
