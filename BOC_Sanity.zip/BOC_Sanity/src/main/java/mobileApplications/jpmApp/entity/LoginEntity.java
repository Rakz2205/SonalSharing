package mobileApplications.jpmApp.entity;
/**
 * To Login into the Application
 *
 * @author Sneha Dasari
 */
import com.relevantcodes.extentreports.ExtentTest;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;


public class LoginEntity extends BaseClass
{
    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/TextInputLayout/android.widget.FrameLayout/android.widget.EditText")
    WebElement mobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/proceed']")
    WebElement proceedButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[2]/android.widget.FrameLayout/android.widget.EditText")
    WebElement pwdField;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[2]/android.widget.FrameLayout/android.widget.EditText

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/login']")
    WebElement loginButton;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.TextView[2]

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/store_name_txt']")
    WebElement storedName;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/tvTbTitle']")
    WebElement title;

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='More options']")
    WebElement moreOptions;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/title']")
    WebElement logOutButton2;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/tvConfirm']")
    WebElement confirmYes;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
    WebElement settingsButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView[5]")
    WebElement logOutButton1;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView[5]

    ExtentTest extent;
    SearchMIDEntity searchMIDEntity;
    public static boolean flag=false;

    public LoginEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    public void enterCredentials(String mobileNo, String Password)
    {
        try
        {
            waitFor(mobileNumber,40);
            mobileNumber.clear();
            mobileNumber.sendKeys(mobileNo);
            clickElement(proceedButton);
            waitFor(20);
            pwdField.sendKeys(Password);
            clickElement(loginButton);

        } catch (Exception ex) {
            throw new RuntimeException("Error in enterCredentials(String mobileNo, String Password): "+ex.getMessage());
        }

    }

    public void enterMobileNumber(String mobileNo)
    {
        try
        {
            waitFor(mobileNumber,20);
            if(!isElementDisplayed(mobileNumber))
            {
                androidDriver.navigate().back();
            }
            waitFor(mobileNumber,20);
            mobileNumber.clear();
            mobileNumber.sendKeys(mobileNo);
            clickElement(proceedButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in enterMobileNumber(String mobileNo): "+ex.getMessage());
        }

    }

    public void clickOnMoreOptions()
    {
        try
        {
            clickElement(moreOptions);
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickOnMoreOptions(): "+ex.getMessage());
        }

    }

    public void clickOnSettingsButton()
    {
        try
        {
            waitFor(settingsButton,30);
            /*clickElement(settingsButton);*/
            new TouchAction(androidDriver).press(PointOption.point( 978,178)).moveTo(PointOption.point(1027,178)).release().perform();
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickOnSettingsButton(): "+ex.getMessage());
        }

    }

    public void confirmLogoutButton()
    {
        try
        {
            clickElement(confirmYes);
        } catch (Exception ex) {
            throw new RuntimeException("Error in confirmLogoutButton(): "+ex.getMessage());
        }

    }

    public void clickLogOutButton1()
    {
        try
        {
            clickElement(logOutButton1);
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickLogOutButton1(): "+ex.getMessage());
        }

    }

    public void clickLogOutButton2()
    {
        try
        {
            clickElement(logOutButton2);
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickLogOutButton2(): "+ex.getMessage());
        }

    }

    public String getTitleText()
    {
        try
        {
            return getTextfromElement(title);
        } catch (Exception ex) {
            throw new RuntimeException("Error in getTitleText(): "+ex.getMessage());
        }

    }

    public String getStoredMerchantName()
    {
        try
        {
            return getTextfromElement(storedName);
        } catch (Exception ex) {
            throw new RuntimeException("Error in getStoredMerchantName(): "+ex.getMessage());
        }

    }

    public String getProceedButtonText()
    {
        try
        {
            return getTextfromElement(proceedButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in getProceedButtonText(): "+ex.getMessage());
        }

    }

    public boolean SingleMIDPresent()
    {
        try
        {
            flag = isElementDisplayed(settingsButton);
            return flag;
        } catch (Exception ex) {
            throw new RuntimeException("Error in SingleMIDPresent(): "+ex.getMessage());
        }

    }
    //Login to JPM
    public void loginToJPM(){
        try
        {
            enterCredentials(JPMAppPro.getProperty("MobileNumber"),JPMAppPro.getProperty("Password"));
            if(SingleMIDPresent())
            {
                waitFor(storedName, 30);
                Assert.assertTrue(getTextfromElement(storedName).length() > 0,"Login Failed");
            }
            else
            {
                waitFor(title,30);
                searchMIDEntity = new SearchMIDEntity();
                searchMIDEntity.selectMID();
                //return getTextfromElement(title);
                waitFor(storedName, 30);
                Assert.assertTrue(getTextfromElement(storedName).length() > 0,"Login Failed");
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in loginToJPM(): "+ex.getMessage());
        }

    }

    public void logoutFromJPM(){
        try
        {
            waitFor(settingsButton, 40);
            clickElement(settingsButton);
            LogManager.getLogger(LoginEntity.class).info("Settings button is clicked");
            waitFor(logOutButton1,10);
            new TouchAction(androidDriver).press(PointOption.point( 64,1698)).moveTo(PointOption.point(205,1698)).release().perform();
            LogManager.getLogger(LoginEntity.class).info("logout button is clicked");
            clickElement(confirmYes);
            LogManager.getLogger(LoginEntity.class).info("Confirm Yes is clicked");
            waitFor(proceedButton,20);
            Assert.assertEquals(getTextfromElement(proceedButton),"Proceed","Logout was Unsuccessful");

        } catch (Exception ex) {
            throw new RuntimeException("Error in logoutFromJPM(): "+ex.getMessage());
        }


    }
}
