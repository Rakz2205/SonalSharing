package mobileApplications.jpmApp.entity;
/**
 * To check the Transaction History and apply filters
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.utils.FilterUtils;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.util.List;

import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;
import static utilityLibrary.testData.Constants.MAX_WAIT_TIME;
import static utilityLibrary.utils.FilterUtils.*;


public class TxnHistoryEntity extends BaseClass
{

    public int flag;
    public TxnHistoryEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
        clickElement(TxnHistoryIcon);
        clickElement(SkipText);
        clickElement(LaterButton);
    }

    @FindBy(id="com.jio.bapp:id/transactionsTxt")
    WebElement TxnHistoryIcon;

    @FindBy(id = "com.jio.bapp:id/skipTxt")
    WebElement SkipText;

    @FindBy(id="com.jio.bapp:id/tvCancel")
    WebElement LaterButton;

    @FindBy(id="com.jio.bapp:id/rlFilterLayout")
    WebElement FilterLayout;

    @FindBy(id="com.jio.bapp:id/tvNoRecordFound")
    WebElement noRecordFoundText;
    //No Record Found, Please Select Other Filter Option

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.support.v4.view.ViewPager/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.LinearLayout")
    WebElement DataCards;

    @FindBy(id="com.jio.bapp:id/etFromDate")
    WebElement FromDateFilter;

    @FindBy(id="com.jio.bapp:id/etToDate")
    WebElement ToDateFilter;

    @FindBy(id="com.jio.bapp:id/bApplyFilter")
    WebElement ApplyFilterButton;

    @FindBy(id="android:id/button1")
    WebElement OKButton;

    @FindBy(id="android:id/button2")
    WebElement CancelButton;

    //@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[2]/android.widget.LinearLayout/android.widget.TextView")
    @FindBy(xpath = "//*[@text='Purchases']")
    WebElement PurchasesButton;

    @FindBy(xpath = "//*[@text='Credit Ledger']")
    WebElement creditLedgerButton;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.support.v4.view.ViewPager/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout[2]/android.widget.TextView[1]")
    WebElement Label1;

    @FindBy(xpath="//android.widget.ImageButton[@content-desc='Previous month']")
    WebElement prevMonthArrow;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[1]/android.widget.LinearLayout/android.widget.TextView")
    WebElement SalesButton;

    //Transactions Cards

    @FindAll(@FindBy(id="com.jio.bapp:id/tvDate"))
    List<WebElement> cardDates;

    @FindAll(@FindBy(id="com.jio.bapp:id/tvMonth"))
    List<WebElement> cardMonths;

    @FindAll(@FindBy(id="com.jio.bapp:id/tvTransactionAmount"))
    List<WebElement> transactionAmounts;

    @FindAll(@FindBy(id="com.jio.bapp:id/tvTransactionMode"))
    List<WebElement> transactionModes;

    @FindAll(@FindBy(id="com.jio.bapp:id/tvTransactionStatus"))
    List<WebElement> transactionStatuses;



    //Filters
    @FindBy(id="com.jio.bapp:id/etTransactionType")
    WebElement transactionType;

    @FindBy(id="com.jio.bapp:id/etPaymentMode")
    WebElement transactionMode;

    @FindBy(id="//*[@text='UPI']")
    WebElement paymentModeUPI;

    @FindBy(id="//*[@text='Jio Money']")
    WebElement paymentModeJioMoney;

    @FindBy(id="//*[@text='Cash']")
    WebElement paymentModeCash;

    //Transaction Details
    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    WebElement orderNumber;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.TextView[2]")
    WebElement paymentModesDisplayed;

    @FindBy(id="com.jio.bapp:id/tvSubTitle")
    WebElement amountSubTitle;
    //₹1.00

    @FindBy(xpath="//*[@resource-id='com.jio.bapp:id/tvTitle' and @text='Cash']")
    WebElement cashDropDown;

    @FindBy(xpath="//*[@resource-id='com.jio.bapp:id/tvTitle' and @text='JioMoney']")
    WebElement jioMoneyDropDown;

    @FindBy(xpath="//*[@resource-id='com.jio.bapp:id/tvTitle' and @text='UPI']")
    WebElement UPIDropDown;

    @FindBy(xpath="//*[@text='Refund']")
    WebElement refundButton;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout[3]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    WebElement jioMoneyTransactionID;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout[4]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
    WebElement jioMoneyAmount;

    @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout[5]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    WebElement cashAmount;

    @FindBy(id="com.jio.bapp:id/enterAmount")
    WebElement enterRefundAmount;

    @FindBy(id="com.jio.bapp:id/tvRefundOption")
    WebElement refundButtonOnRefundPage;

    @FindBy(id="com.jio.bapp:id/password")
    WebElement passwordOnRefundPage;

    @FindBy(id="com.jio.bapp:id/tvConfirm")
    WebElement confirmButton;

    @FindBy(id="com.jio.bapp:id/tvContinue")
    WebElement continueButtonOnRefundReqPage;

    @FindBy(id="com.jio.bapp:id/textinput_error")
    WebElement moreThanAmountErrorMessage;


    public void getSalesTxnHistory()
    {
        boolean result;
        try
        {
            clickElement(SalesButton);
            if(isElementDisplayed(DataCards))
            {
                result= getTextfromElement(Label1).contains("From:");
            }
            else if(isElementDisplayed(noRecordFoundText))
            {
                result= getTextfromElement(noRecordFoundText).equalsIgnoreCase("No Record Found, Please Select Other Filter Option");
            }
            else
            {
                result= false;
            }

            Assert.assertTrue(result,"Sales Page not Loaded");

        } catch (Exception ex) {
            throw new RuntimeException("Error in getSalesTxnHistory(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("After Sales Transaction History");
        }

    }

    public void changeFilter()
    {
        boolean result;
        try
        {
            clickElement(FilterLayout);
            clickElement(FromDateFilter);
            if(getDate().equalsIgnoreCase("01") || getDate().equalsIgnoreCase("1") && getMonth().equalsIgnoreCase("January"))
            {
                clickElement(prevMonthArrow);
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 "+getPreviousMonth()+" "+getPreviousYear()+"']")));
            }
            else if(getDate().equalsIgnoreCase("01") || getDate().equalsIgnoreCase("1") && !getMonth().equalsIgnoreCase("January"))
            {
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 "+getPreviousMonth()+" "+getYear()+"']")));
            }
            else
            {
                clickElement(androidDriver.findElement(By.xpath("//android.view.View[@content-desc='01 "+ getMonth()+" "+getYear()+"']")));
            }
            clickElement(OKButton);
            clickElement(ToDateFilter);
            clickElement(OKButton);
            clickElement(ApplyFilterButton);
            if(isElementDisplayed(DataCards))
            {
                result = getTextfromElement(Label1).contains("From:") || getTextfromElement(Label1).contains("Purchase");
            }
            else if(isElementDisplayed(noRecordFoundText))
            {
                result = getTextfromElement(noRecordFoundText).equalsIgnoreCase("No Record Found, Please Select Other Filter Option");
            }
            else
            {
                result = false;
            }
            Assert.assertTrue(result, "Error Occurred after changing filter while ");
        } catch (Exception ex) {
            throw new RuntimeException("Error in changeFilter(): "+ex.getMessage());
        }

    }

    public void getPurchasesTxnHistory()
    {
        boolean result;
        try
        {
            clickElement(PurchasesButton);
            if(isElementDisplayed(DataCards))
            {
                result = getTextfromElement(Label1).equalsIgnoreCase("Purchase");
            }
            else if(isElementDisplayed(noRecordFoundText))
            {
                result = getTextfromElement(noRecordFoundText).equalsIgnoreCase("No Record Found, Please Select Other Filter Option");
            }
            else
            {
                result = false;
            }
            Assert.assertTrue(result,"Purchase page is not loaded");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getPurchasesTxnHistory(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("After Purchase Transaction History");
        }

    }

    public void getTxnHistoryDetails(String txnMode, String tranAmount)
    {
        try
        {
            Thread.sleep(MAX_WAIT_TIME*10);
            LogManager.getLogger(TxnHistoryEntity.class).info("Transactions Count: "+cardDates.size());
            if (areElementsDisplayed(cardDates))
            {
                flag = getTextfromElement(cardDates.get(0)).equalsIgnoreCase(getDate())? getTextfromElement(transactionModes.get(0)).contains(txnMode) ? getTextfromElement(transactionAmounts.get(0)).contains(tranAmount) ? 0 : 4 : 3 : 2;
            }
            else {
                flag = 1;
            }
            softAssert.assertEquals(flag,0,"Transactions are not displayed");
            softAssert.assertFalse(flag == 1, "Transaction Entry is not displayed in Sales section");
            softAssert.assertFalse(flag == 2, "Transaction Date mismatch");
            softAssert.assertFalse(flag == 3, "Transaction Mode Mismatch");
            softAssert.assertFalse(flag == 4, "Transaction Amount Mismatch");
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in getTxnHistoryDetails(String txnMode, String tranAmount): "+ex.getMessage());
        }

    }

    public void performRefundForBilling(String orderNo,String refundAmount)
    {
        try
        {
            waitFor(orderNumber,30);
            Assert.assertTrue(getTextfromElement(orderNumber).equalsIgnoreCase(orderNo));
            waitForClickable(jioMoneyDropDown,30);
            clickElement(jioMoneyDropDown);
            waitForClickable(refundButton,30);
            clickElement(refundButton);
            waitFor(enterRefundAmount,30);
            enterRefundAmount.sendKeys(refundAmount);
            androidDriver.hideKeyboard();
            waitForClickable(refundButtonOnRefundPage,30);
            clickElement(refundButtonOnRefundPage);
            waitFor(passwordOnRefundPage,30);
            passwordOnRefundPage.sendKeys(JPMAppPro.getProperty("Password"));
            waitForClickable(confirmButton,30);
            clickElement(confirmButton);
            waitForClickable(continueButtonOnRefundReqPage,30);
            clickElement(continueButtonOnRefundReqPage);
        } catch (Exception ex) {
            throw new RuntimeException("Error in performRefundForBilling(String orderNo,String refundAmount): "+ex.getMessage());
        }

    }

    public void performRefundForTxnID(String orderNo,String refundAmount)
    {
        try
        {
            for(int i=0;i<cardDates.size();i++)
            {

            }
            waitFor(orderNumber, 30);
            Assert.assertTrue(getTextfromElement(orderNumber).equalsIgnoreCase(orderNo));
            waitForClickable(jioMoneyDropDown, 30);
            clickElement(jioMoneyDropDown);
            waitForClickable(refundButton, 30);
            clickElement(refundButton);
            waitFor(enterRefundAmount, 30);
            enterRefundAmount.sendKeys(refundAmount);
            androidDriver.hideKeyboard();
            waitForClickable(refundButtonOnRefundPage, 30);
            clickElement(refundButtonOnRefundPage);
            waitFor(passwordOnRefundPage, 30);
            passwordOnRefundPage.sendKeys(JPMAppPro.getProperty("Password"));
            waitForClickable(confirmButton, 30);
            clickElement(confirmButton);
            waitForClickable(continueButtonOnRefundReqPage, 30);
            clickElement(continueButtonOnRefundReqPage);
        } catch (Exception ex) {
            throw new RuntimeException("Error in performRefundForTxnID(String orderNo,String refundAmount): "+ex.getMessage());
        }


    }



    public void performRefundForPayAtShop(String txnID,String refundAmount,String refundType)
    {
        try
        {
            clickElement(cardDates.get(0));
            if(refundType.equalsIgnoreCase("UPI"))
            {
                waitForClickable(UPIDropDown,30);
                clickElement(UPIDropDown);
            }
            else
            {
                waitForClickable(jioMoneyDropDown,30);
                clickElement(jioMoneyDropDown);
            }
            waitFor(jioMoneyTransactionID,30);
            Assert.assertTrue(getTextfromElement(jioMoneyTransactionID).equalsIgnoreCase(txnID),"Transaction ID mismatch");
            waitForClickable(refundButton,30);
            clickElement(refundButton);
            waitFor(enterRefundAmount,30);
            //Verifying the amount more than transaction amount for refund
            enterRefundAmount.sendKeys("3.00");
            waitFor(moreThanAmountErrorMessage,30);
            Assert.assertTrue(getTextfromElement(moreThanAmountErrorMessage).equalsIgnoreCase("Refund Amount cannot be greater than the transaction amount"),"Error message for Invalid amount is not displayed");

            //Performing Refund for the Pay at Shop Transactions
            enterRefundAmount.clear();
            enterRefundAmount.sendKeys(refundAmount);
            androidDriver.hideKeyboard();
            waitForClickable(refundButtonOnRefundPage,30);
            clickElement(refundButtonOnRefundPage);
            waitFor(passwordOnRefundPage,30);
            passwordOnRefundPage.sendKeys(JPMAppPro.getProperty("Password"));
            waitForClickable(confirmButton,30);
            clickElement(confirmButton);
            waitForClickable(continueButtonOnRefundReqPage,30);
            clickElement(continueButtonOnRefundReqPage);
            Thread.sleep(AVG_WAIT_TIME);
        } catch (Exception ex) {
            throw new RuntimeException("Error in performRefundForPayAtShop(String txnID,String refundAmount,String refundType): "+ex.getMessage());
        }


    }

    public void getRefundDetails(String tranAmount)
    {
        try
        {
            clickElement(TxnHistoryIcon);
            LogManager.getLogger(TxnHistoryEntity.class).info("Transactions Count: "+cardDates.size());
            if (areElementsDisplayed(cardDates))
            {
                Assert.assertTrue(getTextfromElement(transactionStatuses.get(0)).equalsIgnoreCase("Refund"));
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in getRefundDetails(String tranAmount): "+ex.getMessage());
        }

    }

    public void verifyTransactionDetails(String billNumberVar)
    {
        try
        {
            /*if (areElementsDisplayed(cardDates))
        {*/
            clickElement(cardDates.get(0));
            Assert.assertTrue(getTextfromElement(orderNumber).equalsIgnoreCase(billNumberVar),"BIll Number Mismatch");

        /*}
        else {
            Assert.assertTrue(false,"Failed");
        }*/
        } catch (Exception ex) {
            throw new RuntimeException("Error in verifyTransactionDetails(String billNumberVar): "+ex.getMessage());
        }

    }




}
