package mobileApplications.jpmApp.entity;
/**
 * To perform Make Payment Functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;

public class MakePaymentEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    public MakePaymentEntity()
    {
        try {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            loginEntity = new LoginEntity();
            searchMIDEntity = new SearchMIDEntity();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in MakePayment(): "+ex.getMessage());
        }

    }



    @FindBy(id="com.jio.bapp:id/makePaymentLyt")
    WebElement makePaymentButton;

    @FindBy(id="com.jio.bapp:id/back")
    WebElement backButton;

    @FindBy(id="com.jio.bapp:id/tv_wallet_MerchantBalance")
    WebElement merchantBalance;

    @FindBy(id = "com.jio.bapp:id/tv1")
    WebElement keypadDigit1;

    @FindBy(id = "com.jio.bapp:id/tv2")
    WebElement keypadDigit2;

    @FindBy(id = "com.jio.bapp:id/tv3")
    WebElement keypadDigit3;

    @FindBy(id = "com.jio.bapp:id/tv4")
    WebElement keypadDigit4;

    @FindBy(id = "com.jio.bapp:id/tv5")
    WebElement keypadDigit5;

    @FindBy(id = "com.jio.bapp:id/tv6")
    WebElement keypadDigit6;

    @FindBy(id = "com.jio.bapp:id/tv7")
    WebElement keypadDigit7;

    @FindBy(id = "com.jio.bapp:id/tv8")
    WebElement keypadDigit8;

    @FindBy(id = "com.jio.bapp:id/tv9")
    WebElement keypadDigit9;

    public void makePayment() {
        try
        {
            clickElement(makePaymentButton);
            char[] digits = new char[4];
            String mpin = JPMAppPro.getProperty("MPIN");
            for(int i=0;i<digits.length;i++)
            {
                digits[i]=mpin.charAt(i);
                clickElement(androidDriver.findElement(By.id("com.jio.bapp:id/tv"+digits[i])));
            }
            Thread.sleep(AVG_WAIT_TIME);
            Assert.assertTrue(getTextfromElement(merchantBalance).contains("₹"),"Make Payment Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in makePayment(): "+ex.getMessage());
        }

    }

}
