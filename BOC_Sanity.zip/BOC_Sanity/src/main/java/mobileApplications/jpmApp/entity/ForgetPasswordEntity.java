package mobileApplications.jpmApp.entity;
/**
 * To perform Forget Password functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class ForgetPasswordEntity extends BaseClass
{

    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    public ForgetPasswordEntity()
    {
        try
        {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            loginEntity = new LoginEntity();
            searchMIDEntity = new SearchMIDEntity();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in ForgetPasswordEntity(): "+ex.getMessage());
        }

    }


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/forgot']")
    WebElement forgetPasswordBtn;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[2]/android.widget.FrameLayout/android.widget.EditText")
    WebElement FPOtp;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout[3]/android.widget.FrameLayout/android.widget.EditText")
    WebElement newPassword;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.jio.bapp:id/confirm']")
    WebElement confirmChangePass;

    @FindBy(id = "com.jio.bapp:id/search_button")
    WebElement searchButton;


    public void forgotPassword()
    {
        try
        {
            androidDriver.openNotifications();
            waitFor(20);
            clickElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")));
            loginEntity.enterMobileNumber(JPMAppPro.getProperty("MobileNumber"));
            waitFor(20);
            clickElement(forgetPasswordBtn);
            waitFor(60);
            androidDriver.openNotifications();
            waitFor(60);
            String otpmessage= getTextfromElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='android:id/message_text']")));
            String otp=otpmessage.replaceAll("[^0-9]","").substring(0,6).trim();
            LogManager.getLogger(ForgetPasswordEntity.class).info("Your otp is "+otp);
            waitFor(20);
            clickElement(androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")));
            waitFor(20);
            FPOtp.sendKeys(otp);
            waitFor(20);
            newPassword.sendKeys(JPMAppPro.getProperty("Password"));
            clickElement(confirmChangePass);
            waitFor(30);
            if(isElementDisplayed(searchButton))
            {
                searchMIDEntity.selectMID();
            }
            Assert.assertTrue(loginEntity.getStoredMerchantName().length()>0, "Forgot Password Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in forgotPassword(): "+ex.getMessage());
        }

    }



}
