package mobileApplications.jpmApp.entity;
/**
 * To Add, Delete and Search Customer
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class MyCustomerEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;

    public MyCustomerEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);

    }


    @FindBy(xpath="//*[@resource-id='com.jio.bapp:id/moreOptionRecyclerView']/android.widget.RelativeLayout[1]")
    WebElement myCustomerButton;

    @FindBy(id="com.jio.bapp:id/back")
    WebElement backButton;

    //	//android.widget.TextView[@content-desc="Add Customer"]

    @FindBy(xpath="//android.widget.TextView[@accessibility-id='Add Customer']")
    WebElement addnewCustomer;
    //co ordinates = (new TouchAction(driver)).tap(1008, 152).perform()

    @FindBy(id="com.jio.bapp:id/customer_name")
    WebElement customerName;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/TextInputLayout/android.widget.FrameLayout/android.widget.EditText

    @FindBy(id="com.jio.bapp:id/et_customer_mobile")
    WebElement customerNumber;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout/android.widget.EditText

    @FindBy(id="com.jio.bapp:id/tvAddCustomer")
    WebElement addCustomerButton;

    @FindBy(id="com.jio.bapp:id/et_search")
    WebElement myCustomerSearchTextBox;

    @FindBy(id="com.jio.bapp:id/ll_customer_item")
    WebElement customerCardOnSearchText;

    @FindBy(id="com.jio.bapp:id/btnDelete")
    WebElement deleteCustomerButton;

    @FindBy(xpath="//*[@text='Delete Customer']")
    WebElement deleteCustomerText;



    @FindBy(id="com.jio.bapp:id/tvConfirm")
    WebElement confirmDeleteButton;

    /*@FindBy(id="com.jio.bapp:id/tv_add_new_customer")
    WebElement addNewCustomerOnSearchText;*/

    @FindBy(xpath="//*[@text='ADD NEW CUSTOMER']")
    WebElement addNewCustomerOnSearchText;

    @FindBy(id="com.jio.bapp:id/rlContainer")
    WebElement customerContainer;

    @FindBy(id="com.jio.bapp:id/iv_expand")
    WebElement customerContainerExpander;

    @FindBy(id="com.jio.bapp:id/tv_edit")
    WebElement customerEditButton;

    @FindBy(id="com.jio.bapp:id/tv_customer_name")
    WebElement nameOnCustomerContainer;

    @FindBy(id="com.jio.bapp:id/tv_customer_mobile")
    WebElement numberOnCustomerContainer;

    @FindBy(id="com.jio.bapp:id/etcustomermobile")
    WebElement numberOnSearchText;

    @FindBy(id="com.jio.bapp:id/etcustomername")
    WebElement nameOnSearchText;

    public void addNewCustomer(String custName, String custNumber)
    {
        try
        {
            customerName.sendKeys(custName);
            customerNumber.sendKeys(custNumber);
            clickElement(addCustomerButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in addNewCustomer(String custName, String custNumber): "+ex.getMessage());
        }

    }

    public boolean searchCustomer(String custNumber)
    {
        try
        {
            waitForClickable(myCustomerSearchTextBox,30);
            myCustomerSearchTextBox.sendKeys(custNumber);
            if(isElementDisplayed(numberOnCustomerContainer)) {
                if(getTextfromElement(numberOnCustomerContainer).equalsIgnoreCase(custNumber))
                {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error in searchCustomer(String custNumber): "+ex.getMessage());
        }

    }

    public void deleteCustomer()
    {
        try
        {
            clickElement(deleteCustomerText);
            clickElement(confirmDeleteButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in deleteCustomer(): "+ex.getMessage());
        }

    }

    public void addCustomerByAddIcon(String custNameArg, String custNumberArg)
    {
        try
        {
            clickElement(myCustomerButton);
            if(isElementDisplayed(addnewCustomer))
            {
                clickElement(addnewCustomer);
            }
            else
            {
                (new TouchAction(androidDriver)).tap(PointOption.point(1008, 152)).perform();
            }
            addNewCustomer(custNameArg, custNumberArg);
            Assert.assertTrue(searchCustomer(custNumberArg), "Customer was not added");
        } catch (Exception ex) {
            throw new RuntimeException("Error in addCustomerByAddIcon(String custNameArg, String custNumberArg): "+ex.getMessage());
        }

    }

    public void addCustomerByButton(String custNameArg, String custNumberArg)
    {
        boolean result;
        try
        {
            if(!searchCustomer("RandomSearchText"))
            {
                clickElement(addNewCustomerOnSearchText);
                addNewCustomer(custNameArg, custNumberArg);
                myCustomerSearchTextBox.clear();
                result = searchCustomer(custNumberArg);
            }
            else
            {
                result = false;
            }
            Assert.assertTrue(result, "Customer was not added");
        } catch (Exception ex) {
            throw new RuntimeException("Error in addCustomerByButton(String custNameArg, String custNumberArg): "+ex.getMessage());
        }

    }

    public void deleteAddedCustomer(String custNumberArg)
    {
        try
        {
            searchCustomer(custNumberArg);
            clickElement(customerContainer);
            deleteCustomer();
            Assert.assertFalse(searchCustomer(custNumberArg), "Customer was not deleted");

        } catch (Exception ex) {
            throw new RuntimeException("Error in deleteAddedCustomer(String custNumberArg): "+ex.getMessage());
        }

    }


}
