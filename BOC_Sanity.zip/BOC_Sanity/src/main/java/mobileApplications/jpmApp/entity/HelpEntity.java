package mobileApplications.jpmApp.entity;
/**
 * To perform Help related operations
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

public class HelpEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    public HelpEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
        //loginEntity = new LoginEntity();
        //searchMIDEntity = new SearchMIDEntity();
    }


    @FindBy(id = "com.jio.bapp:id/helpTxt")
    WebElement helpButton;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout[2]

    @FindBy(id = "com.jio.bapp:id/rlFaqs")
    WebElement faqsButton;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.RelativeLayout[3]

    @FindBy(id = "com.jio.bapp:id/rlEmailUs")
    WebElement emailUsButton;
    //hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]

    @FindBy(id="android:id/button_once")
    WebElement buttonOnce;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Button[1]

    @FindBy(id = "com.google.android.gm:id/to")
    WebElement toMail;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.MultiAutoCompleteTextView

    @FindBy(id="com.jio.bapp:id/rlCallSupport")
    WebElement callSupportButton;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.RelativeLayout[2]

    @FindBy(id = "com.samsung.android.dialer:id/digits")
    WebElement digitsTyped;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout[2]/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText

    @FindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[3]")
    WebElement aboutJioPrimePartner;


    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]")
    WebElement jioPrimePartnerText;


    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]")
    WebElement tutorialVideosTab;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[3]")
    WebElement tutorialVideo1;
    ///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[3]/android.view.View/android.view.View


    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[3]/android.view.View/android.view.View")
    WebElement tutorialVideoLink;

    @FindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]")
    WebElement FAQSandLearningText;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[3]/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.view.View[1]/android.view.View[1]")
    WebElement profileIconOnTutVid;

    @FindBy(xpath = "//*[@text='Benefits of JioMart program']")
    WebElement someVideoText;

    public void clickOnHelp()
    {
        try
        {
            clickElement(helpButton);
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickOnHelp(): "+ex.getMessage());
        }

    }

    public void emailUs()
    {
        try
        {
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            clickElement(emailUsButton);
            clickElement(buttonOnce);
            LogManager.getLogger(HelpEntity.class).info(getTextfromElement(toMail).replaceAll("[^a-zA-Z0-9.@]",""));
            Assert.assertTrue(getTextfromElement(toMail).replaceAll("[^a-zA-Z0-9.@]","").equalsIgnoreCase(JPMAppPro.getProperty("toMail")),"Email us Functionality Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in emailUs(): "+ex.getMessage());
        }

    }

    public void callSupport()
    {
        try
        {
            clickElement(callSupportButton);
            Assert.assertTrue(getTextfromElement(digitsTyped).equalsIgnoreCase(JPMAppPro.getProperty("supportNumber")),"Call Support Functionality Failed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in callSupport(): "+ex.getMessage());
        }

    }

    public void faqs()
    {
        try
        {
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            clickElement(faqsButton);
            waitFor(aboutJioPrimePartner,60);
            Assert.assertTrue(getTextfromElement(FAQSandLearningText).length()>0,"FAQS is not successfully opened");

        } catch (Exception ex) {
            throw new RuntimeException("Error in faqs(): "+ex.getMessage());
        }
        finally {
            takeSnapShot("FAQs Page");
        }

    }

    public void faqsTab()
    {
        try
        {
            clickElement(aboutJioPrimePartner);
            Assert.assertTrue(getTextfromElement(jioPrimePartnerText).length()>0,"FAQS content is not loaded");

        } catch (Exception ex) {
            throw new RuntimeException("Error in faqsTab(): "+ex.getMessage());
        }

    }

    public void tutorialsTab()
    {
        String result;
        try
        {
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            waitFor(tutorialVideosTab,60);
            clickElement(tutorialVideosTab);
            waitFor(tutorialVideo1,60);
            clickElement(tutorialVideo1);
            waitFor(someVideoText,30);
            if(isElementDisplayed(someVideoText))
            {

                result = "true";
            }
            else
            {
                result = "";
            }
            Assert.assertTrue(result.length()>0,"Tutorials page is not successfully opened");
        } catch (Exception ex) {
            throw new RuntimeException("Error in tutorialsTab(): "+ex.getMessage());
        }

    }




}
