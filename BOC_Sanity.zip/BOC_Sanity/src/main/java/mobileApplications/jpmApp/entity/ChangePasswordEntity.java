package mobileApplications.jpmApp.entity;
/**
 * To perform Change Password functionality
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;

public class ChangePasswordEntity extends BaseClass
{
    LoginEntity loginEntity;
    SearchMIDEntity searchMIDEntity;
    public ChangePasswordEntity()
    {
        try {
            PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
            loginEntity = new LoginEntity();
            searchMIDEntity = new SearchMIDEntity();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in ChangePasswordEntity(): "+ex.getMessage());
        }

    }

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView[1]")
    WebElement changePassword;

    @FindBy(id="com.jio.bapp:id/etOldPassword")
    WebElement oldPassword;

    @FindBy(id="com.jio.bapp:id/etNewPassword")
    WebElement newPassword;

    @FindBy(id="com.jio.bapp:id/tvUpdatePassword")
    WebElement updatePassword;

    @FindBy(id="com.jio.bapp:id/back")
    WebElement backButton;

    @FindBy(id="com.jio.bapp:id/tvTbTitle")
    WebElement Title;

    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
    WebElement settingsButton;

    public void changePassword(){
        try
        {
            waitForClickable(settingsButton,10);
            clickElement(settingsButton);
            Thread.sleep(AVG_WAIT_TIME);
            /*waitFor(changePassword,5);*/
            new TouchAction(androidDriver).press(PointOption.point( 92,324)).moveTo(PointOption.point(424,324)).release().perform();
            waitFor(oldPassword,20);
            oldPassword.sendKeys(JPMAppPro.getProperty("Password"));
            newPassword.sendKeys(JPMAppPro.getProperty("TempPassword"));
            waitFor(updatePassword,30);
            clickElement(updatePassword);
            waitFor(60);
            Assert.assertTrue(loginEntity.getProceedButtonText().length()>0,"Change Password Failed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in changePassword(): "+ex.getMessage());
        }

    }

}
