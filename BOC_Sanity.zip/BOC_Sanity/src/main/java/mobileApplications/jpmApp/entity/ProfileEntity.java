package mobileApplications.jpmApp.entity;
/**
 * To Validate the data displayed on Profile
 *
 * @author Sneha Dasari
 */
import io.appium.java_client.TouchAction;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.util.Set;

import static io.appium.java_client.touch.offset.PointOption.point;

public class ProfileEntity extends BaseClass
{
    public ProfileEntity()
    {
        PageFactory.initElements(new AppiumFieldDecorator(androidDriver),this);
    }

    @FindBy(id = "com.jio.bapp:id/homeProfileRyt")
    WebElement profileButton;

    //@FindBy(id ="tvBasicDetails")
    //@FindBy(id ="com.jio.bapp:id/tvBasicDetails']")
    @FindBy(xpath ="//android.widget.TextView[@resource-id='com.jio.bapp:id/tvBasicDetails']")
    WebElement BasicDetailsText;

    @FindBy(id ="com.jio.bapp:id/tvNameValue")
    WebElement profileName;

    @FindBy(id="com.jio.bapp:id/tvMobileNumValue")
    WebElement profileMobileNumber;

    @FindBy(id="com.jio.bapp:id/tvDobValue")
    WebElement profileDOB;

    @FindBy(id="com.jio.bapp:id/tvStoreNameValue")
    WebElement profileStoreName;

    @FindBy(id="com.jio.bapp:id/tvTIdValue")
    WebElement profileTID;

    @FindBy(id="com.jio.bapp:id/tvMIdValue")
    WebElement profileMID;

    @FindBy(id="com.jio.bapp:id/tvDetailsEdit")
    WebElement businessDetailsEdit;

    public void profileDetails()
    {
        String result;
        try
        {
            clickElement(profileButton);
            waitForClickable(businessDetailsEdit,5);

            //Tapping GST Information Edit Button
            new TouchAction(androidDriver).tap(point(998,1478)).perform();

            waitForClickable(businessDetailsEdit,5);
            androidDriver.pressKey(new KeyEvent(AndroidKey.BACK));
            Set<String> contextNames = androidDriver.getContextHandles();
            for (String contextName : contextNames) {
                LogManager.getLogger(ProfileEntity.class).info("************");
                LogManager.getLogger(ProfileEntity.class).info("Context Name: "+contextName);
                LogManager.getLogger(ProfileEntity.class).info("Context Size: "+contextNames.size());
            }
            try{
                androidDriver.context("WEBVIEW_Terrace");
            }
            catch (Exception ex)
            {

            }
            try
            {
                waitFor(BasicDetailsText,60);
                LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(BasicDetailsText));
                result = getTextfromElement(BasicDetailsText);
            }
            catch (Exception ex)
            {
                //LogManager.getLogger(ProfileEntity.class).info(BasicDetailsText.getText());
                result = "";
            }
            Assert.assertTrue(result.length()>0,"Profile Screen is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in profileDetails(): "+ex.getMessage());
        }

    }

    public void getProfileName()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileName));
            Assert.assertTrue(getTextfromElement(profileName).length()>0,"Profile Name is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getProfileName(): "+ex.getMessage());
        }
    }

    public void getMobileNumber()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileMobileNumber));
            Assert.assertTrue(getTextfromElement(profileMobileNumber).length()>0,"Profile Mobile Number is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getMobileNumber(): "+ex.getMessage());
        }

    }

    public void getDOB()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileDOB));
            Assert.assertTrue(getTextfromElement(profileDOB).length()>0,"Profile DOB is not displayed");

        } catch (Exception ex) {
            throw new RuntimeException("Error in getDOB(): "+ex.getMessage());
        }

    }

    public void getStoreName()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileStoreName));
            Assert.assertTrue(getTextfromElement(profileStoreName).length()>0,"Store/Business Name is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getStoreName(): "+ex.getMessage());
        }
    }

    public void getTIDNumber()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileTID));
            Assert.assertTrue(getTextfromElement(profileTID).length()>0,"TID is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getTIDNumber(): "+ex.getMessage());
        }

    }

    public void getMIDNumber()
    {
        try
        {
            LogManager.getLogger(ProfileEntity.class).info(getTextfromElement(profileMID));
            Assert.assertTrue(getTextfromElement(profileMID).length()>0,"MID is not displayed");
        } catch (Exception ex) {
            throw new RuntimeException("Error in getMIDNumber(): "+ex.getMessage());
        }
    }

}
