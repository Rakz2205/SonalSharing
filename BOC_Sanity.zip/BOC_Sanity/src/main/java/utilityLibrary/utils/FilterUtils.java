package utilityLibrary.utils;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebDriver;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import static com.utilities.javaUtils.DateUtility.*;


public class FilterUtils extends BaseClass
{
    public FilterUtils()
    {

    }

    public static String getMonth()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"MMMM");
    }


    public static String getYear()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"yyyy");
    }

    public static String getDate()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"dd");
    }

    public static String getYesterdayDate()
    {
        return addDaysInCurrentDate(-1,"dd");
    }

    public static String getPreviousMonth()
    {
        return addMonthInCurrentDate(-1,"MMMM");
    }

    public static String getPreviousYear()
    {
        return addYearInCurrentDate(-1,"YYYY");
    }

    public static String getFirstDateOfCurrentMonth()
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate todaydate = LocalDate.now();
        LogManager.getLogger(FilterUtils.class).info(dtf.format(todaydate.withDayOfMonth(1)));
        return dtf.format(todaydate.withDayOfMonth(1));
    }

    public static String getFirstDateOfPreviousMonth()
    {
        SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        cal.set(Calendar.DATE, 1);
        LogManager.getLogger(FilterUtils.class).info(ft.format(cal.getTime()));
        return ft.format(cal.getTime());
    }

    public static String getTodaysDatewithSlashes()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"dd/MM/yyyy");
    }

    public static String getYesterdayinddMMyyyy()
    {
        return addDaysInCurrentDate(-1,"ddMMyyyy");
    }

    public static String getTodayinddMMyyyy()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"ddMMyyyy");
    }

    public static String getPreviousDate()
    {
        return addDaysInCurrentDate(-1,"dd");
    }

    public static String getPreviousDateInDDMMYY()
    {
        return addDaysInCurrentDate(-1,"dd MMMM yyyy");
    }
    public static String getFirstDateOfWeek()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("dd");
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(d);
        calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());
        calendar.add(Calendar.DATE, +1);
        LogManager.getLogger(FilterUtils.class).info(ft.format(calendar.getTime()));
        return ft.format(calendar.getTime());
    }

    public static String getCurrentDate()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"dd MMMM yyyy");
    }


    public static String getCurrentdateInNo()
    {
        Date d = new Date();
        return convertDateToNewFormat(d,"dd-MM-yyyy");
    }

    public static String getPreviousDateInNo()
    {
        return addDaysInCurrentDate(-1,"dd-MM-yyyy");
    }


    public static WebDriver getDriver()
    {
        return androidDriver;
    }



}
