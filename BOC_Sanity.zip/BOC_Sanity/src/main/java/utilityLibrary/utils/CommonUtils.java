package utilityLibrary.utils;

import io.appium.java_client.android.AndroidDriver;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CommonUtils<webdriver> extends BaseClass {
    public CommonUtils() throws FileNotFoundException {
    }

    public static void CleanDir(String path) {
        try {
            File file1 = new File(path);
            File[] files = file1.listFiles();
            for (File f : files) {
                if (f.isFile()) {
                    f.delete();
                } else {
                    LogManager.getLogger(CommonUtils.class).info("cant delete a file due to open or error");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void takeSnapShot(WebDriver driver, String fileName) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)driver);

        //Call getScreenshotAs method to create image file

        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

        //Move image file to new destination
        Date d= Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String date = dateFormat.format(d);

        File DestFile=new File(agentportalPro.getProperty("scfilepath").toString()+date+"\\"+fileName+".png");

        //Copy file at destination

        FileUtils.copyFile(SrcFile, DestFile);

    }

    public static boolean isAlertPresent() {
        WebDriverWait wait = new WebDriverWait(driver, 300/*timeout in seconds*/);
        try
        {
            if(wait.until(ExpectedConditions.alertIsPresent()) == null)
            return false;
            else
                return true;
        }
        catch (Exception ex)
        {
            LogManager.getLogger(CommonUtils.class).info("Alert not displayed");
            return true;
        }

    }

    public static WebDriver getDriver()
    {
        return driver;
    }

    public static AndroidDriver getAndroidDriver()
    {
        return androidDriver;
    }



}