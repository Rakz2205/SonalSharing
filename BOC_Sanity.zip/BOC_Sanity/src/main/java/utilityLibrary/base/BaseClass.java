package utilityLibrary.base;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.utilities.fileUtils.FileUtility;
import com.utilities.fileUtils.PropertiesUtility;
import com.utilities.webUtils.LaunchApplication;
import io.appium.java_client.android.AndroidDriver;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static com.utilities.javaUtils.StringUtility.getAllIntegerInString;
import static com.utilities.webUtils.ScreenshotUtility.takeBase64Screenshot;

/**
 * To set and get the property
 *
 * @author Sneha Dasari
 */
public class BaseClass
{
    public static AndroidDriver androidDriver;
    public static AndroidDriver jpbDriver;
    public static AndroidDriver tempDriver;
    public static WebDriver driver;
    public static WebDriver driverToBeReturned;
    public static Properties agentportalPro;
    public static Properties merchantPortalPro;
    public static Properties JPMAppPro;
    public static Properties merchantAppPro;
    public static Properties JPBAppPro;
    static String param;
    public static String Actualtext;
    public SoftAssert softAssert=new SoftAssert();
    public static String MID;
    public static String TID;
    public static ExtentTest extent;
    public static String projectPath;
    public static Properties writeProperties;
    public static FileOutputStream fout;
    public static String payAtShopTxnId;
    public static String payAtShopDate;
    public static String upiTxnId;
    public static String upiTxnDate;


    public BaseClass()
    {
        agentportalPro = PropertiesUtility.getApplicationProperties("src//main//resources//properties//AgentConfig.properties");
        merchantPortalPro = PropertiesUtility.getApplicationProperties("src//main//resources//properties//MerchantConfig.properties");
        JPMAppPro = PropertiesUtility.getApplicationProperties("src//main//resources//properties//JPMConfig.properties");
        merchantAppPro = PropertiesUtility.getApplicationProperties("src//main//resources//properties//MerchantAppConfig.properties");
        JPBAppPro = PropertiesUtility.getApplicationProperties("src//main//resources//properties//JPBConfig.properties");
    }


    public static AndroidDriver getAndroidDriver() {
        try
        {
            androidDriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),desireCapabilitiesForChrome());
            androidDriver.navigate().back();
            return androidDriver;
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in getAndroidDriver(): "+ex.getMessage());
        }
    }

    public static String fetchOTP()
    {
        AndroidDriver androidDriver = getAndroidDriver();
        androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LogManager.getLogger(BaseClass.class).info("start of open notification");
        androidDriver.openNotifications();
        androidDriver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
        String otpmessage= androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='android:id/message_text']")).getText();
        LogManager.getLogger(BaseClass.class).info(otpmessage);
        //String otp=otpmessage.substring(16,22);
        String otp = getAllIntegerInString(otpmessage).trim();
        //String otp = otpmessage.replaceAll("[^0-9]","").trim();
        androidDriver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.systemui:id/clear_all']")).click();
        androidDriver.quit();
        return otp;
    }

    public static void clearNotification() {
        try
        {
        AndroidDriver androidDriver = getAndroidDriver();
        androidDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        LogManager.getLogger(BaseClass.class).info("start of open notification");
        androidDriver.openNotifications();
        androidDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

            androidDriver.findElement(By.xpath("//*[@text='Clear']")).click();
            LogManager.getLogger(BaseClass.class).info("Clear button on Android is clicked");
        }
        catch (Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info("Clear button on Android is not clicked");
            throw new RuntimeException("Error in clearNotifications(): "+ex.getMessage());
        }
        androidDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        androidDriver.quit();
    }

    public void initialization() {
        try
        {
            String downloadFilepath = FileUtility.createDownloadDirectory("Download");
            FileUtility.cleanDirectory(downloadFilepath);
            projectPath = System.getProperty("user.dir");
            driver = LaunchApplication.launchApplication(agentportalPro,"CHROME",true);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in initialization(): "+ex.getMessage());
        }

    }

    public static void merchantAppLaunch() {
        LaunchApplication.isNoReset = false;
        androidDriver = (AndroidDriver)LaunchApplication.launchMobileDevice(merchantAppPro,null);
    }

    public void JPMAppLaunch() {
        LaunchApplication.isNoReset = false;
        androidDriver = (AndroidDriver) LaunchApplication.launchMobileDevice(JPMAppPro,null);
    }

    public void JPMAppLaunchNoReset() {
        LaunchApplication.isNoReset = true;
        androidDriver = (AndroidDriver)LaunchApplication.launchMobileDevice(JPMAppPro,null);
    }

    public void JPBAppLaunch() {

        LaunchApplication.isNoReset = false;
        LogManager.getLogger(BaseClass.class).info("JPB Driver: "+JPBAppPro.getProperty("MobilePlatformName"));
        androidDriver = (AndroidDriver)LaunchApplication.launchMobileDevice(JPBAppPro,null);
        LogManager.getLogger(BaseClass.class).info("JPB Driver: "+androidDriver);
    }

    public void waitFor(long time)
    {
        LogManager.getLogger(BaseClass.class).info("Entering Implicit Wait");
        getCurrentDriver().manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
        LogManager.getLogger(BaseClass.class).info("Exiting Implicit Wait");
    }

    public void waitFor(WebElement element, long time)
    {
        LogManager.getLogger(BaseClass.class).info("entered Explicit Wait");
        WebDriverWait wait = new WebDriverWait(getCurrentDriver(),time);
        try{
            extent.log(LogStatus.INFO,"Waiting the "+element+" to be VISIBLE");
            wait.until(ExpectedConditions.visibilityOf(element));
            LogManager.getLogger(BaseClass.class).info(element+" is VISIBLE");
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(ex.getMessage());
            LogManager.getLogger(BaseClass.class).info(element+" not Found");
            String desc=element+" is not VISIBLE";
            extent.log(LogStatus.INFO,element+" is not VISIBLE");
            this.takeSnapShot(desc);
        }
        LogManager.getLogger(BaseClass.class).info("exiting explicit Wait");
    }

    public boolean isElementEnabled(WebElement element)
    {
        try
        {
            element.isEnabled();
            LogManager.getLogger(BaseClass.class).info(element+" is Enabled");
            element.sendKeys("Fooled Yaa");
            LogManager.getLogger(BaseClass.class).info(element+" unable to enter value");
            extent.log(LogStatus.INFO,element+" is displayed");
            return true;
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(ex.getMessage());
            LogManager.getLogger(BaseClass.class).info(element+" not Enabled");
            String desc=element+" not Enabled";
            extent.log(LogStatus.INFO,element+" not found");
            this.takeSnapShot(desc);
            return false;
        }
    }

    public void waitForClickable(WebElement element, long time)
    {
        LogManager.getLogger(BaseClass.class).info("entered Explicit Wait");
        WebDriverWait wait = new WebDriverWait(getCurrentDriver(),time);
        try{

            wait.until(ExpectedConditions.elementToBeClickable(element));
            extent.log(LogStatus.INFO,"Waiting the "+element+" to be VISIBLE");
            LogManager.getLogger(BaseClass.class).info(element+" is CLICKABLE");
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(ex.getMessage());
            LogManager.getLogger(BaseClass.class).info(element+" not CLICKABLE");
            String desc=element+" is not CLICKABLE";
            extent.log(LogStatus.INFO,element+" is not CLICKABLE");
            this.takeSnapShot(desc);
        }
        LogManager.getLogger(BaseClass.class).info("exiting explicit Wait");
    }

    public void clickElement(WebElement element)
    {
        try
        {
            element.click();
            extent.log(LogStatus.INFO,element+" button is clicked successfully");
            LogManager.getLogger(BaseClass.class).info(element+ " is Clicked");

        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(ex.getMessage());
            LogManager.getLogger(BaseClass.class).info(element+" not CLICKED");
            String desc=element+" not CLICKED";
            extent.log(LogStatus.INFO,element+" not CLICKED");
            this.takeSnapShot(desc);
        }
    }

    //Returning driver
    public WebDriver getCurrentDriver() {
        try
        {
            if(driver.toString().contains("(null)"))
            {
                LogManager.getLogger(BaseClass.class).info(androidDriver);
                driverToBeReturned= androidDriver;

            }
            else
            {
                driverToBeReturned= driver;
            }
        }
        catch (Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(androidDriver);
            driverToBeReturned= androidDriver;
        }
        return driverToBeReturned;
    }

    public void takeSnapShot(String descr)
    {
        //Getting snapshot from CommonUtils method
        String description=takeBase64Screenshot(this.getCurrentDriver());

        ExtentTestManager.getTest().log(LogStatus.INFO, descr,
                ExtentTestManager.getTest().addBase64ScreenShot(description));
    }

    public String getTextfromElement(WebElement element)
    {
        try
        {
            LogManager.getLogger(BaseClass.class).info("Get Text From Element: "+element.getText());
            extent.log(LogStatus.INFO,"Getting Text from "+element);
            return element.getText();
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info("Get Text From Element Failed");
            extent.log(LogStatus.INFO,"Getting Text from "+element+ " Failed");
            this.takeSnapShot("Getting Text from "+element+ " Failed");
            return "";
        }
    }

    public boolean isElementDisplayed(WebElement element)
    {
        try
        {
            element.isDisplayed();
            LogManager.getLogger(BaseClass.class).info(element+" is displayed");
            return true;
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(element+" not Displayed");
            String desc=element+" not found";
            extent.log(LogStatus.INFO,element+" not found");
            this.takeSnapShot(desc);
            return false;
        }
    }

    public boolean areElementsDisplayed(List<WebElement> element)
    {
        try
        {
            if(element.size()>0)
                return true;
            else
                return false;
        }
        catch(Exception ex)
        {
            LogManager.getLogger(BaseClass.class).info(element+" not Displayed");
            String desc=element+" not found";
            extent.log(LogStatus.INFO,element+" not found");
            this.takeSnapShot(desc);
            return false;
        }
    }


    public static void merchantAppsInstallation(String appType) {
        AndroidDriver androidDriver = getAndroidDriver();
        boolean isAppPresent= androidDriver.isAppInstalled("com.jio.bapp");
        if(isAppPresent)
        {
            LogManager.getLogger(BaseClass.class).info("removing App");
            androidDriver.removeApp("com.jio.bapp");
        }
        LogManager.getLogger(BaseClass.class).info("installing App");
        if(appType.equalsIgnoreCase("JPM"))
        {
            androidDriver.installApp( System.getProperty("user.dir") + JPMAppPro.getProperty("appLocation"));
        }
        else
        {
            androidDriver.installApp( System.getProperty("user.dir") + merchantAppPro.getProperty("appLocation"));
        }
        LogManager.getLogger(BaseClass.class).info("installed");
    }


    public static DesiredCapabilities  desireCapabilitiesForChrome() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(CapabilityType.PLATFORM_NAME,"Android");
        capabilities.setCapability(CapabilityType.VERSION,"9");
        capabilities.setCapability("udid","RZ8M51CE05A");
        capabilities.setCapability("deviceName","GALAXY A70");
        capabilities.setCapability("appPackage","com.android.chrome");
        capabilities.setCapability("appActivity","com.google.android.apps.chrome.Main");
        return capabilities;
    }

}
