/*
package utilityLibrary.base;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.*;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class InstallApp extends BaseClass{

    public static AppiumDriver androidDriver = null;

    public InstallApp() throws FileNotFoundException {
    }


    public static void JPMAppInstallation() throws Exception {
        AndroidDriver androidDriver = getAndroidDriver();
        boolean isappPresent1= androidDriver.isAppInstalled("com.jio.bapp");
        if(isappPresent1)
        {
            LogManager.getLogger(InstallApp.class).info("removing App");
            androidDriver.removeApp("com.jio.bapp");
            LogManager.getLogger(InstallApp.class).info("installing App");
            androidDriver.installApp( System.getProperty("user.dir") + "\\APK\\merchant.apk");
        }
        else
        {
            LogManager.getLogger(InstallApp.class).info("installing App");
            androidDriver.installApp( System.getProperty("user.dir") + "\\APK\\merchant.apk");
        }
    }

    public static void merchantAppInstallation() throws Exception {
        AndroidDriver androidDriver = getAndroidDriver();
        boolean isappPresent1= androidDriver.isAppInstalled("com.jio.bapp");
        if(isappPresent1)
        {
            LogManager.getLogger(InstallApp.class).info("removing App");
            androidDriver.removeApp("com.jio.bapp");
            LogManager.getLogger(InstallApp.class).info("installing App");
            androidDriver.installApp( System.getProperty("user.dir") + "\\APK\\JioMoney_Merchant_(BETA).apk");
        }
        else
        {
            LogManager.getLogger(InstallApp.class).info("installing App");
            androidDriver.installApp( System.getProperty("user.dir") + "\\APK\\JioMoney_Merchant_(BETA).apk");
        }
    }

    public static void main(String[] args) throws Exception {
        merchantAppInstallation();
        JPMAppInstallation();
    }
    public static void installMerchantAppWithAppium() throws Exception {
        File rootPath = new File(System.getProperty("user.dir"));
        File app = new File(rootPath, "APK//JioMoney_Merchant_(BETA).apk");
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability("deviceName", "a70q");
        cap.setCapability("udid", "13b4967b");
        cap.setCapability("autoGrantPermissions", "true");
        cap.setCapability("platformName", "Android");
        cap.setCapability("platformVersion", "9");
        cap.setCapability("app", app.getAbsolutePath());
        cap.setCapability("appPackage", "com.jio.bapp");
        cap.setCapability("appActivity", "com.jio.bapp.activity.SplashActivity");
        androidDriver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);
        androidDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
        Thread.sleep(10000);
    }

    public static void installJPMAppWithAppium() throws Exception {
        File rootPath = new File(System.getProperty("user.dir"));
        File app = new File(rootPath, "APK//merchant.apk");
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability("deviceName", "a70q");
        cap.setCapability("udid", "13b4967b");
        cap.setCapability("autoGrantPermissions", "true");
        cap.setCapability("platformName", "Android");
        cap.setCapability("platformVersion", "9");
        cap.setCapability("app", app.getAbsolutePath());
        cap.setCapability("appPackage", "com.jio.bapp");
        cap.setCapability("appActivity", "com.jio.bapp.activity.SplashActivity");
        androidDriver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);
        androidDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
        Thread.sleep(10000);
    }

    public static void installJPMApp() {
        Process p;
        try {
            p = Runtime.getRuntime().exec("cmd /c adb install -r " + "\"" + System.getProperty("user.dir") + "\\APK\\merchant.apk" + "\"");

            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                LogManager.getLogger(InstallApp.class).info(line);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
    }

    public static void installMerchantApp() {
        Process p;
        try {
            p = Runtime.getRuntime().exec("cmd /c adb install -r " + "\"" + System.getProperty("user.dir") + "\\APK\\JioMoney_Merchant_(BETA).apk" + "\"");

            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                LogManager.getLogger(InstallApp.class).info(line);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static boolean uninstallApp()
    {
        Process p;
        try {
            p = Runtime.getRuntime().exec("cmd /c adb uninstall com.jio.bapp");

            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                LogManager.getLogger(InstallApp.class).info(line);
                if (line.contains("Success")) {
                    return true;
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException ignore) {
            return false;
        }
        return true;
    }
}


*/
