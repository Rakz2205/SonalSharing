package utilityLibrary.reports.Listeners;

import com.relevantcodes.extentreports.LogStatus;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import utilityLibrary.utils.CommonUtils;
import utilityLibrary.base.BaseClass;
import utilityLibrary.reports.ExtentReports.ExtentManager;
import utilityLibrary.reports.ExtentReports.ExtentTestManager;


import java.io.FileNotFoundException;

public class TestListenerWeb extends BaseClass implements ITestListener {
    public TestListenerWeb() {
        //super();
    }

    private static String getTestMethodName(ITestResult iTestResult) {
        return iTestResult.getMethod().getConstructorOrMethod().getName();
    }


    //@Attachment(value = "Page Screenshot",type = "image/png")
    public byte[] saveScreenshotPNG(WebDriver driver)
    {
        return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
    }

    //@Attachment(value = "{0}",type = "text/plain")
    public static String saveTextLog(String message)
    {
        return message;
    }


    @Override
    public void onStart(ITestContext iTestContext) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onStart method " + iTestContext.getName());
        iTestContext.setAttribute("WebDriver", driver);
    }

    @Override
    public void onFinish(ITestContext iTestContext) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onFinish method " + iTestContext.getName());
        //Do tier down operations for extentreports reporting!
        ExtentTestManager.endTest();
        ExtentManager.getReporter().flush();
    }

    @Override
    public void onTestStart(ITestResult iTestResult) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onTestStart method " + getTestMethodName(iTestResult) + " start");
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onTestSuccess method " + getTestMethodName(iTestResult) + " succeed");
        //ExtentReports log operation for passed tests.
        ExtentTestManager.getTest().log(LogStatus.PASS, "Test passed");
        Object testClass = iTestResult.getInstance();
        WebDriver webDriver = CommonUtils.getDriver();
        //Take base64Screenshot screenshot.
        String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot) webDriver).
                getScreenshotAs(OutputType.BASE64);

        //ExtentReports log and screenshot operations for failed tests.
        ExtentTestManager.getTest().log(LogStatus.PASS, "Test Passed",
                ExtentTestManager.getTest().addBase64ScreenShot(base64Screenshot));

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onTestFailure method " + getTestMethodName(iTestResult) + " failed");

        //Get driver from BaseTest and assign to local webDriver variable.
        Object testClass = iTestResult.getInstance();
        WebDriver webDriver = CommonUtils.getDriver();
        LogManager.getLogger(TestListenerWeb.class).info("WEBDRIVER+++++++++++++++"+webDriver);

       /* if(driver instanceof WebDriver)
        {
            LogManager.getLogger(TestListenerWeb.class).info("Screenshot capture for testcase:"+getTestMethodName(iTestResult));
            saveScreenshotPNG(driver);
        }

        saveTextLog(getTestMethodName(iTestResult)+"Failed and screenshot taken");*/

        //Take base64Screenshot screenshot.
        String base64Screenshot = "data:image/png;base64," + ((TakesScreenshot) webDriver).
                getScreenshotAs(OutputType.BASE64);

        //ExtentReports log and screenshot operations for failed tests.
        ExtentTestManager.getTest().log(LogStatus.FAIL, "Test Failed",
                ExtentTestManager.getTest().addBase64ScreenShot(base64Screenshot));
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        LogManager.getLogger(TestListenerWeb.class).info("I am in onTestSkipped method " + getTestMethodName(iTestResult) + " skipped");
        //ExtentReports log operation for skipped tests.
        ExtentTestManager.getTest().log(LogStatus.SKIP, "Test Skipped");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
        LogManager.getLogger(TestListenerWeb.class).info("Test failed but it is in defined success ratio " + getTestMethodName(iTestResult));
    }
}