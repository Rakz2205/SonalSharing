package utilityLibrary.testData;

/**
 * Created by Sneha on 17/12/19.
 */
public interface Constants {

    String PROOF_OF_IDENTITY="POI_377452179";
    String PROOF_OF_ADDRESS="POA_377452177";
    String FINANCIAL_STATEMENT="FS_377452173";
    String PROOF_OF_BUSINESS="POB_377452178";
    String YEARS_IN_BUSINESS="&lt; 1 year";

    //Merchant Profile Detail
    String MERCHANT_MOBILE_NUMBER = "+919326716206";
    String MERCHANT_EMAIL = "MerchantAutomation@gmail.com";
    String BUSINESS_NAME = "Testing Merchant";
    String MERCHANT_MID = "100001001881467";
    String SODEXO_ACCEPTANCE = "No";
    String SUPPLIER_PAYMENT_ACCEPTANCE = "No";
    String HYDROLOCAL_PAYMENT_ACCEPTANCE = "No";
    String BUSINESS_VPA = "12190226@JIOPARTNER";
    String POS_CC_DC = "Yes";
    String ONLINE_CC_DC_NB = "No";
    String UPI_PA = "Yes";
    String GSTIN = "27AAACR5055K1ZD";
    String GST_MERCHANT_CATEGORY = "Taxable";
    String GST_DEALER_CATEGORY = "Registered";
    String TYPE_OF_BUSINESS = "Restaurant";
    String RES_ADDRESS_LINE1 = "^th Floor D wing, TC 22";
    String RES_ADDRESS_LINE2 = "RCP";
    String RES_PINCODE = "400701";
    String RES_CITY = "NaviMumbai";
    String RES_STATE = "Maharashtra";
    String RES_COUNTRY = "INDIA";
    String BUS_ADDRESS_LINE1 = "^th Floor D wing, TC 22";
    String BUS_ADDRESS_LINE2 = "RCP";
    String BUS_PINCODE = "400701";
    String BUS_CITY = "NaviMumbai";
    String BUS_STATE = "Maharashtra";
    String BUS_COUNTRY = "INDIA";

    //Error Messages
    String FORGET_PASSWORD_ERROR_MESSAGE="That's not the right OTP. Please re-enter the correct OTP or ask for a new OTP.";
    String INCORRECT_BAR_CODE = "Invalid Code/Amount. Please enter a valid Code/Amount and try again. (13)";
    String TRANSACTION_DECLINED = "Transaction declined. Please try again. (05)";
    String ADD_SAME_NUMBER_USER = "User already exists in this hierarchy.Please try with another number.";
    String INVALID_DATE_RANGE_HISTORY = "The date must be between";


    //Upgrade Limit
    String CLOSED_LOOP_LIMIT="100";
    String OPEN_LOOP_LIMIT="100";

    //UPI Handle
    String UPI_HANDLE="12190226@JIOPARTNER";

    //Waits
    long MIN_WAIT_TIME=1000;
    long AVG_WAIT_TIME=2000;
    long MAX_WAIT_TIME=3000;



}
