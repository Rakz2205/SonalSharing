package webPortals.merchantPortal.webPages;
/**
 * To perform Accept Payments
 *
 * @author Sneha Dasari
 */
import mobileApplications.jpbApp.entity.LoginEntity;
import mobileApplications.jpbApp.entity.PayAtShopEntity;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import static utilityLibrary.testData.Constants.INCORRECT_BAR_CODE;


public class AcceptPaymentsPage extends BaseClass {

    public AcceptPaymentsPage() {
        PageFactory.initElements(driver,this);
    }

    public static String transactionIDVar;
    public static String customerMobileNumberVar;
    public static String amountReceivedVar;
    public static String dateAndTimeVar;

    public HistoryPage historyPage;

    @FindBy(xpath="//*[contains(@id,'it1::content')]")
    public WebElement billAmountEditText;

    @FindBy(xpath="//*[contains(@id,'it4::content')]")
    public WebElement customerGeneratedBarcode;

    @FindBy(xpath="//*[contains(@id,':cb1')]")
    public WebElement submitButton;

    @FindBy(xpath="//*[contains(@id,':pgl10')]/div")
    public WebElement incorrectBardcodeErrorMessage;

    @FindBy(xpath="//*[contains(@id,':cb4')]")
    public WebElement okButtonOnErrorMessage;

    @FindBy(xpath = "//*[contains(@id,'plam1')]/div[2]/span")
    public WebElement transactionID;

    @FindBy(xpath = "//*[contains(@id,'plam2')]/div[2]/span")
    public WebElement customerMobileNumber;

    @FindBy(xpath = "//*[contains(@id,'plam3')]/div[2]/span")
    public WebElement amountReceived;

    @FindBy(xpath = "//*[contains(@id,'plam4')]/div[2]/span")
    public WebElement dateAndTime;

    @FindBy(xpath = "//*[contains(@id,'pgl3')]/div/span")
    public WebElement paymentSuccessMessage;

    @FindBy(xpath = "//*[contains(@id,':pgl10')]//div")
    public WebElement donotHonorTextMessage;
    //Do not honor

    @FindBy(xpath = "//*[contains(@id,':cb4')]")
    public WebElement okOnDonotHonor;



    LoginEntity loginEntity;
    PayAtShopEntity payAtShopEntity;

    public void acceptPaymentinJPB(){
        try
        {
            clearNotification();
            JPBAppLaunch();


            loginEntity = new LoginEntity();
            loginEntity.loginToJPB();

            payAtShopEntity = new PayAtShopEntity();
            String barcodeValue=payAtShopEntity.payUsingBarcode();
            waitForClickable(billAmountEditText,30);
            billAmountEditText.sendKeys(merchantPortalPro.getProperty("amountToBeAccepted"));

            waitForClickable(customerGeneratedBarcode,30);
            customerGeneratedBarcode.sendKeys(barcodeValue);

            waitForClickable(submitButton,30);
            clickElement(submitButton);
            clickElement(submitButton);

            waitFor(paymentSuccessMessage,30);
            String result = getTextfromElement(paymentSuccessMessage);

            transactionIDVar = getTextfromElement(transactionID).trim();
            customerMobileNumberVar = getTextfromElement(customerMobileNumber).trim();
            amountReceivedVar = getTextfromElement(amountReceived).trim();
            dateAndTimeVar = getTextfromElement(dateAndTime).trim();

            /*try
            {
                fout = new FileOutputStream(projectPath+"//outputFiles//merchantAcceptPayment.properties");
                writeProperties = new Properties();
                writeProperties.setProperty("transactionID",transactionIDVar);
                writeProperties.setProperty("customerMobileNumber",customerMobileNumberVar);
                writeProperties.setProperty("amountReceived",amountReceivedVar);
                writeProperties.setProperty("dateAndTime",dateAndTimeVar);
                writeProperties.store(fout,"Accept Payments Transaction");
            }
            catch(Exception ex)
            {
                LogManager.getLogger(AcceptPaymentsPage.class).info("Writing into file has failed");
            }*/


            Assert.assertTrue(result.contains("Successful"));
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in acceptPaymentinJPB()"+ex.getMessage());
        }


    }

    public void acceptPaymentsIncorrectBarcode() {
        try
        {
            waitForClickable(billAmountEditText, 30);
            billAmountEditText.sendKeys("0.01");

            waitForClickable(customerGeneratedBarcode, 30);
            customerGeneratedBarcode.sendKeys("565656");

            clickElement(submitButton);

            waitFor(incorrectBardcodeErrorMessage, 30);
            String result = getTextfromElement(incorrectBardcodeErrorMessage);

            Assert.assertTrue(result.equalsIgnoreCase(INCORRECT_BAR_CODE));
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in acceptPaymentsIncorrectBarcode()"+ex.getMessage());
        }


    }

    public void checkHistoryforAcceptPayments() {
        try
        {
            historyPage = new HistoryPage();
            String result = historyPage.checkHistoryForCertainTID(transactionIDVar,"Debit Card",amountReceivedVar,dateAndTimeVar);
            Assert.assertFalse(result.contains("No"), "Transactional Details are not displayed");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in checkHistoryforAcceptPayments()"+ex.getMessage());
        }

    }







}
