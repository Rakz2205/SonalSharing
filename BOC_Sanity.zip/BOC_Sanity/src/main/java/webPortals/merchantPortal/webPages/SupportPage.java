package webPortals.merchantPortal.webPages;
/**
 * To perform Support related operations
 *
 * @author By Sneha Dasari
 */
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import static utilityLibrary.testData.Constants.*;


public class SupportPage extends BaseClass {

    public SupportPage() {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//select[contains(@id,'soc1::content')]")
    public WebElement interactionTypeSelect;

    @FindBy(xpath = "//select[contains(@id,'soc2::content')]")
    public WebElement categorySelect;

    @FindBy(xpath = "//select[contains(@id,'soc3::content')]")
    public WebElement subCategorySelect;

    @FindBy(xpath = "//select[contains(@id,'soc3::content')]")
    public WebElement subSubCategorySelect;

    @FindBy(xpath = "//textarea[contains(@id,'it3::content')]")
    public WebElement complaintDesc;

    @FindBy(xpath = "//*[contains(@id,'cil1') and contains(@class,'icon-close')]")
    public WebElement closeIcon;

    @FindBy(xpath = "//*[contains(@id,'mcm_cb1')]")
    public WebElement submitButton;



    public void feedbackSupport() {
        boolean result=false;
        try
        {
            Thread.sleep(MAX_WAIT_TIME);
            Select selectInteractionType = new Select(interactionTypeSelect);
            selectInteractionType.selectByVisibleText("FEEDBACK");


            Select selectCategory = new Select(categorySelect);
            Thread.sleep(MIN_WAIT_TIME);
            LogManager.getLogger(SupportPage.class).info("Category: "+selectCategory.getOptions().size());
            Assert.assertTrue(selectCategory.getOptions().size()>0,"Category for FEEDBACK is not loaded");
            selectCategory.selectByIndex(0);

            Select selectSubCategory = new Select(subCategorySelect);
            Thread.sleep(MIN_WAIT_TIME);
            LogManager.getLogger(SupportPage.class).info("Sub Category: "+selectSubCategory.getOptions().size());
            Assert.assertTrue(selectSubCategory.getOptions().size()>0,"Sub Category for FEEDBACK is not loaded");
            selectSubCategory.selectByIndex(0);

            Select selectSubSubCategory = new Select(subSubCategorySelect);
            Thread.sleep(MIN_WAIT_TIME);
            LogManager.getLogger(SupportPage.class).info("Sub Sub Category: "+selectSubSubCategory.getOptions().size());
            Assert.assertTrue(selectSubSubCategory.getOptions().size()>0,"Sub Sub Category for FEEDBACK is not loaded");
            selectSubSubCategory.selectByIndex(0);

            Thread.sleep(MIN_WAIT_TIME);
            clickElement(closeIcon);

            result = true;
        }
        catch (Exception ex)
        {
            result = false;
            throw new RuntimeException("Error in feedbackSupport(): "+ex.getMessage());
        }
        finally {
            Assert.assertTrue(result,"Feedback contains are not displayed successfully");
        }
        
    }



}
