package webPortals.merchantPortal.webPages;
/**
 * To verify the data displayed on Profile
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;


import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;

public class ProfilePage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);

    public ProfilePage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//div[@id='d_pt:acntVew:1:acpgl23']/div/span")
    public WebElement personal_details;

    @FindBy(xpath = "//a[@id='d_pt:emailLink']")
    public WebElement change_email;

    @FindBy(xpath = "//a[@id='d_pt:passLink']")
    public WebElement change_password;

    @FindBy(xpath = "//div[@id='d_pt:pasView:1:mchp_epgl1']/div")
    public WebElement change_password_Heading;
    //Change Password

    @FindBy(xpath = "//input[@id='d_pt:pasView:1:it1::content']")
    public WebElement current_pwd;

    @FindBy(xpath = "//input[@id='d_pt:pasView:1:it2::content']")
    public WebElement new_pwd;

    @FindBy(xpath = "//button[@id='d_pt:pasView:1:cb1']")
    public WebElement pwd_changebtn;

    @FindBy(xpath = "//div[@id='d_pt:pasView:1:d1::_ttxt']")
    public WebElement pwd_changeSuccessfulMsg;

    @FindBy(xpath = "//button[@id='d_pt:pasView:1:cb3']")
    public WebElement pwd_contbtn;

    @FindBy(xpath = "//div[@id='d_pt:milVew:1:ea_epgl1']/div")
    public WebElement editEmailHeading;

    @FindBy(xpath = "//input[@id='d_pt:milVew:1:it1::content']")
    public WebElement email;

    @FindBy(xpath = "//button[@id='d_pt:milVew:1:cb1']")
    public WebElement saveBtn;

    @FindBy(xpath = "//div[@id='d_pt:milVew:1:d1::_ttxt']")
    public WebElement confirmPwd;
    //Confirm Password

    @FindBy(xpath = "//input[@id='d_pt:milVew:1:s4:it3::content']")
    public WebElement pwdField;

    @FindBy(xpath = "//button[@id='d_pt:milVew:1:s4:cb2']")
    public WebElement contBtn;

    @FindBy(xpath = "//div[@id='d_pt:milVew:1:d2::_ttxt']")
    public WebElement successfulMsg;

    @FindBy(xpath = "//button[@id='d_pt:milVew:1:cb4']")
    public WebElement successfulOKBtn;

    @FindBy(xpath = "//span[@id='d_pt:acntVew:0:it2::content']")
    public WebElement updatedEmail;

    @FindBy(xpath = "//img[@id='d_pt:pt_cil1::icon']")
    public static WebElement homePageSymbol;

    public void updateEmail(String mail, String pwd){
        try
        {
            waitFor(personal_details,30);
            Actualtext =personal_details.getText();
            softAssert.assertEquals(Actualtext,"Personal Details");
            softAssert.assertAll();
            clickElement(change_email);
            extent.log(LogStatus.PASS,"Clicked On edit email Button");
            Actualtext =editEmailHeading.getText();
            softAssert.assertEquals(Actualtext,"Edit Email and Web Address");
            softAssert.assertAll();
            email.clear();
            extent.log(LogStatus.PASS,"Cleared email field");
            email.sendKeys(mail);
            extent.log(LogStatus.PASS,"Entered New email ID");
            Thread.sleep(MIN_WAIT_TIME);
            clickElement(saveBtn);
            extent.log(LogStatus.PASS,"Clicked On save Button");
            wait.until(ExpectedConditions.visibilityOf(pwdField));
            pwdField.sendKeys(pwd);
            extent.log(LogStatus.PASS,"Entered Password");
            clickElement(contBtn);
            extent.log(LogStatus.PASS,"Clicked on continue Button");
            wait.until(ExpectedConditions.visibilityOf(successfulOKBtn));
            Actualtext =getTextfromElement(successfulMsg);
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            clickElement(successfulOKBtn);
            extent.log(LogStatus.PASS,"Clicked on OK Button present on Alert");
            wait.until(ExpectedConditions.visibilityOf(updatedEmail));
            Actualtext =getTextfromElement(updatedEmail);
            softAssert.assertEquals(Actualtext,mail);
            softAssert.assertAll();
            clickElement(homePageSymbol);
            extent.log(LogStatus.PASS,"Clicked on Home Symbol");
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in updateEmail(String mail, String pwd): "+ex.getMessage());
        }

    }

    public void changePassword(String oldPassword, String newPassword){

        try
        {
/*       wait.until(ExpectedConditions.visibilityOf(personal_details));
        Actualtext =personal_details.getText();
        softAssert.assertEquals(Actualtext,"Personal Details");
        softAssert.assertAll();*/
            // change_password.click();
            Thread.sleep(5000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", change_password);
            clickOnElement(driver,change_password);
            extent.log(LogStatus.INFO,"Clicked On Change Password Button");
            Actualtext =change_password_Heading.getText();
            softAssert.assertEquals(Actualtext,"Change Password");
            softAssert.assertAll();
            current_pwd.sendKeys(oldPassword);
            extent.log(LogStatus.INFO,"Entered Current Password in Current Password Field");
            new_pwd.sendKeys(newPassword);
            extent.log(LogStatus.INFO,"Entered new Password in new Password Field");
            clickElement(pwd_changebtn);
            extent.log(LogStatus.INFO,"Clicked on Changed Password Button");
            waitFor(pwd_contbtn,30);
            Actualtext =getTextfromElement(pwd_changeSuccessfulMsg);
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            clickElement(pwd_contbtn);
            extent.log(LogStatus.INFO,"Clicked on continue Button");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in changePassword(String oldPassword, String newPassword): "+ex.getMessage());
        }

    }

}
