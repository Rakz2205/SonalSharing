package webPortals.merchantPortal.webPages;
/**
 * To download the transaction and settlement reports
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.utils.FilterUtils;
import utilityLibrary.base.BaseClass;

import java.util.Iterator;
import java.util.List;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;
import static utilityLibrary.testData.Constants.MIN_WAIT_TIME;
import static utilityLibrary.utils.FilterUtils.*;


public class ReportPage<main> extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);
    String newdate="";
    FilterUtils filterUtils;
    String eachTransactionReport;
    WebElement transactionReportToBeDeleted;

    public ReportPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[contains(@id,'id1::content')]")
    WebElement settlementDateTextBox;

    @FindBy(xpath = "//a[contains(@id,'usert1:0:cl4')]")
    WebElement deleteSettlementReport;

    @FindBy(xpath = "//a[contains(@id,'cil1') and @class='edit-icon icon-filter af_commandImageLink p_AFTextOnly']")
    public WebElement filter;

    @FindBy(xpath = "//input[contains(@id,'id3::content')]")
    public WebElement fromDate;

    @FindBy(xpath = "//input[contains(@id,'id4::content')]")
    public WebElement todate;

    @FindBy(xpath = "//button[contains(@id,'cb14')]")
    public WebElement applyBtn;

    @FindBy(xpath = "//a[contains(@id,'rc_icon1')]")
    public WebElement download_Reports;

    @FindBy(xpath = "//div[contains(@id,'pgl50')]/div")
    public WebElement downloadRequest;
    //Download Request Accepted

    @FindBy(xpath = "//button[contains(@id,'cb13')]")
    public WebElement downloadList;

    @FindBy(xpath = "//a[contains(@id,'commandLink1')]")
    public WebElement downloadListonTransaction;

    @FindBy(xpath = "//a[contains(@id,'cl4')]")
    public WebElement singleRecord;

    @FindBy(xpath = "//a[contains(@id,'cl2') and @class='transListLink clsTxtAlignC af_commandLink']")
    public WebElement settlementReport;

    @FindBy(xpath = "//a[contains(@id,'id1::glyph')]")
    public WebElement settlementDate;

    @FindBy(xpath = "//button[contains(@id,'cb56')]")
    public WebElement generateSettlementReport;

    @FindBy(xpath = "//div[contains(@id,'dialog1::_ttxt')]")
    public WebElement informationText;

    @FindBy(xpath = "//div[contains(@id,'panelGroupLayout3')]/div")
    public WebElement informationAlertMessage;


    @FindBy(xpath = "//button[@id='d_pt:r16:1:r2:1:commandButton2']")
    public WebElement infoOkBtn;

    @FindBy(xpath = "//div[@id='d_pt:r16:1:r2:1:dialog1']")
    public WebElement exceedInfoPopup;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr")
    public WebElement tablerows;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr/td/a[@class='delete-icon icon-delete af_commandLink']")
    public WebElement deleteTablerows;

    @FindBy(xpath = "//div[contains(@id,'d1')]")
    public WebElement deleteConfirmationPopup;

    @FindBy(xpath = "//button[contains(@id,'cb2')]")
    public WebElement deleteConfirmationOkBtn;

    @FindBy(xpath = "//div[contains(@id,'dialog1')]")
    public WebElement deleteInfoPopup;

    @FindBy(xpath = "//button[contains(@id,'commandButton2')]")
    public WebElement deleteInfoOkBtn;

    @FindBy(xpath = "//*[contains(text(), 'Processing')]")
    public WebElement reqProcessing;

    @FindBy(xpath = "//img[@id='d_pt:pt_cil1::icon']")
    public static WebElement homePageSymbol;

    @FindBy(id="d_pt:accPymntLink")
    public WebElement AcceptPaymentsButton;

    @FindBy(xpath = "//a[@id='d_pt:reprtlink']")
    public WebElement reports;

    @FindBy(xpath = "//*[text()='Processing']")
    public WebElement processingTextOnReports;

    @FindBy(xpath = "//a[contains(@id,'cl1') and contains(@class,'transListLink clsTxtAlignC')]")
    public WebElement transactionReport;

    @FindBy(xpath = "//*[contains(@id,'r1:0:d6::ok')]")
    public WebElement okDeleteTransactionReport;

    @FindBy(xpath = "//*[contains(@id,'cb1')]")
    public WebElement okButtonAfterDeletion;

    @FindBys(@FindBy(xpath = "//*[contains(@id,':usert1::db')]/table/tbody/tr"))
    public List<WebElement> transactionReportEntries;

    @FindBy(xpath = "//*[contains(@id,'c9l1')]")
    public WebElement transactionListTab;



    public void downloadReport(){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(transactionReport,30);
            clickElement(transactionReport);
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(filter,30);
            clickElement(filter);
            extent.log(LogStatus.PASS,"Clicked On filter");
            waitFor(fromDate,30);
            fromDate.clear();
            extent.log(LogStatus.PASS,"Cleared from date Field");
            Thread.sleep(AVG_WAIT_TIME);
            fromDate.sendKeys(getFirstDateOfCurrentMonth());
            extent.log(LogStatus.PASS,"Entered date in From Date Field");
            waitForClickable(applyBtn,30);
            clickElement(applyBtn);
            extent.log(LogStatus.PASS,"Clicked On apply Button");
            Thread.sleep(5000);
            //String js=download_Reports.getAttribute("onclick");
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();",download_Reports);
            clickOnElement(driver,download_Reports);
        /*waitFor(download_Reports,40);
        waitForClickable(download_Reports,30);
        clickElement(download_Reports);*/
            extent.log(LogStatus.PASS,"Clicked On download Reports Button");
            waitForClickable(downloadRequest,30);
      /*  Actualtext =downloadRequest.getText();
        softAssert.assertEquals(Actualtext,"Download Request Accepted");
        softAssert.assertAll();*/
            clickElement(downloadList);
            extent.log(LogStatus.PASS,"Clicked On download List");
            waitFor(singleRecord,30);
            while(isElementDisplayed(processingTextOnReports))
            {
                driver.navigate().refresh();
                clickElement(AcceptPaymentsButton);
                Thread.sleep(AVG_WAIT_TIME);
                clickElement(reports);
                Thread.sleep(AVG_WAIT_TIME);
                clickElement(downloadListonTransaction);
            }
            clickElement(driver.findElement(By.xpath("//a[contains(text(),'"+getTodayinddMMyyyy()+".csv')]")));
            deleteDownloadedTransactionReport();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in downloadReport(): "+ex.getMessage());
        }

    }

    public void downloadSettlementReport() {
        try
        {
            waitFor(settlementReport,30);
            clickElement(settlementReport);
            extent.log(LogStatus.PASS,"Clicked On Settlement Tab");
            clickElement(settlementDate);
            extent.log(LogStatus.PASS,"Clicked On Settlement date");
            String date = getPreviousDate();
            LogManager.getLogger(ReportPage.class).info(date);
            if (date.startsWith("0")) {
                newdate = date.substring(1, 2);
                LogManager.getLogger(ReportPage.class).info(date);
                LogManager.getLogger(ReportPage.class).info(newdate);
                date=newdate;

            }
            //LogManager.getLogger(ReportPage.class).info("//tr[@class='af_chooseDate_days-row p_AFLast']/td[text()='"+date+"']");
            Thread.sleep(AVG_WAIT_TIME);
            //driver.findElement(By.xpath("//tr[@class='af_chooseDate_days-row p_AFLast']/td[text()='"+date+"']")).click();
            String settlementDate1=date+"-"+getMonth().substring(0,3)+"-"+getYear();
            LogManager.getLogger(ReportPage.class).info(settlementDate1);
            settlementDateTextBox.sendKeys(settlementDate1);
            extent.log(LogStatus.PASS,"Clicked On Settlement starting date");
            waitFor(generateSettlementReport,30);
            clickElement(generateSettlementReport);
            extent.log(LogStatus.PASS,"Clicked On generate Settlement report");
            Thread.sleep(AVG_WAIT_TIME);
            String informationDialogBoxText=getTextfromElement(informationAlertMessage);
            try {
                if (informationDialogBoxText.equalsIgnoreCase("Your download request has been taken. Report will be available for download once the processing is complete.")) {
                    clickElement(infoOkBtn);
                    extent.log(LogStatus.PASS,"Clicked On OK Button");
              /*  while (reqProcessing.getText().equalsIgnoreCase("Processing") ) {
                    driver.navigate().refresh();
                }*/
              /*for(int i=0;i<=100;i++)
              {
                  driver.navigate().refresh();
                  if(!reqProcessing.getText().equalsIgnoreCase("Processing"))
                  {
                      break;
                  }
              }*/
                    int i=0;
                    while(getTextfromElement(reqProcessing).equalsIgnoreCase("Processing"))
                    {
                        if(i<200)
                        {
                            LogManager.getLogger(ReportPage.class).info("i: "+i);
                            Thread.sleep(MIN_WAIT_TIME);
                            clickElement(AcceptPaymentsButton);
                            Thread.sleep(MIN_WAIT_TIME);
                            clickElement(reports);
                            Thread.sleep(MIN_WAIT_TIME);
                            clickElement(settlementReport);
                            Thread.sleep(MIN_WAIT_TIME);
                            driver.navigate().refresh();
                        }
                        else
                        {
                            break;
                        }
                        i++;
                    }
                    Thread.sleep(AVG_WAIT_TIME);
                    LogManager.getLogger(ReportPage.class).info("//a[contains(text(),'"+getYesterdayinddMMyyyy()+".pdf')]");
                    waitForClickable(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".pdf')]")),30);
                    clickElement(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".pdf')]")));
                    Thread.sleep(AVG_WAIT_TIME);
                    waitForClickable(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".csv')]")),30);
                    clickElement(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".csv')]")));
                    deleteDownloadedSettlementReports();
                }
                if (informationDialogBoxText.equalsIgnoreCase("Download request for the specified date already exists.Please check the below section for processing status.")) {
                    LogManager.getLogger(ReportPage.class).info("IF 2");
                    clickElement(infoOkBtn);
                    extent.log(LogStatus.PASS,"Clicked On OK Button");
                    LogManager.getLogger(ReportPage.class).info("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".pdf')]");
                    Thread.sleep(AVG_WAIT_TIME);
                    waitForClickable(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".pdf')]")),30);
                    clickElement(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".pdf')]")));
                    Thread.sleep(AVG_WAIT_TIME);
                    waitForClickable(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".csv')]")),30);
                    clickElement(driver.findElement(By.xpath("//a[contains(text(),'"+ getYesterdayinddMMyyyy()+".csv')]")));
                    deleteDownloadedSettlementReports();

                }
                if (informationDialogBoxText.equalsIgnoreCase("You have reached the maximum download limit. Please delete old records before creating another request."))
                {
                    while (exceedInfoPopup.isDisplayed() && informationText.getText().equalsIgnoreCase("Information")) {
                        clickElement(infoOkBtn);
                        extent.log(LogStatus.PASS,"Clicked On OK Button");
                        List rows = driver.findElements(By.xpath("//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr"));
                        int numOfRow = rows.size();
                        LogManager.getLogger(ReportPage.class).info("numOfRow =" + numOfRow);
                        for (int iRow = 1; iRow <= numOfRow; iRow++) {
                            LogManager.getLogger(ReportPage.class).info("Deleting record");
                            driver.findElements(By.xpath("//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td/a[@class='delete-icon icon-delete af_commandLink']"));
                            waitFor(deleteConfirmationPopup,30);
                            clickElement(deleteConfirmationOkBtn);
                            extent.log(LogStatus.PASS,"Clicked On OK Button of confirmation tab");
                            waitFor(deleteInfoPopup,30);
                            clickElement(deleteInfoOkBtn);
                            extent.log(LogStatus.PASS,"Clicked On OK Button");
                        }
                    }
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            finally {
                //  homePageSymbol.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", homePageSymbol);
                clickOnElement(driver,homePageSymbol);
                clickElement(homePageSymbol);
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in downloadSettlementReport(): "+ex.getMessage());
        }


    }

    public void deleteDownloadedSettlementReports()
    {
        try
        {
            LogManager.getLogger(ReportPage.class).info("Also Deleting the reports");
            waitFor(deleteSettlementReport,40);
            clickElement(deleteSettlementReport);
            waitFor(deleteConfirmationPopup,30);
            clickElement(deleteConfirmationOkBtn);
            extent.log(LogStatus.PASS,"Clicked On OK Button of confirmation tab");
            waitFor(deleteInfoPopup,30);
            clickElement(deleteInfoOkBtn);
            extent.log(LogStatus.PASS,"Clicked On OK Button");
            LogManager.getLogger(ReportPage.class).info("Reports Deleted");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in deleteDownloadedSettlementReports(): "+ex.getMessage());
        }

    }

    public void deleteDownloadedTransactionReport()
    {
        try
        {
        /*waitFor(deleteSettlementReport,40);
        clickElement(deleteSettlementReport);
        waitFor(okDeleteTransactionReport,30);
        clickElement(okDeleteTransactionReport);
        extent.log(LogStatus.PASS,"Clicked On OK Button of confirmation tab");
        waitFor(okButtonAfterDeletion,30);
        clickElement(okButtonAfterDeletion);
        extent.log(LogStatus.PASS,"Clicked On OK Button");*/

            LogManager.getLogger(ReportPage.class).info(transactionReportEntries.size());
            Iterator transactionReportEntriesIterator = transactionReportEntries.iterator();
            int i = 1;
            while(transactionReportEntriesIterator.hasNext())
            {
                eachTransactionReport = getTextfromElement(driver.findElement(By.xpath("//*[contains(@id,':usert1::db')]/table/tbody/tr["+i+"]//td[2]")));
                if(eachTransactionReport.contains(getTodayinddMMyyyy()))
                {
                    waitFor(20);
                    transactionReportToBeDeleted = driver.findElement(By.xpath("//*[contains(@id,'usert1:"+(i-1)+":cl4')]"));
                    break;
                }
                i=i+1;
            }
            clickElement(transactionReportToBeDeleted);
            waitFor(okDeleteTransactionReport,30);
            clickElement(okDeleteTransactionReport);
            extent.log(LogStatus.PASS,"Clicked On OK Button of confirmation tab");
            waitFor(okButtonAfterDeletion,30);
            clickElement(okButtonAfterDeletion);
            extent.log(LogStatus.PASS,"Clicked On OK Button");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in deleteDownloadedTransactionReport(): "+ex.getMessage());
        }

    }



}
