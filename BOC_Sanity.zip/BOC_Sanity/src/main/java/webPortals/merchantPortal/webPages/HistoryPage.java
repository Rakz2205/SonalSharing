package webPortals.merchantPortal.webPages;
/**
 * To Verify the History
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import utilityLibrary.base.BaseClass;

import java.util.Iterator;
import java.util.List;

import static utilityLibrary.testData.Constants.*;

public class HistoryPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);

    public HistoryPage() {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath =  "//*[contains(text(),' No Transactions to display')]")
    public WebElement noTransactionToDisplay;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[1]")
    public WebElement transID;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[2]")
    public WebElement date;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[3]")
    public WebElement time;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[4]")
    public WebElement amount;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[5]")
    public WebElement paymentMode;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[6]")
    public WebElement status;

    @FindBy(xpath = "//table[@class='af_table_data-table af_table_data-table-VH-lines']/tbody/tr[1]/td[7]")
    public WebElement details;

    @FindBy(xpath = "//span[@class='clsFloatL clsW100']")
    public WebElement verifyStatus;

    @FindBy(xpath = "//div[contains(@id,'pgl2')]//div")
    public WebElement verifyDateAndTime;

    @FindBy(xpath = "//div[contains(@id,'pgl4')]/div[3]/span")
    public WebElement verifyAmount;

    @FindBy(xpath = "//div[contains(@id,'d_pt:r2:2:pgl4')]/div[3]/span")
    public WebElement noRecords;

    //Transaction Details
    @FindBys(@FindBy(xpath = "//*[contains(@class,'af_table_data-row')]"))
    public List<WebElement> transactionsList;

    @FindBy(xpath =  "//*[contains(@id,'pgl28')]")
    public WebElement transactionsDetailsText;

    @FindBy(xpath =  "//*[contains(@id,'pgl4')]/div[3]/span")
    public WebElement amountOnTransactionsDetails;

    @FindBy(xpath =  "//*[contains(@id,'pgl2')]/div[contains(text(),'Date')]")
    public WebElement dateAndTimeOnTransactionsDetails;

    @FindBy(xpath =  "//*[contains(@id,':pgl9')]/div")
    public WebElement transTypeOnTransactionsDetails;

    @FindBy(xpath =  "//*[contains(@id,':pgl23')]/div[3]/span")
    public WebElement basicSalesAmountOnTransactionDetails;

    @FindBy(xpath =  "//*[contains(@id,':pgl32')]/div[3]/span")
    public WebElement grossTotalAmountOnTransactionDetails;

    @FindBy(xpath =  "//*[contains(@id,':cb2')]")
    public WebElement cancelButton;

    @FindBy(xpath =  "//*[@class='af_message_detail-cell']")
    public WebElement inValidDateRangeErrorMessage;
    //The date must be between 01/12/2019 and 31/12/2019.


    public void verifyDetails()
    {
        try
        {
            if(isElementDisplayed(noTransactionToDisplay))
            {
                LogManager.getLogger(HistoryPage.class).info("No data Present");
                extent.log(LogStatus.INFO,"No data Present");

            }
            else {
                String Date = getDate();
                String Time = getTime();
                String Amount = getAmount();
                String status = getStatus();
                LogManager.getLogger(HistoryPage.class).info("date= " + getDate());
                LogManager.getLogger(HistoryPage.class).info("Time= " + getTime());
                LogManager.getLogger(HistoryPage.class).info("Amount= " + getAmount());
                LogManager.getLogger(HistoryPage.class).info("status= " + getStatus());
                LogManager.getLogger(HistoryPage.class).info("********************************************");
                clickElement(details);
                extent.log(LogStatus.INFO,"Clicked on Details");
                if (getTextfromElement(verifyStatus).contains(status))
                    softAssert.assertTrue(true);
                softAssert.assertFalse(true);
                extent.log(LogStatus.PASS,"Verified Status");
                if (getTextfromElement(verifyDateAndTime).contains(Date) && verifyDateAndTime.getText().contains(Time))
                    softAssert.assertTrue(true);
                softAssert.assertFalse(true);
                extent.log(LogStatus.PASS,"Verified Time");
                if (getTextfromElement(verifyAmount).contains(Amount))
                    softAssert.assertTrue(true);
                softAssert.assertFalse(true);
                extent.log(LogStatus.PASS,"Verified Amount");
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in verifyDetails()"+ex.getMessage());
        }


    }

    public String checkHistoryForCertainTID(String checkTransID, String checkPaymentMode, String checkAmount, String checkDate) throws Exception {
        //enterFilterDetails(checkTransID);
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            LogManager.getLogger(HistoryPage.class).info(transactionsList.size());
            Iterator transactionsListIterator = transactionsList.iterator();
            int i = 1;
            String eachTransactionId, eachTransactionMode;

            if (transactionsList.size() <= 0) {
                return getTextfromElement(noTransactionToDisplay);
            } else {

                while (transactionsListIterator.hasNext()) {
                    transactionsListIterator.next();
                    Thread.sleep(MIN_WAIT_TIME);
                    eachTransactionId = getTextfromElement(driver.findElement(By.xpath("//*[contains(@class,'af_table_data-row')][" + i + "]//td")));
                    LogManager.getLogger(HistoryPage.class).info("*****************"+eachTransactionId);
                    eachTransactionMode = getTextfromElement(driver.findElement(By.xpath("//*[contains(@class,'af_table_data-row')][" + i + "]//td[5]")));
                    LogManager.getLogger(HistoryPage.class).info("*****************"+eachTransactionMode);
                    if (eachTransactionId.equalsIgnoreCase(checkTransID) && eachTransactionMode.equalsIgnoreCase(checkPaymentMode)) {
                        LogManager.getLogger(HistoryPage.class).info("FOUND");
                        break;
                    }
                    i = i + 1;

                }
                Thread.sleep(AVG_WAIT_TIME);
                clickElement(driver.findElement(By.xpath("//*[contains(@class,'af_table_data-row')][" + i + "]//td[7]")));
                Thread.sleep(AVG_WAIT_TIME);
                getTextfromElement(transactionsDetailsText);

                SoftAssert softAssert = new SoftAssert();
                if(checkPaymentMode.contains("Debit Card") || checkPaymentMode.contains("REFUND"))
                {
                    softAssert.assertTrue(getTextfromElement(transTypeOnTransactionsDetails).contains("Payments"));
                }
                else if(checkPaymentMode.contains("Jio Money"))
                {
                    softAssert.assertTrue(getTextfromElement(transTypeOnTransactionsDetails).contains("P2M") || getTextfromElement(transTypeOnTransactionsDetails).contains("Barcode Purchase"));
                }
                else
                {
                    softAssert.assertTrue(getTextfromElement(transTypeOnTransactionsDetails).contains("P2M"));
                }
                softAssert.assertTrue(getTextfromElement(amountOnTransactionsDetails).contains(checkAmount));
                //softAssert.assertTrue(getTextfromElement(dateAndTimeOnTransactionsDetails).contains(checkDate));
            }
            return "";
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in checkHistoryForCertainTID(String checkTransID, String checkPaymentMode, String checkAmount, String checkDate)"+ex.getMessage());
        }

    }


    public String getDate()
    {
        try
        {
            return getTextfromElement(date);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in "+ex.getMessage());
        }

    }

    public String getTime()
    {
        try
        {
            return getTextfromElement(time);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in "+ex.getMessage());
        }

    }

    public String getAmount()
    {
        try
        {
            return getTextfromElement(amount);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in "+ex.getMessage());
        }

    }

    public String getStatus()
    {
        try
        {
            return getTextfromElement(status);
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in "+ex.getMessage());
        }

    }


}
