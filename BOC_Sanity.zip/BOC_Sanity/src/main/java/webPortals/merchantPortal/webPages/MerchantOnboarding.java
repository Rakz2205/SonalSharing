package webPortals.merchantPortal.webPages;
/**
 * To onboard a new Merchant
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.AVG_WAIT_TIME;

public class MerchantOnboarding extends BaseClass {

    WebDriverWait wait = new WebDriverWait(driver, 25);
    public static String workingDir=System.getProperty("user.dir");

    public MerchantOnboarding()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[contains(@id,'dc1:inputText4::content')]")
    public WebElement pd_mobileNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:inputText5::content')]")
    public WebElement pd_firstName;

    @FindBy(xpath = "//input[contains(@id,'dc1:inputText6::content')]")
    public WebElement pd_lastName;

    @FindBy(xpath = "//button[contains(@id,'dc1:commandButton1')]")
    public WebElement pd_genrateOTP;

    @FindBy(xpath = "//input[contains(@id,'dc1:it2::content')]")
    public WebElement pd_password;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb1')]")
    public WebElement pd_submitPassword;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc1::content')]")
    public WebElement pd_buisnessChannel;
    //Online

    @FindBy(xpath = "//input[contains(@id,'dc1:sor1:_1')]")
    public WebElement pd_completeTheSignup;

    @FindBy(xpath = "//select[contains(@id,'dc1:selectOneChoice1::content')]")
    public WebElement pd_buisnessOwnership;
    //Sole Proprietorship

    @FindBy(xpath = "//input[contains(@id,'dc1:sor1:_1')]")
    public WebElement pd_individualMerchant;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor3:_1')]")
    public WebElement pd_buisnessEntity;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor2:_0')]")
    public WebElement pd_maleGender;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor2:_1')]")
    public WebElement pd_femaleGender;

    @FindBy(xpath = "//input[contains(@id,'dc1:id1::content')]")
    public WebElement pd_dob;

    @FindBy(xpath = "//input[contains(@id,'dc1:it5::content')]")
    public WebElement lastname;


    @FindBy(xpath = "//select[contains(@id,'dc1:soc2::content')]")
    public WebElement pd_poi;
    //Passport

    @FindBy(xpath = "//input[contains(@id,'dc1:inputText2::content')]")
    public WebElement pd_docId;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb1')]")
    public WebElement pd_continue;

    @FindBy(xpath = "//input[contains(@id,'dc1:it13::content')]")
    public WebElement bd_businessDisplayName;

    @FindBy(xpath = "//input[contains(@id,'dc1:it20::content')]")
    public WebElement bd_businessLegalName;

    @FindBy(xpath = "//input[contains(@id,'dc1:it27::content')]")
    public WebElement bd_businessPANNo;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc7::content')]")
    public WebElement bd_industryType;
    //Kirana / Provision store / Supermarket, Pharmacy, Fruit / Veg, Pan Bidi, Book shop

    @FindBy(xpath = "//select[contains(@id,'dc1:soc2::content')]")
    public WebElement bd_businessLine;
    //Kirana / Provision store / Supermarket

    @FindBy(xpath = "//select[contains(@id,'dc1:soc1::content')]")
    public WebElement bd_yearsOfBusiness;
    //Less than a year

    @FindBy(xpath = "//select[contains(@id,'dc1:selectOneChoice1::content')]")
    public WebElement bd_mer_gst_cat;
    //Unregistered

    @FindBy(xpath = "//input[contains(@id,'dc1:sor2:_0')]")
    public WebElement bd_ownedBusinessAdress;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor2:_1')]")
    public WebElement bd_rentedBusinessAdress;

    @FindBy(xpath = "//input[contains(@id,'dc1:it7::content')]")
    public WebElement bd_addressLine1;

    @FindBy(xpath = "//input[contains(@id,'dc1:it11::content')]")
    public WebElement bd_addressLine2;

    @FindBy(xpath = "//input[contains(@id,'dc1:it8::content')]")
    public WebElement bd_pincode;

    @FindBy(xpath = "//input[contains(@id,'dc1:it2::content')]")
    public WebElement bd_city;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc3::content')]")
    public WebElement bd_state;
    //Maharashtra

    @FindBy(xpath = "//input[contains(@id,'dc1:it10::content')]")
    public WebElement bd_webAddress;

    @FindBy(xpath = "//input[contains(@id,'dc1:it14::content')]")
    public WebElement bd_landlineNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:it6::content')]")
    public WebElement bd_emailID;

    @FindBy(xpath = "//input[contains(@id,'dc1:sbc1::content')]")
    public WebElement bd_sameaddress;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc4::content')]")
    public WebElement bd_dailyTransactioVal;
    //Up to Rs 5,000

    @FindBy(xpath = "//input[contains(@id,'dc1:sor4:_0')]")
    public WebElement bd_dailyTransactioNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor5:_0')]")
    public WebElement bd_returnPolicyYes;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor5:_1')]")
    public WebElement bd_returnPolicyNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor6:_0')]")
    public WebElement bd_merchantDeliveryPeriod;

    @FindBy(xpath = "//select[contains(@id,'dc1:selectOneChoice2::content')]")
    public WebElement bd_POA;
    //Utility Bill(within last 3 months)

    @FindBy(xpath = "//input[contains(@id,'dc1:inputText3::content')]")
    public WebElement bd_POSID;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb1')]")
    public WebElement bd_continueBtn;

    @FindBy(xpath = "//select[contains(@id,'dc1:sor3::content')]")
    public WebElement payd_paymentProduct;
    //JioMoney Wallet

    @FindBy(xpath = "//input[contains(@id,'dc1:selectOneRadio1:_0')]")
    public WebElement payd_leranMoreYes;

    @FindBy(xpath = "//input[contains(@id,'dc1:selectOneRadio1:_1')]")
    public WebElement payd_leranMoreNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:sor1:_1')]")
    public WebElement payd_settlementBankaccountdetails;

    @FindBy(xpath = "//input[contains(@id,'dc1:it15::content')]")
    public WebElement payd_bankAccName;

    @FindBy(xpath = "//input[contains(@id,'dc1:it9::content')]")
    public WebElement payd_bankAccNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:cnfrmAccinput::content')]")
    public WebElement payd_bankConfirmAccNo;

    @FindBy(xpath = "//input[contains(@id,'dc1:it16::content')]")
    public WebElement payd_ifscCode;

    @FindBy(xpath = "//a[contains(@id,'dc1:cb2')]")
    public WebElement dd_poiAttachement;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc4::content')]")
    public WebElement dd_selectPOB;

    @FindBy(xpath = "//a[contains(@id,'dc1:cb6')]")
    public WebElement dd_poaAttachement;

    @FindBy(xpath = "//a[contains(@id,'dc1:cb7')]")
    public WebElement dd_pobAttachement;

    @FindBy(xpath = "//input[contains(@id,'dc1:it3::content')]")
    public WebElement dd_pobID;

    @FindBy(xpath = "//a[contains(@id,'dc1:cb5')]")
    public WebElement dd_ccSettlementAc;

    @FindBy(xpath = "//select[contains(@id,'dc1:soc6::content')]")
    public WebElement dd_finDocs;
    //Bank A/c Statement (for last 3 Months)

    @FindBy(xpath = "//a[contains(@id,'dc1:cb9')]")
    public WebElement dd_finDocsattachement;

    @FindBy(xpath = "//input[contains(@id,'dc1:sbc3::content')]")
    public WebElement dd_agreeTemsandCondRadiobtn;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb1')]")
    public WebElement dd_ContinueBtn;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb2')]")
    public WebElement payd_continueBtn;

    @FindBy(xpath = "//input[contains(@id,'dc1:if3::content')]")
    public WebElement dd_POIChooseFile;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb15')]")
    public WebElement dd_saveFile;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb14')]")
    public WebElement dd_OkButton;

    @FindBy(xpath = "//input[contains(@id,'dc1:if4::content')]")
    public WebElement dd_POAChooseFile;

    @FindBy(xpath = "//input[contains(@id,'dc1:if5::content')]")
    public WebElement dd_POBChooseFile;

    @FindBy(xpath = "//input[contains(@id,'dc1:if8::content')]")
    public WebElement dd_CCChooseFile;

    @FindBy(xpath = "//input[contains(@id,'dc1:if9::content')]")
    public WebElement dd_finDocChooseFile;

    @FindBy(xpath = "//button[contains(@id,'dc1:cb4')]")
    public WebElement rv_submitBtn;

    @FindBy(xpath = "//span[@class='clsTxtHeaderBlue']")
    public WebElement pd_personalDetailsHeading;

    @FindBy(xpath = "//div[contains(@id,'dc1:pgl13')]/div/span[@class='clsTxtHeaderBlue']")
    public WebElement pd_buisnessDetailsHeading;

    @FindBy(xpath = "//span[@class='clsTxtHeaderBlue']")
    public WebElement pd_paymentDetailsHeading;

    @FindBy(xpath = "//span[@class='clsTxtHeaderBlue']")
    public WebElement pd_documentsDetailsHeading;

    @FindBy(xpath = "//span[@class='subheading clsTxtHeaderBlue']")
    public WebElement pd_reviewPageHeading;

    @FindBy(xpath = "//div[contains(@id,'dc1:d3::_ttxt')]")
    public WebElement pd_congratulations;

    @FindBy(xpath = "//div[contains(@id,'dc1:pgl44')]/div")
    public WebElement mid;

    @FindBy(xpath = "//div[contains(@id,'dc1:pgl47')]/div")
    public WebElement tid;

    @FindBy(xpath = "//button[contains(@id,'dc1:gasb1')]")
    public WebElement home_btn;

    @FindBy(xpath = "//*[contains(@id,'dc1:cb6')]")
    public WebElement errorOKButton;


    public void enterPersonalDetails(String mMobile,String mFname, String mLname, String mPword, String busiChannel, String busiOwnerdhip,
                                     String mgender,String mdob, String POIType, String POIID){
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
            pd_mobileNo.sendKeys(mMobile);
            extent.log(LogStatus.INFO,"Entered Mobile number in Field");
            pd_firstName.sendKeys(mFname);
            extent.log(LogStatus.INFO,"Entered Firstname in Field");
            pd_lastName.sendKeys(mLname);
            extent.log(LogStatus.INFO,"Entered Lastname in Field");
            clickElement(pd_genrateOTP);
            extent.log(LogStatus.INFO,"Clicked on generate OTP Field");
            waitFor(pd_submitPassword,30);
            pd_password.sendKeys(mPword);
            extent.log(LogStatus.INFO,"Entered Password in Field");
        /*Actualtext =pd_personalDetailsHeading.getText();
        softAssert.assertEquals(Actualtext,"Personal Details");
        softAssert.assertAll();*/
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(pd_submitPassword);
            extent.log(LogStatus.INFO,"Clicked on submit button");
            waitFor(pd_buisnessChannel,30);
            Thread.sleep(AVG_WAIT_TIME);
            Select selBusiChannel=new Select(pd_buisnessChannel);
            selBusiChannel.selectByVisibleText(busiChannel);
            extent.log(LogStatus.INFO,"Selected Business channel option from dropdown");
            clickElement(pd_completeTheSignup);
            extent.log(LogStatus.INFO,"Clicked on signup button");
            waitFor(pd_buisnessOwnership,30);
            Select selBusiOwnership=new Select(pd_buisnessOwnership);
            selBusiOwnership.selectByVisibleText(busiOwnerdhip);
            extent.log(LogStatus.INFO,"Selected Business ownership option from dropdown");
            if(mgender.equalsIgnoreCase("Male"))
            {
                clickElement(pd_maleGender);
                extent.log(LogStatus.INFO,"Selected male gender button");
            }else
            {
                clickElement(pd_femaleGender);
                extent.log(LogStatus.INFO,"Selected Female gender button");
            }
            Thread.sleep(AVG_WAIT_TIME);
            Select selPOI=new Select(pd_poi);
            selPOI.selectByVisibleText(POIType);
            extent.log(LogStatus.INFO,"Selected Proof of Identity Type from the dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            myExecutor.executeScript("arguments[0].value='"+POIID+"';", pd_docId);
            extent.log(LogStatus.INFO,"Entered Proof of Identity ID in field ");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(pd_dob);
            extent.log(LogStatus.INFO,"Clicked on DOB");
            Thread.sleep(300);
            myExecutor.executeScript("arguments[0].value='"+mdob+"';", pd_dob);
            Thread.sleep(AVG_WAIT_TIME);
            myExecutor.executeScript("arguments[0].value='"+mLname+"';", lastname);
            Thread.sleep(AVG_WAIT_TIME);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", pd_continue);
            clickOnElement(driver,pd_continue);
            extent.log(LogStatus.INFO,"Clicked on Continue button");
            Thread.sleep(AVG_WAIT_TIME);
       /* Actualtext =pd_buisnessDetailsHeading.getText();
        softAssert.assertEquals(Actualtext,"Business Details");
        softAssert.assertAll();*/
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in enterPersonalDetails(): "+ex.getMessage());
        }

    }

    public void enterBuisnessDetails(String busiDisplayName, String busiLegalname, String busiPan,String busiType, String busiLine, String busiYears, String gstCat , String addLine1, String addLine2,
                                     String pincode, String state, String web, String landline,String emailId, String dailyTransval,
                                     String POA, String POAID){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            bd_businessDisplayName.sendKeys(busiDisplayName);
            extent.log(LogStatus.INFO,"Entered Business display name");
            bd_businessLegalName.sendKeys(busiLegalname);
            extent.log(LogStatus.INFO,"Entered Business Legal name");
            bd_businessPANNo.sendKeys(busiPan);
            extent.log(LogStatus.INFO,"Entered Business PAN name");
            Select selBusiIndustry=new Select(bd_industryType);
            selBusiIndustry.selectByVisibleText(busiType);
            extent.log(LogStatus.INFO,"Selected Business Type option from dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            Select selBusiLine=new Select(bd_businessLine);
            selBusiLine.selectByVisibleText(busiLine);
            extent.log(LogStatus.INFO,"Selected Business Line option from dropdown");
            waitFor(30);
            Select selYearsOfBusiness=new Select(bd_yearsOfBusiness);
            selYearsOfBusiness.selectByVisibleText(busiYears);
            extent.log(LogStatus.INFO,"Selected Business years option from dropdown");
            Select selgstCat=new Select(bd_mer_gst_cat);
            waitFor(30);
            selgstCat.selectByVisibleText(gstCat);
            extent.log(LogStatus.INFO,"Selected GST Category option from dropdown");
            clickElement(bd_ownedBusinessAdress);
            extent.log(LogStatus.INFO,"Clicked on own Business address");
            bd_addressLine1.sendKeys(addLine1);
            extent.log(LogStatus.INFO,"Entered address line 1");
            bd_addressLine2.sendKeys(addLine2);
            extent.log(LogStatus.INFO,"Entered address line 2");
            bd_pincode.sendKeys(pincode);
            extent.log(LogStatus.INFO,"Entered PINCODE");
            Thread.sleep(AVG_WAIT_TIME);
            Select selstate=new Select(bd_state);
            selstate.selectByVisibleText(state);
            extent.log(LogStatus.INFO,"Selected state option from dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            bd_webAddress.sendKeys(web);
            extent.log(LogStatus.INFO,"Entered Web Address in field");
            Thread.sleep(AVG_WAIT_TIME);
            bd_landlineNo.sendKeys(landline);
            extent.log(LogStatus.INFO,"Entered Landline in landline field");
            Thread.sleep(AVG_WAIT_TIME);
            bd_emailID.sendKeys(emailId);
            extent.log(LogStatus.INFO,"Entered email ID in email id field");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(bd_sameaddress);
            extent.log(LogStatus.INFO,"Clicked on same address checkbox");
            Thread.sleep(AVG_WAIT_TIME);
            Select selDailyTransVal=new Select(bd_dailyTransactioVal);
            selDailyTransVal.selectByVisibleText(dailyTransval);
            extent.log(LogStatus.INFO,"Selected daily trans value option from dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(bd_dailyTransactioNo);
            extent.log(LogStatus.INFO,"Clicked on daily transaction number");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(bd_returnPolicyYes);
            extent.log(LogStatus.INFO,"Clicked on return policy yes check box");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(bd_merchantDeliveryPeriod);
            extent.log(LogStatus.INFO,"Clicked on merchant delivery period");
            Thread.sleep(AVG_WAIT_TIME);
            Select selPOA=new Select(bd_POA);
            selPOA.selectByVisibleText(POA);
            extent.log(LogStatus.INFO,"Selected proof of address option from dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            bd_POSID.sendKeys(POAID);
            extent.log(LogStatus.INFO,"Selected proof of address ID option from dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(bd_continueBtn);
            extent.log(LogStatus.INFO,"Clicked on continue button");
            Thread.sleep(5000);
            Actualtext =getTextfromElement(pd_paymentDetailsHeading);
            softAssert.assertEquals(Actualtext,"Settlement Details");
            softAssert.assertAll();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in enterBuisnessDetails(): "+ex.getMessage());
        }

    }

    public void enterPaymentDetails(String paymentPrd, String bankAccName, String bankAccNo, String ifsc){
        try
        {
            JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
            Select selPayProduct=new Select(payd_paymentProduct);
            selPayProduct.selectByVisibleText(paymentPrd);
            extent.log(LogStatus.INFO,"Selected payment product option in dropdown");
            Thread.sleep(AVG_WAIT_TIME);
//            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", payd_leranMoreNo);
            clickOnElement(driver,payd_leranMoreNo);
            extent.log(LogStatus.INFO,"Clicked on no checkbox of leran more");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(payd_settlementBankaccountdetails);
            extent.log(LogStatus.INFO,"Clicked on settlement bank account details");
            Thread.sleep(AVG_WAIT_TIME);
            payd_bankAccName.sendKeys(bankAccName);
            extent.log(LogStatus.INFO,"Entered bank account name");
            myExecutor.executeScript("arguments[0].value='"+bankAccNo+"';", payd_bankAccNo);
            extent.log(LogStatus.INFO,"Entered bank account number");
            Thread.sleep(AVG_WAIT_TIME);
            myExecutor.executeScript("arguments[0].value='"+bankAccNo+"';", payd_bankConfirmAccNo);
            extent.log(LogStatus.INFO,"Entered confirmed bank account number");
            Thread.sleep(AVG_WAIT_TIME);
            payd_ifscCode.sendKeys(ifsc);
            extent.log(LogStatus.INFO,"Entered IFSC code in IFSC field");
            Thread.sleep(5000);
            clickElement(payd_continueBtn);
            extent.log(LogStatus.INFO,"Clicked on continue button");
            Thread.sleep(7000);
            Actualtext =getTextfromElement(pd_documentsDetailsHeading);
            softAssert.assertEquals(Actualtext,"Document Details");
            softAssert.assertAll();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in enterPaymentDetails(): "+ex.getMessage());
        }

    }

    public void uploadDocuments(String POIPath, String POAPath, String POB, String POBPath, String POBID, String ccPath,
                                String finDoc, String finDocPath){
        try
        {
            waitForClickable(dd_poiAttachement,30);
            clickElement(dd_poiAttachement);
            extent.log(LogStatus.INFO,"Clicked on attachment of proof of identity");
            Thread.sleep(4000);
            waitFor(dd_POIChooseFile,30);
            dd_POIChooseFile.sendKeys(workingDir+POIPath);
            extent.log(LogStatus.INFO,"Entered on attachment of proof of identity");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_saveFile,30);
            clickElement(dd_saveFile);
            extent.log(LogStatus.INFO,"Clicked on save file");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_OkButton,30);
            clickElement(dd_OkButton);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
            Thread.sleep(4000);
            waitForClickable(dd_poaAttachement,30);
            clickElement(dd_poaAttachement);
            extent.log(LogStatus.INFO,"Entered on attachment of proof of address");
            Thread.sleep(AVG_WAIT_TIME);
            dd_POAChooseFile.sendKeys(workingDir+POAPath);
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_saveFile,30);
            clickElement(dd_saveFile);
            extent.log(LogStatus.INFO,"Clicked on save file");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_OkButton,30);
            clickElement(dd_OkButton);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
            Select selroofOfBusiness=new Select(dd_selectPOB);
            selroofOfBusiness.selectByVisibleText(POB);
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_pobAttachement,30);
            clickElement(dd_pobAttachement);
            extent.log(LogStatus.INFO,"Clicked on attachment of proof of business");
            Thread.sleep(AVG_WAIT_TIME);
            dd_POBChooseFile.sendKeys(workingDir+POBPath);
            extent.log(LogStatus.INFO,"Uploaded proof of business document");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_saveFile,30);
            clickElement(dd_saveFile);
            extent.log(LogStatus.INFO,"Clicked on save file");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_OkButton,30);
            clickElement(dd_OkButton);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
            Thread.sleep(AVG_WAIT_TIME);
            dd_pobID.sendKeys(merchantPortalPro.getProperty("ddPOBID"));
            extent.log(LogStatus.INFO,"Entered ID of proof of business");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_ccSettlementAc,30);
            clickElement(dd_ccSettlementAc);
            extent.log(LogStatus.INFO,"Clicked on settlement account");
            Thread.sleep(AVG_WAIT_TIME);
            dd_CCChooseFile.sendKeys(workingDir+ccPath);
            extent.log(LogStatus.INFO,"Uploaded cancel check document");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_saveFile,30);
            clickElement(dd_saveFile);
            extent.log(LogStatus.INFO,"Clicked on save file");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_OkButton,30);
            clickElement(dd_OkButton);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
            Thread.sleep(AVG_WAIT_TIME);
            Select selFinDocs=new Select(dd_finDocs);
            selFinDocs.selectByVisibleText(finDoc);
            extent.log(LogStatus.INFO,"Selected financial document option in dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_finDocsattachement,30);
            clickElement(dd_finDocsattachement);
            extent.log(LogStatus.INFO,"Clicked on attachment of Financial document");
            Thread.sleep(AVG_WAIT_TIME);
            dd_finDocChooseFile.sendKeys(workingDir+finDocPath);
            extent.log(LogStatus.INFO,"Uploaded financial document");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_saveFile,30);
            clickElement(dd_saveFile);
            extent.log(LogStatus.INFO,"Clicked on save file");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_OkButton,30);
            clickElement(dd_OkButton);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_agreeTemsandCondRadiobtn,30);
            clickElement(dd_agreeTemsandCondRadiobtn);
            extent.log(LogStatus.INFO,"Clicked on Accept terms and conditions button");
            Thread.sleep(AVG_WAIT_TIME);
            waitForClickable(dd_ContinueBtn,30);
            clickElement(dd_ContinueBtn);
            extent.log(LogStatus.INFO,"Clicked on continue Button");
            Thread.sleep(5000);
            Actualtext =getTextfromElement(pd_reviewPageHeading);
            softAssert.assertEquals(Actualtext,"Please review the information before submitting the form");
            softAssert.assertAll();
            Thread.sleep(5000);
            waitForClickable(rv_submitBtn,30);
            /*clickElement(rv_submitBtn);*/
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();",rv_submitBtn);
            clickOnElement(driver,rv_submitBtn);
            extent.log(LogStatus.INFO,"Clicked on Submit Button");
            Thread.sleep(5000);
            if(isElementDisplayed(errorOKButton))
            {
                clickElement(errorOKButton);
            }
            else
            {
                Actualtext =getTextfromElement(pd_congratulations);
                MID=getTextfromElement(mid);
                TID=getTextfromElement(tid);
                LogManager.getLogger(MerchantOnboarding.class).info("MID = "+MID);
                LogManager.getLogger(MerchantOnboarding.class).info("TID = "+TID);
            }
            waitForClickable(home_btn,30);
            //clickElement(home_btn);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();",home_btn);
            clickOnElement(driver,home_btn);
            softAssert.assertEquals(Actualtext,"Congratulations!");
            softAssert.assertAll();

            if(isElementDisplayed(rv_submitBtn))
            {
                LogManager.getLogger(MerchantOnboarding.class).info("Inside IFFFFFFFFFFFFFFFFFFFFFFF");
                waitForClickable(rv_submitBtn,30);
                clickOnElement(driver,rv_submitBtn);
                //Thread.sleep(4000);
                clickElement(rv_submitBtn);
                //waitFor(30);
            waitForClickable(home_btn,30);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();",home_btn);
            Thread.sleep(4000);
            clickElement(home_btn);
            LogManager.getLogger(MerchantOnboarding.class).info("Home clicked");
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in uploadDocuments(): "+ex.getMessage());
        }

    }

}
