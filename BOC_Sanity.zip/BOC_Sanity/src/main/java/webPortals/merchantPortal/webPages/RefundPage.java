package webPortals.merchantPortal.webPages;
/**
 * To perform refund of the transactions
 *
 * @author Sneha Dasari
 */
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileOutputStream;
import java.util.List;
import java.util.Properties;
import static utilityLibrary.testData.Constants.*;


public class RefundPage extends BaseClass {


    public RefundPage(){
        PageFactory.initElements(driver,this);
    }



    public HistoryPage historyPage;

    public static String refundedTransactionIDVar;
    public static String refundedDateVar;
    public static String refundedAmountVar;

    @FindBy(xpath =  "//*[contains(text(),' No Transactions to display')]")
    public WebElement noTransactionToDisplay;

    @FindBys(@FindBy(xpath = "//*[contains(@class,'af_table_data-row')]"))
    public List<WebElement> transactionsList;

    @FindBy(xpath =  "//*[contains(@id,'pgl28')]")
    public WebElement transactionsDetailsText;

    @FindBy(xpath =  "//*[contains(@id,':gl1')]")
    public WebElement refundButton;

    @FindBy(xpath =  "//*[contains(@id,':it2::content')]")
    public WebElement amountToBeRefunded;

    @FindBy(xpath =  "//*[contains(@id,':it3::content')]")
    public WebElement passwordToinitRefund;

    @FindBy(xpath =  "//*[contains(@id,'refundBtn')]")
    public WebElement refundButtonOnRefundDialog;


    @FindBy(xpath =  "//*[contains(@id,':pgl1')]/div/span[contains(text(),'Refund')]")
    public WebElement refundAmountIncorrect;
    //Refund Amount Should be less then the Transactional amount.

    @FindBy(xpath =  "//*[contains(@id,':pgl7')]/div")
    public WebElement refundProcessedSuccessfullyMessage;
    //Refund Processed Successfully !

    @FindBy(xpath =  "//*[contains(@id,':cb1')]")
    public WebElement doneButtonAfterRefund;

    //After Refund
    @FindBy(xpath =  "//*[contains(@id,':pgl5')]/div[3]/span")
    public WebElement refundedAmount;

    @FindBy(xpath =  "//*[contains(@id,':pgl2') and contains(@class,'clsTxtRefundWidth50')]/div")
    public WebElement refundedTransactionID;

    @FindBy(xpath =  "//*[contains(@id,':pgl6')]/div")
    public WebElement refundedDate;

    @FindBy(xpath =  "//*[contains(@id,':cb1')]")
    public WebElement doneButton;

    @FindBy(xpath =  "//*[contains(@id,':pgl1') and contains(@class,'clsFloatL ')]/div/span")
    public WebElement transactionDeclinedMessage;
    //Transaction declined. Please try again. (05)

    @FindBy(xpath = "//*[contains(@id,':cancelBtn')]")
    public WebElement cancelButton;

    @FindBy(xpath = "//*[contains(@id,':t1::scroller')]")
    public WebElement scroller;

    public void performRefund(String refundType, String transactionIDArg, String paymentModeArg, String amountReceivedArg, String dateTimeArg){

        try
        {
            historyPage = new HistoryPage();
            String result = historyPage.checkHistoryForCertainTID(transactionIDArg,paymentModeArg,amountReceivedArg, dateTimeArg);
            Assert.assertFalse(result.contains("No"), "Transactional Details are not displayed");
            clickElement(refundButton);
            waitForClickable(amountToBeRefunded, 30);
            if (refundType.equalsIgnoreCase("Partial") || refundType.equalsIgnoreCase("AlreadyRefunded")) {
                float partialRefundAmount = Float.parseFloat(amountReceivedArg);
                amountToBeRefunded.sendKeys(String.valueOf(partialRefundAmount / 2));
            } else {
                amountToBeRefunded.sendKeys(amountReceivedArg);
            }
            waitForClickable(passwordToinitRefund, 30);
            clickElement(passwordToinitRefund);
            passwordToinitRefund.sendKeys("Test@1357");
            waitFor(10);
            clickElement(refundButtonOnRefundDialog);
            Thread.sleep(AVG_WAIT_TIME);

            if (refundType.equalsIgnoreCase("AlreadyRefunded")) {
                String errorMessage = getTextfromElement(transactionDeclinedMessage);
                Assert.assertTrue(errorMessage.equalsIgnoreCase(TRANSACTION_DECLINED));
            } else {
                String successMessage = getTextfromElement(refundProcessedSuccessfullyMessage);

                refundedTransactionIDVar = getTextfromElement(refundedTransactionID).replaceAll("[^0-9]", "").trim();
                refundedDateVar = getTextfromElement(refundedDate).substring(7).trim();
                refundedAmountVar = getTextfromElement(refundedAmount).trim();
                try {
                    fout = new FileOutputStream(projectPath + "//outputFiles//RefundedTransactionIds.properties");
                    writeProperties = new Properties();
                    writeProperties.setProperty("refundedMTransactionID", refundedTransactionIDVar);
                    writeProperties.setProperty("refundedMAmount", refundedAmountVar);
                    writeProperties.setProperty("refundedMDate", refundedDateVar);

                    writeProperties.store(fout, refundType + " Refund Type Details");
                } catch (Exception ex) {
                    LogManager.getLogger(RefundPage.class).info("Writing in Refund file has failed");
                    LogManager.getLogger(RefundPage.class).info(ex.getMessage());
                }

                Assert.assertTrue(successMessage.equalsIgnoreCase("Refund Processed Successfully !"));
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in performRefund(): "+ex.getMessage());
        }

        }


    public void checkHistoryForRefunds(){
        try
        {
            historyPage = new HistoryPage();
            String result = historyPage.checkHistoryForCertainTID(refundedTransactionIDVar,"REFUND",refundedAmountVar,refundedDateVar);
            Assert.assertFalse(result.contains("No"), "Transactional Details are not displayed");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in checkHistoryForRefunds(): "+ex.getMessage());
        }

    }

}
