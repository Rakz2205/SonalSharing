package webPortals.merchantPortal.webPages;
/**
 * To perform operations on elements present on Home Page
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilityLibrary.base.BaseClass;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;

public class HomePage extends BaseClass {
    //WebDriverWait wait = new WebDriverWait(driver, 25);

    public HomePage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//a[@id='d_pt:reprtlink']")
    public WebElement reports;

    @FindBy(xpath = "//a[@id='d_pt:refLink']")
    public WebElement history;

    @FindBy(xpath = "//img[@id='d_pt:pt_cil1::icon']")
    public static WebElement homePageSymbol;

    @FindBy(xpath = "//a[@id='d_pt:accPymntLink']")
    public WebElement acceptPayments;


    public void goToReports()
    {
        try
        {
            waitForClickable(reports,30);
            clickElement(reports);
            extent.log(LogStatus.INFO,"Clicked on reports");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in goToReports()"+ex.getMessage());
        }

    }

    public void goToAcceptPayments()
    {
        try
        {
            driver.navigate().refresh();
            waitForClickable(acceptPayments,30);
            clickElement(acceptPayments);
            extent.log(LogStatus.INFO,"Clicked on Accept Payments");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in goToAcceptPayments()"+ex.getMessage());
        }

    }


    public void goToHistory()
    {
        try
        {
            driver.navigate().refresh();
            waitForClickable(homePageSymbol,30);
            clickElement(homePageSymbol);
            //((JavascriptExecutor)driver).executeScript("arguments[0].click();",history);
            clickOnElement(driver,history);
            extent.log(LogStatus.INFO,"Clicked on History tab");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in goToHistory()"+ex.getMessage());
        }

    }
}
