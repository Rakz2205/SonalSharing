package webPortals.merchantPortal.webPages;
/**
 * To Login into the Application
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */

import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

import java.util.List;

public class LoginPage extends BaseClass {

    WebDriverWait wait = new WebDriverWait(driver, 25);

    public LoginPage() {
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[contains(@id,'s1:ot13::content')]")
    public WebElement mobileNo;

    @FindBy(xpath = "//input[contains(@id,'s1:ot2::content')]")
    public WebElement password;

    @FindBy(xpath = "//button[contains(@id,'s1:cb1')]")
    public WebElement login;

    @FindBy(xpath = "//a[contains(@id,'s1:gl3')]")
    public WebElement registerHere;

    @FindBy(xpath = "//div[contains(@id,'s1:panelGroupLayout3')]/div")
    public WebElement loginPageVerificationField;

    @FindBy(xpath = "//div[contains(@id,'d4::_ttxt')]")
    public WebElement otpPopupVerificationField;

    @FindBy(xpath = "//input[contains(@id,'it1::content')]")
    public WebElement otpField;

    @FindBy(xpath = "//button[contains(@id,'commandButton1')]")
    public WebElement continueBtn;

   /* @FindBy(xpath = "//*[text()='MID: 100001001689765 | ']")
    public WebElement activeMerchant;*/

    @FindBy(xpath = "//div[@class='af_listItem']")
    public WebElement activeMerchant;

    @FindBy(xpath = "//button[contains(@id,'cb4')]")
    public static WebElement activeMerchantContBtn;

    @FindBy(xpath = "//*[contains(text(),'Select Account')]")
    public static WebElement selectAccPopup;

    @FindBy(xpath = "//img[@id='d_pt:pt_cil1::icon']")
    public static WebElement homePageSymbol;

    @FindBy(xpath = "//div[@class='af_menu_bar-item-open-icon-style']")
    public static WebElement dropDown;

    @FindBy(xpath = "//tr[contains(@id,'d_pt:cmi5')]")
    public static WebElement logout;

    @FindBy(xpath = "//td[@class='af_commandMenuItem_menu-item-text' and text()='Profile']")
    public static WebElement profile;

    @FindBy(xpath = "//button[@id='d_pt:pt_cb1']")
    public static WebElement logoutYes;

    @FindBy(xpath = "//a[contains(@id,'s1:gl1')]")
    public static WebElement forgotPassword;

    @FindBy(xpath = "//td[@class='af_commandMenuItem_menu-item-text' and text()='Support']")
    public static WebElement support;

    public void clickOnRegisterHere() {
        try {
            clickElement(registerHere);
            extent.log(LogStatus.INFO, "Clicked on Register here");
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickOnRegisterHere(): " + ex.getMessage());
        }
        //clickElement(homePageSymbol);

    }

    public void clickOnForgotPasswordLink() {
        try {
            clickElement(forgotPassword);
            extent.log(LogStatus.INFO, "Clicked on forget password link");
        } catch (Exception ex) {
            throw new RuntimeException("Error in clickOnForgotPasswordLink(): " + ex.getMessage());
        }

    }

    public void login(String mer_mobile, String mer_pword, String mer_id) {
        try {
            waitFor(loginPageVerificationField, 30);
            Actualtext = getTextfromElement(loginPageVerificationField);
            softAssert.assertEquals(Actualtext, "Log in to your JioPrime Partner account");
            softAssert.assertAll();
            LogManager.getLogger(LoginPage.class).info(mer_mobile);
            mobileNo.sendKeys(mer_mobile);
            extent.log(LogStatus.INFO, "Entered Mobile no");
            LogManager.getLogger(LoginPage.class).info(mer_pword);
            password.sendKeys(mer_pword);
            extent.log(LogStatus.INFO, "Entered Password");
            clickElement(login);
            extent.log(LogStatus.INFO, "Clicked on Login");
            WebDriverWait wait = new WebDriverWait(driver, 30);
            //wait.until(ExpectedConditions.visibilityOfElementLocated((By) otpPopupVerificationField));
            Thread.sleep(5000);
            if (isElementDisplayed(otpPopupVerificationField)) {
                Actualtext = getTextfromElement(otpPopupVerificationField);
                softAssert.assertEquals(Actualtext, "OTP*");
                softAssert.assertAll();
                String otp = fetchOTP();
                otpField.sendKeys(otp);
                extent.log(LogStatus.INFO, "Entered OTP = " + otp + " .");
                clickElement(continueBtn);
                extent.log(LogStatus.INFO, "Clicked on Continue Btn");
            }

            LogManager.getLogger(LoginPage.class).info(isElementDisplayed(selectAccPopup));
            waitForClickable(selectAccPopup, 30);
            if (isElementDisplayed(selectAccPopup)) {
                selectMerchant(mer_id);
                clickElement(activeMerchantContBtn);
            }
            // wait.until(ExpectedConditions.visibilityOf(homePageSymbol));
        } catch (Exception ex) {
            throw new RuntimeException("Error in login(String mer_mobile, String mer_pword): " + ex.getMessage());
        }

    }


    public void selectMerchant(String MID) {
        try {
            LogManager.getLogger(LoginPage.class).info("in select merchant");
            List radioButtons = driver.findElements(By.xpath("//input[@type='radio']"));
            radioButtons.size();
            int i;
            for (i = 0; i < radioButtons.size(); i++) {
                String firstPart = "//div[@id='r1:0:acntLst:";
                String lastPart = ":pgl23']/div";
                String xpath = firstPart + i + lastPart;
                String text = getTextfromElement(driver.findElement(By.xpath(xpath)));
                if (text.contains(MID))
                    break;
            }
            LogManager.getLogger(LoginPage.class).info("----------------");
            LogManager.getLogger(LoginPage.class).info(i);
            String radioBtnXpath = "//input[@id='r1:0:acntLst:" + i + ":sbr2::content']";
            clickElement(driver.findElement(By.xpath(radioBtnXpath)));
            waitFor(activeMerchantContBtn, 30);
        } catch (Exception ex) {
            throw new RuntimeException("Error in selectMerchant(String MID): " + ex.getMessage());
        }

    }

    public void logout() {
        try {
            driver.navigate().refresh();
            waitForClickable(dropDown, 30);
            Thread.sleep(5000);
            clickElement(dropDown);
            extent.log(LogStatus.INFO, "Clicked on dropdown for selecting logout option");
            waitFor(logout, 30);
            clickElement(logout);
            waitFor(logoutYes, 30);
            clickElement(logoutYes);
            extent.log(LogStatus.INFO, "Clicked on yes option");
            Actualtext = getTextfromElement(loginPageVerificationField);
            softAssert.assertEquals(Actualtext, "Log in to your JioPrime Partner account");
            softAssert.assertAll();
        } catch (Exception ex) {
            throw new RuntimeException("Error in logout(): " + ex.getMessage());
        }


    }

    public void goToSupport()  {
        try
        {
            driver.navigate().refresh();
            Thread.sleep(5000);
            waitFor(dropDown,40);
            waitForClickable(dropDown,30);
            clickElement(dropDown);
            extent.log(LogStatus.INFO,"Clicked on dropdown");
            waitForClickable(support,30);
            clickElement(support);
            extent.log(LogStatus.INFO,"Clicked on Support Tab");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in goToSupport(): "+ex.getMessage());
        }

    }


    public void goToProfile() {
        try {
            Thread.sleep(5000);
            waitForClickable(dropDown, 30);
            clickElement(dropDown);
            extent.log(LogStatus.INFO, "Clicked on dropdown");
            waitForClickable(profile, 30);
            clickElement(profile);
            extent.log(LogStatus.INFO, "Clicked on Profile Tab");
        } catch (Exception ex) {
            throw new RuntimeException("Error in goToProfile(): " + ex.getMessage());
        }

    }


}
