package webPortals.merchantPortal.webPages;
/**
 * To perform Forget Password Functionality
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilityLibrary.base.BaseClass;

public class ForgetPasswordPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);

    public ForgetPasswordPage() {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//button[contains(@id,'cb1')]")
    public static WebElement fpContBtn;

    @FindBy(xpath = "//input[contains(@id,'it1::content')]")
    public static WebElement fpMobileNo;

    @FindBy(xpath = "//div[contains(@id,'s5:pgl9')]//div")
    public static WebElement fpHeading;
    //Forgot Password

    @FindBy(xpath = "//input[contains(@id,'s5:it3::content')]")
    public static WebElement fpOTP;

    @FindBy(xpath = "//input[contains(@id,'s5:it2::content')]")
    public static WebElement fpPwd;

    @FindBy(xpath = "//input[contains(@id,'s5:it1::content')]")
    public static WebElement fpConfirmPwd;

    @FindBy(xpath = "//button[contains(@id,'s5:cb1')]")
    public static WebElement fpsubmitBtn;

    @FindBy(xpath = "//div[contains(@id,':pgl6')]//div")
    public static WebElement fpchangedMsg;
    //Your password has been reset successfully.

    @FindBy(xpath = "//button[contains(@id,'cl3')]")
    public static WebElement fpContBtnAfterChangingPWD;

    public void forgotPassword(String mobile, String fpPassword) {
        try
        {
            JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
            waitFor(fpContBtn,30);
            fpMobileNo.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile number");
            clickElement(fpContBtn);
            extent.log(LogStatus.INFO,"Clicked on continue button");
            waitFor(fpsubmitBtn,30);
            Actualtext =getTextfromElement(fpHeading);
            softAssert.assertEquals(Actualtext,"Forgot Password");
            String otp=fetchOTP();
            LogManager.getLogger(ForgetPasswordPage.class).info("**********************"+otp);
            // fpOTP.sendKeys(otp);
            myExecutor.executeScript("arguments[0].value='"+otp+"';", fpOTP);
            extent.log(LogStatus.INFO,"Entered OTP in OTP Field");
            waitFor(fpPwd,30);
            // fpPwd.sendKeys(fpPassword);
            myExecutor.executeScript("arguments[0].value='"+fpPassword+"';", fpPwd);
            extent.log(LogStatus.INFO,"Entered new Password in Field");
            waitFor(fpConfirmPwd,30);
            // fpConfirmPwd.sendKeys(fpPassword);
            myExecutor.executeScript("arguments[0].value='"+fpPassword+"';", fpConfirmPwd);
            extent.log(LogStatus.INFO,"Entered confirmes new Password in Field");
            clickElement(fpsubmitBtn);
            extent.log(LogStatus.INFO,"Clicked on submit button");
            waitFor(fpContBtnAfterChangingPWD,30);
            Actualtext =getTextfromElement(fpchangedMsg);
            softAssert.assertEquals(Actualtext,"Your password has been reset successfully.");
            softAssert.assertAll();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in forgotPassword(String mobile, String fpPassword)"+ex.getMessage());
        }

    }

}
