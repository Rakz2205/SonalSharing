package webPortals.agentPortal.webPages;
/**
 * To update user profile
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;

public class UpdateUserProfilePage extends BaseClass {
    public UpdateUserProfilePage() {
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@id='pt1:r19:1:it6::content']")
    public WebElement userEmailId;

    @FindBy(xpath = "//button[@id='pt1:r19:1:cb2']")
    public WebElement updateButton;

    @FindBy(xpath = "//button[@id='pt1:r19:1:cb8']")
    public WebElement confirmButton;

    @FindBy(xpath = "//button[@id='pt1:r19:1:gb3']")
    public WebElement confirmOKButton;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    public void updateUserProfile(String newID)  {
        try
        {
            jioMoneyIcon.click();
            extent.log(LogStatus.INFO,"Clicked on JIO money Icon");
            userEmailId.clear();
            Thread.sleep(AVG_WAIT_TIME);
            userEmailId.sendKeys(newID);
            extent.log(LogStatus.INFO,"Entered new email ID");
            Thread.sleep(AVG_WAIT_TIME);
            updateButton.click();
            extent.log(LogStatus.INFO,"Clicked on update button");
            Thread.sleep(AVG_WAIT_TIME);
            confirmButton.click();
            extent.log(LogStatus.INFO,"Clicked on confirm button");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(confirmOKButton);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in updateUserProfile(String newID): "+ex.getMessage());
        }

    }
}

