package webPortals.agentPortal.webPages;
/**
 * To Verify Hierarchy and Commission
 *
 * @author By Sneha Dasari
 */
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import static utilityLibrary.testData.Constants.*;


public class HierarchyAndCommissionPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);

    public HierarchyAndCommissionPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(id = "pt1:r10:1:t1:0:cl1")
    public WebElement level1Agent;

    @FindBy(id = "pt1:r10:1:t1:1:cl1")
    public WebElement level2Agent;

    @FindBy(id = "pt1:r10:1:t1:2:cl1")
    public WebElement level3Agent;

    @FindBy(id = "pt1:r10:1:t1:3:cl1")
    public WebElement level4Agent;

    @FindBy(xpath = "//*[@id='pt1:r10:1:pgl2']/span[2]")
    public WebElement agentName;

    @FindBy(xpath = "//*[@id='pt1:pt-pgl1']/div[1]/span")
    public WebElement loggedInAgentName;

    @FindBy(xpath = "//*[@id='pt1:r10:1:pgl29']/span[2]")
    public WebElement distributorName;

    @FindBy(xpath = "//*[@id='pt1:r10:1:pgl27']/span[2]")
    public WebElement agentID;

    @FindBy(xpath = "//*[@id='pt1:r10:1:pgl14']/span[2]")
    public WebElement agentUserRole;

    @FindBy(xpath = "//*[@id='pt1:r10:1:pgl13']/span[2]")
    public WebElement agentMobileNumber;





    public void clickLevel1Agent()
    {
        try
        {
            clickElement(level1Agent);
            Thread.sleep(AVG_WAIT_TIME);
            boolean result=getTextfromElement(level1Agent).equalsIgnoreCase(agentNameDisplayed());
            Assert.assertTrue(result,"Agent Name displayed is Incorrect");
            Assert.assertTrue(agentIDDisplayed().length()>0,"Agent ID is not displayed");
            Assert.assertTrue(agentMobileNumberDisplayed().length()>0,"Agent Mobile Number is not displayed");
            Assert.assertTrue(agentUserRoleDisplayed().equalsIgnoreCase("LEVEL 1"),"User Role is incorrect");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in : "+ex.getMessage());
        }

    }

    public void clickLevel2Agent()
    {
        try
        {
            clickElement(level2Agent);
            Thread.sleep(AVG_WAIT_TIME);
            boolean result=getTextfromElement(level2Agent).equalsIgnoreCase(agentNameDisplayed());
            Assert.assertTrue(result,"Agent Name displayed is Incorrect");
            Assert.assertTrue(distributorNameDisplayed().equalsIgnoreCase(getTextfromElement(level1Agent)),"Distributor Name displayed is Incorrect");
            Assert.assertTrue(agentIDDisplayed().length()>0,"Agent ID is not displayed");
            Assert.assertTrue(agentMobileNumberDisplayed().length()>0,"Agent Mobile Number is not displayed");
            Assert.assertTrue(agentUserRoleDisplayed().equalsIgnoreCase("LEVEL 2"),"User Role is incorrect");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in clickLevel2Agent(): "+ex.getMessage());
        }
    }

    public void clickLevel3Agent()
    {
        try
        {
            clickElement(level3Agent);
            Thread.sleep(AVG_WAIT_TIME);
            boolean result=getTextfromElement(level3Agent).equalsIgnoreCase(agentNameDisplayed());
            Assert.assertTrue(result,"Agent Name displayed is Incorrect");
            Assert.assertTrue(distributorNameDisplayed().equalsIgnoreCase(getTextfromElement(level2Agent)),"Distributor Name displayed is Incorrect");
            Assert.assertTrue(agentIDDisplayed().length()>0,"Agent ID is not displayed");
            Assert.assertTrue(agentMobileNumberDisplayed().length()>0,"Agent Mobile Number is not displayed");
            Assert.assertTrue(agentUserRoleDisplayed().equalsIgnoreCase("LEVEL 3"),"User Role is incorrect");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in : "+ex.getMessage());
        }

    }

    public void clickLevel4Agent()
    {
        try
        {
            clickElement(level4Agent);
            Thread.sleep(AVG_WAIT_TIME);
            boolean result=getTextfromElement(level4Agent).equalsIgnoreCase(getTextfromElement(loggedInAgentName));
            Assert.assertTrue(result,"Agent Name displayed is Incorrect");
            Assert.assertTrue(distributorNameDisplayed().equalsIgnoreCase(getTextfromElement(level3Agent)),"Distributor Name displayed is Incorrect");
            Assert.assertTrue(agentIDDisplayed().length()>0,"Agent ID is not displayed");
            Assert.assertTrue(agentMobileNumberDisplayed().length()>0,"Agent Mobile Number is not displayed");
            Assert.assertTrue(agentUserRoleDisplayed().equalsIgnoreCase("LEVEL 4"),"User Role is incorrect");
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in : "+ex.getMessage());
        }

    }


    public String agentNameDisplayed()
    {
        try
        {
            return getTextfromElement(agentName).replaceAll(":","").trim();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in agentNameDisplayed(): "+ex.getMessage());
        }
    }

    public String agentUserRoleDisplayed()
    {
        try
        {
            return getTextfromElement(agentUserRole).replaceAll(":","").trim();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in agentUserRoleDisplayed(): "+ex.getMessage());
        }

    }

    public String agentMobileNumberDisplayed()
    {
        try
        {
            return getTextfromElement(agentMobileNumber).replaceAll(":","").trim();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in agentMobileNumberDisplayed(): "+ex.getMessage());
        }

    }

    public String agentIDDisplayed()
    {
        try
        {
            return getTextfromElement(agentID).replaceAll(":","").trim();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in agentIDDisplayed(): "+ex.getMessage());
        }

    }

    public String distributorNameDisplayed()
    {
        try
        {
            return getTextfromElement(distributorName).replaceAll(":","").trim();
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error in distributorNameDisplayed(): "+ex.getMessage());
        }

    }


}
