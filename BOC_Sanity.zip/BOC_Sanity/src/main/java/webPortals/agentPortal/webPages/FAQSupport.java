package webPortals.agentPortal.webPages;
/**
 * To perform FAQs related operations
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import static utilityLibrary.testData.Constants.*;

public class FAQSupport extends BaseClass {
    public FAQSupport() {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//a[@id='pt1:cl10']")
    public WebElement generateCode;

    @FindBy(xpath = "//a[@id='pt1:cl23']")
    public WebElement faq;

    @FindBy(xpath = "//select[@id='pt1:r16:1:soc1::content']")
    public WebElement selCategory;
    //Call-in Code

    @FindBy(xpath = "//button[@id='pt1:r16:1:cb1']")
    public WebElement submitBtn;

    @FindBy(xpath = "//button[@id='pt1:r16:1:pt_cl7']")
    public WebElement okBtn;

    @FindBy(xpath = "//a[@id='pt1:r14:1:cni1']")
    public WebElement aboutJioMoney;

    @FindBy(xpath = "//a[@id='pt1:r14:1:cni2']")
    public WebElement signUpOption;

    @FindBy(xpath = "//a[@id='pt1:r14:1:cni3']")
    public WebElement agentActivities;

    @FindBy(xpath = "//a[@id='pt1:r14:1:cni4']")
    public WebElement myAccount;

    @FindBy(xpath = "//img[@title='Expand What is JioMoney?']")
    public WebElement firstExpandBtn;

    @FindBy(xpath = "//img[@title='Expand What do I need to do to become a JioMoney agent?']")
    public WebElement signUpExpandBtn;

    @FindBy(xpath = "//img[@title='Expand How do I recharge my JioMoney Agent account?']")
    public WebElement agentActivitiesExpandBtn;

    @FindBy(xpath = "//img[@title='Expand How do I update my profile information?']")
    public WebElement myAccountExpandBtn;

    @FindBy(xpath = "//div[@class='af_showDetail_child-container']")
    public WebElement jioMoneyAns;
    //JioMoney is an end-to-end payments solution that provides a safe and secure way of making payments.


    @FindBy(xpath = "//div[@id='pt1:r16:1:pgl4']/div[3]")
    public WebElement codeNo;

    @FindBy(xpath = "//a[@id='pt1:pt-gl1']")
    public WebElement home;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    //Raise Ticket xpaths

    @FindBy(xpath = "//*[@id='pt1:cl20']")
    public WebElement raiseTicket;

    @FindBy(xpath = "//*[@id='pt1:r13:1:sor1::content']")
    public WebElement raiseTicketSelectCategory;

    @FindBy(xpath = "//*[@id='pt1:r13:1:it1::content']")
    public WebElement faqsMobileNumber;

    //*[@id="pt1:r13:1:soc1::content"]
    @FindBy(xpath = "//*[@id='pt1:r13:1:soc1::content']")
    public WebElement faqsInteractionType;

    @FindBy(xpath = "//*[@id='pt1:r13:1:soc2::content']")
    public WebElement faqsCategory;

    @FindBy(xpath = "//*[@id='pt1:r13:1:soc3::content']")
    public WebElement faqsSubCategory;

    @FindBy(xpath = "//*[@id='pt1:r13:1:soc4::content']")
    public WebElement faqsSubSubCategory;

    @FindBy(xpath = "//*[@id='pt1:r13:1:it4::content']")
    public WebElement faqsSubject;

    @FindBy(xpath = "//*[@id='pt1:r13:1:it3::content']")
    public WebElement faqsDetails;

    @FindBy(xpath = "//*[@id='pt1:r13:1:mcm_cb1']")
    public WebElement faqsContinueButton;

    @FindBy(xpath = "//*[@id='pt1:r13:1:cb3']")
    public WebElement faqsConfirmButton;

    //*[@id="pt1:r13:1:dialog1::contentContainer"]/span[2]
    @FindBy(xpath = "//*[@id='pt1:r13:1:d1::contentContainer']/span[2]")
    public WebElement faqsSuccessMessage;

    @FindBy(xpath = "//*[@id='pt1:r13:1:panelGroupLayout4']/div[1]")
    public WebElement faqsTicketNumber;

    @FindBy(xpath = "//*[@id='pt1:r13:1:goButton1']")
    public WebElement OkButtononPopup;

    @FindBy(xpath = "//*[@id='pt1:r13:1:goButton3']")
    public WebElement OkButtononPopup3;



    public void generateCode(){
        try
        {
            clickElement(generateCode);
            Thread.sleep(AVG_WAIT_TIME);
            Select selCat=new Select(selCategory);
            selCat.selectByVisibleText("Call-in Code");
            extent.log(LogStatus.INFO,"Call-in Code option selected");
            Thread.sleep(5000);
            clickElement(submitBtn);
            Thread.sleep(AVG_WAIT_TIME);
            Actualtext = codeNo.getText();
      /*  if(Actualtext.length()==6)
            softAssert.assertTrue(Boolean.parseBoolean("True"));
        // softAssert.assertEquals( "Are you sure you want to submit the Adjustment ?", "Are you sure you want to submit the Adjustment ?");
        softAssert.assertAll();*/

            clickElement(okBtn);
            Thread.sleep(AVG_WAIT_TIME);
            Assert.assertTrue(Actualtext.length()==6,"Generate Code Failed");
            // home.click();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in Generate Code Functionality: "+ex.getMessage());
        }
    }

    public void checkAboutJioMoney(){
        try
        {
            clickElement(faq);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(aboutJioMoney);
            Thread.sleep(AVG_WAIT_TIME);
            firstExpandBtn.click();
            extent.log(LogStatus.PASS,"Clicked on expand button");
            Thread.sleep(AVG_WAIT_TIME);
            String ans=getTextfromElement(jioMoneyAns);
            String actualAns="JioMoney is an end-to-end payments solution that provides a safe and secure way of making payments.";
            if(ans.contains(actualAns))
            {
                Assert.assertTrue(true );
            }
            else
            {
                Assert.assertFalse(true );
            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in Check About JioMoney: "+ex.getMessage());
        }
        finally {
            clickElement(home);
            extent.log(LogStatus.INFO,"Clicked on Home Button");
        }

    }

    public void raiseFAQsTicket(String usertype){
        try
        {
            clickElement(raiseTicket);
            Select userType = new Select(raiseTicketSelectCategory);
            userType.selectByVisibleText(usertype);
            Thread.sleep(AVG_WAIT_TIME);
            if(usertype.equalsIgnoreCase("Consumer"))
            {
                faqsMobileNumber.sendKeys(agentportalPro.getProperty("faqsMobNumber"));
                Thread.sleep(AVG_WAIT_TIME);
            }
            Select interactionType = new Select(faqsInteractionType);
            interactionType.selectByIndex(2);
            //waitForSelect(faqsCategory,20);
            Thread.sleep(AVG_WAIT_TIME);
            Select categoryType = new Select(faqsCategory);
            categoryType.selectByIndex(1);
            //waitForSelect(faqsSubCategory,20);
            Thread.sleep(AVG_WAIT_TIME);
            Select subCategoryType = new Select(faqsSubCategory);
            subCategoryType.selectByIndex(1);
            //waitForSelect(faqsSubSubCategory,20);
            Thread.sleep(AVG_WAIT_TIME);
            Select subSubCategoryType = new Select(faqsSubSubCategory);
            subSubCategoryType.selectByIndex(1);
            faqsSubject.sendKeys("Automation Testing, Please delete it");
            faqsDetails.sendKeys("Automation Testing, Please delete it");
            Actions act = new Actions(driver);
            act.sendKeys(Keys.TAB).build().perform();
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(faqsContinueButton);
            waitFor(faqsConfirmButton,30);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(faqsConfirmButton);
            Thread.sleep(MAX_WAIT_TIME);
            String result = getTextfromElement(faqsSuccessMessage);
            takeSnapShot("Ticket Number Captured");
            if(isElementDisplayed(OkButtononPopup))
            {
                clickElement(OkButtononPopup);
            }
            else
            {clickElement(OkButtononPopup3);}
            Assert.assertTrue(result.contains("Success"), "Ticket was not raised Successfully");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in raiseFAQsTicket(String usertype): "+ex.getMessage());
        }

    }

    public void checkJioMoneySignUp() {
        try
        {
            clickElement(faq);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(signUpOption);
            Thread.sleep(AVG_WAIT_TIME);
            signUpExpandBtn.click();
            extent.log(LogStatus.PASS,"Clicked on expand button");
            Thread.sleep(AVG_WAIT_TIME);
            String ans=getTextfromElement(jioMoneyAns);
            Assert.assertTrue(ans.length()>0,"Error Occurred in FAQs Sign Up");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in checkJioMoneySignUp(): "+ex.getMessage());
        }

    }

    public void checkAgentActivities() {
        try
        {
            clickElement(faq);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentActivities);
            Thread.sleep(AVG_WAIT_TIME);
            agentActivitiesExpandBtn.click();
            extent.log(LogStatus.PASS,"Clicked on expand button");
            Thread.sleep(AVG_WAIT_TIME);
            String ans=getTextfromElement(jioMoneyAns);
            Assert.assertTrue(ans.length()>0,"Error Occurred in FAQs Sign Up");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in checkAgentActivities(): "+ex.getMessage());
        }

    }

    public void checkMyAccount() {
        try
        {
            clickElement(faq);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(myAccount);
            Thread.sleep(AVG_WAIT_TIME);
            myAccountExpandBtn.click();
            extent.log(LogStatus.PASS,"Clicked on expand button");
            Thread.sleep(AVG_WAIT_TIME);
            String ans=getTextfromElement(jioMoneyAns);
            Assert.assertTrue(ans.length()>0,"Error Occurred in FAQs Sign Up");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in checkMyAccount(): "+ex.getMessage());
        }

    }


}

