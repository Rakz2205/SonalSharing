package webPortals.agentPortal.webPages;
/**
 * To perform User Management Related operations
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;

public class AgentUserMgmtPage extends BaseClass {

    public AgentUserMgmtPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//a[@id='pt1:setIconId']")
    public WebElement settingIcon;

    @FindBy(xpath = "//a[@id='pt1:pt_gl2']")
    public WebElement agentUserMgmt;

   // @FindBy(xpath = "//select[@id='pt1:r21:1:sor1::content']")
   @FindBy(xpath = " //select[@title='Select Action']")
    public WebElement selectAction;

    @FindBy(xpath = "//button[@class='defaultbtn af_commandButton p_AFTextOnly']")
    public WebElement continuebtn;

    @FindBy(xpath = "//input[contains(@id,'it2::content')]")
    public WebElement firstName;

    @FindBy(xpath = "//input[contains(@id,'it3::content')]")
    public WebElement lastName;

    @FindBy(xpath = "//input[contains(@id,'it4::content')]")
    public WebElement mobileNo;

    @FindBy(xpath = "//input[contains(@id,'id1::content')]")
    public WebElement user_dob;

    @FindBy(xpath = "//input[contains(@id,'it6::content')]")
    public WebElement emailId;

    @FindBy(xpath = "//button[contains(@id,'cb2')]")
    public WebElement createuser_cancelBtn;

    @FindBy(xpath = "//button[contains(@id,'cb9')]")
    public WebElement createuser_createBtn;

    @FindBy(xpath = "//button[contains(@id,'goButton1')]")
    public WebElement afterUserCreation_Okbtn;

    @FindBy(xpath = "//span[@class='tc ttext mtb10']")
    public WebElement successfuluserCreationmsg;
    //The user creation is successful

    @FindBy(xpath = "//span[@class='tc']")
    public WebElement deleteUserConfirmationmsg;
    //Are you sure you want to  delete

    @FindBy(xpath = "//button[@class='smbtn af_commandButton p_AFTextOnly']")
    public WebElement allActionuserConfirmBtn;

    @FindBy(xpath = "//button[@class='smbtn af_commandButton p_AFTextOnly']")
    public WebElement allActionuser_okBtn;

    @FindBy(xpath = "//input[@class='af_inputText_content']")
    public WebElement searchusername;

    @FindBy(xpath = "//button[@class='defaultbtn af_commandButton p_AFTextOnly']")
    public WebElement actionBtn;

    @FindBy(xpath = "//ul[@id='pt1:r21:2:it1::_afrautosuggestpopup']/li[@class='AFAutoSuggestItem']")
    public WebElement autoSuggestUserName;

    @FindBy(xpath = "//a[@id='pt1:pt_cl98']")
    public WebElement tp;

    @FindBy(xpath = "//span[@class='ttext']")
    public WebElement successfulMsg;

    public void addUser(String fname, String lname,String mobile,String dob,String email){

        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(settingIcon);
            extent.log(LogStatus.INFO,"Clicked on setting Icon");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentUserMgmt);
            Thread.sleep(AVG_WAIT_TIME);
            Select drpAction = new Select(selectAction);
            drpAction.selectByVisibleText("Create New User");
            extent.log(LogStatus.INFO,"Create new User Option Selected");
            Thread.sleep(AVG_WAIT_TIME);
            //continuebtn.click();
            clickElement(continuebtn);
            Thread.sleep(AVG_WAIT_TIME);
            firstName.sendKeys(fname);
            extent.log(LogStatus.INFO,"Entered Firstname in Firstname field");
            Thread.sleep(MIN_WAIT_TIME);
            lastName.sendKeys(lname);
            extent.log(LogStatus.INFO,"Entered Lastname in Lastname field");
            Thread.sleep(MIN_WAIT_TIME);
            mobileNo.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile number in mobile number field");
            Thread.sleep(MIN_WAIT_TIME);
            user_dob.sendKeys(dob);
            extent.log(LogStatus.INFO,"Entered dob in dob field");
            Thread.sleep(MIN_WAIT_TIME);
            emailId.sendKeys(email);
            extent.log(LogStatus.INFO,"Entered email in email field");
            Thread.sleep(MIN_WAIT_TIME);
            // createuser_createBtn.click();
            clickElement(createuser_createBtn);
            Thread.sleep(5000);
            Actualtext=getTextfromElement(successfulMsg);
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            // afterUserCreation_Okbtn.click();
            clickElement(afterUserCreation_Okbtn);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in addUser(String fname, String lname,String mobile,String dob,String email): "+ex.getMessage());
        }

    }

    public void suspendUser(String mobile){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(settingIcon);
            extent.log(LogStatus.INFO,"Clicked on setting Icon");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentUserMgmt);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(selectAction);
            Thread.sleep(AVG_WAIT_TIME);
            Select drpAction = new Select(selectAction);
            drpAction.selectByVisibleText("Suspend User");
            extent.log(LogStatus.INFO,"Suspend User Option Selected");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(tp);
            Thread.sleep(5000);
            //continuebtn.click();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", continuebtn);
            clickOnElement(driver,continuebtn);
            extent.log(LogStatus.INFO,"Clicked on continue Button");
       /* Actions actions=new Actions(driver);
        actions.doubleClick(continuebtn).build().perform();*/
            Thread.sleep(5000);
            searchusername.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile number in search box");
            Thread.sleep(5000);
            Actions action = new Actions(driver);
            action.sendKeys(Keys.DOWN).build().perform();
            // searchusername.sendKeys(Keys.DOWN);
            Thread.sleep(8000);
            //searchusername.sendKeys(ENTER);
            Actions actionEnter = new Actions(driver);
            actionEnter.sendKeys(Keys.ENTER).build().perform();
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(actionBtn);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(allActionuserConfirmBtn);
            Thread.sleep(5000);
            Actualtext=getTextfromElement(successfulMsg);
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", allActionuser_okBtn);
            clickOnElement(driver,allActionuser_okBtn);
            extent.log(LogStatus.INFO,"Clicked on OK Button");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in suspendUser(String mobile): "+ex.getMessage());
        }

    }

    public void resumeUser(String mobile){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(settingIcon);
            extent.log(LogStatus.INFO,"Clicked on setting Icon");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentUserMgmt);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(selectAction);
            clickElement(selectAction);
            Thread.sleep(AVG_WAIT_TIME);
            Select drpAction = new Select(selectAction);
            drpAction.selectByVisibleText("Resume User");
            extent.log(LogStatus.INFO,"Resume User Option Selected");
            Thread.sleep(AVG_WAIT_TIME);
            //  tp.click();
            clickElement(tp);
            Thread.sleep(5000);
            //continuebtn.click();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", continuebtn);
            clickOnElement(driver,continuebtn);
            extent.log(LogStatus.INFO,"Clicked on continue button");
       /* Actions actions=new Actions(driver);
        actions.doubleClick(continuebtn).build().perform();*/
            Thread.sleep(5000);
            searchusername.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile number in search box");
            Thread.sleep(AVG_WAIT_TIME);
            //  searchusername.sendKeys(Keys.DOWN);
            Actions action = new Actions(driver);
            action.sendKeys(Keys.DOWN).build().perform();
            Thread.sleep(8000);
            // searchusername.sendKeys(ENTER);
            Actions actionEnter = new Actions(driver);
            actionEnter.sendKeys(Keys.ENTER).build().perform();
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(actionBtn);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(allActionuserConfirmBtn);
            Thread.sleep(5000);
            Actualtext=successfulMsg.getText();
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", allActionuser_okBtn);
            clickOnElement(driver,allActionuser_okBtn);
            extent.log(LogStatus.INFO,"Clicked on ok button");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in resumeUser(String mobile): "+ex.getMessage());
        }

    }

    public void deleteUser(String mobile){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            settingIcon.click();
            extent.log(LogStatus.INFO,"Clicked on setting Icon");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentUserMgmt);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(selectAction);
            Thread.sleep(AVG_WAIT_TIME);
            Select drpAction = new Select(selectAction);
            drpAction.selectByVisibleText("Delete User");
            extent.log(LogStatus.INFO,"Delete User Option Selected");
            Thread.sleep(AVG_WAIT_TIME);
            // tp.click();
            clickElement(tp);
            Thread.sleep(5000);
            //continuebtn.click();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", continuebtn);
            clickOnElement(driver,continuebtn);
            extent.log(LogStatus.INFO,"Clicked on continue button");
      /*  Actions actions=new Actions(driver);
        actions.doubleClick(continuebtn).build().perform();*/
            Thread.sleep(5000);
            searchusername.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile number in search box");
            Thread.sleep(AVG_WAIT_TIME);
            // searchusername.sendKeys(Keys.DOWN);
            Actions action = new Actions(driver);
            action.sendKeys(Keys.DOWN).build().perform();
            Thread.sleep(8000);
            //  searchusername.sendKeys(ENTER);
            Actions actionEnter = new Actions(driver);
            actionEnter.sendKeys(Keys.ENTER).build().perform();
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(actionBtn);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(allActionuserConfirmBtn);
            Thread.sleep(5000);
            Actualtext=successfulMsg.getText();
            softAssert.assertEquals(Actualtext,"Successful");
            softAssert.assertAll();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", allActionuser_okBtn);
            clickOnElement(driver,allActionuser_okBtn);
            extent.log(LogStatus.INFO,"Clicked on ok button");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in Delete User Functionality: "+ex.getMessage());
        }

    }
}
