package webPortals.agentPortal.webPages;
/**
 * To perform Load Own trading balance
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;

public class LoadOwnTradingBalPage extends BaseClass {
    public LoadOwnTradingBalPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[contains(@id,':sor1:_1')]")
    public WebElement netbankingRadioBtn;

    @FindBy(xpath = "//input[contains(@id,':it1::content')]")
    public WebElement amount;

    @FindBy(xpath = "//select[contains(@id,'soc24::content')]")
    public WebElement selectBank;
    //Axis Bank Limited

    @FindBy(xpath = "//button[contains(@id,'cb5')]")
    public WebElement rechargeBtn;

    @FindBy(xpath = "//button[contains(@id,'cb3')]")
    public WebElement confirmBtn;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    @FindBy(xpath = "//*[contains(@id,'sor1:_0')]")
    public WebElement debitCardRadioBtn;

    @FindBy(xpath="//*[contains(@id,'it2::content')]")
    public WebElement cardHolderName;

    @FindBy(xpath="//*[contains(@id,'it3::content')]")
    public WebElement cardNumber;

    @FindBy(xpath="//select[contains(@id,'soc1::content')]")
    public WebElement selectMonth;

    @FindBy(xpath="//select[contains(@id,'soc2::content')]")
    public WebElement selectYear;

    @FindBy(xpath="//*[contains(@id,'it5::content')]")
    public WebElement cvv;

    @FindBy(xpath="//button[contains(@id,'cb1')]")
    public WebElement loadNowButon;

    @FindBy(xpath="//*[@type='password']")
    public WebElement otpField;

    @FindBy(xpath="//*[@class='btn-submit']")
    public WebElement submitButton;

    @FindBy(xpath="//*[text()='Ok']")
    public WebElement okButton;

    public void loadOwnTradingBalance(String bal, String bankName){
        try
        {
            waitForClickable(netbankingRadioBtn,10);
            clickElement(netbankingRadioBtn);
            Thread.sleep(AVG_WAIT_TIME);
            amount.sendKeys(bal);
            Thread.sleep(AVG_WAIT_TIME);
            Select selCat=new Select(selectBank);
            selCat.selectByVisibleText(bankName);
            Thread.sleep(4000);
            clickElement(rechargeBtn);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(confirmBtn);
            Thread.sleep(7000);
            Actualtext =driver.getCurrentUrl();
            softAssert.assertEquals(Actualtext,"https://retail.axisbank.co.in/wps/portal/rBanking/AxisSMRetailLogin/axissmretailpage?AuthenticationFG.MENU_ID=CIMSHP&AuthenticationFG.CALL_MODE=2&CATEGORY_ID=IRRIL");
            softAssert.assertAll();
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in loadOwnTradingBalance(String bal, String bankName): "+ex.getMessage());
        }

    }

    public void loadOwnTradingBalanceforDebit(String amt)
    {
        try
        {
            clearNotification();
            String currentURL=driver.getCurrentUrl();
            LogManager.getLogger(LoadOwnTradingBalPage.class).info("Current URL: "+currentURL);
            waitForClickable(debitCardRadioBtn,30);
            clickElement(debitCardRadioBtn);
            waitForClickable(amount,30);
            amount.sendKeys(amt);

            waitForClickable(cardNumber,30);
            cardNumber.sendKeys(agentportalPro.getProperty("DebitCardNumber"));

            waitForClickable(cardHolderName,30);
            cardHolderName.sendKeys(agentportalPro.getProperty("DebitCardHolderName"));

            waitForClickable(selectMonth,30);
            Select selectMon = new Select(selectMonth);
            selectMon.selectByVisibleText(agentportalPro.getProperty("DebitExpiryMonth"));

            Select selectYr = new Select(selectYear);
            selectYr.selectByVisibleText(agentportalPro.getProperty("DebitExpiryYear"));

            waitForClickable(cvv,30);
            cvv.sendKeys(agentportalPro.getProperty("DebitCVV"));

            clickElement(amount);

            waitForClickable(loadNowButon,30);
            clickElement(loadNowButon);

            waitForClickable(confirmBtn,30);
            clickElement(confirmBtn);
            String otp = fetchOTP();

            waitFor(otpField,30);
            otpField.sendKeys(otp);

            waitFor(submitButton,30);
            clickElement(submitButton);

            Assert.assertFalse(currentURL.equalsIgnoreCase(driver.getCurrentUrl()),"Debit page is not loaded");

            waitFor(okButton,30);
            clickElement(okButton);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in loadOwnTradingBalanceforDebit(String amt): "+ex.getMessage());
        }

    }
}
