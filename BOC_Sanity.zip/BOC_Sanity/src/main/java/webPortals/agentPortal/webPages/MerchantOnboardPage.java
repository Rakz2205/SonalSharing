package webPortals.agentPortal.webPages;
/**
 * To Onboard a new Merchant
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Properties;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;

public class MerchantOnboardPage extends BaseClass {
    public MerchantOnboardPage() {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[contains(@id,':it1::content')]")
    public WebElement BD_Fname;

    @FindBy(xpath = "//input[contains(@id,':it3::content')]")
    public WebElement BD_lname;

    @FindBy(xpath = "//input[contains(@id,':id1::content')]")
    public WebElement BD_dob;

    @FindBy(xpath = "//select[contains(@id,':soc1::content')]")
    public WebElement BD_gender;

    @FindBy(xpath = "//input[contains(@id,':inputText7::content')]")
    public WebElement BD_email;

    @FindBy(xpath = "//input[contains(@id,':it18::content')]")
    public WebElement BD_website;

    @FindBy(xpath = "//input[contains(@id,':it2::content')]")
    public WebElement BD_mobileNo;

    @FindBy(xpath = "//input[contains(@id,':it4::content')]")
    public WebElement BD_alterMobileNo;

    @FindBy(xpath = "//input[contains(@id,':inputText6::content')]")
    public WebElement BD_landline;

    @FindBy(xpath = "//button[contains(@id,':cb3')]")
    public WebElement BD_next;

    @FindBy(xpath = "//select[contains(@id,':soc1::content')]")
    public WebElement add_addressType;

    @FindBy(xpath = "//input[contains(@id,':it8::content')]")
    public WebElement add_flatName;

    @FindBy(xpath = "//input[contains(@id,':it9::content')]")
    public WebElement add_buildNo;

    @FindBy(xpath = "//input[contains(@id,':it11::content')]")
    public WebElement add_area;

    @FindBy(xpath = "//input[contains(@id,':it12::content')]")
    public WebElement add_subLocality;

    @FindBy(xpath = "//input[contains(@id,':it10::content')]")
    public WebElement add_street;

    @FindBy(xpath = "//input[contains(@id,':it15::content')]")
    public WebElement add_landmark;

    @FindBy(xpath = "//input[contains(@id,':it30::content')]")
    public WebElement add_pincode;

    @FindBy(xpath = "//input[contains(@id,':it13::content')]")
    public WebElement add_city;

    @FindBy(xpath = "//input[contains(@id,':it14::content')]")
    public WebElement add_district;

    @FindBy(xpath = "//select[contains(@id,':soc3::content')]")
    public WebElement add_state;

    @FindBy(xpath = "//input[contains(@id,':it26::content')]")
    public WebElement add_website;

    @FindBy(xpath = "//input[contains(@id,':it17::content')]")
    public WebElement add_emailAddress;

    @FindBy(xpath = "//input[contains(@id,':it27::content')]")
    public WebElement add_storeName;

    @FindBy(xpath = "//input[contains(@id,':sbc2::content')]")
    public WebElement add_sameAsAboveAddress;

    @FindBy(xpath = "//button[contains(@id,':cb2')]")
    public WebElement add_next;

    @FindBy(xpath = "//select[contains(@id,':soc9::content')]")
    public WebElement com_selBuisnessLine;

    @FindBy(xpath = "//select[contains(@id,':soc2::content')]")
    public WebElement com_YrsOfBuisness;

    @FindBy(xpath = "//*[contains(@id,':soc6::content')]")
    public WebElement com_selBuisnessDesc;

    @FindBy(xpath = "//select[contains(@id,':soc4::content')]")
    public WebElement com_dailyTransValue;

    @FindBy(xpath = "//select[contains(@id,':soc3::content')]")
    public WebElement com_NoTransPerDay;

    @FindBy(xpath = "//select[contains(@id,':soc5::content')]")
    public WebElement com_returnPolicy;

    @FindBy(xpath = "//select[contains(@id,':soc11::content')]")
    public WebElement com_MerchantDelPeriod;

    @FindBy(xpath = "//button[contains(@id,':cb4')]")
    public WebElement com_next;

    @FindBy(xpath = "//input[contains(@id,':it16::content')]")
    public WebElement od_pancard;

    @FindBy(xpath = "//input[contains(@id,':it4::content')]")
    public WebElement od_serviceTaxNo;

    @FindBy(xpath = "//input[contains(@id,':it33::content')]")
    public WebElement od_tanNo;

    @FindBy(xpath = "//input[contains(@id,':it34::content')]")
    public WebElement od_tinNo;

    @FindBy(xpath = "//input[contains(@id,':it8::content')]")
    public WebElement od_LST;

    @FindBy(xpath = "//input[contains(@id,':it9::content')]")
    public WebElement od_CST;

    @FindBy(xpath = "//select[contains(@id,':soc1::content')]")
    public WebElement od_merchant_gst_cat;
    //Unregistered

    @FindBy(xpath = "//button[contains(@id,':cb2')]")
    public WebElement od_next;

    @FindBy(xpath = "//select[contains(@id,':soc13::content')]")
    public WebElement sd_settlement_Type;
    //Gross

    @FindBy(xpath = "//select[contains(@id,':soc14::content')]")
    public WebElement sd_settlement_frq;
    //Real time (every 15 minutes)

    @FindBy(xpath = "//select[contains(@id,':soc15::content')]")
    public WebElement sd_settlement_medium;
    //Bank Account

    @FindBy(xpath = "//input[contains(@id,':sor2::content')]")
    public WebElement sd_payment_Gateway;

    @FindBy(xpath = "//input[contains(@id,':sor1::content')]")
    public WebElement sd_jioMoney_wallet;

    @FindBy(xpath = "//label[contains(text(),'I accept')]")
    public WebElement sd_acceptConditionCheckbox;

    @FindBy(xpath = "//input[contains(@id,':sbc1::content')]")
    public WebElement sd_creditcard_Checkbox;

    @FindBy(xpath = "//input[contains(@id,':sbc3::content')]")
    public WebElement sd_debitcard_Checkbox;

    @FindBy(xpath = "//input[contains(@id,':sbc4::content')]")
    public WebElement sd_netbanking_Checkbox;

    @FindBy(xpath = "//input[contains(@id,':sbc6::content')]")
    public WebElement sd_cod_Checkbox;

    @FindBy(xpath = "//input[contains(@id,':it7::content')]")
    public WebElement bd_acc_holderName;

    @FindBy(xpath = "//input[contains(@id,':it28::content')]")
    public WebElement bd_bankHAccountno;

    @FindBy(xpath = "//input[contains(@id,':inputText1::content')]")
    public WebElement bd_reenter_acc_no;

    @FindBy(xpath = "//input[contains(@id,':it41::content')]")
    public WebElement bd_ifsccode;

    @FindBy(xpath = "//input[contains(@id,':it29::content')]")
    public WebElement bd_bankName;

    @FindBy(xpath = "//input[contains(@id,':it30::content')]")
    public WebElement bd_branchname;

    @FindBy(xpath = "//select[contains(@id,':poasoc::content')]")
    public WebElement doc_poa;
    //Passport

    @FindBy(xpath = "//input[contains(@id,':inputText1::content')]")
    public WebElement doc_poaID;

    @FindBy(xpath = "//button[contains(@id,':cb4')]")
    public WebElement doc_poaAttchement;

    @FindBy(xpath = "//input[contains(@id,':if2::content')]")
    public WebElement doc_poaAttachbtn;

    @FindBy(xpath = "//button[contains(@id,':cb23')]")
    public WebElement doc_uploadDone;

    @FindBy(xpath = "//select[contains(@id,':soc3::content')]")
    public WebElement doc_pob;
    //Cert issued by Prof Bodies

    @FindBy(xpath = "//input[contains(@id,':inputText2::content')]")
    public WebElement doc_pobID;

    @FindBy(xpath = "//button[contains(@id,':cb10')]")
    public WebElement doc_pobAttchement;

    @FindBy(xpath = "//input[contains(@id,':if3::content')]")
    public WebElement doc_pobAttachbtn;

    @FindBy(xpath = "//input[contains(@id,':it4::content')]")
    public WebElement doc_cancelledCheckLeaf;

    @FindBy(xpath = "//input[contains(@id,':it6::content')]")
    public WebElement doc_remark;

    @FindBy(xpath = "//button[contains(@id,'cb16')]")
    public WebElement doc_cancelledCheckLeafAttchement;

    @FindBy(xpath = "//input[contains(@id,'if7::content')]")
    public WebElement doc_checkAttachbtn;

    @FindBy(xpath = "//select[contains(@id,':selectOneChoice1::content')]")
    public WebElement doc_poi;
    //Aadhaar card / UIDAI letter

    @FindBy(xpath = "//input[contains(@id,':inputText3::content')]")
    public WebElement doc_poiNo;

    @FindBy(xpath = "//input[contains(@id,':inputDate1::content')]")
    public WebElement doc_poiExpiryDate;

    @FindBy(xpath = "//button[contains(@id,':cb22')]")
    public WebElement doc_poiAttchement;

    @FindBy(xpath = "//input[contains(@id,':if8::content')]")
    public WebElement doc_poiAttachbtn;

    @FindBy(xpath = "//input[contains(@id,':it1::content')]")
    public WebElement doc_mafId;

    @FindBy(xpath = "//button[contains(@id,':cb15')]")
    public WebElement doc_mafIdAttachment;

    @FindBy(xpath = "//input[contains(@id,':if13::content')]")
    public WebElement doc_mafAttachbtn;

    @FindBy(xpath = "//button[contains(@id,':cb28')]")
    public WebElement doc_uploadPhotograph;

    @FindBy(xpath = "//input[contains(@id,':if15::content')]")
    public WebElement doc_uploadPhotoAttachBtn;

    @FindBy(xpath = "//button[contains(@id,':cb19')]")
    public WebElement doc_submit;

    @FindBy(xpath = "//button[contains(@id,'rcb1') and text()='CONFIRM']")
    public WebElement merchant_confirm;

    @FindBy(xpath = "//button[contains(@id,':rgb2')]")
    public WebElement merchant_confirmOK;

    @FindBy(xpath = "//select[contains(@id,':soc7::content')]")
    public WebElement doc_selectFinDoc;
    //Bank A/c Statement (for last 3 Months)

    @FindBy(xpath = "//button[contains(@id,':cb26')]")
    public WebElement doc_FinDocAttachement;

    @FindBy(xpath = "//input[contains(@id,':if10::content')]")
    public WebElement doc_FinDocAttachButton;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    @FindBy(xpath = "//table[contains(@id,'rpgl0')]/tbody/tr/td")
    public WebElement newMIDcreated;

  public void enterBasicDetails(String fname, String lname, String dob, String gender, String email, String website, String mobile, String AlterMobile, String landline)
    {
        try
        {
            BD_Fname.sendKeys(fname);
            extent.log(LogStatus.INFO,"Entered Firstname in Basic details of merchant Onbording");
            BD_lname.sendKeys(lname);
            extent.log(LogStatus.INFO,"Entered Lastname in Basic details of merchant Onbording");
            BD_dob.sendKeys(dob);
            extent.log(LogStatus.INFO,"Entered dob in Basic details of merchant Onbording");
            Select sel=new Select(BD_gender);
            sel.selectByVisibleText(gender);
            extent.log(LogStatus.INFO,"Selected gender in Basic details of merchant Onbording");
            BD_email.sendKeys(email);
            extent.log(LogStatus.INFO,"Entered email in Basic details of merchant Onbording");
            BD_website.sendKeys(website);
            extent.log(LogStatus.INFO,"Entered website in Basic details of merchant Onbording");
            BD_mobileNo.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered mobile in Basic details of merchant Onbording");
            BD_alterMobileNo.sendKeys(AlterMobile);
            extent.log(LogStatus.INFO,"Entered alternate mobile number in Basic details of merchant Onbording");
            BD_landline.sendKeys(landline);
            extent.log(LogStatus.INFO,"Entered landline in Basic details of merchant Onbording");
            clickElement(BD_next);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterBasicDetails(): "+ex.getMessage());
        }

    }

    public void enterAddressDetails(String addType,String flatname, String buildingNo, String area, String subLocality,
                                    String Street, String landmark, String pincode, String city, String district,
                                    String state, String web, String email, String storeName) {
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            waitFor(add_addressType,30);
            Select addressType=new Select(add_addressType);
            addressType.selectByVisibleText(addType);
            clickElement(add_addressType);
            addressType.selectByVisibleText(addType);
            extent.log(LogStatus.INFO,"Selected addressType in Address details of merchant Onbording");
            add_flatName.sendKeys(flatname);
            extent.log(LogStatus.INFO,"Entered flatname in Address details of merchant Onbording");
            add_buildNo.sendKeys(buildingNo);
            extent.log(LogStatus.INFO,"Entered Building Number in Address details of merchant Onbording");
            add_area.sendKeys(area);
            extent.log(LogStatus.INFO,"Entered area name in Address details of merchant Onbording");
            add_subLocality.sendKeys(subLocality);
            extent.log(LogStatus.INFO,"Entered sublocality in Address details of merchant Onbording");
            add_street.sendKeys(Street);
            extent.log(LogStatus.INFO,"Entered Street name in Address details of merchant Onbording");
            add_landmark.sendKeys(landmark);
            extent.log(LogStatus.INFO,"Entered landmark in Address details of merchant Onbording");
            add_pincode.sendKeys(pincode);
            extent.log(LogStatus.INFO,"Entered pincode in Address details of merchant Onbording");
            add_city.sendKeys(city);
            extent.log(LogStatus.INFO,"Entered city name in Address details of merchant Onbording");
            add_district.sendKeys(district);
            extent.log(LogStatus.INFO,"Entered district in Address details of merchant Onbording");
            Select selectState=new Select( add_state);
            selectState.selectByVisibleText(state);
            extent.log(LogStatus.INFO,"Selected state in Address details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            add_website.clear();
            Thread.sleep(AVG_WAIT_TIME);
            add_website.sendKeys(web);
            extent.log(LogStatus.INFO,"Entered website in Address details of merchant Onbording");
            add_emailAddress.sendKeys(email);
            extent.log(LogStatus.INFO,"Entered email in Address details of merchant Onbording");
            add_storeName.sendKeys(storeName);
            extent.log(LogStatus.INFO,"Entered storename in Address details of merchant Onbording");
            add_sameAsAboveAddress.click();
            extent.log(LogStatus.INFO,"clicked same as above in Address details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(add_next);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterAddressDetails(): "+ex.getMessage());
        }

    }

    public void enterCompanyDetails(String buisLine, String yrsOfBuisness, String buisnessDesc, String transVal,
                                    String transPerDay, String returnPolicy, String MerDelPeriod ) {
        try
        {
            Select selBuisnessLine=new Select(com_selBuisnessLine);
            selBuisnessLine.selectByVisibleText(buisLine);
            extent.log(LogStatus.INFO,"Selected buisness line in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select selyrsOfBuis=new Select(com_YrsOfBuisness);
            selyrsOfBuis.selectByVisibleText(yrsOfBuisness);
            extent.log(LogStatus.INFO,"Selected years of Buisness in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select selBuinDesc=new Select(com_selBuisnessDesc);
            selBuinDesc.selectByVisibleText(buisnessDesc);
            extent.log(LogStatus.INFO,"Selected buisness Description in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select seldailyTransVal=new Select(com_dailyTransValue);
            // seldailyTransVal.selectByVisibleText(transVal);
            seldailyTransVal.selectByIndex(2);
            extent.log(LogStatus.INFO,"Selected daily transaction value in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select seltransPerday=new Select(com_NoTransPerDay);
            seltransPerday.selectByVisibleText(transPerDay);
            extent.log(LogStatus.INFO,"Selected no of transaction per day in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select selreturnPolicy=new Select(com_returnPolicy);
            selreturnPolicy.selectByVisibleText(returnPolicy);
            extent.log(LogStatus.INFO,"Selected return policy value in Company details of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Select selMerDelPeriod=new Select(com_MerchantDelPeriod);
            selMerDelPeriod.selectByVisibleText(MerDelPeriod);
            extent.log(LogStatus.INFO,"Selected merchant delivery period in Company details of merchant Onbording");
            try {
                Thread.sleep(AVG_WAIT_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            clickElement(com_next);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterCompanyDetails(): "+ex.getMessage());
        }

    }

    public void enterFinancialInfo(String pan, String taxNo, String tan, String tin, String lst, String cst,String gst_cat, String SettlementType,
    String settlementFrq, String settlementMedium,String accName, String accNo, String ifsc, String bankname, String Branchname) {
        try
        {
            od_pancard.sendKeys(pan);
            extent.log(LogStatus.INFO,"Entered Pancard details in Financial details of merchant Onbording");
            od_serviceTaxNo.sendKeys(taxNo);
            extent.log(LogStatus.INFO,"Entered tax number in Financial details of merchant Onbording");
            od_tanNo.sendKeys(tan);
            extent.log(LogStatus.INFO,"Entered TAN in Financial details of merchant Onbording");
            od_tinNo.sendKeys(tin);
            extent.log(LogStatus.INFO,"Entered TIN in Financial details of merchant Onbording");
            od_LST.sendKeys(lst);
            extent.log(LogStatus.INFO,"Entered LST in Financial details of merchant Onbording");
            od_CST.sendKeys(cst);
            extent.log(LogStatus.INFO,"Entered CST in Financial details of merchant Onbording");
            Select selMerchantGstCat=new Select(od_merchant_gst_cat);
            selMerchantGstCat.selectByVisibleText(gst_cat);
            extent.log(LogStatus.INFO,"Selected GST category in Financial details of merchant Onbording");
            Select selSettlementType=new Select(sd_settlement_Type);
            selSettlementType.selectByVisibleText(SettlementType);
            extent.log(LogStatus.INFO,"Selected settlement type in Financial details of merchant Onbording");
            Select selSettlementFreq=new Select(sd_settlement_frq);
            selSettlementFreq.selectByVisibleText(settlementFrq);
            extent.log(LogStatus.INFO,"Selected settlement frequency in Financial details of merchant Onbording");
            Select selSettlementMedium=new Select(sd_settlement_medium);
            selSettlementMedium.selectByVisibleText(settlementMedium);
            extent.log(LogStatus.INFO,"Selected settlement medium in Financial details of merchant Onbording");
            // sd_payment_Gateway.click();
            //  sd_jioMoney_wallet.click();
            Thread.sleep(AVG_WAIT_TIME);
            bd_acc_holderName.sendKeys(accName);
            extent.log(LogStatus.INFO,"Entered Account holder name in Financial details of merchant Onbording");
            bd_bankHAccountno.sendKeys(accNo);
            extent.log(LogStatus.INFO,"Entered bank account number in Financial details of merchant Onbording");
            bd_reenter_acc_no.sendKeys(accNo);
            extent.log(LogStatus.INFO,"Entered bank account number in Financial details of merchant Onbording");
            bd_ifsccode.sendKeys(ifsc);
            extent.log(LogStatus.INFO,"Entered IFSC in Financial details of merchant Onbording");
            clickElement(bd_reenter_acc_no);
            Thread.sleep(5000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", sd_acceptConditionCheckbox);
            clickOnElement(driver,sd_acceptConditionCheckbox);
            extent.log(LogStatus.INFO,"clicked on accept condition checkbox");
            Thread.sleep(AVG_WAIT_TIME);
            od_next.click();
            clickElement(od_next);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in enterFinancialInfo(): "+ex.getMessage());
        }

    }


    public void uploadDocuments(String addProof, String addProofID,  String PathOfPOA,
                                String busiProof, String busiProofID,  String PathOfPOB,
                                String checkLeaf,String checkRemark, String checkpath,
                                String identityproof,String identityNo, String identityExpDate,
                                String identityProofPath, String mafId, String mafPath, String photoPath,
                                String FinDoc, String FinDocPath) {
        try
        {
            String result;
            Select selPOA=new Select(doc_poa);
            selPOA.selectByVisibleText(addProof);
            extent.log(LogStatus.INFO,"Selected Address Proof in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            doc_poaID.sendKeys(addProofID);
            extent.log(LogStatus.INFO,"Entered Address Proof ID in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            clickElement(doc_poaAttchement);
            extent.log(LogStatus.INFO,"Clicked on proof of address attachement in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            doc_poaAttachbtn.sendKeys(System.getProperty("user.dir")+PathOfPOA);
            extent.log(LogStatus.INFO,"uploaded Proof of address document in document uploading of merchant Onbording");
            Thread.sleep(5000);
            clickElement(doc_uploadDone);
            Thread.sleep(AVG_WAIT_TIME);
            Select selPOB=new Select(doc_pob);
            selPOB.selectByVisibleText(busiProof);
            extent.log(LogStatus.INFO,"Selected Business Proof in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            doc_pobID.sendKeys(busiProofID);
            extent.log(LogStatus.INFO,"Entered Business Proof ID in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            clickElement(doc_pobAttchement);
            extent.log(LogStatus.INFO,"Clicked on proof of Business attachement in document uploading of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            doc_pobAttachbtn.sendKeys(System.getProperty("user.dir")+PathOfPOB);
            extent.log(LogStatus.INFO,"uploaded Proof of Business document in document uploading of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(doc_uploadDone);
            Thread.sleep(5000);
            doc_cancelledCheckLeaf.sendKeys(checkLeaf);
            extent.log(LogStatus.INFO,"Entered cancel check in document uploading of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            // doc_remark.sendKeys(checkRemark);
            JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
            myExecutor.executeScript("arguments[0].value='"+checkRemark+"';", doc_remark);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(doc_cancelledCheckLeafAttchement);
            extent.log(LogStatus.INFO,"Clicked on cancel check attachment in document uploading of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            waitFor(doc_checkAttachbtn,20);
            doc_checkAttachbtn.sendKeys(System.getProperty("user.dir")+checkpath);
            extent.log(LogStatus.INFO,"uploaded cancel check in document uploading of merchant Onbording");
            Thread.sleep(5000);
            clickElement(doc_uploadDone);
            Thread.sleep(AVG_WAIT_TIME);
            Select selPoI=new Select(doc_poi);
            Thread.sleep(MIN_WAIT_TIME);
            selPoI.selectByVisibleText(identityproof);
            extent.log(LogStatus.INFO,"Selected Identity Proof in document uploading of merchant Onbording");
            Thread.sleep(MIN_WAIT_TIME);
            doc_poiExpiryDate.sendKeys(identityExpDate);
            extent.log(LogStatus.INFO,"Entered Identity expiry date in document uploading of merchant Onbording");
            Thread.sleep(AVG_WAIT_TIME);
            Thread.sleep(AVG_WAIT_TIME);
            // doc_poiNo.sendKeys(identityNo);
            JavascriptExecutor myExecutor1 = ((JavascriptExecutor) driver);
            myExecutor1.executeScript("arguments[0].value='"+identityNo+"';", doc_poiNo);
            Thread.sleep(AVG_WAIT_TIME);
            doc_poiAttchement.click();
            extent.log(LogStatus.INFO,"Clicked on proof of identity attachment in document uploading of merchant Onboarding");
            Thread.sleep(AVG_WAIT_TIME);
            doc_poiAttachbtn.sendKeys(System.getProperty("user.dir")+identityProofPath);
            extent.log(LogStatus.INFO,"uploaded Identity Proof in document uploading of merchant Onboarding");
            Thread.sleep(5000);
            clickElement(doc_uploadDone);
            Thread.sleep(AVG_WAIT_TIME);
            doc_mafId.sendKeys(mafId);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(doc_mafIdAttachment);
            extent.log(LogStatus.INFO,"Clicked on attachment in document uploading of merchant Onboarding");
            Thread.sleep(AVG_WAIT_TIME);
            doc_mafAttachbtn.sendKeys(System.getProperty("user.dir")+mafPath);
            extent.log(LogStatus.INFO,"uploaded Identity Proof in document uploading of merchant Onboarding");
            Thread.sleep(5000);
            clickElement(doc_uploadDone);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(doc_uploadPhotograph);
            extent.log(LogStatus.INFO,"Clicked photo in document uploading of merchant Onboarding");
            Thread.sleep(MIN_WAIT_TIME);
            doc_uploadPhotoAttachBtn.sendKeys(System.getProperty("user.dir")+photoPath);
            extent.log(LogStatus.INFO,"uploaded photo in document uploading of merchant Onboarding");
            Thread.sleep(5000);
            clickElement(doc_uploadDone);
            Thread.sleep(AVG_WAIT_TIME);

            /*Select selFinDoc = new Select(doc_selectFinDoc);
            selFinDoc.selectByVisibleText(FinDoc);
            doc_FinDocAttachement.click();
            doc_FinDocAttachButton.sendKeys(FinDocPath);
            Thread.sleep(5000);
            doc_uploadDone.click();*/
            clickElement(doc_submit);
            Thread.sleep(5000);
            clickElement(merchant_confirm);


            if(isElementDisplayed(newMIDcreated))
            {
                String MID=newMIDcreated.getAttribute("innerHTML").replaceAll("[^0-9]","").trim();
                Thread.sleep(5000);
                clickElement(merchant_confirmOK);
                fout = new FileOutputStream(projectPath+"\\inputFiles\\merchantMID.properties");
                writeProperties = new Properties();
                writeProperties.setProperty("MID",MID);
                writeProperties.store(fout,"New MID created");
                result= MID;
            }
            else
            {
                result= "";
            }
            Assert.assertTrue(result.length()>0,"Merchant Onboarding Failed ");
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in uploadDocuments(): "+ex.getMessage());
        }

    }

}

