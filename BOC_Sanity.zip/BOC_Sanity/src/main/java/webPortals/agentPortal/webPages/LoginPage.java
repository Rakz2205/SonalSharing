package webPortals.agentPortal.webPages;
/**
 * To Login into the application
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import java.io.FileNotFoundException;

import static utilityLibrary.testData.Constants.*;

public class LoginPage extends BaseClass {
    WebDriverWait wait = new WebDriverWait(driver, 25);

    public LoginPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[@id='r1:0:it1::content']")
    public WebElement username;

    @FindBy(xpath = "//input[@id='r1:0:it2::content']")
    public WebElement password;

    @FindBy(xpath = "//button[@id='r1:0:cb1']")
    public WebElement loginBtn;

    @FindBy(xpath = "//a[@id='pt1:setIconId']")
    public WebElement settingBtn;

    @FindBy(xpath = "//a[@id='pt1:pt-cb1']")
    public WebElement logout;

    @FindBy(xpath = "//input[@id='pt1:it5::content']")
    public WebElement otpField;

    @FindBy(xpath = "//button[@id='pt1:otp_cl7']")
    public WebElement submitBtn;

    @FindBy(xpath = "//a[@id='r1:0:goLink2']")
    public WebElement forgetPassword;

    @FindBy(xpath = "//input[@name='username']")
    public WebElement usernameAfterForgetPassword;

    @FindBy(xpath = "//input[@name='username']")
    public WebElement continueBtn;

    @FindBy(xpath = "//input[@type='submit' and @value='Send OTP']")
    public WebElement sendOTP;

    @FindBy(xpath="//*[@id='pt1:pt-pgl1']//span")
    public WebElement agentUserName;

    public void login(String un,String pwd){
        try
        {
            boolean result;
            Thread.sleep(AVG_WAIT_TIME);
            username.sendKeys(un);
            extent.log(LogStatus.INFO,"Entered Data In Username Field");
            Thread.sleep(AVG_WAIT_TIME);
            password.sendKeys(pwd);
            extent.log(LogStatus.INFO,"Entered Data In Password Field");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(loginBtn);
            Thread.sleep(AVG_WAIT_TIME);
            Thread.sleep(5000);
            String otp=fetchOTP();
            Thread.sleep(AVG_WAIT_TIME);
            otpField.sendKeys(otp);
            extent.log(LogStatus.INFO,"Entered OTP In OTP Field");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(submitBtn);
            Thread.sleep(AVG_WAIT_TIME);
            result = getTextfromElement(agentUserName).equalsIgnoreCase(agentportalPro.getProperty("agentUserName"));
            Assert.assertTrue(result,"Login Successful");
            LogManager.getLogger(LoginPage.class).info("Login Successful");

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in login(String un,String pwd): "+ex.getMessage());
        }

    }

    public void forgetPassword(String un)
    {
        try
        {
            clickElement(forgetPassword);
            extent.log(LogStatus.INFO,"Clicked on forget password link");
            wait.until(ExpectedConditions.visibilityOf(usernameAfterForgetPassword));
            usernameAfterForgetPassword.sendKeys(un);
            clickElement(continueBtn);
            clickElement(sendOTP);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("forgetPassword(String un): "+ex.getMessage());
        }

    }


}
