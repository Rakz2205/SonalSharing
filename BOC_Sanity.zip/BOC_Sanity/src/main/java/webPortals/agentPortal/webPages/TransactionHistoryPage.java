package webPortals.agentPortal.webPages;
/**
 * To verify the Transaction History data
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import utilityLibrary.base.BaseClass;

import java.io.File;
import java.io.FileNotFoundException;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;
import static utilityLibrary.utils.CommonUtils.isAlertPresent;


public class TransactionHistoryPage extends BaseClass {

    public TransactionHistoryPage() {
        PageFactory.initElements(driver, this);
        LogManager.getLogger(TransactionHistoryPage.class).info(driver);
    }

    @FindBy(xpath = "//select[contains(@id,'soc5::content')]")
    public WebElement selDateRange;

    @FindBy(xpath = "//input[contains(@id,'id1::content')]")
    public WebElement fromDate;

    @FindBy(xpath = "//input[contains(@id,'id2::content')]")
    public WebElement toDate;

    @FindBy(xpath = "//input[contains(@id,'sor1::content')]")
    public WebElement transactionType;

    @FindBy(xpath = "//input[contains(@id,'soc4::content')]")
    public WebElement statusTH;

    @FindBy(xpath = "//button[contains(@id,'cb7')]")
    public WebElement applyBtn;

    @FindBy(xpath = "//a[contains(@id,'cl5')]")
    public WebElement viewDetailsLink;

    @FindBy(xpath = "//button[contains(@id,'ctb1')]")
    public WebElement downloadLink;

    @FindBy(xpath = "//button[contains(@id,'cb1')]")
    public WebElement download;


    @FindBy(xpath = "//input[contains(@id,'sor3:_1')]")
    public WebElement excelRadioBtn;

    @FindBy(xpath = "//a[contains(@id,'pt-gl1')]")
    public WebElement home;

    @FindBy(xpath = "//img[contains(@id,'pt1:pt-g178::icon')]")
    public WebElement jioMoneyIcon;

    @FindBy(xpath = "//span[text()='No results. Try using a different filter.']")
    WebElement noDataPresent;

    @FindBy(xpath = "//div[@class='af_message_detail']")
    public WebElement inValidDateRangeMessage;
    //Date range cannot be greater than 31 days.


    public void downloadTransactionHistory(String dateRange) {
        try
        {
            Select selFinDoc=new Select(selDateRange);
            selFinDoc.selectByVisibleText(dateRange);
            extent.log(LogStatus.INFO,"Selected date Range");
            //applyBtn.click();
            Thread.sleep(8000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", applyBtn);
            clickOnElement(driver,applyBtn);
            extent.log(LogStatus.INFO,"Clicked on Apply button");
            Thread.sleep(10000);
            clickElement(viewDetailsLink);
            Thread.sleep(5000);
            //downloadLink.click();
            LogManager.getLogger(TransactionHistoryPage.class).info("Waiting for No data present message");
            //download.click();
            waitFor(noDataPresent,30);
            if(isElementEnabled(downloadLink))
            {
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", downloadLink);
                clickOnElement(driver,downloadLink);
                extent.log(LogStatus.INFO,"Clicked on download link");
                Thread.sleep(AVG_WAIT_TIME);
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", download);
                clickOnElement(driver,download);
                extent.log(LogStatus.INFO,"Clicked on download ");
                Thread.sleep(5000);
                //downloadLink.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", downloadLink);
                clickOnElement(driver,downloadLink);
                extent.log(LogStatus.INFO,"Clicked on download link");
                Thread.sleep(AVG_WAIT_TIME);
                excelRadioBtn.click();
                extent.log(LogStatus.INFO,"Clicked on excel radio button ");
                Thread.sleep(AVG_WAIT_TIME);
                // download.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", download);
                clickOnElement(driver,download);
                extent.log(LogStatus.INFO,"Clicked on download ");
                if(isAlertPresent())
                {
                    Alert alert= driver.switchTo().alert();
                    alert.accept();
                    extent.log(LogStatus.INFO,"Clicked on OK Button on alert ");

                }

                clickElement(home);
                extent.log(LogStatus.INFO,"Clicked on home button ");
                String projectPath=System.getProperty("user.dir");

                File pdf1= new File(projectPath+"\\Download\\Report.pdf");
                File pdf2= new File(projectPath+"\\Download\\Report(1).pdf");
       /* if(pdf1.exists() || pdf2.exists())
        {
            boolean pdfexits;
        }*/
                boolean pdfexits=(pdf1.exists() || pdf2.exists());
                if (pdfexits) Actualtext = String.valueOf(true);
                else {
                    Actualtext = String.valueOf(true);
                }
                softAssert.assertEquals(Actualtext,"true");
                softAssert.assertAll();
                File excel1= new File(projectPath+"\\Download\\TransactionSummary.xls");
                File excel2= new File(projectPath+"\\Download\\TransactionSummary(1).xls");
                boolean excelexits=(excel1.exists() || excel2.exists());
                if (excelexits) Actualtext = String.valueOf(true);
                else {
                    Actualtext = String.valueOf(true);
                }
                softAssert.assertEquals(Actualtext,"true");
                softAssert.assertAll();
                Thread.sleep(5000);

                //Thread.sleep(AVG_WAIT_TIME);
            }
            else
            {
                LogManager.getLogger(TransactionHistoryPage.class).info("Download is not enabled");
            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in downloadTransactionHistory(String dateRange): "+ex.getMessage());
        }

    }

    public void downloadTransactionHistoryForCustom(String startDate, String endDate) {
        try
        {
            Select selFinDoc=new Select(selDateRange);
            selFinDoc.selectByVisibleText("Custom");
            extent.log(LogStatus.INFO,"Selected Custom option");
            Thread.sleep(AVG_WAIT_TIME);
            fromDate.sendKeys(startDate);
            extent.log(LogStatus.INFO,"Entered Start date");
            Thread.sleep(AVG_WAIT_TIME);
            toDate.sendKeys(endDate);
            extent.log(LogStatus.INFO,"Entered end date");
            Thread.sleep(AVG_WAIT_TIME);
            fromDate.click();
            extent.log(LogStatus.INFO,"clicked on from date");
            Thread.sleep(8000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", applyBtn);
            clickOnElement(driver,applyBtn);
            extent.log(LogStatus.INFO,"clicked on Apply Button");
            //applyBtn.click();
            Thread.sleep(10000);
            clickElement(viewDetailsLink);
            Thread.sleep(5000);
            // downloadLink.click();

            // download.click();
            LogManager.getLogger(TransactionHistoryPage.class).info("Waiting for No data present message");
            //download.click();
            waitFor(noDataPresent,30);
            if(isElementEnabled(downloadLink))
            {
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", downloadLink);
                clickOnElement(driver,downloadLink);
                extent.log(LogStatus.INFO,"clicked on download Link");
                Thread.sleep(5000);
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", download);
                clickOnElement(driver,download);
                extent.log(LogStatus.INFO,"clicked on download");
                Thread.sleep(5000);
                // downloadLink.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", downloadLink);
                clickOnElement(driver,downloadLink);
                extent.log(LogStatus.INFO,"clicked on download Link");
                Thread.sleep(AVG_WAIT_TIME);
                clickElement(excelRadioBtn);
                extent.log(LogStatus.INFO,"clicked on excel radio button");
                Thread.sleep(AVG_WAIT_TIME);
                // download.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", download);
                clickOnElement(driver,download);
                extent.log(LogStatus.INFO,"clicked on download");
                Thread.sleep(MAX_WAIT_TIME);
                try {
                    if(isAlertPresent())
                    {
                        Alert alert= driver.switchTo().alert();
                        alert.accept();
                        extent.log(LogStatus.INFO,"clicked on OK button on Alert");
                    }
                }
                catch(Exception ex)
                {
                    LogManager.getLogger(TransactionHistoryPage.class).info("Alert is not present");
                }
                home.click();
                extent.log(LogStatus.INFO,"clicked on home button");
                Thread.sleep(AVG_WAIT_TIME);
                String projectPath=System.getProperty("user.dir");
                File pdf1= new File(projectPath+"\\Download\\Report.pdf");
                File pdf2= new File(projectPath+"\\Download\\Report(1).pdf");
       /* if(pdf1.exists() || pdf2.exists())
        {
            boolean pdfexits;
        }*/
                boolean pdfexits=(pdf1.exists() || pdf2.exists());
                if (pdfexits) Actualtext = String.valueOf(true);
                else {
                    Actualtext = String.valueOf(true);
                }
                softAssert.assertEquals(Actualtext,"true");
                softAssert.assertAll();
                File excel1= new File(projectPath+"\\Download\\TransactionSummary.xls");
                File excel2= new File(projectPath+"\\Download\\TransactionSummary(1).xls");
                boolean excelexits=(excel1.exists() || excel2.exists());
                if (excelexits) Actualtext = String.valueOf(true);
                else {
                    Actualtext = String.valueOf(true);
                }
                softAssert.assertEquals(Actualtext,"true");
                softAssert.assertAll();

            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in downloadTransactionHistoryForCustom(String startDate, String endDate): "+ex.getMessage());
        }

    }

    public String inValidDateRange(String startDate, String endDate) {
        try
        {
            Select selFinDoc=new Select(selDateRange);
            selFinDoc.selectByVisibleText("Custom");
            extent.log(LogStatus.INFO,"Selected Custom option");
            Thread.sleep(AVG_WAIT_TIME);
            fromDate.sendKeys(startDate);
            extent.log(LogStatus.INFO,"Entered Start date");
            Thread.sleep(AVG_WAIT_TIME);
            toDate.sendKeys(endDate);
            extent.log(LogStatus.INFO,"Entered end date");
            Thread.sleep(AVG_WAIT_TIME);
            fromDate.click();
            extent.log(LogStatus.INFO,"clicked on from date");
            Thread.sleep(8000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", applyBtn);
            clickOnElement(driver,applyBtn);
            extent.log(LogStatus.INFO,"clicked on Apply Button");
            //applyBtn.click();
            Thread.sleep(MAX_WAIT_TIME);
            Thread.sleep(MAX_WAIT_TIME);
            if(isElementDisplayed(inValidDateRangeMessage))
            {
                return getTextfromElement(inValidDateRangeMessage);
            }
            else
            {
                return "";
            }
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in inValidDateRange(String startDate, String endDate): "+ex.getMessage());
        }

    }




}