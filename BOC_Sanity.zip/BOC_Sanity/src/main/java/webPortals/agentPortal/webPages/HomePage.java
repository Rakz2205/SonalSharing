package webPortals.agentPortal.webPages;
/**
 * To perform operations on elements present on Home Page
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import utilityLibrary.base.BaseClass;
import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;

public class HomePage extends BaseClass {
    public HomePage() {
            PageFactory.initElements(driver,this);
    }

    @FindBy(id = "pt1:pt-gl3")
    public WebElement onboarding;

    @FindBy(xpath = "//div[@id='pt1:panelGroupLayout15']")
    public WebElement jioMoneyPartner;

    @FindBy(xpath = "//select[@id='pt1:r12:1:soc1::content']")
    public WebElement selectBusinessOwnership;
    //  Individual

    @FindBy(xpath = "//input[@id='pt1:r12:1:sbc2::content']")
    public WebElement selectJioMoneyMerchant;

    @FindBy(xpath = "//a[@id='pt1:pt-gl2']")
    public WebElement agentServices;

    @FindBy(xpath = "//a[@id='pt1:cl1']")
    public WebElement loadOwnTradingbal;

    @FindBy(xpath = "//a[@id='pt1:cl13']")
    public WebElement hierarchyAndComm;

    @FindBy(xpath = "//button[@id='pt1:r12:1:cb1']")
    public WebElement jioMoneyPartnerContinueBtn;

    @FindBy(xpath = "//select[@id='pt1:r12:1:soc3::content']")
    public WebElement selectBusinessType;
    //Online

    @FindBy(xpath = "//button[@id='pt1:r12:1:cb2']")
    public WebElement BusinessChannelContinueBtn;

    @FindBy(xpath = "//a[@id='pt1:pt_cl1011']")
    public WebElement faqSupport;

    @FindBy(xpath = "//a[@id='pt1:cl37']")
    public WebElement reports;

    @FindBy(xpath = "//a[@id='pt1:cl35']")
    public WebElement transactionHistory;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    public void selectJioMoneyPartner(){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", onboarding);
            clickOnElement(driver,onboarding);
            extent.log(LogStatus.INFO,"Merchant onboard In Agent Portal");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(jioMoneyPartner);
            extent.log(LogStatus.INFO,"Clicked on Jio Money Partner");
            Thread.sleep(AVG_WAIT_TIME);
            Select selectBusinessQwnership= new Select(selectBusinessOwnership);
            selectBusinessQwnership.selectByVisibleText("Individual");
            extent.log(LogStatus.INFO,"Selected INDIVIDUAL Option in dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(selectJioMoneyMerchant);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(jioMoneyPartnerContinueBtn);
            Thread.sleep(AVG_WAIT_TIME);
            Select selectBusinessTypes= new Select(selectBusinessType);
            selectBusinessTypes.selectByVisibleText("Online");
            extent.log(LogStatus.INFO,"Selected ONLINE Option in dropdown");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(BusinessChannelContinueBtn);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in Select JioMoney Partner: "+ex.getMessage());
        }

    }

    public void goToFAQSupportPage(){
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            jioMoneyIcon.click();
            extent.log(LogStatus.INFO,"Clicked on JioMoney Icon Page");
            Thread.sleep(AVG_WAIT_TIME);
            // faqSupport.click();
            clickElement(faqSupport);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in goToFAQSupportPage(): "+ex.getMessage());
        }

    }

    public void goToHierarchyAndComm(){
        try
        {
            driver.navigate().refresh();
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(jioMoneyIcon);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentServices);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(hierarchyAndComm);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in  goToHierarchyAndComm(): "+ex.getMessage());
        }
    }


    public void goToLoadOwnTradingBal() {
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(jioMoneyIcon);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(agentServices);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(loadOwnTradingbal);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in goToLoadOwnTradingBal(): "+ex.getMessage());
        }

    }

    public void goToTransactionHistory() {
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(jioMoneyIcon);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(reports);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(transactionHistory);
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in goToTransactionHistory(): "+ex.getMessage());
        }

    }






}
