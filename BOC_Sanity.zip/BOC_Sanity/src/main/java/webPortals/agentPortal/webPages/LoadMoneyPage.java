package webPortals.agentPortal.webPages;
/**
 * To Load Money into the Account
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilityLibrary.base.BaseClass;
import static utilityLibrary.testData.Constants.*;


import java.io.FileNotFoundException;

public class LoadMoneyPage extends BaseClass {

    public LoadMoneyPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//a[contains(@id,'pt1:cl9')]")
    public WebElement loadJioMoney;

    @FindBy(xpath = "//input[contains(@id,'it1::content')]")
    public WebElement enterMobile;

    @FindBy(xpath = "//input[@id='pt1:r2:1:it2::content']")
    public WebElement enterAmount;

    @FindBy(xpath = "//button[contains(@id,'cb122')]")
    public WebElement loadNow;

    @FindBy(xpath = "//button[contains(@id,'cb3')]")
    public WebElement confirmBtn;

    @FindBy(xpath = "//div[@class='af_message_detail']")
    public WebElement error_msg;
    //The amount entered should be between Rs. 1 and Account balance

    @FindBy(xpath = "//span[@id='pt1:pt-aot1']")
    public WebElement totalBal;

    @FindBy(xpath = "//button[@id='pt1:r2:1:goButton1']")
    public WebElement okBtn;

    @FindBy(xpath = "//button[@id='pt1:r2:1:pt_cl7']")
    public WebElement errorOkBtn;

    @FindBy(xpath = "//div[contains(text(),'You do not have sufficient balance in your JioMoney a/c to complete the transaction. Please recharge or enter a lower amount.')]")
    public WebElement errormsgForSameAmt;




    @FindBy(xpath = "//span[@class='tsuccess mtb10']")
    public WebElement succeessMsg;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    public void loadMoney(String mobile, String amt){
        try
        {
            clickElement(jioMoneyIcon);
            extent.log(LogStatus.INFO,"Clicked on Jio Money Icon");
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(loadJioMoney);
            Thread.sleep(AVG_WAIT_TIME);
            enterMobile.sendKeys(mobile);
            extent.log(LogStatus.INFO,"Entered Mobile number in Field");
            Thread.sleep(AVG_WAIT_TIME);
            // enterAmount.sendKeys(amt);
            JavascriptExecutor myExecutor1 = ((JavascriptExecutor) driver);
            myExecutor1.executeScript("arguments[0].value='"+amt+"';", enterAmount);
            extent.log(LogStatus.INFO,"Entered Amount in Field");
            Thread.sleep(AVG_WAIT_TIME);
            loadNow.click();
            extent.log(LogStatus.INFO,"Clicked on Load now");
            Thread.sleep(AVG_WAIT_TIME);
            String totalBalance =getTextfromElement(totalBal);
            String[] amount=totalBalance.split("\\.");
            totalBalance=amount[0];
            LogManager.getLogger(LoadMoneyPage.class).info("Total bal in string "+totalBalance);
            int tbal= Integer.parseInt(totalBalance);
            LogManager.getLogger(LoadMoneyPage.class).info("Total bal in int ="+tbal);
            int enterAmt=Integer.parseInt(amt);
            LogManager.getLogger(LoadMoneyPage.class).info("Total bal in int ="+enterAmt);
            if(tbal<enterAmt) {
                String lowBal = getTextfromElement(error_msg);
                LogManager.getLogger(LoadMoneyPage.class).info("lowBal msg ==========="+lowBal);
                if (lowBal.equalsIgnoreCase("The amount entered should be between Rs. 1 and Account balance")) {
                    LogManager.getLogger(LoadMoneyPage.class).info("Low balance");
                }
            }
            else if(enterAmt==tbal)
            {
                LogManager.getLogger(LoadMoneyPage.class).info("**********************In same  rs scenario *************************************");
                clickElement(confirmBtn);
                extent.log(LogStatus.INFO,"Clicked on confirm button");
                Thread.sleep(AVG_WAIT_TIME);
                String error = getTextfromElement(errormsgForSameAmt);
                LogManager.getLogger(LoadMoneyPage.class).info("lowBal msg ==========="+error);
                if (error.equalsIgnoreCase("You do not have sufficient balance in your JioMoney a/c to complete the transaction. Please recharge or enter a lower amount.")) {
                    LogManager.getLogger(LoadMoneyPage.class).info("same balance");
                    //this.takeSnapShot(driver, "c://test.png") ;
                    // CommonUtils.takeSnapShot(WebDriver:driver, "C:\\Users\\Dikshita.Shetty\\Desktop\\dikkkk");
               /* String nameofCurrMethod = new Throwable()
                        .getStackTrace()[0]
                        .getMethodName();
                CommonUtils.takeSnapShot(driver, nameofCurrMethod);*/
                    errorOkBtn.click();
                    extent.log(LogStatus.INFO,"Clicked on OK button");
                    Thread.sleep(AVG_WAIT_TIME);
                }
            }
            else
            {
                LogManager.getLogger(LoadMoneyPage.class).info("in else");
                clickElement(confirmBtn);
                extent.log(LogStatus.INFO,"Clicked on confirm button");
                Actualtext=getTextfromElement(succeessMsg);
                softAssert.assertEquals(Actualtext,"Successful");
                clickElement(okBtn);
                extent.log(LogStatus.INFO,"Clicked on OK button");
            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in loadMoney(String mobile, String amt): "+ex.getMessage());
        }

    }
}
