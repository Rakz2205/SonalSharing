package webPortals.agentPortal.webPages;
/**
 * To perform operations on elements present on settings Page
 *
 * @author Sonal Salunkhe
 * @modified By Sneha Dasari
 */
import com.relevantcodes.extentreports.LogStatus;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilityLibrary.base.BaseClass;

import static com.utilities.webUtils.JavascriptExecutorUtility.clickOnElement;
import static utilityLibrary.testData.Constants.*;

import static utilityLibrary.utils.CommonUtils.isAlertPresent;


public class SettingPage extends BaseClass {
    public SettingPage()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//a[@id='pt1:setIconId']")
    public WebElement settingIcon;

    @FindBy(xpath = "//a[@id='pt1:pt_cl4']")
    public WebElement changePassword;

    @FindBy(xpath = "//a[@id='pt1:pt_cl1']")
    public WebElement downloadFtr;

    @FindBy(xpath = "//a[@id='pt1:pt_cl3']")
    public WebElement updateUserProfile;



    @FindBy(xpath = "//input[@id='pt1:r20:1:it2::content']")
    public WebElement oldPassword;

    @FindBy(xpath = "//input[@id='pt1:r20:1:it3::content']")
    public WebElement newPassword;

    @FindBy(xpath = "//input[@id='pt1:r20:1:it4::content']")
    public WebElement retypeNewPassword;

    @FindBy(xpath = "//button[@id='pt1:r20:1:cb1']")
    public WebElement continueBtn;

    @FindBy(xpath = "//button[@id='pt1:r20:1:cb2']")
    public WebElement confirmBtn;

    @FindBy(xpath = "//button[@id='pt1:r20:1:gb2']")
    public WebElement OKBtn;

    @FindBy(xpath = "//a[@id='pt1:pt-cb1']")
    public WebElement logout;

    @FindBy(xpath = "//span[@class='tc ttext mtb10']")
    public WebElement changePasswordConfirmationMessage;

    @FindBy(xpath = "//span[@class='tinfo mtb10']")
    public WebElement pwdChangedSuccessfulMessage;

    @FindBy(xpath = "//a[@id='r1:0:goLink2']")
    public WebElement forgetPassword; //input[@name='username']

    @FindBy(xpath = "//input[@name='username']")
    public WebElement fp_username;  //input[@name='action']

    @FindBy(xpath = "//input[@name='action']")
    public WebElement fp_continue;

    @FindBy(xpath = "//input[@name='action']")
    public WebElement fp_sendOTP;

    @FindBy(xpath = "//input[@name='otp']")
    public WebElement fp_enterOTP;

    @FindBy(xpath = "//input[contains(@id,':id1::content')]")
    public WebElement df_fromDate;

    @FindBy(xpath = "//input[contains(@id,':id2::content')]")
    public WebElement df_toDate;

    @FindBy(xpath = "//button[contains(@id,':cb5')]")
    public WebElement df_submit;

    @FindBy(xpath = "//a[contains(@id,':gl1')]")
    public WebElement df_linkForDownloadingFTR;

    @FindBy(xpath = "//button[contains(@id,':d1::ok')]")
    public WebElement df_OKButton;

    @FindBy(xpath = "//img[@id='pt1:pt-g178::icon']")
    public WebElement jioMoneyIcon;

    @FindBy(xpath = "//*[contains(text(), 'Error')]")
    public WebElement error;

    @FindBy(xpath = "//button[contains(@id,':pt_cl7')]")
    public WebElement errorOK;


    public void changePassword(String oldPwd, String newPwd,String retypePwd) {
        try
        {
            jioMoneyIcon.click();
            settingIcon.click();
            changePassword.click();
            Thread.sleep(AVG_WAIT_TIME);
            oldPassword.sendKeys(oldPwd);
            Thread.sleep(AVG_WAIT_TIME);
            newPassword.sendKeys(newPwd);
            Thread.sleep(5000);
            //retypeNewPassword.sendKeys(retypePwd);
            retypeNewPassword.click();
            Thread.sleep(AVG_WAIT_TIME);
            JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
            myExecutor.executeScript("arguments[0].value='"+retypePwd+"';", retypeNewPassword);
            Thread.sleep(5000);
            newPassword.click();
            Thread.sleep(AVG_WAIT_TIME);
            Actions action=new Actions(driver);
            action.doubleClick(continueBtn).build().perform();
            Thread.sleep(AVG_WAIT_TIME);
            Actualtext = changePasswordConfirmationMessage.getText();
            softAssert.assertEquals(Actualtext, "Do you want to continue changing password?");
            softAssert.assertAll();
            Thread.sleep(AVG_WAIT_TIME);
            confirmBtn.click();
            Actualtext = pwdChangedSuccessfulMessage.getText();
            LogManager.getLogger(SettingPage.class).info("==============="+Actualtext);
            softAssert.assertEquals(Actualtext, "Pasword Changed Successfully");
            softAssert.assertAll();
            // OKBtn.click();
            //((JavascriptExecutor) driver).executeScript("arguments[0].click();", OKBtn);
            clickOnElement(driver,OKBtn);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in changePassword(String oldPwd, String newPwd,String retypePwd): "+ex.getMessage());
        }

    }

    public void logout() {
        try
        {
            clickElement(settingIcon);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(logout);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in logout(): "+ex.getMessage());
        }

    }

    public void downloadFTR(String fDate, String tdate)
    {
        try
        {
            clickElement(jioMoneyIcon);
            Thread.sleep(5000);
            clickElement(settingIcon);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(downloadFtr);
            Thread.sleep(AVG_WAIT_TIME);
            df_fromDate.sendKeys(fDate);
            Thread.sleep(AVG_WAIT_TIME);
            df_toDate.sendKeys(tdate);
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(df_fromDate);
            Thread.sleep(MIN_WAIT_TIME);
            clickElement(df_submit);
            Thread.sleep(AVG_WAIT_TIME);
            if(isElementDisplayed(error))
            {
                clickElement(errorOK);
            }
            else {
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", df_linkForDownloadingFTR);
                clickOnElement(driver,df_linkForDownloadingFTR);
                Thread.sleep(7000);
                if (isAlertPresent()) {
                    Alert alert = driver.switchTo().alert();
                    alert.accept();

                }
                // df_OKButton.click();
                //((JavascriptExecutor) driver).executeScript("arguments[0].click();", df_OKButton);
                clickOnElement(driver,df_OKButton);
            }

        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in downloadFTR(String fDate, String tdate): "+ex.getMessage());
        }


    }

    public void goToUserProfilePage() {
        //settingIcon.click();
        try
        {
            Thread.sleep(AVG_WAIT_TIME);
            clickElement(updateUserProfile);
            extent.log(LogStatus.INFO,"Clicked on Update user profile");
            Thread.sleep(AVG_WAIT_TIME);
        }
        catch(Exception ex)
        {
            throw new RuntimeException("Error in goToUserProfilePage(): "+ex.getMessage());
        }

    }




}
